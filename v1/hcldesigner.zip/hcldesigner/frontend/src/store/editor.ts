// État de l'éditeur (canvas) : modèle courant, historique undo/redo, sélection,
// cache des schémas chargés, superpositions (plan, conformité, diagnostics).
import { create } from "zustand";
import { produce, type Draft } from "immer";
import type { Diagnostic, Project } from "@/types/model";
import type { SchemaBlock, Violation } from "@/types/api";

const HISTORY_MAX = 300;

export interface SchemaEntry {
  block?: SchemaBlock;
  defaults?: Record<string, unknown>;
  error?: string;
}

interface EditorState {
  model: Project | null;
  serverVersion: number;
  dirty: boolean;
  past: Project[];
  future: Project[];
  selection: string[];
  schemas: Record<string, SchemaEntry>;
  planByNode: Record<string, string>;
  violations: Violation[];
  diagnostics: Diagnostic[];
  readOnly: boolean;

  load: (model: Project, version: number, readOnly?: boolean) => void;
  /** Modifie le modèle ; chaque appel est une entrée d'historique. */
  update: (fn: (draft: Draft<Project>) => void) => void;
  undo: () => void;
  redo: () => void;
  markSaved: (version: number) => void;
  select: (ids: string[]) => void;
  setSchema: (key: string, entry: SchemaEntry) => void;
  setPlanOverlay: (byNode: Record<string, string>) => void;
  setViolations: (v: Violation[]) => void;
  setDiagnostics: (d: Diagnostic[]) => void;
}

export const useEditor = create<EditorState>((set, get) => ({
  model: null,
  serverVersion: 0,
  dirty: false,
  past: [],
  future: [],
  selection: [],
  schemas: {},
  planByNode: {},
  violations: [],
  diagnostics: [],
  readOnly: false,

  load: (model, version, readOnly = false) =>
    set({ model, serverVersion: version, dirty: false, past: [], future: [], selection: [], planByNode: {}, violations: [], diagnostics: [], readOnly }),

  update: (fn) => {
    const { model, past, readOnly } = get();
    if (!model || readOnly) return;
    const next = produce(model, fn);
    if (next === model) return;
    set({ model: next, past: [...past.slice(-HISTORY_MAX), model], future: [], dirty: true });
  },

  undo: () => {
    const { model, past, future } = get();
    if (!model || !past.length) return;
    set({ model: past[past.length - 1], past: past.slice(0, -1), future: [model, ...future], dirty: true });
  },

  redo: () => {
    const { model, past, future } = get();
    if (!model || !future.length) return;
    set({ model: future[0], future: future.slice(1), past: [...past, model], dirty: true });
  },

  markSaved: (version) => set({ serverVersion: version, dirty: false }),
  select: (ids) => set({ selection: ids }),
  setSchema: (key, entry) => set((s) => ({ schemas: { ...s.schemas, [key]: entry } })),
  setPlanOverlay: (planByNode) => set({ planByNode }),
  setViolations: (violations) => set({ violations }),
  setDiagnostics: (diagnostics) => set({ diagnostics }),
}));

/** Clé de cache d'un schéma. */
export const schemaKey = (source: string, version: string, kind: string, type: string) => `${source}@${version}|${kind}|${type}`;
