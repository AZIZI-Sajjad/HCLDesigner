// Canvas React Flow : affichage du modèle, drag & drop depuis le catalogue, liaisons,
// suppression, copier/coller, duplication, auto-layout, recherche, surlignage des dépendances.
import { useCallback, useEffect, useMemo, useRef, useState, type DragEvent } from "react";
import {
  Background,
  BackgroundVariant,
  Controls,
  MiniMap,
  ReactFlow,
  ReactFlowProvider,
  useNodesState,
  useReactFlow,
  type Connection,
  type Edge as RFEdge,
  type Node as RFNode,
  type NodeChange,
  type OnConnectStart,
} from "@xyflow/react";
import { LayoutGrid, Search } from "lucide-react";
import { current, type Draft } from "immer";
import { api } from "@/api/client";
import type { TfNode } from "@/types/model";
import { useEditor } from "@/store/editor";
import { deriveEdges, newId, nodeAddress, removeRefsTo, uniqueLabel, wouldCycle } from "@/lib/model";
import { missingRequired } from "@/lib/schema";
import { autoLayout } from "@/lib/layout";
import { loadSchema, nodeSchemaKey, providerFor } from "@/lib/useSchema";
import { Button, Input, toast } from "@/components/ui";
import { TfNodeCard, type TfNodeData } from "./TfNodeCard";
import ConnectionDialog, { endpointSpec } from "./ConnectionDialog";

const nodeTypes = { tf: TfNodeCard };

/** Données glissées depuis le catalogue. */
export interface DragItem {
  kind: TfNode["kind"];
  type: string;
  source?: string; // provider (ressources/data)
  module?: TfNode["module"];
  label?: string;
}

export const DRAG_MIME = "application/x-hcldesigner";

function CanvasInner() {
  const model = useEditor((s) => s.model)!;
  const update = useEditor((s) => s.update);
  const select = useEditor((s) => s.select);
  const selection = useEditor((s) => s.selection);
  const schemas = useEditor((s) => s.schemas);
  const planByNode = useEditor((s) => s.planByNode);
  const violations = useEditor((s) => s.violations);
  const diagnostics = useEditor((s) => s.diagnostics);
  const readOnly = useEditor((s) => s.readOnly);
  const rf = useReactFlow();
  const wrapper = useRef<HTMLDivElement>(null);
  const [pending, setPending] = useState<{ source: string; target: string } | null>(null);
  const [compatible, setCompatible] = useState<Set<string> | null>(null);
  const [hovered, setHovered] = useState<string | null>(null);
  const [search, setSearch] = useState("");
  const clipboard = useRef<TfNode[]>([]);

  // Chargement des schémas de tous les nœuds (badges "requis manquants", attributs exportés).
  useEffect(() => {
    for (const n of model.nodes) {
      if (n.kind !== "resource" && n.kind !== "data") continue;
      const pc = providerFor(model, n);
      if (pc) void loadSchema(pc.source, pc.resolved, n.kind, n.type);
    }
  }, [model]);

  const edges = useMemo(() => deriveEdges(model), [model]);

  // Chaîne de dépendances (amont + aval) du nœud survolé ou sélectionné.
  const focus = hovered ?? (selection.length === 1 ? selection[0] : null);
  const related = useMemo(() => {
    if (!focus) return null;
    const set = new Set([focus]);
    const walk = (dir: "up" | "down") => {
      const queue = [focus];
      while (queue.length) {
        const cur = queue.shift()!;
        for (const e of edges) {
          const next = dir === "up" ? (e.target === cur ? e.source : null) : e.source === cur ? e.target : null;
          if (next && !set.has(next)) {
            set.add(next);
            queue.push(next);
          }
        }
      }
    };
    walk("up");
    walk("down");
    return set;
  }, [focus, edges]);

  const flowNodes = useMemo<RFNode<TfNodeData>[]>(
    () =>
      model.nodes.map((n) => {
        const key = nodeSchemaKey(model, n);
        return {
          id: n.id,
          type: "tf",
          position: n.position,
          selected: selection.includes(n.id),
          data: {
            node: n,
            missing: missingRequired(n, key ? schemas[key]?.block : undefined).length,
            errors: diagnostics.filter((d) => d.nodeId === n.id && d.severity === "error").length,
            violations: violations.filter((v) => v.nodeId === n.id).length,
            plan: planByNode[n.id],
            compatible: compatible?.has(n.id),
            dimmed: !!related && !related.has(n.id),
          },
        };
      }),
    [model, schemas, selection, diagnostics, violations, planByNode, compatible, related],
  );

  // Positions locales pendant le glisser ; le modèle n'est mis à jour qu'au relâchement.
  const [nodes, setNodes, onNodesChangeBase] = useNodesState<RFNode<TfNodeData>>(flowNodes);
  // Fusion avec l'état React Flow existant : conserver les dimensions mesurées évite de perdre
  // les positions des poignées (et donc la liaison en cours) à chaque nouveau rendu.
  useEffect(
    () =>
      setNodes((prev) => {
        const byId = new Map(prev.map((n) => [n.id, n]));
        return flowNodes.map((n) => {
          const old = byId.get(n.id);
          return old ? { ...old, ...n, measured: old.measured, dragging: old.dragging } : n;
        });
      }),
    [flowNodes, setNodes],
  );

  const flowEdges = useMemo<RFEdge[]>(() => {
    const seen = new Map<string, RFEdge>();
    for (const e of edges) {
      const id = `${e.source}->${e.target}:${e.targetPath}`;
      const dim = related && !(related.has(e.source) && related.has(e.target));
      seen.set(id, {
        id,
        source: e.source,
        target: e.target,
        label: e.kind === "depends_on" ? "depends_on" : e.targetPath.replace(/\[\d+\]/g, ""),
        animated: e.kind === "depends_on",
        // depends_on : tirets animés ; expr (adresse citée dans une expression) : pointillés
        style: { strokeDasharray: e.kind === "depends_on" ? "5 4" : e.kind === "expr" ? "2 3" : undefined, opacity: dim ? 0.2 : 1 },
        labelStyle: { fontSize: 10 },
        data: { targetPath: e.targetPath, kind: e.kind },
      });
    }
    return [...seen.values()];
  }, [edges, related]);

  const onNodesChange = useCallback(
    (changes: NodeChange<RFNode<TfNodeData>>[]) => onNodesChangeBase(changes.filter((c) => c.type !== "remove")),
    [onNodesChangeBase],
  );

  const commitPositions = useCallback(
    (moved: RFNode[]) =>
      update((d) => {
        for (const m of moved) {
          const n = d.nodes.find((x) => x.id === m.id);
          if (n) n.position = { x: Math.round(m.position.x), y: Math.round(m.position.y) };
        }
      }),
    [update],
  );

  const deleteNodes = useCallback(
    (ids: string[]) => {
      if (!ids.length || readOnly) return;
      update((d) => {
        d.nodes = d.nodes.filter((n) => !ids.includes(n.id)) as Draft<TfNode>[];
        d.nodes = d.nodes.map((n) => ids.reduce((acc, id) => removeRefsTo(acc, id), current(n) as TfNode)) as Draft<TfNode>[];
      });
      select([]);
    },
    [update, select, readOnly],
  );

  const onConnect = useCallback(
    (c: Connection) => {
      setCompatible(null);
      if (readOnly || !c.source || !c.target) return;
      if (wouldCycle(model, c.source, c.target)) {
        toast.error("Cette liaison créerait un cycle de dépendances.");
        return;
      }
      setPending({ source: c.source, target: c.target });
    },
    [model, readOnly],
  );

  // Surlignage des cibles compatibles pendant le drag d'un lien
  const onConnectStart: OnConnectStart = useCallback(
    (_e, params) => {
      const src = model.nodes.find((n) => n.id === params.nodeId);
      if (!src || params.handleType !== "source") return;
      const targets = model.nodes.filter((n) => n.id !== src.id && n.kind !== "variable").map(endpointSpec);
      api
        .post<{ compatible: string[] }>("/connections/compatible", { providers: model.providers, source: endpointSpec(src), targets })
        .then((r) => setCompatible(new Set(r.compatible)))
        .catch(() => undefined);
    },
    [model],
  );

  const onDrop = useCallback(
    (e: DragEvent) => {
      e.preventDefault();
      if (readOnly) return;
      const raw = e.dataTransfer.getData(DRAG_MIME);
      if (!raw) return;
      const item = JSON.parse(raw) as DragItem;
      const position = rf.screenToFlowPosition({ x: e.clientX, y: e.clientY });
      addNode(item, position);
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [rf, readOnly, model],
  );

  const addNode = (item: DragItem, position: { x: number; y: number }) => {
    const id = newId();
    update((d) => {
      const base = item.label ?? (item.kind === "resource" || item.kind === "data" ? item.type.split("_").slice(-1)[0] : item.kind === "module" ? item.module?.name ?? "module" : item.kind);
      const provider = item.source ? d.providers.find((p) => p.source === item.source && p.localName !== item.type.split("_")[0]) : undefined;
      d.nodes.push({
        id,
        kind: item.kind,
        type: item.type,
        label: uniqueLabel(d as never, item.kind, item.type, base),
        provider: provider ? (provider.alias ? `${provider.localName}.${provider.alias}` : provider.localName) : undefined,
        attrs: item.kind === "output" || item.kind === "local" ? {} : {},
        meta: {},
        position: { x: Math.round(position.x), y: Math.round(position.y) },
        module: item.module,
      } as Draft<TfNode>);
    });
    select([id]);
  };

  // Raccourcis : suppression, copier/coller, duplication
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const tag = (e.target as HTMLElement)?.tagName;
      if (tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT" || (e.target as HTMLElement)?.isContentEditable) return;
      const mod = e.ctrlKey || e.metaKey;
      if ((e.key === "Delete" || e.key === "Backspace") && selection.length) {
        e.preventDefault();
        deleteNodes(selection);
      } else if (mod && e.key === "c" && selection.length) {
        clipboard.current = model.nodes.filter((n) => selection.includes(n.id));
      } else if (mod && (e.key === "v" || e.key === "d")) {
        const src = e.key === "d" ? model.nodes.filter((n) => selection.includes(n.id)) : clipboard.current;
        if (!src.length || readOnly) return;
        e.preventDefault();
        pasteNodes(src);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  });

  /** Colle des nœuds avec de nouveaux ids et labels ; les références internes à la sélection suivent. */
  const pasteNodes = (src: TfNode[]) => {
    const idMap = new Map(src.map((n) => [n.id, newId()]));
    update((d) => {
      for (const n of src) {
        const copy: TfNode = JSON.parse(JSON.stringify(n).replace(/"node":"([^"]+)"/g, (m, id) => (idMap.has(id) ? `"node":"${idMap.get(id)}"` : m)));
        copy.id = idMap.get(n.id)!;
        copy.label = uniqueLabel(d as never, n.kind, n.type, n.label);
        copy.position = { x: n.position.x + 40, y: n.position.y + 40 };
        copy.meta.dependsOn = (copy.meta.dependsOn ?? []).map((x) => idMap.get(x) ?? x);
        delete copy.importId;
        delete copy.movedFrom;
        d.nodes.push(copy as Draft<TfNode>);
      }
    });
    select([...idMap.values()]);
  };

  const runLayout = async () => {
    const pos = await autoLayout(model);
    update((d) => {
      for (const n of d.nodes) if (pos[n.id]) n.position = pos[n.id];
    });
    setTimeout(() => rf.fitView({ padding: 0.15, duration: 300 }), 50);
  };

  const find = () => {
    const q = search.toLowerCase();
    const n = model.nodes.find((x) => nodeAddress(x).toLowerCase().includes(q));
    if (!n) return toast.info("Aucun objet ne correspond.");
    select([n.id]);
    rf.setCenter(n.position.x + 112, n.position.y + 36, { zoom: 1.2, duration: 400 });
  };

  return (
    <div ref={wrapper} className="relative h-full w-full" onDragOver={(e) => (e.preventDefault(), (e.dataTransfer.dropEffect = "copy"))} onDrop={onDrop}>
      <ReactFlow
        nodes={nodes}
        edges={flowEdges}
        nodeTypes={nodeTypes}
        onNodesChange={onNodesChange}
        onNodeDragStop={(_e, _n, moved) => commitPositions(moved)}
        onSelectionChange={({ nodes: sel }) => {
          const ids = sel.map((n) => n.id);
          if (ids.join() !== selection.join()) select(ids);
        }}
        onConnect={onConnect}
        onConnectStart={onConnectStart}
        onConnectEnd={() => setTimeout(() => setCompatible(null), 100)}
        onEdgesDelete={(eds) =>
          !readOnly &&
          update((d) => {
            for (const e of eds) {
              const i = d.nodes.findIndex((n) => n.id === e.target);
              if (i >= 0) d.nodes[i] = removeRefsTo(current(d.nodes[i]) as TfNode, e.source, (e.data as { targetPath?: string })?.targetPath) as Draft<TfNode>;
            }
          })
        }
        onNodeMouseEnter={(_e, n) => setHovered(n.id)}
        onNodeMouseLeave={() => setHovered(null)}
        deleteKeyCode={null}
        nodesDraggable={!readOnly}
        nodesConnectable={!readOnly}
        snapToGrid
        snapGrid={[16, 16]}
        fitView
        fitViewOptions={{ maxZoom: 1, padding: 0.2 }}
        minZoom={0.1}
        proOptions={{ hideAttribution: true }}
        multiSelectionKeyCode={["Shift", "Meta", "Control"]}
      >
        <Background variant={BackgroundVariant.Dots} gap={16} size={1} />
        <Controls />
        <MiniMap pannable zoomable nodeStrokeWidth={3} />
      </ReactFlow>
      <div className="absolute left-3 top-3 flex items-center gap-2">
        <div className="flex items-center gap-1 rounded-md bg-white/90 p-1 shadow dark:bg-slate-900/90">
          <Input className="h-7 w-48 text-xs" placeholder="Chercher un objet…" value={search} onChange={(e) => setSearch(e.target.value)} onKeyDown={(e) => e.key === "Enter" && find()} />
          <Button size="sm" icon={<Search className="h-3.5 w-3.5" />} onClick={find} />
        </div>
        {!readOnly && (
          <Button size="sm" icon={<LayoutGrid className="h-3.5 w-3.5" />} onClick={runLayout}>
            Disposition auto
          </Button>
        )}
      </div>
      {model.nodes.length === 0 && (
        <div className="pointer-events-none absolute inset-0 flex items-center justify-center text-sm text-slate-400">
          Glissez des objets depuis le catalogue pour commencer.
        </div>
      )}
      {pending && <ConnectionDialog sourceId={pending.source} targetId={pending.target} onClose={() => setPending(null)} />}
    </div>
  );
}

export default function Canvas() {
  return (
    <ReactFlowProvider>
      <CanvasInner />
    </ReactFlowProvider>
  );
}
