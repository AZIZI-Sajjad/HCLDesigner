// Lancement d'une exécution : init, validate, plan, plan -destroy, avec options (-target, -replace...).
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { api } from "@/api/client";
import type { Environment, Run } from "@/types/api";
import { useCan } from "@/lib/auth";
import { Button, ConfirmDialog, ErrorBox, Field, Input, Modal, Select, Textarea, Toggle } from "@/components/ui";

type Op = "init" | "validate" | "plan" | "destroy";

export default function RunLauncher({ projectId, projectName, environments, onClose }: { projectId: string; projectName: string; environments: Environment[]; onClose: () => void }) {
  const navigate = useNavigate();
  const can = useCan();
  const [envId, setEnvId] = useState(environments[0]?.id ?? "");
  const [op, setOp] = useState<Op>("plan");
  const [targets, setTargets] = useState("");
  const [replace, setReplace] = useState("");
  const [refreshOnly, setRefreshOnly] = useState(false);
  const [upgrade, setUpgrade] = useState(false);
  const [parallelism, setParallelism] = useState("");
  const [error, setError] = useState<unknown>(null);
  const [loading, setLoading] = useState(false);
  const [confirm, setConfirm] = useState(false);
  const env = environments.find((e) => e.id === envId);

  const perm = { init: "runs.init", validate: "runs.init", plan: "runs.plan", destroy: "runs.destroy" }[op];
  const allowed = env ? can(perm, projectId, env.name) : false;
  const lines = (s: string) => s.split("\n").map((l) => l.trim()).filter(Boolean);

  const launch = async () => {
    setLoading(true);
    setError(null);
    try {
      const run = await api.post<Run>(`/projects/${projectId}/runs`, {
        environmentId: envId,
        operation: op === "destroy" ? "plan" : op,
        destroy: op === "destroy",
        options: { targets: lines(targets), replace: lines(replace), refreshOnly, upgrade, parallelism: Number(parallelism) || 0 },
      });
      navigate(`/runs/${run.id}`);
    } catch (e) {
      setError(e);
      setConfirm(false);
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <Modal
        open
        onClose={onClose}
        title="Nouvelle exécution"
        footer={
          <>
            <Button onClick={onClose}>Annuler</Button>
            <Button variant={op === "destroy" ? "danger" : "primary"} disabled={!allowed} loading={loading} onClick={() => (op === "destroy" ? setConfirm(true) : void launch())}>
              Lancer
            </Button>
          </>
        }
      >
        <div className="space-y-3">
          <ErrorBox error={error} />
          <Field label="Environnement">
            <Select value={envId} onChange={(e) => setEnvId(e.target.value)}>
              {environments.map((e) => (
                <option key={e.id} value={e.id}>
                  {e.name} — backend {e.backendType}
                  {e.protected ? " (protégé)" : ""}
                </option>
              ))}
            </Select>
          </Field>
          <Field label="Opération">
            <Select value={op} onChange={(e) => setOp(e.target.value as Op)}>
              <option value="init">init (test du backend et des providers)</option>
              <option value="validate">validate</option>
              <option value="plan">plan</option>
              <option value="destroy" disabled={env && !env.allowDestroy}>
                plan -destroy{env && !env.allowDestroy ? " (désactivé sur cet environnement)" : ""}
              </option>
            </Select>
          </Field>
          {!allowed && <p className="text-xs text-rose-600">Vous n'avez pas la permission {perm} sur cet environnement.</p>}
          {(op === "plan" || op === "destroy") && (
            <details className="rounded border border-slate-200 p-2 text-sm dark:border-slate-700">
              <summary className="cursor-pointer text-xs font-medium">Options avancées</summary>
              <div className="mt-2 space-y-2">
                <Field label="-target (une adresse par ligne)">
                  <Textarea rows={2} value={targets} onChange={(e) => setTargets(e.target.value)} />
                </Field>
                <Field label="-replace (une adresse par ligne)">
                  <Textarea rows={2} value={replace} onChange={(e) => setReplace(e.target.value)} />
                </Field>
                <Field label="-parallelism">
                  <Input type="number" value={parallelism} onChange={(e) => setParallelism(e.target.value)} placeholder="défaut des paramètres" />
                </Field>
                <Toggle checked={refreshOnly} onChange={setRefreshOnly} label="-refresh-only" />
                <Toggle checked={upgrade} onChange={setUpgrade} label="init -upgrade (mettre à jour providers et modules)" />
              </div>
            </details>
          )}
          {op === "plan" && env && env.requireApprovals > 0 && <p className="text-xs text-slate-500">Cet environnement exige {env.requireApprovals} approbation(s) avant l'apply.</p>}
        </div>
      </Modal>
      <ConfirmDialog
        open={confirm}
        danger
        onClose={() => setConfirm(false)}
        onConfirm={launch}
        loading={loading}
        title="Planifier une destruction"
        confirmText="Lancer le plan -destroy"
        message={<>Le plan listera toutes les ressources de l'environnement <b>{env?.name}</b> à détruire. Rien n'est détruit avant l'apply du plan.</>}
        typeToConfirm={`${projectName}/${env?.name}`}
      />
    </>
  );
}
