// Transformation de la sélection en module interne v1.0.0, réutilisé dans le projet.
import { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { api } from "@/api/client";
import type { Project } from "@/types/model";
import { nodeAddress } from "@/lib/model";
import { useEditor } from "@/store/editor";
import { Button, ErrorBox, Field, Input, Modal, toast } from "@/components/ui";

export default function ExtractModuleDialog({ projectId, onClose }: { projectId: string; onClose: () => void }) {
  const { model, selection, serverVersion, load } = useEditor();
  const qc = useQueryClient();
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [error, setError] = useState<unknown>(null);
  const [loading, setLoading] = useState(false);
  const nodes = model!.nodes.filter((n) => selection.includes(n.id));

  const submit = async () => {
    setLoading(true);
    setError(null);
    try {
      const r = await api.post<{ moduleId: string; model: Project; version: number; warnings: string[] | null }>(`/projects/${projectId}/extract-module`, {
        model,
        version: serverVersion,
        nodeIds: selection,
        name,
        description,
      });
      load(r.model, r.version);
      void qc.invalidateQueries({ queryKey: ["project", projectId] });
      void qc.invalidateQueries({ queryKey: ["modules"] });
      toast.success(`Module « ${name} » v1.0.0 créé et utilisé dans le projet (version ${r.version}).`);
      (r.warnings ?? []).forEach((w) => toast.info(w));
      onClose();
    } catch (e) {
      setError(e);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Modal
      open
      onClose={onClose}
      title="Extraire la sélection en module"
      footer={
        <>
          <Button onClick={onClose}>Annuler</Button>
          <Button variant="primary" loading={loading} disabled={!/^[a-zA-Z_][a-zA-Z0-9_-]*$/.test(name)} onClick={submit}>
            Créer le module
          </Button>
        </>
      }
    >
      <div className="space-y-3 text-sm">
        <p>
          Les références sortant de la sélection deviennent des <b>variables</b> du module, celles qui y entrent deviennent des <b>outputs</b>. La sélection est
          remplacée par un nœud module ; le projet est enregistré dans une nouvelle version.
        </p>
        <ul className="max-h-40 overflow-y-auto rounded bg-slate-100 p-2 font-mono text-xs dark:bg-slate-800">
          {nodes.map((n) => (
            <li key={n.id}>{nodeAddress(n)}</li>
          ))}
        </ul>
        <ErrorBox error={error} />
        <Field label="Nom du module" required help="Lettres, chiffres, _ et -. Généré dans modules/<nom>/.">
          <Input autoFocus value={name} onChange={(e) => setName(e.target.value)} placeholder="network" />
        </Field>
        <Field label="Description">
          <Input value={description} onChange={(e) => setDescription(e.target.value)} />
        </Field>
      </div>
    </Modal>
  );
}
