// Panneau de propriétés du nœud sélectionné : identité (label, provider, fichier, groupe),
// formulaire dynamique issu du schéma, méta-arguments, champs spécifiques variable/output/local/module.
import { useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Plus, Trash2 } from "lucide-react";
import type { Draft } from "immer";
import { api } from "@/api/client";
import type { ModuleRow, SchemaAttribute } from "@/types/api";
import type { Block, Condition, Project, TfNode, Value } from "@/types/model";
import { useEditor } from "@/store/editor";
import { useNodeSchema } from "@/lib/useSchema";
import { LABEL_RE, newId, nodeAddress, uniqueLabel } from "@/lib/model";
import { isEmptyValue, missingRequired } from "@/lib/schema";
import { Badge, Button, Field, IconButton, Input, Select, Textarea, Toggle } from "@/components/ui";
import { SchemaForm } from "./SchemaForm";
import { ValueInput, variableTypeFor } from "./ValueInput";

export default function PropertiesPanel() {
  const model = useEditor((s) => s.model)!;
  const selection = useEditor((s) => s.selection);
  const update = useEditor((s) => s.update);
  const readOnly = useEditor((s) => s.readOnly);
  const violations = useEditor((s) => s.violations);
  const diagnostics = useEditor((s) => s.diagnostics);
  const node = selection.length === 1 ? model.nodes.find((n) => n.id === selection[0]) : undefined;
  const schema = useNodeSchema(model, node);

  if (!node) {
    return (
      <div className="p-4 text-sm text-slate-500">
        {selection.length > 1 ? `${selection.length} objets sélectionnés.` : "Sélectionnez un objet du canvas pour afficher ses propriétés."}
      </div>
    );
  }

  /** Modifie le nœud courant dans le modèle (une entrée d'historique). */
  const edit = (fn: (n: Draft<TfNode>) => void) =>
    update((d) => {
      const n = d.nodes.find((x) => x.id === node.id);
      if (n) fn(n);
    });
  const setAttr = (name: string, v: Value | undefined) =>
    edit((n) => {
      if (v === undefined) delete n.attrs[name];
      else n.attrs[name] = v as Draft<Value>;
    });

  /** Extraire en variable : variable typée, valeur actuelle en défaut, attribut relié à la variable. */
  const extract = (name: string, a: SchemaAttribute) =>
    update((d) => {
      const n = d.nodes.find((x) => x.id === node.id)!;
      const label = uniqueLabel(d as Project, "variable", "", `${n.label}_${name}`);
      const id = newId();
      const current = n.attrs[name];
      const attrs: Record<string, Value> = { type: { mode: "literal", value: variableTypeFor(a.type) }, description: { mode: "literal", value: `${nodeAddress(n as TfNode)}.${name}` } };
      if (current?.mode === "literal") attrs.default = current as Value;
      if (a.sensitive) attrs.sensitive = { mode: "literal", value: true };
      d.nodes.push({ id, kind: "variable", type: "", label, attrs, meta: {}, position: { x: n.position.x - 320, y: n.position.y } } as Draft<TfNode>);
      n.attrs[name] = { mode: "ref", ref: { node: id, attr: "" } };
    });

  const labelTaken = model.nodes.some((n) => n.id !== node.id && n.kind === node.kind && n.label === node.label && (node.kind !== "resource" && node.kind !== "data" ? true : n.type === node.type));
  const nodeViolations = violations.filter((v) => v.nodeId === node.id);
  const nodeDiags = diagnostics.filter((d) => d.nodeId === node.id);
  const missing = missingRequired(node, schema?.block);

  return (
    <div className="space-y-4 p-3 text-sm">
      <div>
        <div className="flex items-center gap-2">
          <Badge tone="indigo">{node.kind}</Badge>
          <span className="truncate font-mono text-xs text-slate-500">{node.type || node.module?.source || ""}</span>
        </div>
        <p className="mt-1 font-mono text-xs">{nodeAddress(node)}</p>
      </div>

      {(nodeDiags.length > 0 || nodeViolations.length > 0 || missing.length > 0) && (
        <div className="space-y-1">
          {missing.length > 0 && <div className="rounded bg-rose-50 p-2 text-xs text-rose-800 dark:bg-rose-950 dark:text-rose-200">Obligatoires manquants : {missing.join(", ")}</div>}
          {nodeDiags.map((d, i) => (
            <div key={i} className="rounded bg-rose-50 p-2 text-xs text-rose-800 dark:bg-rose-950 dark:text-rose-200">
              {d.summary} {d.detail && <span className="opacity-80">— {d.detail}</span>}
            </div>
          ))}
          {nodeViolations.map((v, i) => (
            <div key={i} className="rounded bg-amber-50 p-2 text-xs text-amber-900 dark:bg-amber-950 dark:text-amber-200">
              [{v.severity}] {v.policy} : {v.message}
            </div>
          ))}
        </div>
      )}

      <Field label="Nom logique (label HCL)" help={labelTaken ? "Ce nom est déjà utilisé." : !LABEL_RE.test(node.label) ? "Lettres, chiffres, _ et -, sans commencer par un chiffre." : undefined}>
        <Input value={node.label} disabled={readOnly} onChange={(e) => edit((n) => void (n.label = e.target.value))} />
      </Field>

      {(node.kind === "resource" || node.kind === "data" || node.kind === "module") && <ProviderSelect node={node} model={model} disabled={readOnly} onChange={(p) => edit((n) => void (n.provider = p || undefined))} />}

      {model.fileLayout.mode === "custom" && node.kind !== "variable" && node.kind !== "output" && (
        <Field label="Fichier cible">
          <Select value={node.file ?? ""} disabled={readOnly} onChange={(e) => edit((n) => void (n.file = e.target.value || undefined))}>
            <option value="">main.tf (défaut)</option>
            {model.fileLayout.customFiles.map((f) => (
              <option key={f} value={f}>
                {f}
              </option>
            ))}
          </Select>
        </Field>
      )}
      <Field label="Groupe visuel" help="Regroupement d'affichage, sans effet sur le code.">
        <Input value={node.group ?? ""} disabled={readOnly} onChange={(e) => edit((n) => void (n.group = e.target.value || undefined))} />
      </Field>

      <hr className="border-slate-200 dark:border-slate-800" />

      {(node.kind === "resource" || node.kind === "data") &&
        (schema?.block ? (
          <SchemaForm
            block={schema.block}
            attrs={node.attrs}
            blocks={node.blocks}
            defaults={schema.defaults}
            onAttr={setAttr}
            onBlocks={(name, list) => edit((n) => void ((n.blocks ??= {})[name] = list as Draft<Block>[]))}
            model={model}
            selfId={node.id}
            onExtract={extract}
            disabled={readOnly}
          />
        ) : schema?.error ? (
          <p className="text-xs text-rose-600">Schéma indisponible : {schema.error}</p>
        ) : (
          <p className="text-xs text-slate-500">Chargement du schéma…</p>
        ))}
      {node.kind === "variable" && <VariableForm node={node} model={model} setAttr={setAttr} edit={edit} disabled={readOnly} />}
      {node.kind === "output" && <OutputForm node={node} model={model} setAttr={setAttr} disabled={readOnly} />}
      {node.kind === "local" && (
        <Field label="Valeur" required>
          <ValueInput value={node.attrs.value} onChange={(v) => setAttr("value", v)} type="dynamic" model={model} selfId={node.id} disabled={readOnly} />
        </Field>
      )}
      {node.kind === "module" && <ModuleForm node={node} model={model} setAttr={setAttr} edit={edit} disabled={readOnly} />}

      {(node.kind === "resource" || node.kind === "data" || node.kind === "module") && <MetaEditor node={node} model={model} edit={edit} disabled={readOnly} />}
    </div>
  );
}

function ProviderSelect({ node, model, onChange, disabled }: { node: TfNode; model: Project; onChange: (p: string) => void; disabled?: boolean }) {
  const prefix = node.type.split("_")[0];
  const options = model.providers.filter((p) => node.kind === "module" || p.localName === prefix);
  if (options.length <= 1 && node.kind !== "module") return null;
  return (
    <Field label={node.kind === "module" ? "Provider transmis (alias)" : "Provider (alias)"}>
      <Select value={node.provider ?? ""} disabled={disabled} onChange={(e) => onChange(e.target.value)}>
        <option value="">par défaut</option>
        {options
          .filter((p) => p.alias)
          .map((p) => (
            <option key={p.alias} value={`${p.localName}.${p.alias}`}>
              {p.localName}.{p.alias}
            </option>
          ))}
      </Select>
    </Field>
  );
}

type EditFn = (fn: (n: Draft<TfNode>) => void) => void;

const primitiveTypes = ["string", "number", "bool", "list(string)", "list(number)", "set(string)", "map(string)", "map(number)", "any"];

function VariableForm({ node, model, setAttr, edit, disabled }: { node: TfNode; model: Project; setAttr: (n: string, v: Value | undefined) => void; edit: EditFn; disabled?: boolean }) {
  const typeText = node.attrs.type?.mode === "literal" ? String(node.attrs.type.value ?? "") : node.attrs.type?.expr ?? "";
  const isPrimitive = primitiveTypes.includes(typeText);
  const validations = node.blocks?.validation ?? [];
  const str = (v?: Value) => (v?.mode === "literal" ? String(v.value ?? "") : "");
  return (
    <div className="space-y-3">
      <Field label="Type" help="Constructeur : choisir un type simple, ou « complexe » pour saisir object({...}), tuple, etc.">
        <div className="flex gap-1">
          <Select
            value={isPrimitive ? typeText : "__complex"}
            disabled={disabled}
            onChange={(e) => setAttr("type", e.target.value === "__complex" ? { mode: "literal", value: "object({})" } : { mode: "literal", value: e.target.value })}
          >
            <option value="">(non typé)</option>
            {primitiveTypes.map((t) => (
              <option key={t}>{t}</option>
            ))}
            <option value="__complex">complexe…</option>
          </Select>
        </div>
        {!isPrimitive && typeText !== "" && (
          <Textarea rows={3} value={typeText} disabled={disabled} onChange={(e) => setAttr("type", { mode: "literal", value: e.target.value })} placeholder="object({ name = string, size = optional(number, 10) })" />
        )}
      </Field>
      <Field label="Valeur par défaut" help="Vide = variable obligatoire.">
        <ValueInput value={node.attrs.default} onChange={(v) => setAttr("default", v)} type={isPrimitive && typeText !== "any" ? typeText : "dynamic"} model={model} selfId={node.id} disabled={disabled} />
      </Field>
      <Field label="Description">
        <Input value={str(node.attrs.description)} disabled={disabled} onChange={(e) => setAttr("description", e.target.value ? { mode: "literal", value: e.target.value } : undefined)} />
      </Field>
      <div className="flex gap-4">
        <Toggle checked={node.attrs.sensitive?.value === true} disabled={disabled} onChange={(v) => setAttr("sensitive", v ? { mode: "literal", value: true } : undefined)} label="Sensible" />
        <Toggle checked={node.attrs.nullable?.value !== false} disabled={disabled} onChange={(v) => setAttr("nullable", v ? undefined : { mode: "literal", value: false })} label="Nullable" />
      </div>
      <Field label="Validations">
        <div className="space-y-2">
          {validations.map((b, i) => (
            <div key={i} className="space-y-1 rounded border border-slate-200 p-2 dark:border-slate-700">
              <Input
                placeholder="condition, ex. length(var.x) > 3"
                value={b.attrs.condition?.expr ?? ""}
                disabled={disabled}
                onChange={(e) => edit((n) => void (n.blocks!.validation[i].attrs.condition = { mode: "expr", expr: e.target.value }))}
              />
              <div className="flex gap-1">
                <Input
                  placeholder="message d'erreur"
                  value={str(b.attrs.error_message)}
                  disabled={disabled}
                  onChange={(e) => edit((n) => void (n.blocks!.validation[i].attrs.error_message = { mode: "literal", value: e.target.value }))}
                />
                {!disabled && (
                  <IconButton title="Supprimer" onClick={() => edit((n) => void n.blocks!.validation.splice(i, 1))}>
                    <Trash2 className="h-3.5 w-3.5" />
                  </IconButton>
                )}
              </div>
            </div>
          ))}
          {!disabled && (
            <Button size="sm" icon={<Plus className="h-3 w-3" />} onClick={() => edit((n) => void ((n.blocks ??= {}).validation = [...(n.blocks.validation ?? []), { attrs: {} }]))}>
              Ajouter une validation
            </Button>
          )}
        </div>
      </Field>
    </div>
  );
}

function OutputForm({ node, model, setAttr, disabled }: { node: TfNode; model: Project; setAttr: (n: string, v: Value | undefined) => void; disabled?: boolean }) {
  return (
    <div className="space-y-3">
      <Field label="Valeur" required>
        <ValueInput value={node.attrs.value} onChange={(v) => setAttr("value", v)} type="dynamic" model={model} selfId={node.id} disabled={disabled} />
      </Field>
      <Field label="Description">
        <Input
          value={node.attrs.description?.mode === "literal" ? String(node.attrs.description.value ?? "") : ""}
          disabled={disabled}
          onChange={(e) => setAttr("description", e.target.value ? { mode: "literal", value: e.target.value } : undefined)}
        />
      </Field>
      <Toggle checked={node.attrs.sensitive?.value === true} disabled={disabled} onChange={(v) => setAttr("sensitive", v ? { mode: "literal", value: true } : undefined)} label="Sensible" />
    </div>
  );
}

function ModuleForm({ node, model, setAttr, edit, disabled }: { node: TfNode; model: Project; setAttr: (n: string, v: Value | undefined) => void; edit: EditFn; disabled?: boolean }) {
  const mod = node.module;
  const internal = useQuery({
    queryKey: ["module", mod?.moduleId],
    queryFn: () => api.get<ModuleRow>(`/modules/${mod!.moduleId}`),
    enabled: mod?.sourceKind === "internal" && !!mod.moduleId,
  });
  const version = useQuery({
    queryKey: ["module-version", mod?.moduleId, mod?.version || internal.data?.latest],
    queryFn: () => api.get<{ inputs: ModuleRow["inputs"]; outputs: ModuleRow["outputs"] }>(`/modules/${mod!.moduleId}/versions/${mod!.version || internal.data!.latest}`),
    enabled: mod?.sourceKind === "internal" && !!(mod.version || internal.data?.latest),
  });
  const inputs = mod?.sourceKind === "internal" ? version.data?.inputs ?? [] : mod?.inputs ?? [];
  const outputs = mod?.sourceKind === "internal" ? version.data?.outputs ?? [] : mod?.outputs ?? [];
  // Les outputs sont mémorisés sur le nœud pour proposer les références (sélecteur, liaisons).
  const outputsKey = JSON.stringify(outputs);
  useEffect(() => {
    if (mod?.sourceKind === "internal" && version.data && JSON.stringify(mod.outputs ?? []) !== outputsKey && !disabled) {
      edit((n) => void (n.module!.outputs = JSON.parse(outputsKey)));
    }
  }, [outputsKey]); // eslint-disable-line react-hooks/exhaustive-deps
  return (
    <div className="space-y-3">
      <Field label="Source">
        {mod?.sourceKind === "internal" ? (
          <div className="flex gap-1">
            <Input value={`modules/${internal.data?.name ?? mod.name ?? ""}`} disabled />
            <Select value={mod.version ?? ""} disabled={disabled} onChange={(e) => edit((n) => void (n.module!.version = e.target.value))}>
              <option value="">dernière ({internal.data?.latest ?? "…"})</option>
              {internal.data?.versions.map((v) => (
                <option key={v}>{v}</option>
              ))}
            </Select>
          </div>
        ) : (
          <div className="flex gap-1">
            <Input value={mod?.source ?? ""} disabled={disabled} onChange={(e) => edit((n) => void (n.module!.source = e.target.value))} />
            {mod?.sourceKind === "registry" && <Input className="w-28" placeholder="version" value={mod.version ?? ""} disabled={disabled} onChange={(e) => edit((n) => void (n.module!.version = e.target.value))} />}
          </div>
        )}
      </Field>
      <section className="space-y-2">
        <h4 className="text-[11px] font-semibold uppercase tracking-wide text-slate-500">Entrées</h4>
        {inputs.map((iv) => {
          const missing = iv.required && isEmptyValue(node.attrs[iv.name]);
          return (
            <div key={iv.name} className={missing ? "rounded bg-rose-50 p-1.5 dark:bg-rose-950/30" : "p-1.5"}>
              <div className="mb-1 flex items-center gap-1.5 text-xs">
                <span className="font-mono font-medium">{iv.name}</span>
                <span className="text-slate-400">{iv.type}</span>
                {iv.required && <Badge tone="red">obligatoire</Badge>}
              </div>
              <ValueInput value={node.attrs[iv.name]} onChange={(v) => setAttr(iv.name, v)} type="dynamic" model={model} selfId={node.id} sensitive={iv.sensitive} disabled={disabled} placeholder={iv.default ? `défaut : ${iv.default}` : undefined} />
              {iv.description && <p className="text-[11px] text-slate-500">{iv.description}</p>}
            </div>
          );
        })}
        {mod?.sourceKind !== "internal" && !disabled && <ExternalInterfaceEditor node={node} edit={edit} />}
      </section>
      <section>
        <h4 className="text-[11px] font-semibold uppercase tracking-wide text-slate-500">Sorties</h4>
        <div className="mt-1 flex flex-wrap gap-1">
          {outputs.map((o) => (
            <Badge key={o.name} title={o.description}>
              {o.name}
            </Badge>
          ))}
        </div>
      </section>
    </div>
  );
}

/** Pour un module Git/local : déclaration manuelle des entrées et sorties. */
function ExternalInterfaceEditor({ node, edit }: { node: TfNode; edit: EditFn }) {
  return (
    <div className="space-y-1 text-xs">
      <Field label="Entrées (une par ligne : nom[:type][!] — ! = obligatoire)">
        <Textarea
          rows={3}
          defaultValue={(node.module?.inputs ?? []).map((i) => `${i.name}:${i.type}${i.required ? "!" : ""}`).join("\n")}
          onBlur={(e) =>
            edit((n) => {
              n.module!.inputs = e.target.value
                .split("\n")
                .map((l) => l.trim())
                .filter(Boolean)
                .map((l) => {
                  const required = l.endsWith("!");
                  const [name, type] = l.replace(/!$/, "").split(":");
                  return { name: name.trim(), type: (type ?? "any").trim(), required, sensitive: false };
                });
            })
          }
        />
      </Field>
      <Field label="Sorties (une par ligne)">
        <Textarea
          rows={2}
          defaultValue={(node.module?.outputs ?? []).map((o) => o.name).join("\n")}
          onBlur={(e) =>
            edit((n) => {
              n.module!.outputs = e.target.value
                .split("\n")
                .map((l) => l.trim())
                .filter(Boolean)
                .map((name) => ({ name }));
            })
          }
        />
      </Field>
    </div>
  );
}

function MetaEditor({ node, model, edit, disabled }: { node: TfNode; model: Project; edit: EditFn; disabled?: boolean }) {
  const lc = node.meta.lifecycle;
  const setLc = (patch: Partial<NonNullable<TfNode["meta"]["lifecycle"]>>) =>
    edit((n) => {
      n.meta.lifecycle = { createBeforeDestroy: false, preventDestroy: false, ignoreChanges: [], ignoreAll: false, replaceTriggeredBy: [], ...(n.meta.lifecycle ?? {}), ...patch };
    });
  const others = model.nodes.filter((n) => n.id !== node.id && (n.kind === "resource" || n.kind === "data" || n.kind === "module"));
  return (
    <details className="rounded-md border border-slate-200 dark:border-slate-700" open={!!(node.meta.count || node.meta.forEach || node.meta.dependsOn?.length || lc)}>
      <summary className="cursor-pointer px-2 py-1.5 text-xs font-semibold">Méta-arguments</summary>
      <div className="space-y-3 border-t border-slate-100 p-2 dark:border-slate-800">
        <Field label="count">
          <ValueInput value={node.meta.count} onChange={(v) => edit((n) => void (v ? (n.meta.count = v as Draft<Value>) : delete n.meta.count))} type="number" model={model} selfId={node.id} disabled={disabled || !!node.meta.forEach} />
        </Field>
        <Field label="for_each" help="Expression ou référence vers un map/set.">
          <ValueInput value={node.meta.forEach} onChange={(v) => edit((n) => void (v ? (n.meta.forEach = v as Draft<Value>) : delete n.meta.forEach))} type="dynamic" model={model} selfId={node.id} disabled={disabled || !!node.meta.count} />
        </Field>
        <Field label="depends_on">
          <div className="space-y-1">
            {others.map((o) => (
              <label key={o.id} className="flex items-center gap-2 text-xs">
                <input
                  type="checkbox"
                  disabled={disabled}
                  checked={node.meta.dependsOn?.includes(o.id) ?? false}
                  onChange={(e) =>
                    edit((n) => {
                      const deps = new Set(n.meta.dependsOn ?? []);
                      if (e.target.checked) deps.add(o.id);
                      else deps.delete(o.id);
                      n.meta.dependsOn = [...deps];
                    })
                  }
                />
                <span className="font-mono">{nodeAddress(o)}</span>
              </label>
            ))}
          </div>
        </Field>
        {node.kind === "resource" && (
          <>
            <div className="space-y-1.5">
              <p className="text-xs font-medium text-slate-600 dark:text-slate-400">lifecycle</p>
              <Toggle checked={lc?.createBeforeDestroy ?? false} disabled={disabled} onChange={(v) => setLc({ createBeforeDestroy: v })} label="create_before_destroy" />
              <Toggle checked={lc?.preventDestroy ?? false} disabled={disabled} onChange={(v) => setLc({ preventDestroy: v })} label="prevent_destroy" />
              <Toggle checked={lc?.ignoreAll ?? false} disabled={disabled} onChange={(v) => setLc({ ignoreAll: v })} label="ignore_changes = all" />
              {!lc?.ignoreAll && (
                <Field label="ignore_changes (un attribut par ligne)">
                  <Textarea rows={2} defaultValue={(lc?.ignoreChanges ?? []).join("\n")} disabled={disabled} onBlur={(e) => setLc({ ignoreChanges: lines(e.target.value) })} />
                </Field>
              )}
              <Field label="replace_triggered_by (une expression par ligne)">
                <Textarea rows={2} defaultValue={(lc?.replaceTriggeredBy ?? []).join("\n")} disabled={disabled} onBlur={(e) => setLc({ replaceTriggeredBy: lines(e.target.value) })} />
              </Field>
            </div>
            <ConditionsEditor conditions={node.meta.conditions ?? []} disabled={disabled} onChange={(c) => edit((n) => void (n.meta.conditions = c))} />
            <Field label="Ressource existante à importer (ID)" help="Génère un bloc import {} (Terraform ≥ 1.5).">
              <Input value={node.importId ?? ""} disabled={disabled} onChange={(e) => edit((n) => void (n.importId = e.target.value || undefined))} />
            </Field>
            <Field label="Ancienne adresse (renommage)" help="Génère un bloc moved {} pour ne pas recréer la ressource.">
              <Input placeholder="ex. aws_instance.old" value={node.movedFrom ?? ""} disabled={disabled} onChange={(e) => edit((n) => void (n.movedFrom = e.target.value || undefined))} />
            </Field>
          </>
        )}
      </div>
    </details>
  );
}

const lines = (s: string) => s.split("\n").map((l) => l.trim()).filter(Boolean);

function ConditionsEditor({ conditions, onChange, disabled }: { conditions: Condition[]; onChange: (c: Condition[]) => void; disabled?: boolean }) {
  const set = (i: number, patch: Partial<Condition>) => onChange(conditions.map((c, j) => (j === i ? { ...c, ...patch } : c)));
  return (
    <Field label="Préconditions / postconditions">
      <div className="space-y-2">
        {conditions.map((c, i) => (
          <div key={i} className="space-y-1 rounded border border-slate-200 p-2 dark:border-slate-700">
            <div className="flex gap-1">
              <Select value={c.kind} disabled={disabled} onChange={(e) => set(i, { kind: e.target.value as Condition["kind"] })}>
                <option value="precondition">precondition</option>
                <option value="postcondition">postcondition</option>
              </Select>
              {!disabled && (
                <IconButton title="Supprimer" onClick={() => onChange(conditions.filter((_, j) => j !== i))}>
                  <Trash2 className="h-3.5 w-3.5" />
                </IconButton>
              )}
            </div>
            <Input placeholder="condition (expression HCL)" value={c.condition} disabled={disabled} onChange={(e) => set(i, { condition: e.target.value })} />
            <Input placeholder="message d'erreur" value={c.errorMessage} disabled={disabled} onChange={(e) => set(i, { errorMessage: e.target.value })} />
          </div>
        ))}
        {!disabled && (
          <Button size="sm" icon={<Plus className="h-3 w-3" />} onClick={() => onChange([...conditions, { kind: "precondition", condition: "", errorMessage: "" }])}>
            Ajouter une condition
          </Button>
        )}
      </div>
    </Field>
  );
}
