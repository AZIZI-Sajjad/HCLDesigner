// Vue du code généré : un onglet par fichier, synchronisation nœud ↔ bloc HCL, diff avec la version enregistrée.
import { useEffect, useMemo, useRef, useState } from "react";
import Editor, { DiffEditor, type OnMount } from "@monaco-editor/react";
import { Copy, GitCompare } from "lucide-react";
import type { GenerateResult } from "@/types/api";
import { registerHCL, monaco } from "@/lib/monaco";
import { useEditor } from "@/store/editor";
import { Button, cx, toast } from "@/components/ui";
import { copyText } from "@/lib/model";

registerHCL();

export default function CodeView({ result, saved }: { result: GenerateResult | null; saved?: Record<string, string> | null }) {
  const selection = useEditor((s) => s.selection);
  const select = useEditor((s) => s.select);
  const files = useMemo(() => Object.keys(result?.files ?? {}).sort(fileOrder), [result]);
  const [file, setFile] = useState<string>("");
  const [diff, setDiff] = useState(false);
  const editorRef = useRef<monaco.editor.IStandaloneCodeEditor | null>(null);
  const decorations = useRef<monaco.editor.IEditorDecorationsCollection | null>(null);
  const dark = document.documentElement.classList.contains("dark");

  useEffect(() => {
    if (!files.includes(file)) setFile(files[0] ?? "");
  }, [files, file]);

  // Sélection d'un nœud : ouverture du fichier et surlignage de son bloc.
  const range = result?.ranges.find((r) => r.nodeId === selection[0]);
  useEffect(() => {
    if (range && range.file !== file) setFile(range.file);
  }, [range?.nodeId]); // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => {
    const ed = editorRef.current;
    if (!ed) return;
    decorations.current?.clear();
    if (range && range.file === file) {
      decorations.current = ed.createDecorationsCollection([
        { range: new monaco.Range(range.start, 1, range.end, 1), options: { isWholeLine: true, className: "bg-indigo-500/10", linesDecorationsClassName: "border-l-4 border-indigo-500" } },
      ]);
      ed.revealLinesInCenterIfOutsideViewport(range.start, range.end);
    }
  }, [range, file, result]);

  const onMount: OnMount = (ed) => {
    editorRef.current = ed;
    // Clic dans un bloc : sélection du nœud correspondant sur le canvas.
    ed.onMouseDown((e) => {
      const line = e.target.position?.lineNumber;
      if (!line || !result) return;
      const r = result.ranges.find((x) => x.file === file && line >= x.start && line <= x.end);
      if (r) select([r.nodeId]);
    });
  };

  if (!result) return <div className="p-4 text-sm text-slate-500">Génération en cours…</div>;
  const content = result.files[file] ?? "";
  return (
    <div className="flex h-full flex-col">
      <div className="flex items-center gap-1 overflow-x-auto border-b border-slate-200 px-2 dark:border-slate-800">
        {files.map((f) => (
          <button key={f} onClick={() => setFile(f)} className={cx("whitespace-nowrap border-b-2 px-2.5 py-2 font-mono text-xs", f === file ? "border-indigo-600 text-indigo-600" : "border-transparent text-slate-500")}>
            {f}
            {saved && saved[f] !== result.files[f] && <span className="ml-1 text-amber-500">●</span>}
          </button>
        ))}
        <span className="flex-1" />
        {saved && (
          <Button size="sm" variant={diff ? "primary" : "ghost"} icon={<GitCompare className="h-3.5 w-3.5" />} onClick={() => setDiff((d) => !d)}>
            Diff
          </Button>
        )}
        <Button size="sm" variant="ghost" icon={<Copy className="h-3.5 w-3.5" />} onClick={() => void copyText(content).then(() => toast.success("Copié"), () => toast.error("Copie impossible"))}>
          Copier
        </Button>
      </div>
      {result.diagnostics.length > 0 && (
        <div className="max-h-28 overflow-y-auto border-b border-slate-200 bg-rose-50 px-3 py-1.5 text-xs text-rose-800 dark:border-slate-800 dark:bg-rose-950 dark:text-rose-200">
          {result.diagnostics.map((d, i) => (
            <div key={i} className="cursor-pointer" onClick={() => d.nodeId && select([d.nodeId])}>
              {d.severity === "error" ? "✖" : "⚠"} {d.summary}
            </div>
          ))}
        </div>
      )}
      <div className="min-h-0 flex-1">
        {diff && saved ? (
          <DiffEditor original={saved[file] ?? ""} modified={content} language="hcl" theme={dark ? "vs-dark" : "vs"} options={{ readOnly: true, renderSideBySide: true, minimap: { enabled: false } }} />
        ) : (
          <Editor value={content} language={file.endsWith(".md") ? "markdown" : "hcl"} theme={dark ? "vs-dark" : "vs"} onMount={onMount} options={{ readOnly: true, minimap: { enabled: false }, fontSize: 13, scrollBeyondLastLine: false }} />
        )}
      </div>
    </div>
  );
}

const order = ["versions.tf", "backend.tf", "providers.tf", "variables.tf", "locals.tf", "main.tf"];
function fileOrder(a: string, b: string): number {
  const ia = order.indexOf(a), ib = order.indexOf(b);
  const ma = a.startsWith("modules/"), mb = b.startsWith("modules/");
  if (ma !== mb) return ma ? 1 : -1;
  if (a === "outputs.tf" || b === "outputs.tf") return a === "outputs.tf" ? 1 : -1;
  if (ia >= 0 || ib >= 0) return (ia < 0 ? 99 : ia) - (ib < 0 ? 99 : ib);
  return a.localeCompare(b);
}
