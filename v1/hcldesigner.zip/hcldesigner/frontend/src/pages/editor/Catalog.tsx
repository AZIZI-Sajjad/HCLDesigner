// Catalogue : ressources et data sources des providers du projet (recherche, filtres,
// favoris), objets de base (variable, local, output) et modules. Les éléments se glissent sur le canvas.
import { useEffect, useMemo, useState, type DragEvent } from "react";
import { useQuery } from "@tanstack/react-query";
import { Star, FileInput, FileOutput, Sigma, Package } from "lucide-react";
import { api, qs } from "@/api/client";
import type { CatalogEntry, ModuleRow } from "@/types/api";
import type { Project } from "@/types/model";
import { categoryLabels } from "@/lib/schema";
import { Input, Select, cx } from "@/components/ui";
import { DRAG_MIME, type DragItem } from "./Canvas";

function drag(e: DragEvent, item: DragItem) {
  e.dataTransfer.setData(DRAG_MIME, JSON.stringify(item));
  e.dataTransfer.effectAllowed = "copy";
}

export default function Catalog({ model, onRegistryModule }: { model: Project; onRegistryModule: () => void }) {
  const [q, setQ] = useState("");
  const [kind, setKind] = useState("resource");
  const [cat, setCat] = useState("");
  const [tab, setTab] = useState<"providers" | "base" | "modules">("providers");
  const sources = useMemo(() => [...new Set(model.providers.filter((p) => p.resolved).map((p) => `${p.source}@${p.resolved}`))].join(","), [model.providers]);
  const [debounced, setDebounced] = useState(q);
  useEffect(() => {
    const t = setTimeout(() => setDebounced(q), 250);
    return () => clearTimeout(t);
  }, [q]);

  const catalog = useQuery({
    queryKey: ["catalog", sources, debounced, kind, cat],
    queryFn: () => api.get<CatalogEntry[]>("/catalog" + qs({ sources, q: debounced, kind, category: cat })),
    enabled: !!sources,
  });
  const favorites = useQuery({ queryKey: ["catalog-favorites"], queryFn: () => api.get<string[] | null>("/prefs/user/catalog_favorites") });
  const favs = new Set(favorites.data ?? []);
  const toggleFav = async (type: string) => {
    const next = favs.has(type) ? [...favs].filter((x) => x !== type) : [...favs, type];
    await api.put("/prefs/user/catalog_favorites", next);
    void favorites.refetch();
  };
  const modules = useQuery({ queryKey: ["modules"], queryFn: () => api.get<ModuleRow[]>("/modules"), enabled: tab === "modules" });

  const entries = [...(catalog.data ?? [])].sort((a, b) => Number(favs.has(b.type)) - Number(favs.has(a.type)));

  return (
    <div className="flex h-full flex-col">
      <div className="flex border-b border-slate-200 text-xs dark:border-slate-800">
        {(
          [
            ["providers", "Providers"],
            ["base", "Objets"],
            ["modules", "Modules"],
          ] as const
        ).map(([id, label]) => (
          <button key={id} className={cx("flex-1 py-2 font-medium", tab === id ? "border-b-2 border-indigo-600 text-indigo-600" : "text-slate-500")} onClick={() => setTab(id)}>
            {label}
          </button>
        ))}
      </div>

      {tab === "providers" && (
        <>
          <div className="space-y-1.5 p-2">
            <Input placeholder="Rechercher (ex. vpc, bucket)…" value={q} onChange={(e) => setQ(e.target.value)} />
            <div className="flex gap-1">
              <Select value={kind} onChange={(e) => setKind(e.target.value)}>
                <option value="resource">Ressources</option>
                <option value="data">Data sources</option>
                <option value="ephemeral">Éphémères</option>
              </Select>
              <Select value={cat} onChange={(e) => setCat(e.target.value)}>
                <option value="">Toutes catégories</option>
                {Object.entries(categoryLabels).map(([k, v]) => (
                  <option key={k} value={k}>
                    {v}
                  </option>
                ))}
              </Select>
            </div>
          </div>
          <div className="flex-1 overflow-y-auto px-2 pb-2">
            {!sources && <p className="p-2 text-xs text-slate-500">Ajoutez un provider dans l'onglet Paramètres pour alimenter le catalogue.</p>}
            {entries.map((e) => (
              <div
                key={`${e.source}:${e.kind}:${e.type}`}
                draggable
                onDragStart={(ev) => drag(ev, { kind: e.kind === "data" ? "data" : "resource", type: e.type, source: e.source })}
                className="group mb-1 cursor-grab rounded-md border border-slate-200 bg-white px-2 py-1.5 hover:border-indigo-400 active:cursor-grabbing dark:border-slate-700 dark:bg-slate-900"
                title={e.description}
              >
                <div className="flex items-center gap-1">
                  <span className={cx("flex-1 truncate font-mono text-xs", e.deprecated && "line-through opacity-60")}>{e.type}</span>
                  <button onClick={() => void toggleFav(e.type)} title="Favori" className={favs.has(e.type) ? "text-amber-500" : "text-slate-300 opacity-0 group-hover:opacity-100"}>
                    <Star className="h-3.5 w-3.5" fill={favs.has(e.type) ? "currentColor" : "none"} />
                  </button>
                </div>
                <div className="text-[10px] text-slate-400">
                  {categoryLabels[e.category] ?? e.category} · {e.source}
                </div>
              </div>
            ))}
          </div>
        </>
      )}

      {tab === "base" && (
        <div className="space-y-1 p-2">
          {(
            [
              { kind: "variable", label: "Variable", icon: FileInput, help: "Entrée paramétrable (var.x)" },
              { kind: "local", label: "Local", icon: Sigma, help: "Valeur calculée réutilisable (local.x)" },
              { kind: "output", label: "Output", icon: FileOutput, help: "Valeur exposée en sortie" },
            ] as const
          ).map((b) => (
            <div
              key={b.kind}
              draggable
              onDragStart={(ev) => drag(ev, { kind: b.kind, type: "" })}
              className="flex cursor-grab items-center gap-2 rounded-md border border-slate-200 bg-white px-2 py-2 hover:border-indigo-400 dark:border-slate-700 dark:bg-slate-900"
            >
              <b.icon className="h-4 w-4 text-slate-500" />
              <div>
                <div className="text-sm font-medium">{b.label}</div>
                <div className="text-[11px] text-slate-500">{b.help}</div>
              </div>
            </div>
          ))}
        </div>
      )}

      {tab === "modules" && (
        <div className="flex-1 space-y-1 overflow-y-auto p-2">
          <button className="w-full rounded-md border border-dashed border-slate-300 px-2 py-2 text-xs text-indigo-600 dark:border-slate-600" onClick={onRegistryModule}>
            + Module du Registry, Git ou local…
          </button>
          {(modules.data ?? [])
            .filter((m) => m.latest)
            .map((m) => (
              <div
                key={m.id}
                draggable
                onDragStart={(ev) =>
                  drag(ev, { kind: "module", type: m.name, label: m.name.replace(/-/g, "_"), module: { sourceKind: "internal", moduleId: m.id, name: m.name, version: m.latest, outputs: m.outputs } })
                }
                className="cursor-grab rounded-md border border-slate-200 bg-white px-2 py-1.5 hover:border-indigo-400 dark:border-slate-700 dark:bg-slate-900"
                title={m.description}
              >
                <div className="flex items-center gap-1.5">
                  <Package className="h-3.5 w-3.5 text-violet-500" />
                  <span className="flex-1 truncate text-xs font-medium">{m.name}</span>
                  <span className="text-[10px] text-slate-400">{m.latest}</span>
                </div>
                <div className="text-[10px] text-slate-400">
                  {m.inputs.length} entrée(s) · {m.outputs.length} sortie(s) · {m.scope}
                </div>
              </div>
            ))}
          {modules.data && modules.data.filter((m) => m.latest).length === 0 && <p className="text-xs text-slate-500">Aucun module publié.</p>}
        </div>
      )}
    </div>
  );
}
