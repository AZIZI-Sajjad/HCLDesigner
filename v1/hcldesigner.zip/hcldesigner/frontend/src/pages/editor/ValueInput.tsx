// Saisie d'une valeur d'attribut selon trois modes : littéral (widget adapté au type),
// référence (objet + attribut du projet), expression HCL libre.
import { useMemo, useState } from "react";
import { Braces, Link2, Type, Plus, X, Variable } from "lucide-react";
import type { IndexMode, Project, TfNode, Value } from "@/types/model";
import { elemType, isCollection, typeString } from "@/lib/schema";
import { multiOf, nodeAddress, refExpression } from "@/lib/model";
import { useEditor } from "@/store/editor";
import { nodeSchemaKey } from "@/lib/useSchema";
import { IconButton, Input, Select, Textarea, Toggle, cx } from "@/components/ui";

interface Props {
  value?: Value;
  onChange: (v: Value | undefined) => void;
  type: string; // type lisible (string, number, list(string)...)
  model: Project;
  selfId?: string; // nœud propriétaire (exclu des références)
  sensitive?: boolean;
  placeholder?: string;
  disabled?: boolean;
}

const modeIcons = { literal: Type, ref: Link2, expr: Braces } as const;
const modeLabels = { literal: "Valeur", ref: "Référence", expr: "Expression HCL" } as const;

export function ValueInput({ value, onChange, type, model, selfId, sensitive, placeholder, disabled }: Props) {
  const mode = value?.mode === "list" ? "literal" : (value?.mode as "literal" | "ref" | "expr") ?? "literal";
  const isRefList = value?.mode === "list";
  return (
    <div className="flex items-start gap-1">
      <div className="min-w-0 flex-1">
        {isRefList ? (
          <RefListEditor value={value!} onChange={onChange} model={model} selfId={selfId} disabled={disabled} />
        ) : mode === "ref" ? (
          <RefPicker value={value} onChange={onChange} model={model} selfId={selfId} disabled={disabled} />
        ) : mode === "expr" ? (
          <Textarea
            rows={Math.min(8, Math.max(1, (value?.expr ?? "").split("\n").length))}
            value={value?.expr ?? ""}
            disabled={disabled}
            placeholder="ex. cidrsubnet(var.cidr, 8, count.index)"
            onChange={(e) => onChange(e.target.value ? { mode: "expr", expr: e.target.value } : undefined)}
          />
        ) : (
          <LiteralInput value={value?.value} type={type} sensitive={sensitive} placeholder={placeholder} disabled={disabled} onChange={(v) => onChange(v === undefined ? undefined : { mode: "literal", value: v })} />
        )}
      </div>
      {!disabled && (
        <div className="flex shrink-0 rounded-md border border-slate-200 dark:border-slate-700">
          {(Object.keys(modeIcons) as (keyof typeof modeIcons)[]).map((m) => {
            const Icon = modeIcons[m];
            return (
              <button
                key={m}
                type="button"
                title={modeLabels[m]}
                className={cx("p-1.5", mode === m && !isRefList ? "bg-indigo-600 text-white" : "text-slate-400 hover:text-slate-700")}
                onClick={() => {
                  if (m === mode && !isRefList) return;
                  if (m === "expr") onChange({ mode: "expr", expr: value ? toExpr(value, model) : "" });
                  else if (m === "ref") onChange({ mode: "ref", ref: { node: "", attr: "" } });
                  else onChange(undefined);
                }}
              >
                <Icon className="h-3.5 w-3.5" />
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
}

/** Convertit une valeur en texte d'expression (bascule vers le mode expression). */
function toExpr(v: Value, model: Project): string {
  const nodes = new Map(model.nodes.map((n) => [n.id, n]));
  if (v.mode === "literal") return JSON.stringify(v.value ?? "");
  if (v.mode === "ref" && v.ref) {
    const n = nodes.get(v.ref.node);
    return n ? refExpression(v.ref, n) : "";
  }
  if (v.mode === "expr") return v.expr ?? "";
  if (v.mode === "list") return `[${(v.items ?? []).map((i) => toExpr(i, model)).join(", ")}]`;
  return "";
}

function LiteralInput({ value, type, onChange, sensitive, placeholder, disabled }: { value: unknown; type: string; onChange: (v: unknown) => void; sensitive?: boolean; placeholder?: string; disabled?: boolean }) {
  const [reveal, setReveal] = useState(false);
  if (type === "bool") return <Toggle checked={value === true} disabled={disabled} onChange={(v) => onChange(v)} label={value === undefined ? <span className="text-xs text-slate-400">non défini</span> : String(value)} />;
  if (type === "number")
    return <Input type="number" value={value === undefined ? "" : String(value)} disabled={disabled} placeholder={placeholder} onChange={(e) => onChange(e.target.value === "" ? undefined : Number(e.target.value))} />;
  if (type === "string") {
    const s = typeof value === "string" ? value : value === undefined ? "" : String(value);
    if (s.includes("\n")) return <Textarea rows={4} value={s} disabled={disabled} onChange={(e) => onChange(e.target.value || undefined)} />;
    return (
      <div className="relative">
        <Input
          type={sensitive && !reveal ? "password" : "text"}
          value={s}
          disabled={disabled}
          placeholder={placeholder}
          onChange={(e) => onChange(e.target.value === "" ? undefined : e.target.value)}
          onPaste={(e) => {
            const t = e.clipboardData.getData("text");
            if (t.includes("\n")) {
              e.preventDefault();
              onChange(t);
            }
          }}
        />
        {sensitive && (
          <button type="button" className="absolute right-2 top-1.5 text-xs text-slate-400" onClick={() => setReveal((r) => !r)}>
            {reveal ? "masquer" : "voir"}
          </button>
        )}
      </div>
    );
  }
  if (isCollection(type) && ["string", "number"].includes(elemType(type)))
    return <ChipsInput values={Array.isArray(value) ? (value as unknown[]).map(String) : []} numeric={elemType(type) === "number"} disabled={disabled} onChange={(vs) => onChange(vs.length ? vs : undefined)} />;
  if (type === "map(string)") return <MapInput value={(value as Record<string, string>) ?? {}} disabled={disabled} onChange={(m) => onChange(Object.keys(m).length ? m : undefined)} />;
  return <JsonInput value={value} disabled={disabled} onChange={onChange} />;
}

function ChipsInput({ values, onChange, numeric, disabled }: { values: string[]; onChange: (v: unknown[]) => void; numeric?: boolean; disabled?: boolean }) {
  const [draft, setDraft] = useState("");
  const add = () => {
    const parts = draft.split(/[,\n]/).map((s) => s.trim()).filter(Boolean);
    if (!parts.length) return;
    const next = [...values, ...parts];
    onChange(numeric ? next.map(Number) : next);
    setDraft("");
  };
  return (
    <div className="flex min-h-[34px] flex-wrap items-center gap-1 rounded-md border border-slate-300 px-1.5 py-1 dark:border-slate-600">
      {values.map((v, i) => (
        <span key={i} className="inline-flex items-center gap-1 rounded bg-slate-100 px-1.5 py-0.5 text-xs dark:bg-slate-800">
          {v}
          {!disabled && (
            <button type="button" onClick={() => onChange(values.filter((_, j) => j !== i).map((x) => (numeric ? Number(x) : x)))}>
              <X className="h-3 w-3" />
            </button>
          )}
        </span>
      ))}
      {!disabled && (
        <input
          className="min-w-[80px] flex-1 bg-transparent text-sm outline-none"
          placeholder="Ajouter (Entrée)"
          value={draft}
          onChange={(e) => setDraft(e.target.value)}
          onKeyDown={(e) => (e.key === "Enter" || e.key === ",") && (e.preventDefault(), add())}
          onBlur={add}
        />
      )}
    </div>
  );
}

function MapInput({ value, onChange, disabled }: { value: Record<string, string>; onChange: (m: Record<string, string>) => void; disabled?: boolean }) {
  const entries = Object.entries(value);
  const set = (i: number, k: string, v: string) => {
    const next = [...entries];
    next[i] = [k, v];
    onChange(Object.fromEntries(next.filter(([key]) => key !== "")));
  };
  return (
    <div className="space-y-1">
      {entries.map(([k, v], i) => (
        <div key={i} className="flex gap-1">
          <Input className="w-2/5" value={k} disabled={disabled} placeholder="clé" onChange={(e) => set(i, e.target.value, v)} />
          <Input value={v} disabled={disabled} placeholder="valeur" onChange={(e) => set(i, k, e.target.value)} />
          {!disabled && (
            <IconButton title="Retirer" onClick={() => onChange(Object.fromEntries(entries.filter((_, j) => j !== i)))}>
              <X className="h-3.5 w-3.5" />
            </IconButton>
          )}
        </div>
      ))}
      {!disabled && (
        <button type="button" className="inline-flex items-center gap-1 text-xs text-indigo-600" onClick={() => onChange({ ...value, [`cle_${entries.length + 1}`]: "" })}>
          <Plus className="h-3 w-3" /> Ajouter une entrée
        </button>
      )}
    </div>
  );
}

function JsonInput({ value, onChange, disabled }: { value: unknown; onChange: (v: unknown) => void; disabled?: boolean }) {
  const [text, setText] = useState(value === undefined ? "" : JSON.stringify(value, null, 2));
  const [err, setErr] = useState("");
  return (
    <div>
      <Textarea
        rows={Math.min(10, Math.max(2, text.split("\n").length))}
        value={text}
        disabled={disabled}
        placeholder='JSON, ex. {"cle": "valeur"} ou ["a", "b"]'
        onChange={(e) => {
          setText(e.target.value);
          if (!e.target.value.trim()) {
            setErr("");
            onChange(undefined);
            return;
          }
          try {
            onChange(JSON.parse(e.target.value));
            setErr("");
          } catch {
            setErr("JSON invalide");
          }
        }}
      />
      {err && <p className="text-xs text-rose-600">{err}</p>}
    </div>
  );
}

/** Sélection d'une référence : nœud source, attribut exporté, forme d'index si count/for_each. */
export function RefPicker({ value, onChange, model, selfId, disabled }: { value?: Value; onChange: (v: Value | undefined) => void; model: Project; selfId?: string; disabled?: boolean }) {
  const ref = value?.ref ?? { node: "", attr: "" };
  const candidates = model.nodes.filter((n) => n.id !== selfId && n.kind !== "output");
  const src = model.nodes.find((n) => n.id === ref.node);
  const attrs = useSourceAttrs(model, src);
  const multi = src ? multiOf(src) : "";
  const set = (patch: Partial<typeof ref>) => onChange({ mode: "ref", ref: { ...ref, ...patch } });
  return (
    <div className="space-y-1">
      <div className="flex gap-1">
        <Select value={ref.node} disabled={disabled} onChange={(e) => set({ node: e.target.value, attr: defaultAttr(model.nodes.find((n) => n.id === e.target.value)) })}>
          <option value="">— objet —</option>
          {candidates.map((n) => (
            <option key={n.id} value={n.id}>
              {nodeAddress(n)}
            </option>
          ))}
        </Select>
        {src && (src.kind === "resource" || src.kind === "data" || src.kind === "module") && (
          <Select value={ref.attr} disabled={disabled} onChange={(e) => set({ attr: e.target.value })}>
            <option value="">— attribut —</option>
            {attrs.map((a) => (
              <option key={a} value={a}>
                {a}
              </option>
            ))}
            {ref.attr && !attrs.includes(ref.attr) && <option value={ref.attr}>{ref.attr}</option>}
          </Select>
        )}
      </div>
      {multi && (
        <div className="flex gap-1">
          <Select value={ref.indexMode ?? ""} disabled={disabled} onChange={(e) => set({ indexMode: e.target.value as IndexMode })}>
            <option value="">sans index</option>
            {multi === "count" && <option value="index">élément [n]</option>}
            {multi === "count" && <option value="splat">tous [*]</option>}
            {multi === "for_each" && <option value="key">clé ["…"]</option>}
            {multi === "for_each" && <option value="values">tous values(…)[*]</option>}
            <option value="each">[each.key] (for_each identique)</option>
          </Select>
          {(ref.indexMode === "index" || ref.indexMode === "key") && (
            <Input className="w-24" placeholder={ref.indexMode === "index" ? "0" : "clé"} value={ref.index ?? ""} disabled={disabled} onChange={(e) => set({ index: e.target.value })} />
          )}
        </div>
      )}
      {src && <p className="font-mono text-[11px] text-slate-500">{refExpression(ref, src)}</p>}
    </div>
  );
}

/** Liste de références (argument liste alimenté par plusieurs liens). */
function RefListEditor({ value, onChange, model, selfId, disabled }: { value: Value; onChange: (v: Value | undefined) => void; model: Project; selfId?: string; disabled?: boolean }) {
  const items = value.items ?? [];
  const setItem = (i: number, v: Value | undefined) => {
    const next = items.map((it, j) => (j === i ? v : it)).filter(Boolean) as Value[];
    onChange(next.length ? { mode: "list", items: next } : undefined);
  };
  return (
    <div className="space-y-1.5 rounded-md border border-dashed border-slate-300 p-1.5 dark:border-slate-600">
      {items.map((it, i) => (
        <div key={i} className="flex items-start gap-1">
          <div className="flex-1">
            {it.mode === "ref" ? (
              <RefPicker value={it} onChange={(v) => setItem(i, v)} model={model} selfId={selfId} disabled={disabled} />
            ) : (
              <Input value={it.mode === "expr" ? it.expr : JSON.stringify(it.value)} disabled={disabled} onChange={(e) => setItem(i, { mode: "expr", expr: e.target.value })} />
            )}
          </div>
          {!disabled && (
            <IconButton title="Retirer" onClick={() => setItem(i, undefined)}>
              <X className="h-3.5 w-3.5" />
            </IconButton>
          )}
        </div>
      ))}
      {!disabled && (
        <div className="flex gap-2 text-xs">
          <button type="button" className="text-indigo-600" onClick={() => onChange({ mode: "list", items: [...items, { mode: "ref", ref: { node: "", attr: "" } }] })}>
            + référence
          </button>
          <button type="button" className="text-indigo-600" onClick={() => onChange({ mode: "list", items: [...items, { mode: "expr", expr: "" }] })}>
            + expression
          </button>
        </div>
      )}
    </div>
  );
}

function defaultAttr(n?: TfNode): string {
  if (!n) return "";
  if (n.kind === "variable" || n.kind === "local") return "";
  if (n.kind === "module") return n.module?.outputs?.[0]?.name ?? "";
  return "id";
}

/** Attributs exportés par un nœud source (schéma chargé, ou outputs de module). */
export function useSourceAttrs(model: Project, src?: TfNode): string[] {
  const key = src ? nodeSchemaKey(model, src) : undefined;
  const entry = useEditor((s) => (key ? s.schemas[key] : undefined));
  return useMemo(() => {
    if (!src) return [];
    if (src.kind === "module") return (src.module?.outputs ?? []).map((o) => o.name);
    const attrs = Object.keys(entry?.block?.attributes ?? {}).sort();
    return attrs.length ? ["id", ...attrs.filter((a) => a !== "id")] : ["id", "arn", "name"];
  }, [src, entry]);
}

/** Bouton "Extraire en variable" : crée une variable typée et y relie l'attribut. */
export function ExtractVariableButton({ onExtract }: { onExtract: () => void }) {
  return (
    <button type="button" title="Extraire en variable" className="text-slate-400 hover:text-indigo-600" onClick={onExtract}>
      <Variable className="h-3.5 w-3.5" />
    </button>
  );
}

/** Type HCL d'une variable déduit du type de l'attribut. */
export function variableTypeFor(rawType: unknown): string {
  const t = typeString(rawType);
  return t === "dynamic" ? "any" : t;
}
