// Carte d'un nœud sur le canvas : icône, type, label, badges d'état, poignées de connexion.
import { memo } from "react";
import { Handle, Position, type NodeProps, type Node } from "@xyflow/react";
import { AlertCircle, Box, Database, FileInput, FileOutput, Package, Sigma, ShieldAlert } from "lucide-react";
import type { TfNode } from "@/types/model";
import { category } from "@/lib/schema";
import { cx } from "@/components/ui";

export interface TfNodeData extends Record<string, unknown> {
  node: TfNode;
  missing: number;
  errors: number;
  violations: number;
  plan?: string; // create | update | replace | delete
  compatible?: boolean; // surlignage pendant le drag d'un lien
  dimmed?: boolean; // hors de la chaîne de dépendances survolée
}

const kindStyle: Record<TfNode["kind"], { icon: typeof Box; color: string; label: string }> = {
  resource: { icon: Box, color: "border-l-indigo-500", label: "resource" },
  data: { icon: Database, color: "border-l-sky-500", label: "data" },
  module: { icon: Package, color: "border-l-violet-500", label: "module" },
  variable: { icon: FileInput, color: "border-l-emerald-500", label: "variable" },
  local: { icon: Sigma, color: "border-l-teal-500", label: "local" },
  output: { icon: FileOutput, color: "border-l-amber-500", label: "output" },
};

const planStyle: Record<string, string> = {
  create: "ring-2 ring-emerald-500",
  update: "ring-2 ring-amber-500",
  replace: "ring-2 ring-orange-600",
  delete: "ring-2 ring-rose-600",
};

const planLabel: Record<string, string> = { create: "+ créer", update: "~ modifier", replace: "± remplacer", delete: "− détruire" };

/** Couleur stable d'un groupe visuel. */
function groupColor(g: string): string {
  let h = 0;
  for (const c of g) h = (h * 31 + c.charCodeAt(0)) % 360;
  return `hsl(${h} 70% 50%)`;
}

function TfNodeCardInner({ data, selected }: NodeProps<Node<TfNodeData>>) {
  const { node, missing, errors, violations, plan, compatible, dimmed } = data;
  const k = kindStyle[node.kind];
  const Icon = k.icon;
  const subtitle = node.kind === "resource" || node.kind === "data" ? node.type : node.kind === "module" ? node.module?.name ?? node.module?.source ?? "module" : k.label;
  return (
    <div
      className={cx(
        "w-56 rounded-md border border-l-4 bg-white text-xs shadow-sm transition-opacity dark:bg-slate-900",
        k.color,
        selected ? "border-indigo-500 shadow-md" : "border-slate-200 dark:border-slate-700",
        plan && planStyle[plan],
        compatible && "ring-2 ring-indigo-400 ring-offset-1",
        dimmed && "opacity-30",
      )}
      style={node.group ? { boxShadow: `inset 0 3px 0 ${groupColor(node.group)}` } : undefined}
    >
      {node.kind !== "variable" && <Handle type="target" position={Position.Left} className="!h-3 !w-3 !border-2 !border-white !bg-slate-400" />}
      {node.kind !== "output" && <Handle type="source" position={Position.Right} className="!h-3 !w-3 !border-2 !border-white !bg-indigo-500" />}
      <div className="flex items-start gap-2 px-2.5 py-2">
        <Icon className="mt-0.5 h-4 w-4 shrink-0 text-slate-500" />
        <div className="min-w-0 flex-1">
          <div className="truncate font-semibold" title={node.label}>
            {node.label}
          </div>
          <div className="truncate font-mono text-[10px] text-slate-500" title={subtitle}>
            {subtitle}
            {node.provider?.includes(".") ? ` (${node.provider})` : ""}
          </div>
        </div>
      </div>
      {(missing > 0 || errors > 0 || violations > 0 || plan || node.meta.count || node.meta.forEach || node.group) && (
        <div className="flex flex-wrap gap-1 border-t border-slate-100 px-2 py-1 dark:border-slate-800">
          {missing > 0 && (
            <span className="inline-flex items-center gap-0.5 rounded bg-rose-100 px-1 text-[10px] text-rose-700 dark:bg-rose-950 dark:text-rose-300" title="Arguments obligatoires manquants">
              <AlertCircle className="h-3 w-3" /> {missing} requis
            </span>
          )}
          {errors > 0 && <span className="rounded bg-rose-600 px-1 text-[10px] text-white">{errors} erreur(s)</span>}
          {violations > 0 && (
            <span className="inline-flex items-center gap-0.5 rounded bg-amber-100 px-1 text-[10px] text-amber-800 dark:bg-amber-950 dark:text-amber-300" title="Non-conformités">
              <ShieldAlert className="h-3 w-3" /> {violations}
            </span>
          )}
          {plan && <span className="rounded bg-slate-800 px-1 text-[10px] text-white">{planLabel[plan] ?? plan}</span>}
          {node.meta.count && <span className="rounded bg-slate-100 px-1 text-[10px] dark:bg-slate-800">count</span>}
          {node.meta.forEach && <span className="rounded bg-slate-100 px-1 text-[10px] dark:bg-slate-800">for_each</span>}
          {node.kind === "resource" && <span className="ml-auto text-[10px] text-slate-400">{category(node.type)}</span>}
          {node.group && <span className="text-[10px]" style={{ color: groupColor(node.group) }}>{node.group}</span>}
        </div>
      )}
    </div>
  );
}

export const TfNodeCard = memo(TfNodeCardInner);
