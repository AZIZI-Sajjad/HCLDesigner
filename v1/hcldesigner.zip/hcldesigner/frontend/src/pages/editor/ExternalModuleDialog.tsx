// Ajout d'un module externe : Terraform Registry (interface lue automatiquement), Git ou chemin local.
import { useState } from "react";
import type { Draft } from "immer";
import { api, qs } from "@/api/client";
import type { ModuleOutput, ModuleVar, TfNode } from "@/types/model";
import { newId, uniqueLabel } from "@/lib/model";
import { useEditor } from "@/store/editor";
import { Button, ErrorBox, Field, Input, Modal, Tabs } from "@/components/ui";

interface RegistryHit {
  id: string;
  namespace: string;
  name: string;
  provider: string;
  version: string;
  description: string;
  downloads: number;
}

export default function ExternalModuleDialog({ onClose }: { onClose: () => void }) {
  const update = useEditor((s) => s.update);
  const select = useEditor((s) => s.select);
  const [tab, setTab] = useState<"registry" | "git" | "local">("registry");
  const [q, setQ] = useState("");
  const [hits, setHits] = useState<RegistryHit[]>([]);
  const [picked, setPicked] = useState<RegistryHit | null>(null);
  const [version, setVersion] = useState("");
  const [source, setSource] = useState("");
  const [label, setLabel] = useState("");
  const [error, setError] = useState<unknown>(null);
  const [loading, setLoading] = useState(false);

  const search = async () => {
    setError(null);
    setLoading(true);
    try {
      const r = await api.get<{ modules: RegistryHit[] }>("/registry/modules/search" + qs({ q }));
      setHits(r.modules ?? []);
    } catch (e) {
      setError(e);
    } finally {
      setLoading(false);
    }
  };

  const add = (mod: TfNode["module"], base: string) => {
    const id = newId();
    update((d) => {
      d.nodes.push({
        id,
        kind: "module",
        type: base,
        label: uniqueLabel(d as never, "module", base, label || base.replace(/-/g, "_")),
        attrs: {},
        meta: {},
        position: { x: 80, y: 80 + d.nodes.length * 20 },
        module: mod,
      } as Draft<TfNode>);
    });
    select([id]);
    onClose();
  };

  const addRegistry = async () => {
    if (!picked) return;
    setLoading(true);
    try {
      const r = await api.get<{ version: string; inputs: ModuleVar[]; outputs: ModuleOutput[] }>(
        `/registry/modules/${picked.namespace}/${picked.name}/${picked.provider}` + qs({ version }),
      );
      add({ sourceKind: "registry", source: `${picked.namespace}/${picked.name}/${picked.provider}`, version: version ? version : `~> ${r.version.split(".")[0]}.0`, inputs: r.inputs, outputs: r.outputs }, picked.name);
    } catch (e) {
      setError(e);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Modal open onClose={onClose} title="Ajouter un module externe" wide>
      <Tabs
        tabs={[
          { id: "registry", label: "Terraform Registry" },
          { id: "git", label: "Git" },
          { id: "local", label: "Chemin local" },
        ]}
        value={tab}
        onChange={setTab}
      />
      <div className="space-y-3 pt-3">
        <ErrorBox error={error} />
        <Field label="Nom du module dans le projet (label)">
          <Input value={label} onChange={(e) => setLabel(e.target.value)} placeholder="ex. vpc" />
        </Field>
        {tab === "registry" ? (
          <>
            <div className="flex gap-2">
              <Input placeholder="Rechercher (ex. vpc aws)" value={q} onChange={(e) => setQ(e.target.value)} onKeyDown={(e) => e.key === "Enter" && search()} />
              <Button onClick={search} loading={loading}>
                Rechercher
              </Button>
            </div>
            <div className="max-h-72 space-y-1 overflow-y-auto">
              {hits.map((h) => (
                <button
                  key={h.id}
                  className={`block w-full rounded border px-2 py-1.5 text-left text-sm ${picked?.id === h.id ? "border-indigo-500 bg-indigo-50 dark:bg-indigo-950/40" : "border-slate-200 dark:border-slate-700"}`}
                  onClick={() => (setPicked(h), setVersion(""))}
                >
                  <div className="font-mono text-xs">
                    {h.namespace}/{h.name}/{h.provider} <span className="text-slate-400">{h.version}</span>
                  </div>
                  <div className="truncate text-xs text-slate-500">{h.description}</div>
                </button>
              ))}
            </div>
            {picked && (
              <div className="flex items-end gap-2">
                <Field label="Version (vide = contrainte ~> majeure courante)" className="flex-1">
                  <Input value={version} onChange={(e) => setVersion(e.target.value)} placeholder={picked.version} />
                </Field>
                <Button variant="primary" loading={loading} onClick={addRegistry}>
                  Ajouter
                </Button>
              </div>
            )}
          </>
        ) : (
          <>
            <Field
              label={tab === "git" ? "Source Git" : "Chemin"}
              help={tab === "git" ? 'ex. git::https://gitlab.local/infra/modules.git//vpc?ref=v1.2.0' : "ex. ./modules/vpc (relatif au code généré)"}
            >
              <Input value={source} onChange={(e) => setSource(e.target.value)} />
            </Field>
            <p className="text-xs text-slate-500">Les entrées et sorties se déclarent ensuite dans le panneau de propriétés du module.</p>
            <div className="flex justify-end">
              <Button variant="primary" disabled={!source} onClick={() => add({ sourceKind: tab, source, inputs: [], outputs: [] }, source.split(/[/?]/).filter(Boolean).pop()?.replace(/\.git$/, "") || "module")}>
                Ajouter
              </Button>
            </div>
          </>
        )}
      </div>
    </Modal>
  );
}
