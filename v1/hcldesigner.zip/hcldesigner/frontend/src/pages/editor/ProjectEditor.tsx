// Page projet : conception (catalogue, canvas, propriétés), code, exécutions, environnements,
// state, versions, planification, partage et paramètres.
import { useCallback, useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Download, Package, Play, Redo2, Save, Undo2 } from "lucide-react";
import { api, ApiError, download } from "@/api/client";
import type { Environment, GenerateResult, ProjectDetail, Run } from "@/types/api";
import { useEditor } from "@/store/editor";
import { useLiveGenerate } from "@/lib/useLiveGenerate";
import { useCan } from "@/lib/auth";
import { Badge, Button, ErrorBox, IconButton, Spinner, Tabs, toast } from "@/components/ui";
import Canvas from "./Canvas";
import Catalog from "./Catalog";
import PropertiesPanel from "./PropertiesPanel";
import CodeView from "./CodeView";
import ExternalModuleDialog from "./ExternalModuleDialog";
import ExtractModuleDialog from "./ExtractModuleDialog";
import RunLauncher from "./RunLauncher";
import ProjectSettings from "../project/ProjectSettings";
import Environments from "../project/Environments";
import StateExplorer from "../project/StateExplorer";
import Versions from "../project/Versions";
import Sharing from "../project/Sharing";
import RunsTable from "../runs/RunsTable";
import SchedulesTable from "../admin/SchedulesTable";

type Tab = "design" | "code" | "runs" | "envs" | "state" | "versions" | "schedules" | "sharing" | "settings";

export default function ProjectEditor() {
  const { id = "" } = useParams();
  const navigate = useNavigate();
  const qc = useQueryClient();
  const can = useCan();
  const detail = useQuery({ queryKey: ["project", id], queryFn: () => api.get<ProjectDetail>(`/projects/${id}`) });
  const envs = useQuery({ queryKey: ["envs", id], queryFn: () => api.get<Environment[]>(`/projects/${id}/environments`) });
  const { model, dirty, serverVersion, past, future, selection, load, undo, redo, markSaved } = useEditor();
  const [tab, setTab] = useState<Tab>("design");
  const [saving, setSaving] = useState(false);
  const [externalModule, setExternalModule] = useState(false);
  const [extract, setExtract] = useState(false);
  const [launcher, setLauncher] = useState(false);
  const [savedFiles, setSavedFiles] = useState<Record<string, string> | null>(null);

  const p = detail.data?.project;
  const perms = detail.data?.permissions ?? {};
  useEffect(() => {
    if (p) load(p.model, p.version, !perms.edit);
  }, [p?.id, p?.version]); // eslint-disable-line react-hooks/exhaustive-deps

  // Code de la version enregistrée (référence du diff).
  useEffect(() => {
    if (p) api.post<GenerateResult>(`/projects/${id}/generate`, {}).then((r) => setSavedFiles(r.files)).catch(() => undefined);
  }, [p?.version]); // eslint-disable-line react-hooks/exhaustive-deps

  // Dernier plan en attente : actions projetées sur les nœuds du canvas.
  const setPlanOverlay = useEditor((s) => s.setPlanOverlay);
  const lastPlan = useQuery({
    queryKey: ["last-plan", id],
    queryFn: () => api.get<Run[]>(`/runs?project=${id}&status=planned&limit=1`),
    refetchInterval: 10000,
  });
  useEffect(() => setPlanOverlay(lastPlan.data?.[0]?.summary?.byNode ?? {}), [lastPlan.data, setPlanOverlay]);

  const live = useLiveGenerate(`/projects/${id}/generate`, model, "model", `/projects/${id}/policies/check`);

  const save = useCallback(async () => {
    if (!model || !dirty) return;
    const message = window.prompt("Message de la version (optionnel)", "") ?? "";
    setSaving(true);
    try {
      const r = await api.put<{ version: number }>(`/projects/${id}/model`, { version: serverVersion, model, message });
      markSaved(r.version);
      void qc.invalidateQueries({ queryKey: ["project", id] });
      toast.success(`Version ${r.version} enregistrée`);
    } catch (e) {
      toast.error(e instanceof ApiError && e.status === 409 ? "Le projet a été modifié par quelqu'un d'autre : rechargez la page." : e);
    } finally {
      setSaving(false);
    }
  }, [model, dirty, serverVersion, id, markSaved, qc]);

  // Raccourcis clavier globaux de l'éditeur
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const mod = e.ctrlKey || e.metaKey;
      if (!mod) return;
      const tag = (e.target as HTMLElement)?.tagName;
      if (e.key === "s") {
        e.preventDefault();
        void save();
      } else if (tag !== "INPUT" && tag !== "TEXTAREA" && e.key.toLowerCase() === "z") {
        e.preventDefault();
        if (e.shiftKey) redo();
        else undo();
      } else if (tag !== "INPUT" && tag !== "TEXTAREA" && e.key === "y") {
        e.preventDefault();
        redo();
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [save, undo, redo]);

  // Avertissement si l'on quitte avec des modifications non enregistrées
  useEffect(() => {
    const h = (e: BeforeUnloadEvent) => {
      if (useEditor.getState().dirty) e.preventDefault();
    };
    window.addEventListener("beforeunload", h);
    return () => window.removeEventListener("beforeunload", h);
  }, []);

  if (detail.isLoading) return <Spinner />;
  if (detail.error) return <div className="p-6"><ErrorBox error={detail.error} /></div>;
  if (!p || !model) return <Spinner />;

  const tabs: { id: Tab; label: string; hidden?: boolean }[] = [
    { id: "design", label: "Conception" },
    { id: "code", label: "Code", hidden: !can("code.view", id) },
    { id: "runs", label: "Exécutions" },
    { id: "envs", label: "Environnements" },
    { id: "state", label: "State" },
    { id: "versions", label: "Versions" },
    { id: "schedules", label: "Planification" },
    { id: "sharing", label: "Partage", hidden: !perms.share },
    { id: "settings", label: "Paramètres" },
  ];

  return (
    <div className="flex h-full flex-col">
      <header className="flex flex-wrap items-center gap-2 border-b border-slate-200 bg-white px-4 py-2 dark:border-slate-800 dark:bg-slate-900">
        <button className="text-sm text-slate-500 hover:underline" onClick={() => navigate("/projects")}>
          Projets
        </button>
        <span className="text-slate-400">/</span>
        <h1 className="text-base font-semibold">{p.name}</h1>
        <Badge>v{serverVersion}</Badge>
        {dirty && <Badge tone="yellow">modifications non enregistrées</Badge>}
        {!perms.edit && <Badge>lecture seule</Badge>}
        <span className="flex-1" />
        <IconButton title="Annuler (Ctrl+Z)" disabled={!past.length} onClick={undo}>
          <Undo2 className="h-4 w-4" />
        </IconButton>
        <IconButton title="Rétablir (Ctrl+Maj+Z)" disabled={!future.length} onClick={redo}>
          <Redo2 className="h-4 w-4" />
        </IconButton>
        {perms.modulesCreate && perms.edit && (
          <Button size="sm" icon={<Package className="h-3.5 w-3.5" />} disabled={selection.length < 1} onClick={() => setExtract(true)} title="Transformer la sélection en module">
            Extraire en module
          </Button>
        )}
        {perms.export && (
          <Button size="sm" icon={<Download className="h-3.5 w-3.5" />} onClick={() => download(`/projects/${id}/export`)}>
            Export ZIP
          </Button>
        )}
        <Button size="sm" icon={<Play className="h-3.5 w-3.5" />} onClick={() => setLauncher(true)} disabled={dirty} title={dirty ? "Enregistrez avant d'exécuter" : "init / validate / plan / destroy"}>
          Exécuter
        </Button>
        {perms.edit && (
          <Button size="sm" variant="primary" icon={<Save className="h-3.5 w-3.5" />} loading={saving} disabled={!dirty} onClick={save}>
            Enregistrer
          </Button>
        )}
      </header>
      <div className="bg-white px-4 dark:bg-slate-900">
        <Tabs tabs={tabs} value={tab} onChange={setTab} />
      </div>

      <div className="min-h-0 flex-1">
        {tab === "design" && (
          <div className="grid h-full grid-cols-[260px_1fr_360px]">
            <aside className="min-h-0 border-r border-slate-200 bg-slate-50 dark:border-slate-800 dark:bg-slate-900/50">
              <Catalog model={model} onRegistryModule={() => setExternalModule(true)} />
            </aside>
            <section className="min-h-0">
              <Canvas />
            </section>
            <aside className="min-h-0 overflow-y-auto border-l border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900">
              <PropertiesPanel />
            </aside>
          </div>
        )}
        {tab === "code" && (
          <div className="grid h-full grid-cols-[1fr_320px]">
            <CodeView result={live} saved={savedFiles} />
            <aside className="overflow-y-auto border-l border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900">
              <PropertiesPanel />
            </aside>
          </div>
        )}
        <div className={tab === "design" || tab === "code" ? "hidden" : "h-full overflow-y-auto p-4"}>
          {tab === "runs" && <RunsTable projectId={id} />}
          {tab === "envs" && <Environments projectId={id} canManage={!!perms.environments} />}
          {tab === "state" && <StateExplorer projectId={id} environments={envs.data ?? []} />}
          {tab === "versions" && <Versions projectId={id} canEdit={!!perms.edit} />}
          {tab === "schedules" && <SchedulesTable projectId={id} />}
          {tab === "sharing" && <Sharing projectId={id} environments={envs.data ?? []} />}
          {tab === "settings" && <ProjectSettings project={p} canEdit={!!perms.edit} canDelete={!!perms.delete} />}
        </div>
      </div>

      {externalModule && <ExternalModuleDialog onClose={() => setExternalModule(false)} />}
      {extract && <ExtractModuleDialog projectId={id} onClose={() => setExtract(false)} />}
      {launcher && <RunLauncher projectId={id} projectName={p.name} environments={envs.data ?? []} onClose={() => setLauncher(false)} />}
    </div>
  );
}
