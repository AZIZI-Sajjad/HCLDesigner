// Formulaire généré à partir d'un bloc de schéma : obligatoires d'abord, puis optionnels
// (valeur par défaut affichée), attributs calculés en lecture seule, blocs imbriqués.
import { useState } from "react";
import { ChevronDown, ChevronRight, Plus, Trash2, AlertTriangle, Lock } from "lucide-react";
import type { SchemaAttribute, SchemaBlock } from "@/types/api";
import type { Block, Project, Value } from "@/types/model";
import { attrType, isEmptyValue, writable } from "@/lib/schema";
import { Badge, IconButton, Input, cx } from "@/components/ui";
import { ExtractVariableButton, ValueInput } from "./ValueInput";

interface Props {
  block: SchemaBlock;
  attrs: Record<string, Value>;
  blocks?: Record<string, Block[]>;
  onAttr: (name: string, v: Value | undefined) => void;
  onBlocks: (name: string, list: Block[]) => void;
  model: Project;
  selfId?: string;
  defaults?: Record<string, unknown>;
  onExtract?: (name: string, attr: SchemaAttribute) => void;
  disabled?: boolean;
  depth?: number;
}

export function SchemaForm({ block, attrs, blocks, onAttr, onBlocks, model, selfId, defaults, onExtract, disabled, depth = 0 }: Props) {
  const [showOptional, setShowOptional] = useState(depth > 0);
  const [showComputed, setShowComputed] = useState(false);
  const [filter, setFilter] = useState("");
  const entries = Object.entries(block.attributes ?? {}).sort(([a], [b]) => a.localeCompare(b));
  const required = entries.filter(([, a]) => a.required);
  const optional = entries.filter(([n, a]) => !a.required && writable(a) && !(n === "id" && depth === 0));
  const computed = entries.filter(([, a]) => !writable(a));
  const setOptional = optional.filter(([n]) => !isEmptyValue(attrs[n]));
  const match = (n: string) => !filter || n.includes(filter.toLowerCase());

  const row = ([name, a]: [string, SchemaAttribute]) => (
    <AttrRow
      key={name}
      name={name}
      attr={a}
      value={attrs[name]}
      defaultValue={defaults?.[name]}
      onChange={(v) => onAttr(name, v)}
      model={model}
      selfId={selfId}
      onExtract={onExtract ? () => onExtract(name, a) : undefined}
      disabled={disabled}
    />
  );

  return (
    <div className="space-y-3">
      {depth === 0 && entries.length > 12 && <Input placeholder="Filtrer les attributs…" value={filter} onChange={(e) => setFilter(e.target.value)} />}
      {required.length > 0 && (
        <section className="space-y-2">
          <h4 className="text-[11px] font-semibold uppercase tracking-wide text-rose-600">Obligatoires</h4>
          {required.filter(([n]) => match(n)).map(row)}
        </section>
      )}
      {optional.length > 0 && (
        <section className="space-y-2">
          <button type="button" className="flex items-center gap-1 text-[11px] font-semibold uppercase tracking-wide text-slate-500" onClick={() => setShowOptional((s) => !s)}>
            {showOptional ? <ChevronDown className="h-3 w-3" /> : <ChevronRight className="h-3 w-3" />}
            Optionnels ({setOptional.length}/{optional.length} renseignés)
          </button>
          {(showOptional || filter ? optional : setOptional).filter(([n]) => match(n)).map(row)}
        </section>
      )}
      {Object.entries(block.block_types ?? {})
        .sort(([a], [b]) => a.localeCompare(b))
        .filter(([n]) => match(n))
        .map(([name, bt]) => (
          <NestedBlocks
            key={name}
            name={name}
            nesting={bt.nesting_mode}
            min={bt.min_items ?? 0}
            max={bt.max_items ?? 0}
            schema={bt.block}
            list={blocks?.[name] ?? []}
            onChange={(list) => onBlocks(name, list)}
            model={model}
            selfId={selfId}
            disabled={disabled}
            depth={depth}
          />
        ))}
      {depth === 0 && computed.length > 0 && (
        <section>
          <button type="button" className="flex items-center gap-1 text-[11px] font-semibold uppercase tracking-wide text-slate-500" onClick={() => setShowComputed((s) => !s)}>
            {showComputed ? <ChevronDown className="h-3 w-3" /> : <ChevronRight className="h-3 w-3" />}
            Attributs exportés (lecture seule) — {computed.length}
          </button>
          {showComputed && (
            <div className="mt-1 flex flex-wrap gap-1">
              {computed.map(([n, a]) => (
                <Badge key={n} title={a.description}>
                  {n}
                </Badge>
              ))}
            </div>
          )}
        </section>
      )}
    </div>
  );
}

function AttrRow({
  name,
  attr,
  value,
  defaultValue,
  onChange,
  model,
  selfId,
  onExtract,
  disabled,
}: {
  name: string;
  attr: SchemaAttribute;
  value?: Value;
  defaultValue?: unknown;
  onChange: (v: Value | undefined) => void;
  model: Project;
  selfId?: string;
  onExtract?: () => void;
  disabled?: boolean;
}) {
  const t = attrType(attr);
  const missing = attr.required && isEmptyValue(value);
  return (
    <div className={cx("space-y-1 rounded-md p-1.5", missing && "bg-rose-50 dark:bg-rose-950/30")}>
      <div className="flex items-center gap-1.5 text-xs">
        <span className="font-mono font-medium">{name}</span>
        <span className="text-slate-400">{t}</span>
        {attr.sensitive && <Lock className="h-3 w-3 text-amber-500" aria-label="sensible" />}
        {attr.deprecated && (
          <Badge tone="yellow">
            <AlertTriangle className="h-3 w-3" /> déprécié
          </Badge>
        )}
        <span className="flex-1" />
        {onExtract && !disabled && <ExtractVariableButton onExtract={onExtract} />}
      </div>
      <ValueInput
        value={value}
        onChange={onChange}
        type={t.startsWith("nested(") ? "dynamic" : t}
        model={model}
        selfId={selfId}
        sensitive={attr.sensitive}
        disabled={disabled}
        placeholder={defaultValue !== undefined ? `défaut : ${JSON.stringify(defaultValue)}` : attr.computed ? "calculé par le provider si vide" : undefined}
      />
      {defaultValue !== undefined && isEmptyValue(value) && <p className="text-[11px] text-slate-500">Défaut connu : {JSON.stringify(defaultValue)}</p>}
      {attr.description && <p className="line-clamp-2 text-[11px] text-slate-500" title={attr.description}>{attr.description}</p>}
    </div>
  );
}

function NestedBlocks({
  name,
  nesting,
  min,
  max,
  schema,
  list,
  onChange,
  model,
  selfId,
  disabled,
  depth,
}: {
  name: string;
  nesting: string;
  min: number;
  max: number;
  schema: SchemaBlock;
  list: Block[];
  onChange: (l: Block[]) => void;
  model: Project;
  selfId?: string;
  disabled?: boolean;
  depth: number;
}) {
  const [open, setOpen] = useState(list.length > 0 || min > 0);
  const single = nesting === "single" || nesting === "group" || max === 1;
  const canAdd = !disabled && (max === 0 || list.length < max) && !(single && list.length >= 1);
  const update = (i: number, b: Block) => onChange(list.map((x, j) => (j === i ? b : x)));
  return (
    <section className={cx("rounded-md border border-slate-200 dark:border-slate-700", min > 0 && list.length < min && "border-rose-300")}>
      <header className="flex items-center gap-1 px-2 py-1.5">
        <button type="button" className="flex flex-1 items-center gap-1 text-left text-xs font-medium" onClick={() => setOpen((o) => !o)}>
          {open ? <ChevronDown className="h-3 w-3" /> : <ChevronRight className="h-3 w-3" />}
          <span className="font-mono">{name}</span>
          <span className="text-slate-400">
            bloc {nesting}
            {min > 0 && `, min ${min}`}
            {max > 0 && `, max ${max}`} — {list.length}
          </span>
        </button>
        {canAdd && (
          <IconButton title={`Ajouter un bloc ${name}`} onClick={() => (onChange([...list, { attrs: {} }]), setOpen(true))}>
            <Plus className="h-3.5 w-3.5" />
          </IconButton>
        )}
      </header>
      {open &&
        list.map((b, i) => (
          <div key={i} className="space-y-2 border-t border-slate-100 p-2 dark:border-slate-800">
            <div className="flex items-center gap-2">
              {nesting === "map" ? (
                <Input className="w-40" placeholder="clé du bloc" value={b.key ?? ""} disabled={disabled} onChange={(e) => update(i, { ...b, key: e.target.value })} />
              ) : (
                <span className="text-[11px] text-slate-400">#{i + 1}</span>
              )}
              <span className="flex-1" />
              {!disabled && list.length > min && (
                <IconButton title="Supprimer ce bloc" onClick={() => onChange(list.filter((_, j) => j !== i))}>
                  <Trash2 className="h-3.5 w-3.5" />
                </IconButton>
              )}
            </div>
            <SchemaForm
              block={schema}
              attrs={b.attrs}
              blocks={b.blocks}
              onAttr={(n, v) => {
                const attrs = { ...b.attrs };
                if (v === undefined) delete attrs[n];
                else attrs[n] = v;
                update(i, { ...b, attrs });
              }}
              onBlocks={(n, l) => update(i, { ...b, blocks: { ...(b.blocks ?? {}), [n]: l } })}
              model={model}
              selfId={selfId}
              disabled={disabled}
              depth={depth + 1}
            />
          </div>
        ))}
    </section>
  );
}
