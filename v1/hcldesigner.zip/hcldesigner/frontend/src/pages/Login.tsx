import { useState, type FormEvent } from "react";
import { api } from "@/api/client";
import { Button, ErrorBox, Field, Input } from "@/components/ui";

/** Connexion (identifiant + mot de passe), puis code TOTP si la MFA est activée. */
export default function Login({ mfaPending, onDone }: { mfaPending: boolean; onDone: () => void }) {
  const [step, setStep] = useState<"password" | "mfa">(mfaPending ? "mfa" : "password");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [code, setCode] = useState("");
  const [error, setError] = useState<unknown>(null);
  const [loading, setLoading] = useState(false);

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      if (step === "password") {
        const r = await api.post<{ mfaRequired: boolean }>("/auth/login", { username, password });
        if (r.mfaRequired) setStep("mfa");
        else onDone();
      } else {
        await api.post("/auth/mfa/verify", { code });
        onDone();
      }
    } catch (err) {
      setError(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex min-h-full items-center justify-center bg-gradient-to-br from-slate-900 to-indigo-950 p-4">
      <form onSubmit={submit} className="w-full max-w-sm space-y-4 rounded-xl bg-white p-6 shadow-2xl dark:bg-slate-900">
        <div className="flex items-center gap-2">
          <img src="/favicon.svg" alt="" className="h-8 w-8" />
          <h1 className="text-lg font-semibold">HCLDesigner</h1>
        </div>
        {step === "password" ? (
          <>
            <Field label="Identifiant">
              <Input autoFocus autoComplete="username" value={username} onChange={(e) => setUsername(e.target.value)} />
            </Field>
            <Field label="Mot de passe">
              <Input type="password" autoComplete="current-password" value={password} onChange={(e) => setPassword(e.target.value)} />
            </Field>
          </>
        ) : (
          <Field label="Code de l'application d'authentification" help="6 chiffres, renouvelés toutes les 30 secondes.">
            <Input autoFocus inputMode="numeric" autoComplete="one-time-code" maxLength={6} value={code} onChange={(e) => setCode(e.target.value.replace(/\D/g, ""))} />
          </Field>
        )}
        <ErrorBox error={error} />
        <Button type="submit" variant="primary" className="w-full" loading={loading}>
          {step === "password" ? "Se connecter" : "Valider"}
        </Button>
      </form>
    </div>
  );
}
