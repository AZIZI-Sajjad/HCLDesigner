// Partage d'un projet : attribution de rôles à des utilisateurs ou équipes, sur le projet ou un environnement.
import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Trash2 } from "lucide-react";
import { api, qs } from "@/api/client";
import type { Environment } from "@/types/api";
import { Badge, Button, Card, IconButton, Select, toast } from "@/components/ui";

export interface BindingRow {
  id: string;
  roleId: string;
  roleName: string;
  userId: string | null;
  username: string;
  teamId: string | null;
  teamName: string;
  scope: string;
  projectId: string | null;
  projectName: string;
  environment: string;
}

export default function Sharing({ projectId, environments }: { projectId: string; environments: Environment[] }) {
  const bindings = useQuery({ queryKey: ["bindings", projectId], queryFn: () => api.get<BindingRow[]>("/admin/bindings" + qs({ project: projectId })) });
  const roles = useQuery({ queryKey: ["roles"], queryFn: () => api.get<{ id: string; name: string; permissions: string[] }[]>("/admin/roles") });
  const users = useQuery({ queryKey: ["directory"], queryFn: () => api.get<{ id: string; username: string; displayName: string }[]>("/directory/users") });
  const teams = useQuery({ queryKey: ["teams"], queryFn: () => api.get<{ id: string; name: string }[]>("/admin/teams"), retry: false });
  const [who, setWho] = useState("");
  const [roleId, setRoleId] = useState("");
  const [env, setEnv] = useState("");

  const add = async () => {
    const [kind, id] = who.split(":");
    try {
      await api.post("/admin/bindings", {
        roleId,
        userId: kind === "u" ? id : null,
        teamId: kind === "t" ? id : null,
        scope: env ? "environment" : "project",
        projectId,
        environment: env,
      });
      void bindings.refetch();
      toast.success("Accès attribué");
    } catch (e) {
      toast.error(e);
    }
  };

  return (
    <div className="mx-auto max-w-4xl space-y-4">
      <Card title="Accès au projet">
        <table className="w-full text-sm">
          <thead className="text-left text-xs text-slate-500">
            <tr>
              <th className="py-1">Utilisateur / équipe</th>
              <th>Rôle</th>
              <th>Portée</th>
              <th />
            </tr>
          </thead>
          <tbody>
            {(bindings.data ?? []).map((b) => (
              <tr key={b.id} className="border-t border-slate-100 dark:border-slate-800">
                <td className="py-1.5">{b.username || <Badge tone="purple">équipe {b.teamName}</Badge>}</td>
                <td>{b.roleName}</td>
                <td>{b.scope === "environment" ? `environnement ${b.environment}` : "projet entier"}</td>
                <td className="text-right">
                  <IconButton title="Retirer" onClick={() => void api.del(`/admin/bindings/${b.id}`).then(() => bindings.refetch(), toast.error)}>
                    <Trash2 className="h-4 w-4" />
                  </IconButton>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>
      <Card title="Ajouter un accès">
        <div className="flex flex-wrap gap-2">
          <Select className="w-60" value={who} onChange={(e) => setWho(e.target.value)}>
            <option value="">— utilisateur ou équipe —</option>
            <optgroup label="Utilisateurs">
              {(users.data ?? []).map((u) => (
                <option key={u.id} value={`u:${u.id}`}>
                  {u.displayName || u.username}
                </option>
              ))}
            </optgroup>
            {teams.data && (
              <optgroup label="Équipes">
                {teams.data.map((t) => (
                  <option key={t.id} value={`t:${t.id}`}>
                    {t.name}
                  </option>
                ))}
              </optgroup>
            )}
          </Select>
          <Select className="w-48" value={roleId} onChange={(e) => setRoleId(e.target.value)}>
            <option value="">— rôle —</option>
            {(roles.data ?? [])
              .filter((r) => !r.permissions.includes("*"))
              .map((r) => (
                <option key={r.id} value={r.id}>
                  {r.name}
                </option>
              ))}
          </Select>
          <Select className="w-48" value={env} onChange={(e) => setEnv(e.target.value)}>
            <option value="">Tout le projet</option>
            {environments.map((e) => (
              <option key={e.id} value={e.name}>
                Environnement {e.name}
              </option>
            ))}
          </Select>
          <Button variant="primary" disabled={!who || !roleId} onClick={add}>
            Attribuer
          </Button>
        </div>
      </Card>
    </div>
  );
}
