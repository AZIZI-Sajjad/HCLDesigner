// Environnements d'un projet : backend de state (formulaire par type), secrets, credentials,
// tfvars, protection, approbations, fenêtre de changement, test de connexion et migration de backend.
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Plus, ShieldCheck, Trash2 } from "lucide-react";
import { api } from "@/api/client";
import type { BackendType, ChangeWindow, Environment, Run } from "@/types/api";
import { useCan } from "@/lib/auth";
import { FieldsForm } from "@/components/FieldsForm";
import { Badge, Button, Card, ConfirmDialog, Empty, ErrorBox, Field, Input, Modal, Select, Textarea, Toggle, toast } from "@/components/ui";

const days = ["Lun", "Mar", "Mer", "Jeu", "Ven", "Sam", "Dim"];
const defaultWindow: ChangeWindow = { enabled: false, days: [1, 2, 3, 4], start: "08:00", end: "18:00", timezone: "Europe/Paris" };

export default function Environments({ projectId, canManage }: { projectId: string; canManage: boolean }) {
  const qc = useQueryClient();
  const envs = useQuery({ queryKey: ["envs", projectId], queryFn: () => api.get<Environment[]>(`/projects/${projectId}/environments`) });
  const backends = useQuery({ queryKey: ["backends"], queryFn: () => api.get<BackendType[]>("/backends") });
  const [editing, setEditing] = useState<Environment | "new" | null>(null);
  const [migrating, setMigrating] = useState<Environment | null>(null);
  const [deleting, setDeleting] = useState<Environment | null>(null);
  const navigate = useNavigate();

  const testInit = async (e: Environment) => {
    try {
      const run = await api.post<Run>(`/projects/${projectId}/runs`, { environmentId: e.id, operation: "init" });
      navigate(`/runs/${run.id}`);
    } catch (err) {
      toast.error(err);
    }
  };

  return (
    <div className="mx-auto max-w-5xl space-y-3">
      <div className="flex justify-between">
        <h2 className="text-base font-semibold">Environnements</h2>
        {canManage && (
          <Button variant="primary" icon={<Plus className="h-4 w-4" />} onClick={() => setEditing("new")}>
            Nouvel environnement
          </Button>
        )}
      </div>
      {envs.data?.length === 0 && <Empty>Aucun environnement.</Empty>}
      {(envs.data ?? []).map((e) => (
        <Card
          key={e.id}
          title={
            <span className="flex items-center gap-2">
              {e.name}
              {e.protected && (
                <Badge tone="red">
                  <ShieldCheck className="h-3 w-3" /> protégé
                </Badge>
              )}
              <Badge tone="indigo">backend {backends.data?.find((b) => b.type === e.backendType)?.label ?? e.backendType}</Badge>
            </span>
          }
          actions={
            canManage && (
              <>
                <Button size="sm" onClick={() => void testInit(e)}>
                  Tester (init)
                </Button>
                <Button size="sm" onClick={() => setMigrating(e)}>
                  Migrer le backend
                </Button>
                <Button size="sm" onClick={() => setEditing(e)}>
                  Modifier
                </Button>
                <Button size="sm" variant="ghost" icon={<Trash2 className="h-3.5 w-3.5" />} onClick={() => setDeleting(e)} />
              </>
            )
          }
        >
          <dl className="grid grid-cols-2 gap-x-6 gap-y-1 text-sm md:grid-cols-4">
            <dt className="text-slate-500">Approbations requises</dt>
            <dd>{e.requireApprovals}</dd>
            <dt className="text-slate-500">Destroy</dt>
            <dd>{e.allowDestroy ? "autorisé" : "désactivé"}</dd>
            <dt className="text-slate-500">Credentials</dt>
            <dd>{e.credentialIds.length}</dd>
            <dt className="text-slate-500">Fenêtre de changement</dt>
            <dd>{e.changeWindow.enabled ? `${e.changeWindow.days.map((d) => days[d - 1]).join(" ")} ${e.changeWindow.start}-${e.changeWindow.end}` : "aucune"}</dd>
            <dt className="text-slate-500">Workspace</dt>
            <dd>{e.workspace || "default"}</dd>
          </dl>
        </Card>
      ))}
      {editing && (
        <EnvForm
          projectId={projectId}
          env={editing === "new" ? null : editing}
          backends={backends.data ?? []}
          onClose={() => setEditing(null)}
          onSaved={() => (setEditing(null), void qc.invalidateQueries({ queryKey: ["envs", projectId] }))}
        />
      )}
      {migrating && <MigrateDialog env={migrating} backends={backends.data ?? []} onClose={() => setMigrating(null)} />}
      <ConfirmDialog
        open={!!deleting}
        danger
        onClose={() => setDeleting(null)}
        title="Supprimer l'environnement"
        message="Refusé si l'environnement possède encore un state."
        typeToConfirm={deleting?.name}
        onConfirm={async () => {
          try {
            await api.del(`/environments/${deleting!.id}`);
            setDeleting(null);
            void qc.invalidateQueries({ queryKey: ["envs", projectId] });
          } catch (e) {
            toast.error(e);
          }
        }}
      />
    </div>
  );
}

function EnvForm({ projectId, env, backends, onClose, onSaved }: { projectId: string; env: Environment | null; backends: BackendType[]; onClose: () => void; onSaved: () => void }) {
  const can = useCan();
  const credentials = useQuery({ queryKey: ["credentials"], queryFn: () => api.get<{ id: string; name: string; kind: string }[]>("/credentials"), retry: false });
  const [name, setName] = useState(env?.name ?? "");
  const [backendType, setBackendType] = useState(env?.backendType ?? "internal");
  const [config, setConfig] = useState<Record<string, unknown>>(env?.backendConfig ?? {});
  const [workspace, setWorkspace] = useState(env?.workspace ?? "");
  const [credentialIds, setCredentialIds] = useState<string[]>(env?.credentialIds ?? []);
  const [tfvars, setTfvars] = useState(env?.tfvars ?? "");
  const [isProtected, setProtected] = useState(env?.protected ?? false);
  const [approvals, setApprovals] = useState(env?.requireApprovals ?? 0);
  const [allowDestroy, setAllowDestroy] = useState(env?.allowDestroy ?? true);
  const [win, setWin] = useState<ChangeWindow>({ ...defaultWindow, ...(env?.changeWindow ?? {}) });
  const [error, setError] = useState<unknown>(null);
  const [saving, setSaving] = useState(false);
  const bt = backends.find((b) => b.type === backendType);
  const tfvarsVisible = env ? env.tfvarsVisible : true;
  const tfvarsEditable = can("variables.sensitive.edit", projectId, name);

  const save = async () => {
    setSaving(true);
    setError(null);
    try {
      const body = {
        name,
        backendType,
        backendConfig: config,
        workspace,
        credentialIds,
        tfvars: tfvarsVisible && tfvarsEditable ? tfvars : undefined,
        protected: isProtected,
        requireApprovals: approvals,
        allowDestroy,
        changeWindow: win,
      };
      if (env) await api.put(`/environments/${env.id}`, body);
      else await api.post(`/projects/${projectId}/environments`, body);
      toast.success("Environnement enregistré");
      onSaved();
    } catch (e) {
      setError(e);
    } finally {
      setSaving(false);
    }
  };

  return (
    <Modal
      open
      wide
      onClose={onClose}
      title={env ? `Environnement ${env.name}` : "Nouvel environnement"}
      footer={
        <>
          <Button onClick={onClose}>Annuler</Button>
          <Button variant="primary" loading={saving} onClick={save}>
            Enregistrer
          </Button>
        </>
      }
    >
      <div className="space-y-4">
        <ErrorBox error={error} />
        <div className="grid gap-3 md:grid-cols-3">
          <Field label="Nom" required>
            <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="prod" />
          </Field>
          <Field label="Workspace Terraform" help="Vide = default">
            <Input value={workspace} onChange={(e) => setWorkspace(e.target.value)} />
          </Field>
          <Field label="Backend de state">
            <Select value={backendType} onChange={(e) => (setBackendType(e.target.value), setConfig({}))}>
              {backends.map((b) => (
                <option key={b.type} value={b.type}>
                  {b.label}
                </option>
              ))}
            </Select>
          </Field>
        </div>
        {bt?.description && <p className="text-xs text-slate-500">{bt.description}</p>}
        {bt?.fields && bt.fields.length > 0 && (
          <FieldsForm fields={bt.fields} values={config} onChange={setConfig} secretsSet={env?.hasBackendSecrets && env.backendType === backendType ? bt.fields.filter((f) => f.secret).map((f) => f.name) : []} />
        )}

        <Field label="Credentials injectés dans le runner" help={credentials.error ? "Permission credentials.use requise pour les modifier." : undefined}>
          <div className="flex flex-wrap gap-2">
            {credentials.data?.length === 0 && <span className="text-xs text-slate-500">Aucun credential : créez-les dans Control panel → Credentials.</span>}
            {(credentials.data ?? []).map((c) => (
              <label key={c.id} className="flex items-center gap-1.5 rounded border border-slate-200 px-2 py-1 text-xs dark:border-slate-700">
                <input type="checkbox" checked={credentialIds.includes(c.id)} onChange={(e) => setCredentialIds(e.target.checked ? [...credentialIds, c.id] : credentialIds.filter((x) => x !== c.id))} />
                {c.name} <span className="text-slate-400">({c.kind})</span>
              </label>
            ))}
          </div>
        </Field>

        {tfvarsVisible ? (
          <Field label="Valeurs des variables (terraform.tfvars)" help={tfvarsEditable ? undefined : "Lecture seule : permission variables.sensitive.edit requise."}>
            <Textarea rows={6} value={tfvars} disabled={!tfvarsEditable} onChange={(e) => setTfvars(e.target.value)} placeholder={'region        = "eu-west-3"\ninstance_type = "t3.small"'} />
          </Field>
        ) : (
          <p className="text-xs text-slate-500">Les tfvars de cet environnement sont masqués (permission variables.sensitive.view).</p>
        )}

        <div className="grid gap-3 md:grid-cols-3">
          <Toggle checked={isProtected} onChange={setProtected} label="Environnement protégé (prod)" />
          <Field label="Approbations requises avant apply">
            <Input type="number" min={isProtected ? 1 : 0} max={10} value={approvals} onChange={(e) => setApprovals(Number(e.target.value))} />
          </Field>
          <Toggle checked={allowDestroy && !isProtected} disabled={isProtected} onChange={setAllowDestroy} label="Autoriser le destroy" />
        </div>

        <fieldset className="space-y-2 rounded-md border border-slate-200 p-3 dark:border-slate-700">
          <Toggle checked={win.enabled} onChange={(v) => setWin({ ...win, enabled: v })} label="Fenêtre de changement (apply / destroy autorisés uniquement)" />
          {win.enabled && (
            <div className="flex flex-wrap items-end gap-3">
              <div className="flex gap-1">
                {days.map((d, i) => (
                  <label key={d} className="flex items-center gap-1 text-xs">
                    <input type="checkbox" checked={win.days.includes(i + 1)} onChange={(e) => setWin({ ...win, days: e.target.checked ? [...win.days, i + 1] : win.days.filter((x) => x !== i + 1) })} />
                    {d}
                  </label>
                ))}
              </div>
              <Field label="Début">
                <Input type="time" value={win.start} onChange={(e) => setWin({ ...win, start: e.target.value })} />
              </Field>
              <Field label="Fin">
                <Input type="time" value={win.end} onChange={(e) => setWin({ ...win, end: e.target.value })} />
              </Field>
              <Field label="Fuseau">
                <Input value={win.timezone} onChange={(e) => setWin({ ...win, timezone: e.target.value })} />
              </Field>
            </div>
          )}
        </fieldset>
      </div>
    </Modal>
  );
}

function MigrateDialog({ env, backends, onClose }: { env: Environment; backends: BackendType[]; onClose: () => void }) {
  const navigate = useNavigate();
  const [type, setType] = useState(backends.find((b) => b.type !== env.backendType)?.type ?? "s3");
  const [config, setConfig] = useState<Record<string, unknown>>({});
  const [error, setError] = useState<unknown>(null);
  const [loading, setLoading] = useState(false);
  const bt = backends.find((b) => b.type === type);
  const submit = async () => {
    setLoading(true);
    try {
      const r = await api.post<{ pullRunId: string; pushRunId: string }>(`/environments/${env.id}/migrate`, { backendType: type, backendConfig: config });
      toast.success("Migration lancée : sauvegarde puis transfert du state");
      navigate(`/runs/${r.pullRunId}`);
    } catch (e) {
      setError(e);
    } finally {
      setLoading(false);
    }
  };
  return (
    <Modal
      open
      wide
      onClose={onClose}
      title={`Migrer le backend de ${env.name}`}
      footer={
        <>
          <Button onClick={onClose}>Annuler</Button>
          <Button variant="primary" loading={loading} onClick={submit}>
            Migrer
          </Button>
        </>
      }
    >
      <div className="space-y-3">
        <p className="text-sm">
          Deux exécutions s'enchaînent : <b>state pull</b> sur le backend actuel ({env.backendType}, copie chiffrée archivée), puis <b>state push</b> de cette copie dans le nouveau
          backend. Le push est annulé si la sauvegarde échoue.
        </p>
        <ErrorBox error={error} />
        <Field label="Nouveau backend">
          <Select value={type} onChange={(e) => (setType(e.target.value), setConfig({}))}>
            {backends
              .filter((b) => b.type !== env.backendType)
              .map((b) => (
                <option key={b.type} value={b.type}>
                  {b.label}
                </option>
              ))}
          </Select>
        </Field>
        {bt?.fields && <FieldsForm fields={bt.fields} values={config} onChange={setConfig} />}
      </div>
    </Modal>
  );
}
