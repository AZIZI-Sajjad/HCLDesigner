// Historique des versions du modèle : consultation, comparaison du code et restauration.
import { useMemo, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import type { ColumnDef } from "@tanstack/react-table";
import { DiffEditor } from "@monaco-editor/react";
import { api } from "@/api/client";
import type { GenerateResult } from "@/types/api";
import type { Project } from "@/types/model";
import { useEditor } from "@/store/editor";
import { registerHCL } from "@/lib/monaco";
import { DataTable } from "@/components/table/DataTable";
import { Button, ConfirmDialog, Modal, Select, formatDate, toast } from "@/components/ui";

registerHCL();

interface VersionItem {
  version: number;
  message: string;
  author: string;
  createdAt: string;
  nodes: number;
}

export default function Versions({ projectId, canEdit }: { projectId: string; canEdit: boolean }) {
  const qc = useQueryClient();
  const load = useEditor((s) => s.load);
  const versions = useQuery({ queryKey: ["versions", projectId], queryFn: () => api.get<VersionItem[]>(`/projects/${projectId}/versions`) });
  const [restore, setRestore] = useState<number | null>(null);
  const [compare, setCompare] = useState<number | null>(null);

  const cols = useMemo<ColumnDef<VersionItem, unknown>[]>(
    () => [
      { id: "version", header: "Version", accessorKey: "version", size: 90 },
      { id: "createdAt", header: "Date", accessorKey: "createdAt", size: 170, cell: (c) => formatDate(c.getValue() as string), meta: { text: (r) => formatDate(r.createdAt) } },
      { id: "author", header: "Auteur", accessorKey: "author", size: 140, meta: { filter: "multi" } },
      { id: "nodes", header: "Objets", accessorKey: "nodes", size: 90 },
      { id: "message", header: "Message", accessorKey: "message", size: 360 },
      {
        id: "actions",
        header: "Actions",
        size: 220,
        enableSorting: false,
        cell: ({ row }) => (
          <div className="flex gap-1" onClick={(e) => e.stopPropagation()}>
            <Button size="sm" onClick={() => setCompare(row.original.version)}>
              Comparer
            </Button>
            {canEdit && (
              <Button size="sm" onClick={() => setRestore(row.original.version)}>
                Restaurer
              </Button>
            )}
          </div>
        ),
      },
    ],
    [canEdit],
  );

  return (
    <div className="h-[calc(100vh-180px)]">
      <DataTable id="project-versions" title="Versions" data={versions.data ?? []} columns={cols} getRowId={(r) => String(r.version)} onRefresh={() => void versions.refetch()} />
      <ConfirmDialog
        open={restore !== null}
        onClose={() => setRestore(null)}
        title={`Restaurer la version ${restore}`}
        message="Le modèle de cette version devient une nouvelle version (l'historique est conservé)."
        onConfirm={async () => {
          try {
            await api.post(`/projects/${projectId}/versions/${restore}/restore`);
            const detail = await qc.fetchQuery({ queryKey: ["project", projectId], queryFn: () => api.get<{ project: { model: Project; version: number } }>(`/projects/${projectId}`) });
            load(detail.project.model, detail.project.version);
            void versions.refetch();
            toast.success("Version restaurée");
          } catch (e) {
            toast.error(e);
          }
          setRestore(null);
        }}
      />
      {compare !== null && <CompareDialog projectId={projectId} version={compare} onClose={() => setCompare(null)} />}
    </div>
  );
}

/** Compare le code généré d'une version avec le modèle courant de l'éditeur. */
function CompareDialog({ projectId, version, onClose }: { projectId: string; version: number; onClose: () => void }) {
  const current = useEditor((s) => s.model);
  const old = useQuery({
    queryKey: ["version-code", projectId, version],
    queryFn: async () => {
      const m = await api.get<Project>(`/projects/${projectId}/versions/${version}`);
      return api.post<GenerateResult>(`/projects/${projectId}/generate`, { model: m });
    },
  });
  const now = useQuery({ queryKey: ["current-code", projectId, current], queryFn: () => api.post<GenerateResult>(`/projects/${projectId}/generate`, { model: current }) });
  const files = [...new Set([...Object.keys(old.data?.files ?? {}), ...Object.keys(now.data?.files ?? {})])].sort();
  const [file, setFile] = useState("");
  const f = file || files[0] || "";
  return (
    <Modal open wide onClose={onClose} title={`Version ${version} ↔ modèle courant`}>
      <Select className="mb-2" value={f} onChange={(e) => setFile(e.target.value)}>
        {files.map((x) => (
          <option key={x}>{x}</option>
        ))}
      </Select>
      <div className="h-[55vh]">
        <DiffEditor original={old.data?.files[f] ?? ""} modified={now.data?.files[f] ?? ""} language="hcl" theme={document.documentElement.classList.contains("dark") ? "vs-dark" : "vs"} options={{ readOnly: true, minimap: { enabled: false } }} />
      </div>
    </Modal>
  );
}
