// Explorateur de state : ressources (dernière version ou version choisie), détail masqué,
// historique des versions, diff, téléchargement, opérations (list, mv, rm, import, force-unlock).
import { useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import type { ColumnDef } from "@tanstack/react-table";
import { api, download, qs } from "@/api/client";
import type { Environment, Run } from "@/types/api";
import { useCan } from "@/lib/auth";
import { DataTable } from "@/components/table/DataTable";
import { Button, Card, ConfirmDialog, Empty, Field, Input, Modal, Select, formatDate, toast } from "@/components/ui";

interface StateResource {
  address: string;
  mode: string;
  type: string;
  module?: string;
}
interface StateVersion {
  id: string;
  serial: number;
  lineage: string;
  resources: number;
  runId: string | null;
  reason: string;
  createdAt: string;
}

type StateOp = "mv" | "rm" | "import" | "unlock" | "list" | "pull";

export default function StateExplorer({ projectId, environments }: { projectId: string; environments: Environment[] }) {
  const can = useCan();
  const navigate = useNavigate();
  const [envId, setEnvId] = useState(environments[0]?.id ?? "");
  const [version, setVersion] = useState("");
  const [detail, setDetail] = useState<string | null>(null);
  const [op, setOp] = useState<{ cmd: StateOp; args: string[] } | null>(null);
  const [diff, setDiff] = useState<{ from: string; to: string } | null>(null);
  const env = environments.find((e) => e.id === envId);
  const resources = useQuery({
    queryKey: ["state-resources", envId, version],
    queryFn: () => api.get<{ serial: number; resources: StateResource[]; internal: boolean }>(`/environments/${envId}/state/resources` + qs({ version })),
    enabled: !!envId,
  });
  const versions = useQuery({ queryKey: ["state-versions", envId], queryFn: () => api.get<StateVersion[]>(`/environments/${envId}/state/versions`), enabled: !!envId });

  const runOp = async (cmd: StateOp, args: string[]) => {
    try {
      const run = await api.post<Run>(`/projects/${projectId}/runs`, { environmentId: envId, operation: "state", options: { stateCmd: cmd, stateArgs: args } });
      navigate(`/runs/${run.id}`);
    } catch (e) {
      toast.error(e);
    }
  };

  const resCols = useMemo<ColumnDef<StateResource, unknown>[]>(
    () => [
      { id: "address", header: "Adresse", accessorKey: "address", size: 380 },
      { id: "type", header: "Type", accessorKey: "type", size: 220, meta: { filter: "multi" } },
      { id: "mode", header: "Mode", accessorKey: "mode", size: 90, meta: { filter: "multi" } },
      { id: "module", header: "Module", accessorKey: "module", size: 160 },
    ],
    [],
  );
  const verCols = useMemo<ColumnDef<StateVersion, unknown>[]>(
    () => [
      { id: "createdAt", header: "Date", accessorKey: "createdAt", size: 160, cell: (c) => formatDate(c.getValue() as string), meta: { text: (r) => formatDate(r.createdAt) } },
      { id: "serial", header: "Serial", accessorKey: "serial", size: 80 },
      { id: "resources", header: "Ressources", accessorKey: "resources", size: 100 },
      { id: "reason", header: "Origine", accessorKey: "reason", size: 220 },
      {
        id: "actions",
        header: "Actions",
        size: 260,
        enableSorting: false,
        cell: ({ row }) => (
          <div className="flex gap-1" onClick={(e) => e.stopPropagation()}>
            <Button size="sm" onClick={() => setVersion(row.original.id)}>
              Afficher
            </Button>
            {can("state.download", projectId, env?.name) && (
              <Button size="sm" onClick={() => download(`/environments/${envId}/state/versions/${row.original.id}/download`)}>
                Télécharger
              </Button>
            )}
            {versions.data && versions.data[row.index + 1] && (
              <Button size="sm" onClick={() => setDiff({ from: versions.data![row.index + 1].id, to: row.original.id })}>
                Diff
              </Button>
            )}
          </div>
        ),
      },
    ],
    [can, projectId, env?.name, envId, versions.data],
  );

  if (!environments.length) return <Empty>Aucun environnement.</Empty>;
  const canEdit = can("state.edit", projectId, env?.name);
  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-end gap-2">
        <Field label="Environnement">
          <Select value={envId} onChange={(e) => (setEnvId(e.target.value), setVersion(""))}>
            {environments.map((e) => (
              <option key={e.id} value={e.id}>
                {e.name}
              </option>
            ))}
          </Select>
        </Field>
        {version && (
          <Button size="sm" onClick={() => setVersion("")}>
            Revenir à la dernière version
          </Button>
        )}
        <span className="flex-1" />
        {can("state.view", projectId, env?.name) && <Button onClick={() => void runOp("list", [])}>state list (backend)</Button>}
        {can("state.download", projectId, env?.name) && <Button onClick={() => void runOp("pull", [])}>Sauvegarder (state pull)</Button>}
        {canEdit && (
          <>
            <Button onClick={() => setOp({ cmd: "mv", args: ["", ""] })}>state mv</Button>
            <Button onClick={() => setOp({ cmd: "import", args: ["", ""] })}>import</Button>
          </>
        )}
        {can("state.unlock", projectId, env?.name) && <Button onClick={() => setOp({ cmd: "unlock", args: [""] })}>force-unlock</Button>}
      </div>
      <p className="text-xs text-slate-500">
        Contenu issu de la dernière copie archivée par HCLDesigner (après chaque apply ou sauvegarde). Serial {resources.data?.serial ?? "—"}.
      </p>
      <div className="h-[420px]">
        <DataTable
          id="state-resources"
          title="Ressources du state"
          data={resources.data?.resources ?? []}
          columns={resCols}
          loading={resources.isFetching}
          onRefresh={() => void resources.refetch()}
          onRowClick={(r) => setDetail(r.address)}
          getRowId={(r) => r.address}
          bulkActions={
            canEdit
              ? (rows, clear) => (
                  <Button size="sm" variant="danger" onClick={() => (setOp({ cmd: "rm", args: rows.map((r) => r.address) }), clear())}>
                    state rm
                  </Button>
                )
              : undefined
          }
        />
      </div>
      <Card title="Historique des versions">
        <div className="h-80">
          <DataTable id="state-versions" data={versions.data ?? []} columns={verCols} getRowId={(r) => r.id} onRefresh={() => void versions.refetch()} />
        </div>
      </Card>
      {detail && <ResourceDetail envId={envId} version={version} address={detail} onClose={() => setDetail(null)} />}
      {diff && <DiffDialog envId={envId} {...diff} onClose={() => setDiff(null)} />}
      {op && op.cmd === "rm" && (
        <ConfirmDialog
          open
          danger
          onClose={() => setOp(null)}
          title="Retirer du state"
          message={<>Les ressources suivantes ne seront plus gérées par Terraform (elles ne sont pas détruites) : {op.args.join(", ")}. Une sauvegarde du state est faite avant.</>}
          typeToConfirm={env?.name}
          onConfirm={() => (void runOp("rm", op.args), setOp(null))}
        />
      )}
      {op && op.cmd !== "rm" && <StateOpDialog op={op} onClose={() => setOp(null)} onRun={(args) => (void runOp(op.cmd, args), setOp(null))} />}
    </div>
  );
}

function ResourceDetail({ envId, version, address, onClose }: { envId: string; version: string; address: string; onClose: () => void }) {
  const q = useQuery({ queryKey: ["state-resource", envId, version, address], queryFn: () => api.get<{ attributes: Record<string, unknown>; dependencies?: string[] }>(`/environments/${envId}/state/resource` + qs({ address, version })) });
  return (
    <Modal open wide onClose={onClose} title={address}>
      <pre className="max-h-[60vh] overflow-auto rounded bg-slate-100 p-3 text-xs dark:bg-slate-800">{q.data ? JSON.stringify(q.data, null, 2) : "Chargement…"}</pre>
      <p className="mt-2 text-xs text-slate-500">Les valeurs sensibles sont masquées.</p>
    </Modal>
  );
}

function DiffDialog({ envId, from, to, onClose }: { envId: string; from: string; to: string; onClose: () => void }) {
  const q = useQuery({ queryKey: ["state-diff", from, to], queryFn: () => api.get<{ added: string[]; removed: string[]; changed: string[] }>(`/environments/${envId}/state/diff` + qs({ from, to })) });
  const section = (title: string, list: string[] | undefined, cls: string) => (
    <div>
      <h4 className={`text-sm font-semibold ${cls}`}>
        {title} ({list?.length ?? 0})
      </h4>
      <ul className="font-mono text-xs">{list?.map((a) => <li key={a}>{a}</li>)}</ul>
    </div>
  );
  return (
    <Modal open onClose={onClose} title="Différences entre versions">
      <div className="space-y-3">
        {section("Ajoutées", q.data?.added, "text-emerald-600")}
        {section("Modifiées", q.data?.changed, "text-amber-600")}
        {section("Supprimées", q.data?.removed, "text-rose-600")}
      </div>
    </Modal>
  );
}

function StateOpDialog({ op, onClose, onRun }: { op: { cmd: StateOp; args: string[] }; onClose: () => void; onRun: (args: string[]) => void }) {
  const [args, setArgs] = useState(op.args);
  const labels: Record<string, string[]> = { mv: ["Adresse source", "Adresse cible"], import: ["Adresse Terraform", "ID de la ressource existante"], unlock: ["ID du verrou"] };
  const titles: Record<string, string> = { mv: "Déplacer une ressource dans le state", import: "Importer une ressource existante", unlock: "Forcer la libération du verrou" };
  return (
    <Modal
      open
      onClose={onClose}
      title={titles[op.cmd] ?? op.cmd}
      footer={
        <>
          <Button onClick={onClose}>Annuler</Button>
          <Button variant="primary" disabled={args.some((a) => !a.trim())} onClick={() => onRun(args.map((a) => a.trim()))}>
            Exécuter
          </Button>
        </>
      }
    >
      <div className="space-y-3">
        {(labels[op.cmd] ?? []).map((l, i) => (
          <Field key={l} label={l}>
            <Input className="font-mono" value={args[i] ?? ""} onChange={(e) => setArgs(args.map((a, j) => (j === i ? e.target.value : a)))} />
          </Field>
        ))}
        {op.cmd !== "unlock" && <p className="text-xs text-slate-500">Une sauvegarde du state est faite automatiquement avant la modification.</p>}
      </div>
    </Modal>
  );
}
