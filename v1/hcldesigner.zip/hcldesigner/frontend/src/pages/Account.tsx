// Mon compte : mot de passe, MFA (TOTP), jetons d'API personnels, abonnements aux notifications.
import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Trash2 } from "lucide-react";
import { api } from "@/api/client";
import type { ProjectListItem } from "@/types/api";
import { useAuth } from "@/lib/auth";
import { Badge, Button, Card, Field, IconButton, Input, PageHeader, Select, formatDate, toast } from "@/components/ui";

export default function Account() {
  const { me, refresh } = useAuth();
  return (
    <div className="mx-auto max-w-4xl space-y-4 p-6">
      <PageHeader title="Mon compte" subtitle={`${me.displayName || me.username} — ${me.email}`} />
      {me.mfaSetupRequired && <div className="rounded bg-amber-50 p-3 text-sm text-amber-900 dark:bg-amber-950 dark:text-amber-200">La politique de sécurité impose l'activation de la double authentification.</div>}
      <PasswordCard />
      <MFACard enabled={me.totpEnabled} onChange={refresh} />
      <SubscriptionsCard />
      <TokensCard />
    </div>
  );
}

function PasswordCard() {
  const [current, setCurrent] = useState("");
  const [next, setNext] = useState("");
  const [confirm, setConfirm] = useState("");
  const submit = async () => {
    if (next !== confirm) return toast.error("Les deux saisies diffèrent.");
    try {
      await api.post("/auth/password", { current, new: next });
      toast.success("Mot de passe modifié ; vos autres sessions ont été fermées.");
      setCurrent("");
      setNext("");
      setConfirm("");
    } catch (e) {
      toast.error(e);
    }
  };
  return (
    <Card title="Mot de passe">
      <div className="grid gap-3 md:grid-cols-3">
        <Field label="Actuel">
          <Input type="password" value={current} onChange={(e) => setCurrent(e.target.value)} />
        </Field>
        <Field label="Nouveau">
          <Input type="password" value={next} onChange={(e) => setNext(e.target.value)} />
        </Field>
        <Field label="Confirmation">
          <Input type="password" value={confirm} onChange={(e) => setConfirm(e.target.value)} />
        </Field>
      </div>
      <Button className="mt-3" variant="primary" disabled={!current || !next} onClick={submit}>
        Modifier
      </Button>
    </Card>
  );
}

function MFACard({ enabled, onChange }: { enabled: boolean; onChange: () => void }) {
  const [setup, setSetup] = useState<{ uri: string; secret: string } | null>(null);
  const [code, setCode] = useState("");
  const [pw, setPw] = useState("");
  return (
    <Card title={<span>Double authentification {enabled ? <Badge tone="green">active</Badge> : <Badge>inactive</Badge>}</span>}>
      {enabled ? (
        <div className="flex items-end gap-2">
          <Field label="Mot de passe pour désactiver">
            <Input type="password" value={pw} onChange={(e) => setPw(e.target.value)} />
          </Field>
          <Button variant="danger" onClick={() => void api.post("/auth/mfa/disable", { password: pw }).then(() => (toast.success("MFA désactivée"), onChange()), toast.error)}>
            Désactiver
          </Button>
        </div>
      ) : setup ? (
        <div className="space-y-3 text-sm">
          <p>Ajoutez ce compte dans votre application (Google Authenticator, FreeOTP, Bitwarden…) via l'URI ou la clé, puis saisissez le code affiché.</p>
          <code className="block break-all rounded bg-slate-100 p-2 text-xs dark:bg-slate-800">{setup.uri}</code>
          <div className="flex items-end gap-2">
            <Field label="Code">
              <Input value={code} maxLength={6} onChange={(e) => setCode(e.target.value.replace(/\D/g, ""))} />
            </Field>
            <Button variant="primary" onClick={() => void api.post("/auth/mfa/enable", { code }).then(() => (toast.success("MFA activée"), setSetup(null), onChange()), toast.error)}>
              Activer
            </Button>
          </div>
        </div>
      ) : (
        <Button onClick={() => void api.post<{ uri: string; secret: string }>("/auth/mfa/setup").then(setSetup, toast.error)}>Configurer</Button>
      )}
    </Card>
  );
}

function SubscriptionsCard() {
  const events = useQuery({ queryKey: ["notif-events"], queryFn: () => api.get<{ event: string; label: string }[]>("/notifications/events") });
  const rules = useQuery({ queryKey: ["notif-rules"], queryFn: () => api.get<{ id: string; projectId: string | null; projectName: string; events: string[]; digest: string }[]>("/notifications/rules") });
  const projects = useQuery({ queryKey: ["projects"], queryFn: () => api.get<ProjectListItem[]>("/projects") });
  const [projectId, setProjectId] = useState("");
  const [selected, setSelected] = useState<string[]>([]);
  const [digest, setDigest] = useState("none");
  const add = async () => {
    try {
      await api.post("/notifications/rules", { projectId: projectId || null, events: selected, digest });
      setSelected([]);
      void rules.refetch();
    } catch (e) {
      toast.error(e);
    }
  };
  const label = (e: string) => events.data?.find((x) => x.event === e)?.label ?? e;
  return (
    <Card title="Notifications par mail">
      <div className="space-y-2">
        {(rules.data ?? []).map((r) => (
          <div key={r.id} className="flex items-start gap-2 rounded border border-slate-200 p-2 text-sm dark:border-slate-700">
            <div className="flex-1">
              <div className="font-medium">
                {r.projectName || "Tous les projets"} {r.digest !== "none" && <Badge>{r.digest === "daily" ? "résumé quotidien" : "résumé hebdo"}</Badge>}
              </div>
              <div className="text-xs text-slate-500">{r.events.map(label).join(" · ")}</div>
            </div>
            <IconButton title="Supprimer" onClick={() => void api.del(`/notifications/rules/${r.id}`).then(() => rules.refetch())}>
              <Trash2 className="h-4 w-4" />
            </IconButton>
          </div>
        ))}
      </div>
      <div className="mt-4 space-y-2 border-t border-slate-200 pt-3 dark:border-slate-800">
        <div className="flex gap-2">
          <Select className="w-64" value={projectId} onChange={(e) => setProjectId(e.target.value)}>
            <option value="">Tous les projets</option>
            {(projects.data ?? []).map((p) => (
              <option key={p.id} value={p.id}>
                {p.name}
              </option>
            ))}
          </Select>
          <Select className="w-48" value={digest} onChange={(e) => setDigest(e.target.value)}>
            <option value="none">Envoi immédiat</option>
            <option value="daily">Résumé quotidien</option>
            <option value="weekly">Résumé hebdomadaire</option>
          </Select>
        </div>
        <div className="grid gap-1 md:grid-cols-2">
          {(events.data ?? []).map((e) => (
            <label key={e.event} className="flex items-center gap-2 text-sm">
              <input type="checkbox" checked={selected.includes(e.event)} onChange={(x) => setSelected(x.target.checked ? [...selected, e.event] : selected.filter((s) => s !== e.event))} />
              {e.label}
            </label>
          ))}
        </div>
        <Button variant="primary" disabled={!selected.length} onClick={add}>
          S'abonner
        </Button>
      </div>
    </Card>
  );
}

function TokensCard() {
  const tokens = useQuery({ queryKey: ["tokens"], queryFn: () => api.get<{ id: string; name: string; prefix: string; expiresAt: string | null; lastUsed: string | null; createdAt: string }[]>("/auth/tokens") });
  const [name, setName] = useState("");
  const [expires, setExpires] = useState("");
  const [created, setCreated] = useState<string | null>(null);
  const create = async () => {
    try {
      const r = await api.post<{ token: string }>("/auth/tokens", { name, expiresAt: expires ? new Date(expires).toISOString() : null });
      setCreated(r.token);
      setName("");
      void tokens.refetch();
    } catch (e) {
      toast.error(e);
    }
  };
  return (
    <Card title="Jetons d'API">
      <p className="mb-2 text-xs text-slate-500">Utilisation : en-tête « Authorization: Bearer &lt;jeton&gt; ». Le jeton porte vos permissions.</p>
      {created && (
        <div className="mb-3 rounded bg-emerald-50 p-2 text-sm dark:bg-emerald-950">
          Copiez ce jeton maintenant, il ne sera plus affiché : <code className="break-all">{created}</code>
        </div>
      )}
      {(tokens.data ?? []).map((t) => (
        <div key={t.id} className="flex items-center gap-2 border-b border-slate-100 py-1.5 text-sm dark:border-slate-800">
          <span className="flex-1">
            {t.name} <code className="text-xs text-slate-500">{t.prefix}…</code>
          </span>
          <span className="text-xs text-slate-500">
            {t.expiresAt ? `expire ${formatDate(t.expiresAt)}` : "sans expiration"} · utilisé {t.lastUsed ? formatDate(t.lastUsed) : "jamais"}
          </span>
          <IconButton title="Révoquer" onClick={() => void api.del(`/auth/tokens/${t.id}`).then(() => tokens.refetch())}>
            <Trash2 className="h-4 w-4" />
          </IconButton>
        </div>
      ))}
      <div className="mt-3 flex items-end gap-2">
        <Field label="Nom">
          <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="ci-gitlab" />
        </Field>
        <Field label="Expiration">
          <Input type="date" value={expires} onChange={(e) => setExpires(e.target.value)} />
        </Field>
        <Button variant="primary" disabled={!name} onClick={create}>
          Créer
        </Button>
      </div>
    </Card>
  );
}
