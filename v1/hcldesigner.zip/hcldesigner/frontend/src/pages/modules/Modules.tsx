// Bibliothèque de modules : liste, recherche, création.
import { useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import type { ColumnDef } from "@tanstack/react-table";
import { Plus } from "lucide-react";
import { api } from "@/api/client";
import type { ModuleRow, ProjectListItem } from "@/types/api";
import { useCan } from "@/lib/auth";
import { DataTable } from "@/components/table/DataTable";
import { Badge, Button, ErrorBox, Field, Input, Modal, PageHeader, Select, formatDate } from "@/components/ui";

export default function Modules() {
  const navigate = useNavigate();
  const can = useCan();
  const list = useQuery({ queryKey: ["modules"], queryFn: () => api.get<ModuleRow[]>("/modules") });
  const [creating, setCreating] = useState(false);
  const columns = useMemo<ColumnDef<ModuleRow, unknown>[]>(
    () => [
      { id: "name", header: "Nom", accessorKey: "name", size: 200 },
      { id: "description", header: "Description", accessorKey: "description", size: 280 },
      { id: "latest", header: "Dernière version", accessorKey: "latest", size: 120, cell: (c) => (c.getValue() ? <Badge tone="indigo">{c.getValue() as string}</Badge> : <Badge>brouillon</Badge>) },
      { id: "scope", header: "Portée", accessorKey: "scope", size: 100, meta: { filter: "multi" } },
      { id: "tags", header: "Tags", accessorFn: (m) => m.tags.join(", "), size: 160 },
      { id: "inputs", header: "Entrées", accessorFn: (m) => m.inputs.length, size: 80 },
      { id: "outputs", header: "Sorties", accessorFn: (m) => m.outputs.length, size: 80 },
      { id: "updatedAt", header: "Modifié", accessorKey: "updatedAt", size: 150, cell: (c) => formatDate(c.getValue() as string), meta: { text: (m) => formatDate(m.updatedAt) } },
    ],
    [],
  );
  return (
    <div className="p-6">
      <PageHeader
        title="Modules"
        subtitle="Modules internes versionnés, utilisables dans tous les projets"
        actions={
          can("modules.create") && (
            <Button variant="primary" icon={<Plus className="h-4 w-4" />} onClick={() => setCreating(true)}>
              Nouveau module
            </Button>
          )
        }
      />
      <div className="h-[calc(100vh-150px)]">
        <DataTable id="modules" title="Modules" data={list.data ?? []} columns={columns} loading={list.isFetching} onRefresh={() => void list.refetch()} onRowClick={(m) => navigate(`/modules/${m.id}`)} getRowId={(m) => m.id} />
      </div>
      {creating && <CreateModule onClose={() => setCreating(false)} onCreated={(id) => navigate(`/modules/${id}`)} />}
    </div>
  );
}

function CreateModule({ onClose, onCreated }: { onClose: () => void; onCreated: (id: string) => void }) {
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [scope, setScope] = useState("global");
  const [projectId, setProjectId] = useState("");
  const [tags, setTags] = useState("");
  const [error, setError] = useState<unknown>(null);
  const projects = useQuery({ queryKey: ["projects"], queryFn: () => api.get<ProjectListItem[]>("/projects"), enabled: scope === "project" });
  const create = async () => {
    try {
      const r = await api.post<{ id: string }>("/modules", { name, description, scope, projectId: scope === "project" ? projectId : null, tags: tags.split(",").map((t) => t.trim()).filter(Boolean) });
      onCreated(r.id);
    } catch (e) {
      setError(e);
    }
  };
  return (
    <Modal
      open
      onClose={onClose}
      title="Nouveau module"
      footer={
        <>
          <Button onClick={onClose}>Annuler</Button>
          <Button variant="primary" disabled={!/^[a-zA-Z_][a-zA-Z0-9_-]*$/.test(name)} onClick={create}>
            Créer
          </Button>
        </>
      }
    >
      <div className="space-y-3">
        <ErrorBox error={error} />
        <Field label="Nom" required help="Lettres, chiffres, _ et -">
          <Input autoFocus value={name} onChange={(e) => setName(e.target.value)} />
        </Field>
        <Field label="Description">
          <Input value={description} onChange={(e) => setDescription(e.target.value)} />
        </Field>
        <Field label="Portée">
          <Select value={scope} onChange={(e) => setScope(e.target.value)}>
            <option value="global">Globale (tous les projets)</option>
            <option value="team">Équipe</option>
            <option value="project">Projet</option>
          </Select>
        </Field>
        {scope === "project" && (
          <Field label="Projet">
            <Select value={projectId} onChange={(e) => setProjectId(e.target.value)}>
              <option value="">—</option>
              {(projects.data ?? []).map((p) => (
                <option key={p.id} value={p.id}>
                  {p.name}
                </option>
              ))}
            </Select>
          </Field>
        )}
        <Field label="Tags (séparés par des virgules)">
          <Input value={tags} onChange={(e) => setTags(e.target.value)} />
        </Field>
      </div>
    </Modal>
  );
}
