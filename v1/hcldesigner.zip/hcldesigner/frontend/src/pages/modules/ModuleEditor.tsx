// Éditeur de module : même canvas que les projets ; les variables sont les entrées du module,
// les outputs ses sorties. Publication en versions sémantiques avec contrôle des ruptures d'interface.
import { useCallback, useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Redo2, Save, Tag, Undo2 } from "lucide-react";
import { api } from "@/api/client";
import type { ModuleRow } from "@/types/api";
import { useEditor } from "@/store/editor";
import { useLiveGenerate } from "@/lib/useLiveGenerate";
import { useCan } from "@/lib/auth";
import { Badge, Button, ErrorBox, Field, IconButton, Input, Modal, Spinner, Tabs, Textarea, toast } from "@/components/ui";
import Canvas from "../editor/Canvas";
import Catalog from "../editor/Catalog";
import PropertiesPanel from "../editor/PropertiesPanel";
import CodeView from "../editor/CodeView";
import ExternalModuleDialog from "../editor/ExternalModuleDialog";
import { ProvidersCard } from "../project/ProjectSettings";

export default function ModuleEditor() {
  const { id = "" } = useParams();
  const can = useCan();
  const qc = useQueryClient();
  const mod = useQuery({ queryKey: ["module", id], queryFn: () => api.get<ModuleRow>(`/modules/${id}`) });
  const { model, dirty, past, future, load, undo, redo, markSaved } = useEditor();
  const [tab, setTab] = useState<"design" | "code" | "providers" | "versions">("design");
  const [publish, setPublish] = useState(false);
  const [external, setExternal] = useState(false);
  const editable = can("modules.create");

  useEffect(() => {
    if (mod.data?.draft) load(mod.data.draft, 0, !editable);
  }, [mod.data?.id]); // eslint-disable-line react-hooks/exhaustive-deps

  const live = useLiveGenerate(`/modules/${id}/generate`, model, "draft");

  const save = useCallback(async () => {
    if (!model) return;
    try {
      await api.put(`/modules/${id}/draft`, { draft: model });
      markSaved(0);
      void qc.invalidateQueries({ queryKey: ["module", id] });
      toast.success("Brouillon enregistré");
    } catch (e) {
      toast.error(e);
    }
  }, [model, id, markSaved, qc]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key === "s") {
        e.preventDefault();
        void save();
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [save]);

  if (!mod.data || !model) return <Spinner />;
  return (
    <div className="flex h-full flex-col">
      <header className="flex items-center gap-2 border-b border-slate-200 bg-white px-4 py-2 dark:border-slate-800 dark:bg-slate-900">
        <Link to="/modules" className="text-sm text-slate-500 hover:underline">
          Modules
        </Link>
        <span className="text-slate-400">/</span>
        <h1 className="font-semibold">{mod.data.name}</h1>
        <Badge>{mod.data.latest || "jamais publié"}</Badge>
        {dirty && <Badge tone="yellow">brouillon modifié</Badge>}
        <span className="flex-1" />
        <IconButton title="Annuler" disabled={!past.length} onClick={undo}>
          <Undo2 className="h-4 w-4" />
        </IconButton>
        <IconButton title="Rétablir" disabled={!future.length} onClick={redo}>
          <Redo2 className="h-4 w-4" />
        </IconButton>
        {editable && (
          <Button size="sm" icon={<Save className="h-3.5 w-3.5" />} disabled={!dirty} onClick={save}>
            Enregistrer le brouillon
          </Button>
        )}
        {can("modules.publish") && (
          <Button size="sm" variant="primary" icon={<Tag className="h-3.5 w-3.5" />} disabled={dirty} title={dirty ? "Enregistrez d'abord le brouillon" : undefined} onClick={() => setPublish(true)}>
            Publier une version
          </Button>
        )}
      </header>
      <div className="bg-white px-4 dark:bg-slate-900">
        <Tabs
          tabs={[
            { id: "design", label: "Conception" },
            { id: "code", label: "Code" },
            { id: "providers", label: "Providers" },
            { id: "versions", label: "Versions" },
          ]}
          value={tab}
          onChange={setTab}
        />
      </div>
      <div className="min-h-0 flex-1">
        {tab === "design" && (
          <div className="grid h-full grid-cols-[260px_1fr_360px]">
            <aside className="min-h-0 border-r border-slate-200 dark:border-slate-800">
              <Catalog model={model} onRegistryModule={() => setExternal(true)} />
            </aside>
            <Canvas />
            <aside className="min-h-0 overflow-y-auto border-l border-slate-200 dark:border-slate-800">
              <PropertiesPanel />
            </aside>
          </div>
        )}
        {tab === "code" && <CodeView result={live} />}
        {tab === "providers" && (
          <div className="h-full overflow-y-auto p-4">
            <ProvidersCard canEdit={editable} />
          </div>
        )}
        {tab === "versions" && <VersionsList module={mod.data} />}
      </div>
      {publish && <PublishDialog module={mod.data} onClose={() => setPublish(false)} onDone={() => (setPublish(false), void mod.refetch())} />}
      {external && <ExternalModuleDialog onClose={() => setExternal(false)} />}
    </div>
  );
}

function bump(v: string, part: 0 | 1 | 2): string {
  const n = (v || "0.0.0").split(".").map(Number);
  n[part]++;
  for (let i = part + 1; i < 3; i++) n[i] = 0;
  return n.join(".");
}

function PublishDialog({ module, onClose, onDone }: { module: ModuleRow; onClose: () => void; onDone: () => void }) {
  const [version, setVersion] = useState(module.latest ? bump(module.latest, 1) : "1.0.0");
  const [changelog, setChangelog] = useState("");
  const [error, setError] = useState<unknown>(null);
  const publish = async () => {
    try {
      await api.post(`/modules/${module.id}/versions`, { version, changelog });
      toast.success(`Version ${version} publiée`);
      onDone();
    } catch (e) {
      setError(e);
    }
  };
  return (
    <Modal
      open
      onClose={onClose}
      title="Publier une version"
      footer={
        <>
          <Button onClick={onClose}>Annuler</Button>
          <Button variant="primary" onClick={publish}>
            Publier
          </Button>
        </>
      }
    >
      <div className="space-y-3">
        <ErrorBox error={error} />
        <Field label="Version" help={module.latest ? `Dernière : ${module.latest}. Majeure si l'interface change de façon incompatible.` : undefined}>
          <div className="flex gap-1">
            <Input value={version} onChange={(e) => setVersion(e.target.value)} />
            {module.latest &&
              (["majeure", "mineure", "correctif"] as const).map((l, i) => (
                <Button key={l} size="sm" onClick={() => setVersion(bump(module.latest, i as 0 | 1 | 2))}>
                  {l}
                </Button>
              ))}
          </div>
        </Field>
        <Field label="Changelog">
          <Textarea rows={4} value={changelog} onChange={(e) => setChangelog(e.target.value)} />
        </Field>
        <div className="text-xs text-slate-500">
          Interface publiée : {module.inputs.length} entrée(s) ({module.inputs.map((i) => i.name).join(", ")}), {module.outputs.length} sortie(s).
        </div>
      </div>
    </Modal>
  );
}

function VersionsList({ module }: { module: ModuleRow }) {
  const [from, setFrom] = useState(module.versions[1] ?? "");
  const [to, setTo] = useState(module.versions[0] ?? "");
  const diff = useQuery({
    queryKey: ["module-diff", module.id, from, to],
    queryFn: () => api.get<{ changes: { kind: string; name: string; breaking?: boolean; from?: string; to?: string }[]; breaking: boolean }>(`/modules/${module.id}/diff?from=${from}&to=${to}`),
    enabled: !!from && !!to && from !== to,
  });
  return (
    <div className="mx-auto max-w-3xl space-y-4 p-4">
      <ul className="space-y-1">
        {module.versions.map((v) => (
          <li key={v} className="rounded border border-slate-200 px-3 py-2 text-sm dark:border-slate-700">
            <Badge tone="indigo">{v}</Badge>
          </li>
        ))}
      </ul>
      {module.versions.length > 1 && (
        <div className="space-y-2">
          <div className="flex items-center gap-2 text-sm">
            Comparer
            <select className="rounded border px-1 dark:bg-slate-900" value={from} onChange={(e) => setFrom(e.target.value)}>
              {module.versions.map((v) => (
                <option key={v}>{v}</option>
              ))}
            </select>
            →
            <select className="rounded border px-1 dark:bg-slate-900" value={to} onChange={(e) => setTo(e.target.value)}>
              {module.versions.map((v) => (
                <option key={v}>{v}</option>
              ))}
            </select>
            {diff.data && (diff.data.breaking ? <Badge tone="red">changement incompatible</Badge> : <Badge tone="green">compatible</Badge>)}
          </div>
          {diff.data?.changes.map((c, i) => (
            <div key={i} className="text-sm">
              {c.breaking ? "⚠" : "•"} {c.kind} <code>{c.name}</code> {c.from && `${c.from} → ${c.to}`}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
