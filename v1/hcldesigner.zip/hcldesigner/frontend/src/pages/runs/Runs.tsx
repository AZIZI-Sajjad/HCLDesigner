import { PageHeader } from "@/components/ui";
import RunsTable from "./RunsTable";

export default function Runs() {
  return (
    <div className="p-6">
      <PageHeader title="Exécutions" subtitle="init, validate, plan, apply, destroy et opérations de state de tous les projets visibles" />
      <RunsTable />
    </div>
  );
}
