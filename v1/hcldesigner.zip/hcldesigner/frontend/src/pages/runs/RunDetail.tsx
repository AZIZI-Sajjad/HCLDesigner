// Détail d'une exécution : logs en temps réel (WebSocket), résumé et détail du plan,
// conformité, diagnostics, approbations, apply / destroy avec confirmation forte, annulation.
import { useEffect, useRef, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { CheckCircle2, Download, Play, XCircle } from "lucide-react";
import { api, download } from "@/api/client";
import type { Run } from "@/types/api";
import { Badge, Button, Card, ConfirmDialog, ErrorBox, Field, Input, Modal, RunStatus, Spinner, Tabs, duration, formatDate, toast } from "@/components/ui";
import { opLabel } from "./RunsTable";

interface RunDetailResponse {
  run: Run;
  approvals: { userId: string; username: string; decision: string; comment: string; createdAt: string }[];
  applicableError: string;
  permissions: { apply: boolean; approve: boolean; cancel: boolean; code: boolean };
}

interface PlanChange {
  address: string;
  type: string;
  actions: string[];
  before: unknown;
  after: unknown;
}

const actionTone: Record<string, "green" | "yellow" | "red" | "purple" | "gray"> = { create: "green", update: "yellow", delete: "red", read: "gray" };

export default function RunDetail() {
  const { id = "" } = useParams();
  const navigate = useNavigate();
  const q = useQuery({
    queryKey: ["run", id],
    queryFn: () => api.get<RunDetailResponse>(`/runs/${id}`),
    refetchInterval: (query) => (["queued", "running"].includes(query.state.data?.run.status ?? "") ? 2000 : false),
  });
  const [tab, setTab] = useState<"logs" | "plan" | "diagnostics" | "files">("logs");
  const [confirmApply, setConfirmApply] = useState(false);
  const [decision, setDecision] = useState<"approve" | "reject" | null>(null);
  const [comment, setComment] = useState("");
  const [busy, setBusy] = useState(false);

  if (q.isLoading) return <Spinner />;
  if (q.error) return <div className="p-6"><ErrorBox error={q.error} /></div>;
  const { run, approvals, applicableError, permissions } = q.data!;
  const s = run.summary ?? {};
  const okCount = approvals.filter((a) => a.decision === "approve").length;

  const apply = async () => {
    setBusy(true);
    try {
      const r = await api.post<Run>(`/projects/${run.projectId}/runs`, { environmentId: run.environmentId, operation: "apply", planRunId: run.id });
      navigate(`/runs/${r.id}`);
    } catch (e) {
      toast.error(e);
    } finally {
      setBusy(false);
      setConfirmApply(false);
    }
  };

  const decide = async () => {
    try {
      await api.post(`/runs/${run.id}/approve`, { decision, comment });
      toast.success(decision === "approve" ? "Plan approuvé" : "Plan refusé");
      setDecision(null);
      void q.refetch();
    } catch (e) {
      toast.error(e);
    }
  };

  return (
    <div className="space-y-4 p-6">
      <div className="flex flex-wrap items-center gap-3">
        <Link to="/runs" className="text-sm text-slate-500 hover:underline">
          Exécutions
        </Link>
        <span className="text-slate-400">/</span>
        <h1 className="text-lg font-semibold">
          {opLabel(run)} — <Link className="hover:underline" to={`/projects/${run.projectId}`}>{run.projectName}</Link> / {run.environmentName}
        </h1>
        <RunStatus status={run.status} />
        <span className="flex-1" />
        {permissions.cancel && ["queued", "running", "planned"].includes(run.status) && (
          <Button onClick={() => void api.post(`/runs/${run.id}/cancel`).then(() => q.refetch(), toast.error)}>{run.status === "planned" ? "Écarter le plan" : "Annuler"}</Button>
        )}
        {run.status === "planned" && permissions.approve && run.approvalsRequired > 0 && (
          <>
            <Button variant="success" icon={<CheckCircle2 className="h-4 w-4" />} onClick={() => setDecision("approve")}>
              Approuver
            </Button>
            <Button variant="danger" icon={<XCircle className="h-4 w-4" />} onClick={() => setDecision("reject")}>
              Refuser
            </Button>
          </>
        )}
        {run.status === "planned" && permissions.apply && (
          <Button variant={run.destroy ? "danger" : "primary"} icon={<Play className="h-4 w-4" />} disabled={!!applicableError} title={applicableError} onClick={() => setConfirmApply(true)}>
            {run.destroy ? "Détruire (apply du plan)" : "Appliquer"}
          </Button>
        )}
      </div>

      <div className="grid gap-4 md:grid-cols-4">
        <Card title="Changements">
          {s.add !== undefined ? (
            <div className="flex gap-3 text-sm">
              <span className="text-emerald-600">+{s.add} créer</span>
              <span className="text-amber-600">~{s.change} modifier</span>
              <span className="text-orange-600">±{s.replace} remplacer</span>
              <span className="text-rose-600">−{s.destroy} détruire</span>
            </div>
          ) : (
            <span className="text-sm text-slate-500">—</span>
          )}
          {!!s.drift?.length && <p className="mt-2 text-sm text-violet-600">{s.drift.length} drift(s) détecté(s)</p>}
        </Card>
        <Card title="Exécution">
          <dl className="space-y-0.5 text-xs">
            <div>Créée {formatDate(run.createdAt)} par {run.createdByName || run.triggeredBy}</div>
            <div>Durée : {duration(run.startedAt, run.finishedAt)}</div>
            <div>Version du projet : {run.projectVersion}</div>
            {run.planExpiresAt && <div>Plan valable jusqu'au {formatDate(run.planExpiresAt)}</div>}
            {run.planRunId && (
              <div>
                Plan : <Link className="text-indigo-600" to={`/runs/${run.planRunId}`}>{run.planRunId.slice(0, 8)}</Link>
              </div>
            )}
          </dl>
        </Card>
        <Card title="Approbations">
          {run.approvalsRequired === 0 ? (
            <span className="text-sm text-slate-500">Aucune requise</span>
          ) : (
            <div className="space-y-1 text-xs">
              <div className="font-medium">
                {okCount} / {run.approvalsRequired}
              </div>
              {approvals.map((a) => (
                <div key={a.userId}>
                  <Badge tone={a.decision === "approve" ? "green" : "red"}>{a.decision === "approve" ? "approuvé" : "refusé"}</Badge> {a.username} {a.comment && `— ${a.comment}`}
                </div>
              ))}
            </div>
          )}
        </Card>
        <Card title="Conformité">
          {run.policyReport?.violations?.length ? (
            <div className="space-y-1 text-xs">
              {run.policyReport.blocking && <Badge tone="red">bloquant</Badge>}
              {run.policyReport.violations.slice(0, 6).map((v, i) => (
                <div key={i}>
                  <Badge tone={v.severity === "blocking" ? "red" : v.severity === "warning" ? "yellow" : "gray"}>{v.severity}</Badge> {v.address} : {v.message}
                </div>
              ))}
            </div>
          ) : (
            <span className="text-sm text-slate-500">Aucune violation</span>
          )}
        </Card>
      </div>
      {applicableError && run.status === "planned" && <p className="text-sm text-amber-700 dark:text-amber-400">{applicableError}</p>}
      {run.error && <ErrorBox error={new Error(run.error)} />}

      <Tabs
        tabs={[
          { id: "logs", label: "Logs" },
          { id: "plan", label: "Détail du plan", hidden: run.operation !== "plan" && run.operation !== "apply" },
          { id: "diagnostics", label: `Diagnostics (${run.diagnostics?.length ?? 0})`, hidden: !run.diagnostics?.length },
          { id: "files", label: "Code exécuté", hidden: !permissions.code },
        ]}
        value={tab}
        onChange={setTab}
      />
      {tab === "logs" && <LogViewer runId={run.id} finished={!!run.finishedAt} onFinished={() => void q.refetch()} />}
      {tab === "plan" && <PlanDetail runId={run.id} />}
      {tab === "diagnostics" && (
        <div className="space-y-1">
          {run.diagnostics.map((d, i) => (
            <div key={i} className="rounded border border-slate-200 p-2 text-sm dark:border-slate-700">
              <Badge tone={d.severity === "error" ? "red" : "yellow"}>{d.severity}</Badge> {d.summary}{" "}
              <span className="text-xs text-slate-500">
                {d.file}:{d.line}
              </span>
              {d.detail && <p className="mt-1 text-xs text-slate-500">{d.detail}</p>}
            </div>
          ))}
        </div>
      )}
      {tab === "files" && <RunFiles runId={run.id} />}

      <ConfirmDialog
        open={confirmApply}
        danger={run.destroy}
        loading={busy}
        onClose={() => setConfirmApply(false)}
        onConfirm={apply}
        title={run.destroy ? "Détruire l'infrastructure" : "Appliquer le plan"}
        confirmText={run.destroy ? "Détruire" : "Appliquer"}
        message={
          run.destroy ? (
            <>
              {s.destroy} ressource(s) de <b>{run.environmentName}</b> seront détruites définitivement.
            </>
          ) : (
            <>
              Application du plan sur <b>{run.environmentName}</b> : +{s.add} ~{s.change} ±{s.replace} −{s.destroy}.
            </>
          )
        }
        typeToConfirm={run.destroy ? `${run.projectName}/${run.environmentName}` : undefined}
      />
      <Modal
        open={!!decision}
        onClose={() => setDecision(null)}
        title={decision === "approve" ? "Approuver le plan" : "Refuser le plan"}
        footer={
          <>
            <Button onClick={() => setDecision(null)}>Annuler</Button>
            <Button variant={decision === "approve" ? "success" : "danger"} onClick={decide}>
              Confirmer
            </Button>
          </>
        }
      >
        <Field label="Commentaire">
          <Input value={comment} onChange={(e) => setComment(e.target.value)} />
        </Field>
      </Modal>
    </div>
  );
}

/** Conversion minimale des codes ANSI (couleurs terraform) en spans. */
function ansiToHtml(text: string): string {
  const esc = text.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  const map: Record<string, string> = { "31": "ansi-red", "32": "ansi-green", "33": "ansi-yellow", "36": "ansi-cyan", "1": "ansi-bold" };
  let open = 0;
  const out = esc.replace(/\x1b\[([\d;]*)m/g, (_m, codes: string) => {
    let s = "";
    for (const c of codes.split(";")) {
      if (c === "0" || c === "") {
        s += "</span>".repeat(open);
        open = 0;
      } else if (map[c]) {
        s += `<span class="${map[c]}">`;
        open++;
      }
    }
    return s;
  });
  return out + "</span>".repeat(open);
}

function LogViewer({ runId, finished, onFinished }: { runId: string; finished: boolean; onFinished: () => void }) {
  const [text, setText] = useState("");
  const [search, setSearch] = useState("");
  const [follow, setFollow] = useState(true);
  const box = useRef<HTMLPreElement>(null);

  useEffect(() => {
    setText("");
    if (finished) {
      api.get<{ content: string }>(`/runs/${runId}/logs`).then((r) => setText(r.content)).catch(() => undefined);
      return;
    }
    const proto = location.protocol === "https:" ? "wss" : "ws";
    const ws = new WebSocket(`${proto}://${location.host}/api/runs/${runId}/ws`);
    ws.binaryType = "arraybuffer";
    ws.onmessage = (e) => {
      if (typeof e.data === "string") setText((t) => t + e.data);
      else {
        try {
          const msg = JSON.parse(new TextDecoder().decode(e.data));
          if (msg.event === "finished") onFinished();
        } catch {
          /* message binaire inattendu : ignoré */
        }
      }
    };
    return () => ws.close();
  }, [runId, finished]); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    if (follow && box.current) box.current.scrollTop = box.current.scrollHeight;
  }, [text, follow]);

  const shown = search ? text.split("\n").filter((l) => l.toLowerCase().includes(search.toLowerCase())).join("\n") : text;
  return (
    <div className="space-y-2">
      <div className="flex items-center gap-2">
        <Input className="w-72" placeholder="Rechercher dans les logs" value={search} onChange={(e) => setSearch(e.target.value)} />
        <label className="flex items-center gap-1 text-xs">
          <input type="checkbox" checked={follow} onChange={(e) => setFollow(e.target.checked)} /> suivre
        </label>
        <span className="flex-1" />
        <Button size="sm" icon={<Download className="h-3.5 w-3.5" />} onClick={() => download(`/runs/${runId}/logs?download=1`)}>
          Télécharger
        </Button>
      </div>
      <pre ref={box} className="h-[60vh] overflow-auto rounded-lg bg-slate-950 p-3 font-mono text-xs leading-relaxed text-slate-200" dangerouslySetInnerHTML={{ __html: ansiToHtml(shown) || "En attente du worker…" }} />
    </div>
  );
}

function PlanDetail({ runId }: { runId: string }) {
  const q = useQuery({ queryKey: ["plan", runId], queryFn: () => api.get<{ changes: PlanChange[]; drift: { address: string; actions: string[] }[] }>(`/runs/${runId}/plan`), retry: false });
  const [open, setOpen] = useState<string | null>(null);
  if (q.error) return <ErrorBox error={q.error} />;
  if (!q.data) return <Spinner />;
  const changes = q.data.changes.filter((c) => !(c.actions.length === 1 && (c.actions[0] === "no-op" || c.actions[0] === "read")));
  return (
    <div className="space-y-2">
      {changes.length === 0 && <p className="text-sm text-slate-500">Aucun changement.</p>}
      {changes.map((c) => (
        <div key={c.address} className="rounded border border-slate-200 dark:border-slate-700">
          <button className="flex w-full items-center gap-2 px-3 py-2 text-left" onClick={() => setOpen(open === c.address ? null : c.address)}>
            {c.actions.map((a) => (
              <Badge key={a} tone={actionTone[a] ?? "gray"}>
                {a}
              </Badge>
            ))}
            <span className="font-mono text-sm">{c.address}</span>
          </button>
          {open === c.address && <AttrDiff before={c.before} after={c.after} />}
        </div>
      ))}
      {q.data.drift.length > 0 && (
        <Card title="Drift (modifications hors Terraform)">
          {q.data.drift.map((d) => (
            <div key={d.address} className="font-mono text-xs">
              {d.actions.join(",")} {d.address}
            </div>
          ))}
        </Card>
      )}
    </div>
  );
}

/** Diff attribut par attribut entre "before" et "after". */
function AttrDiff({ before, after }: { before: unknown; after: unknown }) {
  const b = (before ?? {}) as Record<string, unknown>;
  const a = (after ?? {}) as Record<string, unknown>;
  const keys = [...new Set([...Object.keys(b), ...Object.keys(a)])].sort();
  const fmt = (v: unknown) => (v === undefined ? "" : typeof v === "string" ? v : JSON.stringify(v));
  return (
    <table className="w-full border-t border-slate-100 text-xs dark:border-slate-800">
      <tbody>
        {keys
          .filter((k) => fmt(b[k]) !== fmt(a[k]) || before === null)
          .map((k) => (
            <tr key={k} className="border-b border-slate-50 dark:border-slate-800">
              <td className="w-48 px-3 py-1 font-mono">{k}</td>
              <td className="px-3 py-1 text-rose-600 line-through">{fmt(b[k])}</td>
              <td className="px-3 py-1 text-emerald-700 dark:text-emerald-400">{a[k] === undefined && after !== null ? "(connu après apply)" : fmt(a[k])}</td>
            </tr>
          ))}
      </tbody>
    </table>
  );
}

function RunFiles({ runId }: { runId: string }) {
  const q = useQuery({ queryKey: ["run-files", runId], queryFn: () => api.get<{ files: Record<string, string> }>(`/runs/${runId}/files`) });
  if (!q.data) return <Spinner />;
  return (
    <div className="space-y-3">
      {Object.entries(q.data.files)
        .sort(([x], [y]) => x.localeCompare(y))
        .map(([name, content]) => (
          <Card key={name} title={<span className="font-mono">{name}</span>}>
            <pre className="overflow-auto text-xs">{content}</pre>
          </Card>
        ))}
    </div>
  );
}
