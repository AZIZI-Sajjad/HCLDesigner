// Tableau des exécutions (global ou filtré par projet), rafraîchi en continu.
import { useMemo } from "react";
import { useNavigate } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import type { ColumnDef } from "@tanstack/react-table";
import { api, qs } from "@/api/client";
import type { Run } from "@/types/api";
import { DataTable } from "@/components/table/DataTable";
import { Badge, Button, RunStatus, duration, formatDate, runStatusMeta, toast } from "@/components/ui";

export function opLabel(r: Run): string {
  if (r.operation === "plan" && r.destroy) return "plan -destroy";
  if (r.operation === "apply" && r.destroy) return "destroy";
  if (r.operation === "plan" && r.options?.drift) return "drift";
  if (r.operation === "state") return `state ${String(r.options?.stateCmd ?? "")}`;
  return r.operation;
}

function changes(r: Run): string {
  const s = r.summary;
  if (!s || s.add === undefined) return "";
  return `+${s.add} ~${s.change} ±${s.replace} −${s.destroy}`;
}

export default function RunsTable({ projectId }: { projectId?: string }) {
  const navigate = useNavigate();
  const runs = useQuery({
    queryKey: ["runs", projectId],
    queryFn: () => api.get<Run[]>("/runs" + qs({ project: projectId, limit: 1000 })),
    refetchInterval: 5000,
  });
  const columns = useMemo<ColumnDef<Run, unknown>[]>(
    () => [
      { id: "createdAt", header: "Date", accessorKey: "createdAt", size: 160, cell: (c) => formatDate(c.getValue() as string), meta: { text: (r) => formatDate(r.createdAt) } },
      ...(projectId ? [] : [{ id: "project", header: "Projet", accessorKey: "projectName", size: 160, meta: { filter: "multi" as const } }]),
      { id: "environment", header: "Environnement", accessorKey: "environmentName", size: 120, meta: { filter: "multi" } },
      { id: "operation", header: "Opération", size: 130, accessorFn: opLabel, meta: { filter: "multi" } },
      {
        id: "status",
        header: "Statut",
        accessorKey: "status",
        size: 150,
        cell: (c) => <RunStatus status={c.getValue() as string} />,
        meta: { filter: "multi", text: (r) => runStatusMeta[r.status]?.label ?? r.status },
      },
      { id: "changes", header: "Changements", size: 130, accessorFn: changes, cell: (c) => <span className="font-mono text-xs">{c.getValue() as string}</span> },
      {
        id: "policy",
        header: "Conformité",
        size: 110,
        accessorFn: (r) => (r.policyReport?.violations?.length ? (r.policyReport.blocking ? "bloquant" : `${r.policyReport.violations.length} alerte(s)`) : ""),
        cell: (c) => (c.getValue() ? <Badge tone={c.getValue() === "bloquant" ? "red" : "yellow"}>{c.getValue() as string}</Badge> : null),
        meta: { filter: "multi" },
      },
      { id: "user", header: "Par", accessorFn: (r) => r.createdByName || r.triggeredBy, size: 120, meta: { filter: "multi" } },
      { id: "trigger", header: "Déclencheur", accessorKey: "triggeredBy", size: 110, meta: { filter: "multi" } },
      { id: "duration", header: "Durée", size: 100, accessorFn: (r) => duration(r.startedAt, r.finishedAt) },
      { id: "error", header: "Erreur", accessorKey: "error", size: 260 },
      { id: "id", header: "ID", accessorKey: "id", size: 290 },
    ],
    [projectId],
  );
  return (
    <div className="h-[calc(100vh-180px)] min-h-[400px]">
      <DataTable
        id={projectId ? "project-runs" : "runs"}
        title="Exécutions"
        data={runs.data ?? []}
        columns={columns}
        loading={runs.isFetching}
        onRefresh={() => void runs.refetch()}
        onRowClick={(r) => navigate(`/runs/${r.id}`)}
        getRowId={(r) => r.id}
        defaultHidden={["id", "trigger", "error"]}
        bulkActions={(rows, clear) => (
          <Button
            size="sm"
            onClick={async () => {
              const cancellable = rows.filter((r) => ["queued", "running", "planned"].includes(r.status));
              await Promise.allSettled(cancellable.map((r) => api.post(`/runs/${r.id}/cancel`)));
              toast.success(`${cancellable.length} exécution(s) annulée(s) ou écartée(s)`);
              clear();
              void runs.refetch();
            }}
          >
            Annuler / écarter
          </Button>
        )}
      />
    </div>
  );
}
