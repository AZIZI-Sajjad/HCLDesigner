// Tableau de bord : indicateurs, exécutions en cours et récentes, approbations en attente,
// drifts, non-conformités, prochaines tâches, statistiques et graphiques personnalisables.
import { useState } from "react";
import { Link } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { Bar, BarChart, CartesianGrid, Cell, Legend, Line, LineChart, Pie, PieChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { Plus, X } from "lucide-react";
import { api, qs } from "@/api/client";
import type { Run } from "@/types/api";
import { Badge, Button, Card, Field, Modal, PageHeader, RunStatus, Select, Spinner, formatDate } from "@/components/ui";
import { opLabel } from "./runs/RunsTable";
import { newId } from "@/lib/model";

interface Point {
  key: string;
  group?: string;
  value: number;
}

interface DashboardData {
  projects: number;
  environments: number;
  running: number;
  failed24h: number;
  recentRuns: Run[];
  activeRuns: Run[];
  pendingApprovals: Run[];
  drifts: Run[];
  nonCompliant: Run[];
  nextTasks: { id: string; name: string; kind: string; nextRunAt: string; project: string }[];
  runsPerDay: Point[];
  resourcesByProvider: Point[];
  durations: Point[];
  topChanged: Point[];
}

interface Widget {
  id: string;
  title: string;
  metric: string;
  dimension: string;
  chart: "bar" | "line" | "pie";
  period: number;
}

const palette = ["#6366f1", "#10b981", "#f59e0b", "#ef4444", "#0ea5e9", "#8b5cf6", "#14b8a6", "#f97316", "#64748b", "#ec4899"];

export default function Dashboard() {
  const q = useQuery({ queryKey: ["dashboard"], queryFn: () => api.get<DashboardData>("/dashboard"), refetchInterval: 15000 });
  const widgets = useQuery({ queryKey: ["dashboard-widgets"], queryFn: () => api.get<Widget[] | null>("/prefs/user/dashboard_widgets") });
  const [adding, setAdding] = useState(false);
  if (!q.data) return <Spinner />;
  const d = q.data;

  // Exécutions par jour : pivot (date -> succès / échec)
  const perDay = Object.values(
    d.runsPerDay.reduce<Record<string, Record<string, string | number>>>((acc, p) => {
      acc[p.key] ??= { day: p.key.slice(5) };
      acc[p.key][p.group ?? "total"] = p.value;
      return acc;
    }, {}),
  );

  const saveWidgets = async (list: Widget[]) => {
    await api.put("/prefs/user/dashboard_widgets", list);
    void widgets.refetch();
  };

  return (
    <div className="space-y-4 p-6">
      <PageHeader
        title="Tableau de bord"
        actions={
          <Button icon={<Plus className="h-4 w-4" />} onClick={() => setAdding(true)}>
            Ajouter un graphique
          </Button>
        }
      />
      <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
        <Kpi label="Projets" value={d.projects} to="/projects" />
        <Kpi label="Environnements" value={d.environments} />
        <Kpi label="Exécutions en cours" value={d.running} to="/runs" tone="blue" />
        <Kpi label="Échecs (24 h)" value={d.failed24h} to="/runs" tone={d.failed24h ? "red" : undefined} />
      </div>

      <div className="grid gap-4 lg:grid-cols-3">
        <RunList title="Approbations en attente" runs={d.pendingApprovals} empty="Aucune approbation en attente." />
        <RunList title="Drifts détectés" runs={d.drifts} empty="Aucun drift détecté au dernier contrôle." />
        <RunList title="Non-conformités récentes" runs={d.nonCompliant} empty="Aucune non-conformité." />
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <Card title="Exécutions par jour (30 j)">
          <div className="h-64">
            <ResponsiveContainer>
              <BarChart data={perDay}>
                <CartesianGrid strokeDasharray="3 3" opacity={0.3} />
                <XAxis dataKey="day" fontSize={11} />
                <YAxis allowDecimals={false} fontSize={11} />
                <Tooltip />
                <Legend />
                <Bar dataKey="succès" stackId="a" fill="#10b981" />
                <Bar dataKey="échec" stackId="a" fill="#ef4444" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </Card>
        <Card title="Ressources gérées par provider">
          <SimpleChart data={d.resourcesByProvider} chart="pie" />
        </Card>
        <Card title="Durée moyenne par opération (s)">
          <SimpleChart data={d.durations} chart="bar" />
        </Card>
        <Card title="Ressources les plus modifiées (30 j)">
          <SimpleChart data={d.topChanged} chart="bar" horizontal />
        </Card>
      </div>

      {(widgets.data ?? []).length > 0 && (
        <div className="grid gap-4 lg:grid-cols-2">
          {(widgets.data ?? []).map((w) => (
            <CustomWidget key={w.id} widget={w} onRemove={() => void saveWidgets((widgets.data ?? []).filter((x) => x.id !== w.id))} />
          ))}
        </div>
      )}

      <div className="grid gap-4 lg:grid-cols-2">
        <RunList title="En cours" runs={d.activeRuns} empty="Aucune exécution en cours." />
        <Card title="Prochaines tâches planifiées">
          {d.nextTasks.length === 0 && <p className="text-sm text-slate-500">Aucune tâche planifiée.</p>}
          {d.nextTasks.map((t) => (
            <div key={t.id} className="flex items-center justify-between border-b border-slate-100 py-1.5 text-sm last:border-0 dark:border-slate-800">
              <span>
                {t.name} <span className="text-xs text-slate-500">{t.project}</span>
              </span>
              <span className="text-xs text-slate-500">{formatDate(t.nextRunAt)}</span>
            </div>
          ))}
        </Card>
      </div>
      <RunList title="Exécutions récentes" runs={d.recentRuns} empty="Aucune exécution." />
      {adding && <WidgetDialog onClose={() => setAdding(false)} onSave={(w) => void saveWidgets([...(widgets.data ?? []), w]).then(() => setAdding(false))} />}
    </div>
  );
}

function Kpi({ label, value, to, tone }: { label: string; value: number; to?: string; tone?: "red" | "blue" }) {
  const body = (
    <div className="rounded-lg border border-slate-200 bg-white p-4 dark:border-slate-800 dark:bg-slate-900">
      <div className="text-xs text-slate-500">{label}</div>
      <div className={`mt-1 text-2xl font-semibold ${tone === "red" ? "text-rose-600" : tone === "blue" ? "text-sky-600" : ""}`}>{value}</div>
    </div>
  );
  return to ? <Link to={to}>{body}</Link> : body;
}

function RunList({ title, runs, empty }: { title: string; runs: Run[]; empty: string }) {
  return (
    <Card title={title}>
      {runs.length === 0 && <p className="text-sm text-slate-500">{empty}</p>}
      <div className="space-y-1">
        {runs.slice(0, 8).map((r) => (
          <Link key={r.id} to={`/runs/${r.id}`} className="flex items-center gap-2 rounded px-1 py-1 text-sm hover:bg-slate-50 dark:hover:bg-slate-800">
            <RunStatus status={r.status} />
            <span className="truncate">
              {r.projectName}/{r.environmentName}
            </span>
            <Badge>{opLabel(r)}</Badge>
            <span className="ml-auto whitespace-nowrap text-xs text-slate-500">{formatDate(r.createdAt)}</span>
          </Link>
        ))}
      </div>
    </Card>
  );
}

function SimpleChart({ data, chart, horizontal }: { data: Point[]; chart: Widget["chart"]; horizontal?: boolean }) {
  if (!data.length) return <p className="py-8 text-center text-sm text-slate-500">Pas encore de données.</p>;
  return (
    <div className="h-64">
      <ResponsiveContainer>
        {chart === "pie" ? (
          <PieChart>
            <Pie data={data} dataKey="value" nameKey="key" outerRadius={90} label={(e: { key?: string }) => e.key ?? ""}>
              {data.map((_, i) => (
                <Cell key={i} fill={palette[i % palette.length]} />
              ))}
            </Pie>
            <Tooltip />
          </PieChart>
        ) : chart === "line" ? (
          <LineChart data={data}>
            <CartesianGrid strokeDasharray="3 3" opacity={0.3} />
            <XAxis dataKey="key" fontSize={11} />
            <YAxis fontSize={11} />
            <Tooltip />
            <Line dataKey="value" stroke="#6366f1" strokeWidth={2} />
          </LineChart>
        ) : (
          <BarChart data={data} layout={horizontal ? "vertical" : "horizontal"} margin={horizontal ? { left: 120 } : undefined}>
            <CartesianGrid strokeDasharray="3 3" opacity={0.3} />
            {horizontal ? <XAxis type="number" fontSize={11} /> : <XAxis dataKey="key" fontSize={11} />}
            {horizontal ? <YAxis type="category" dataKey="key" fontSize={10} width={120} /> : <YAxis fontSize={11} />}
            <Tooltip />
            <Bar dataKey="value" fill="#6366f1" />
          </BarChart>
        )}
      </ResponsiveContainer>
    </div>
  );
}

function CustomWidget({ widget, onRemove }: { widget: Widget; onRemove: () => void }) {
  const q = useQuery({
    queryKey: ["metric", widget],
    queryFn: () => api.get<Point[]>("/dashboard/metric" + qs({ metric: widget.metric, dimension: widget.dimension, period: widget.period })),
  });
  return (
    <Card
      title={widget.title}
      actions={
        <button onClick={onRemove} className="text-slate-400 hover:text-slate-700" aria-label="Retirer">
          <X className="h-4 w-4" />
        </button>
      }
    >
      <SimpleChart data={q.data ?? []} chart={widget.chart} />
    </Card>
  );
}

const metrics = [
  { id: "runs", label: "Nombre d'exécutions", dims: ["status", "project", "environment", "operation", "day", "user", "trigger"] },
  { id: "duration", label: "Durée moyenne (s)", dims: ["operation", "project", "environment", "day"] },
  { id: "resources", label: "Ressources gérées", dims: ["provider", "type", "project", "environment"] },
  { id: "changes", label: "Ressources les plus modifiées", dims: ["address"] },
];
const dimLabels: Record<string, string> = { status: "Statut", project: "Projet", environment: "Environnement", operation: "Opération", day: "Jour", user: "Utilisateur", trigger: "Déclencheur", provider: "Provider", type: "Type de ressource", address: "Adresse" };

function WidgetDialog({ onClose, onSave }: { onClose: () => void; onSave: (w: Widget) => void }) {
  const [metric, setMetric] = useState("runs");
  const [dimension, setDimension] = useState("status");
  const [chart, setChart] = useState<Widget["chart"]>("bar");
  const [period, setPeriod] = useState(30);
  const m = metrics.find((x) => x.id === metric)!;
  return (
    <Modal
      open
      onClose={onClose}
      title="Nouveau graphique"
      footer={
        <>
          <Button onClick={onClose}>Annuler</Button>
          <Button variant="primary" onClick={() => onSave({ id: newId(), title: `${m.label} par ${dimLabels[dimension]?.toLowerCase() ?? dimension}`, metric, dimension, chart, period })}>
            Épingler
          </Button>
        </>
      }
    >
      <div className="grid gap-3 md:grid-cols-2">
        <Field label="Métrique">
          <Select value={metric} onChange={(e) => (setMetric(e.target.value), setDimension(metrics.find((x) => x.id === e.target.value)!.dims[0]))}>
            {metrics.map((x) => (
              <option key={x.id} value={x.id}>
                {x.label}
              </option>
            ))}
          </Select>
        </Field>
        <Field label="Dimension">
          <Select value={dimension} onChange={(e) => setDimension(e.target.value)}>
            {m.dims.map((dm) => (
              <option key={dm} value={dm}>
                {dimLabels[dm] ?? dm}
              </option>
            ))}
          </Select>
        </Field>
        <Field label="Type de graphique">
          <Select value={chart} onChange={(e) => setChart(e.target.value as Widget["chart"])}>
            <option value="bar">Barres</option>
            <option value="line">Ligne</option>
            <option value="pie">Camembert</option>
          </Select>
        </Field>
        <Field label="Période (jours)">
          <Select value={period} onChange={(e) => setPeriod(Number(e.target.value))}>
            {[7, 30, 90, 365].map((p) => (
              <option key={p} value={p}>
                {p}
              </option>
            ))}
          </Select>
        </Field>
      </div>
    </Modal>
  );
}
