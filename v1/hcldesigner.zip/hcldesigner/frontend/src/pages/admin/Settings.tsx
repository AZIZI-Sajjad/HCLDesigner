// Paramètres généraux : exécutions et rétention, mirror de providers, versions Terraform/OpenTofu,
// sécurité (mots de passe, MFA, protections), export syslog, identité visuelle.
import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Plus, Trash2 } from "lucide-react";
import { api } from "@/api/client";
import { Button, Card, Field, IconButton, Input, PageHeader, Select, Toggle, toast } from "@/components/ui";

interface Settings {
  runs: { planTtlMinutes: number; logRetentionDays: number; planRetentionDays: number; stateVersionsKept: number; auditRetentionDays: number; timeoutMinutes: number; parallelism: number };
  mirror: { mode: string; path: string; url: string };
  branding: { name: string; logoUrl: string; language: string };
  security: { passwordPolicy: { minLength: number; minClasses: number }; blockLocalExec: boolean; blockFileFuncs: boolean; requireMfa: boolean };
  syslog: { addr: string };
  engines: { versions: { engine: string; version: string }[] };
}

export default function SettingsPage() {
  const q = useQuery({ queryKey: ["settings"], queryFn: () => api.get<Settings>("/admin/settings") });
  const [s, setS] = useState<Settings | null>(null);
  useEffect(() => {
    if (q.data) setS(q.data);
  }, [q.data]);
  if (!s) return null;
  const num = (v: string) => Number(v) || 0;
  const save = () => void api.put("/admin/settings", s).then(() => toast.success("Paramètres enregistrés"), toast.error);
  return (
    <div className="mx-auto max-w-5xl space-y-4 p-6">
      <PageHeader title="Paramètres" actions={<Button variant="primary" onClick={save}>Enregistrer</Button>} />
      <Card title="Exécutions et rétention">
        <div className="grid gap-3 md:grid-cols-4">
          <Field label="Validité d'un plan (min)">
            <Input type="number" value={s.runs.planTtlMinutes} onChange={(e) => setS({ ...s, runs: { ...s.runs, planTtlMinutes: num(e.target.value) } })} />
          </Field>
          <Field label="Délai max d'un run (min)">
            <Input type="number" value={s.runs.timeoutMinutes} onChange={(e) => setS({ ...s, runs: { ...s.runs, timeoutMinutes: num(e.target.value) } })} />
          </Field>
          <Field label="-parallelism par défaut">
            <Input type="number" value={s.runs.parallelism} onChange={(e) => setS({ ...s, runs: { ...s.runs, parallelism: num(e.target.value) } })} />
          </Field>
          <Field label="Versions de state conservées">
            <Input type="number" value={s.runs.stateVersionsKept} onChange={(e) => setS({ ...s, runs: { ...s.runs, stateVersionsKept: num(e.target.value) } })} />
          </Field>
          <Field label="Rétention des logs (jours)">
            <Input type="number" value={s.runs.logRetentionDays} onChange={(e) => setS({ ...s, runs: { ...s.runs, logRetentionDays: num(e.target.value) } })} />
          </Field>
          <Field label="Rétention des plans (jours)">
            <Input type="number" value={s.runs.planRetentionDays} onChange={(e) => setS({ ...s, runs: { ...s.runs, planRetentionDays: num(e.target.value) } })} />
          </Field>
          <Field label="Rétention de l'audit (jours)">
            <Input type="number" value={s.runs.auditRetentionDays} onChange={(e) => setS({ ...s, runs: { ...s.runs, auditRetentionDays: num(e.target.value) } })} />
          </Field>
        </div>
      </Card>

      <Card title="Installation des providers">
        <div className="grid gap-3 md:grid-cols-3">
          <Field label="Mode">
            <Select value={s.mirror.mode} onChange={(e) => setS({ ...s, mirror: { ...s.mirror, mode: e.target.value } })}>
              <option value="none">Registry public (accès Internet)</option>
              <option value="filesystem">Mirror sur disque (air-gap)</option>
              <option value="network">Network mirror (HTTPS)</option>
            </Select>
          </Field>
          {s.mirror.mode === "filesystem" && (
            <Field label="Chemin du mirror (dans le worker)">
              <Input value={s.mirror.path} onChange={(e) => setS({ ...s, mirror: { ...s.mirror, path: e.target.value } })} placeholder="/data/mirror" />
            </Field>
          )}
          {s.mirror.mode === "network" && (
            <Field label="URL du network mirror">
              <Input value={s.mirror.url} onChange={(e) => setS({ ...s, mirror: { ...s.mirror, url: e.target.value } })} placeholder="https://mirror.local/providers/" />
            </Field>
          )}
        </div>
      </Card>

      <Card title="Versions Terraform / OpenTofu proposées">
        <div className="space-y-2">
          {s.engines.versions.map((v, i) => (
            <div key={i} className="flex gap-2">
              <Select className="w-40" value={v.engine} onChange={(e) => setS({ ...s, engines: { versions: s.engines.versions.map((x, j) => (j === i ? { ...x, engine: e.target.value } : x)) } })}>
                <option value="terraform">Terraform</option>
                <option value="opentofu">OpenTofu</option>
              </Select>
              <Input className="w-40" value={v.version} placeholder="1.9.8" onChange={(e) => setS({ ...s, engines: { versions: s.engines.versions.map((x, j) => (j === i ? { ...x, version: e.target.value } : x)) } })} />
              <IconButton title="Retirer" onClick={() => setS({ ...s, engines: { versions: s.engines.versions.filter((_, j) => j !== i) } })}>
                <Trash2 className="h-4 w-4" />
              </IconButton>
            </div>
          ))}
          <Button size="sm" icon={<Plus className="h-3 w-3" />} onClick={() => setS({ ...s, engines: { versions: [...s.engines.versions, { engine: "terraform", version: "" }] } })}>
            Ajouter une version
          </Button>
          <p className="text-xs text-slate-500">Les binaires sont téléchargés par le worker au premier usage (HCLD_TERRAFORM_URL / HCLD_TOFU_URL pour un dépôt interne).</p>
        </div>
      </Card>

      <Card title="Sécurité">
        <div className="grid gap-3 md:grid-cols-4">
          <Field label="Longueur minimale du mot de passe">
            <Input type="number" min={8} value={s.security.passwordPolicy.minLength} onChange={(e) => setS({ ...s, security: { ...s.security, passwordPolicy: { ...s.security.passwordPolicy, minLength: num(e.target.value) } } })} />
          </Field>
          <Field label="Types de caractères requis (1-4)">
            <Input type="number" min={1} max={4} value={s.security.passwordPolicy.minClasses} onChange={(e) => setS({ ...s, security: { ...s.security, passwordPolicy: { ...s.security.passwordPolicy, minClasses: num(e.target.value) } } })} />
          </Field>
        </div>
        <div className="mt-3 space-y-2">
          <Toggle checked={s.security.requireMfa} onChange={(v) => setS({ ...s, security: { ...s.security, requireMfa: v } })} label="Imposer la double authentification" />
          <Toggle checked={s.security.blockLocalExec} onChange={(v) => setS({ ...s, security: { ...s.security, blockLocalExec: v } })} label="Interdire les provisioners local-exec" />
          <Toggle checked={s.security.blockFileFuncs} onChange={(v) => setS({ ...s, security: { ...s.security, blockFileFuncs: v } })} label="Interdire file() / templatefile() hors du workspace" />
        </div>
      </Card>

      <Card title="Export syslog de l'audit">
        <Field label="Hôte:port UDP (Wazuh, Graylog…)" help="Vide = désactivé">
          <Input className="w-72" value={s.syslog.addr} onChange={(e) => setS({ ...s, syslog: { addr: e.target.value } })} placeholder="wazuh.local:514" />
        </Field>
      </Card>

      <Card title="Identité visuelle">
        <div className="grid gap-3 md:grid-cols-3">
          <Field label="Nom de l'application">
            <Input value={s.branding.name} onChange={(e) => setS({ ...s, branding: { ...s.branding, name: e.target.value } })} />
          </Field>
          <Field label="URL du logo">
            <Input value={s.branding.logoUrl} onChange={(e) => setS({ ...s, branding: { ...s.branding, logoUrl: e.target.value } })} />
          </Field>
          <Field label="Langue">
            <Select value={s.branding.language} onChange={(e) => setS({ ...s, branding: { ...s.branding, language: e.target.value } })}>
              <option value="fr">Français</option>
            </Select>
          </Field>
        </div>
      </Card>
    </div>
  );
}
