// Notifications : configuration SMTP (+ mail de test), modèles de mails (avec prévisualisation),
// webhooks (générique, Teams, Slack) et historique des envois.
import { useEffect, useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import type { ColumnDef } from "@tanstack/react-table";
import { Plus } from "lucide-react";
import { api } from "@/api/client";
import { DataTable } from "@/components/table/DataTable";
import { Badge, Button, Card, Field, Input, Modal, PageHeader, Select, Tabs, Textarea, Toggle, formatDate, toast } from "@/components/ui";

export default function Notifications() {
  const [tab, setTab] = useState<"smtp" | "templates" | "webhooks" | "outbox">("smtp");
  return (
    <div className="p-6">
      <PageHeader title="Notifications" subtitle="Les abonnements se gèrent par utilisateur dans « Mon compte »." />
      <Tabs
        tabs={[
          { id: "smtp", label: "SMTP" },
          { id: "templates", label: "Modèles de mails" },
          { id: "webhooks", label: "Webhooks" },
          { id: "outbox", label: "Historique" },
        ]}
        value={tab}
        onChange={setTab}
      />
      <div className="pt-3">
        {tab === "smtp" && <SmtpTab />}
        {tab === "templates" && <TemplatesTab />}
        {tab === "webhooks" && <WebhooksTab />}
        {tab === "outbox" && <OutboxTab />}
      </div>
    </div>
  );
}

interface Smtp {
  host: string;
  port: number;
  security: string;
  username: string;
  password?: string;
  hasPassword: boolean;
  from: string;
  skipVerify: boolean;
}

function SmtpTab() {
  const q = useQuery({ queryKey: ["smtp"], queryFn: () => api.get<Smtp>("/admin/smtp") });
  const [s, setS] = useState<Smtp | null>(null);
  const [to, setTo] = useState("");
  useEffect(() => {
    if (q.data) setS({ ...q.data, password: "" });
  }, [q.data]);
  if (!s) return null;
  return (
    <Card title="Serveur SMTP" actions={<Button variant="primary" size="sm" onClick={() => void api.put("/admin/smtp", s).then(() => (toast.success("Enregistré"), q.refetch()), toast.error)}>Enregistrer</Button>}>
      <div className="grid gap-3 md:grid-cols-3">
        <Field label="Hôte">
          <Input value={s.host} onChange={(e) => setS({ ...s, host: e.target.value })} placeholder="smtp.example.com" />
        </Field>
        <Field label="Port">
          <Input type="number" value={s.port} onChange={(e) => setS({ ...s, port: Number(e.target.value) })} />
        </Field>
        <Field label="Sécurité">
          <Select value={s.security} onChange={(e) => setS({ ...s, security: e.target.value })}>
            <option value="starttls">STARTTLS (587)</option>
            <option value="tls">SSL/TLS implicite (465)</option>
            <option value="none">Aucune (25, relais interne)</option>
          </Select>
        </Field>
        <Field label="Utilisateur">
          <Input value={s.username} onChange={(e) => setS({ ...s, username: e.target.value })} />
        </Field>
        <Field label="Mot de passe">
          <Input type="password" value={s.password ?? ""} placeholder={s.hasPassword ? "•••••• (inchangé si vide)" : ""} onChange={(e) => setS({ ...s, password: e.target.value })} />
        </Field>
        <Field label="Expéditeur">
          <Input value={s.from} onChange={(e) => setS({ ...s, from: e.target.value })} placeholder="HCLDesigner <hcldesigner@example.com>" />
        </Field>
      </div>
      <div className="mt-3">
        <Toggle checked={s.skipVerify} onChange={(v) => setS({ ...s, skipVerify: v })} label="Ne pas vérifier le certificat (déconseillé)" />
      </div>
      <div className="mt-4 flex items-end gap-2 border-t border-slate-200 pt-3 dark:border-slate-800">
        <Field label="Destinataire du test (vide = mon adresse)">
          <Input value={to} onChange={(e) => setTo(e.target.value)} />
        </Field>
        <Button onClick={() => void api.post<{ sentTo: string }>("/admin/smtp/test", { to }).then((r) => toast.success(`Mail envoyé à ${r.sentTo}`), toast.error)}>Envoyer un mail de test</Button>
      </div>
    </Card>
  );
}

interface Tpl {
  subject: string;
  body: string;
}

function TemplatesTab() {
  const q = useQuery({ queryKey: ["templates"], queryFn: () => api.get<{ custom: Record<string, Tpl>; default: Tpl }>("/admin/templates") });
  const events = useQuery({ queryKey: ["notif-events"], queryFn: () => api.get<{ event: string; label: string }[]>("/notifications/events") });
  const [event, setEvent] = useState("default");
  const [custom, setCustom] = useState<Record<string, Tpl>>({});
  const [preview, setPreview] = useState<{ subject: string; body: string } | null>(null);
  useEffect(() => {
    if (q.data) setCustom(q.data.custom ?? {});
  }, [q.data]);
  if (!q.data) return null;
  const tpl = custom[event] ?? custom.default ?? q.data.default;
  const set = (patch: Partial<Tpl>) => setCustom({ ...custom, [event]: { ...tpl, ...patch } });
  return (
    <Card
      title="Modèles"
      actions={
        <>
          <Button size="sm" onClick={() => void api.post<{ subject: string; body: string }>("/admin/templates/preview", tpl).then(setPreview, toast.error)}>
            Prévisualiser
          </Button>
          <Button size="sm" variant="primary" onClick={() => void api.put("/admin/templates", custom).then(() => toast.success("Modèles enregistrés"), toast.error)}>
            Enregistrer
          </Button>
        </>
      }
    >
      <div className="space-y-3">
        <div className="flex items-end gap-2">
          <Field label="Événement">
            <Select className="w-80" value={event} onChange={(e) => setEvent(e.target.value)}>
              <option value="default">Modèle par défaut (tous les événements)</option>
              {(events.data ?? []).map((e) => (
                <option key={e.event} value={e.event}>
                  {e.label} {custom[e.event] ? "✱" : ""}
                </option>
              ))}
            </Select>
          </Field>
          {custom[event] && event !== "default" && (
            <Button size="sm" onClick={() => setCustom(Object.fromEntries(Object.entries(custom).filter(([k]) => k !== event)))}>
              Revenir au modèle par défaut
            </Button>
          )}
        </div>
        <p className="text-xs text-slate-500">
          Variables : {"{{.Brand}} {{.Label}} {{.Event}} {{.Project}} {{.Environment}} {{.Actor}} {{.Summary}} {{.Link}} {{.Time}}"} (syntaxe Go template).
        </p>
        <Field label="Sujet">
          <Input value={tpl.subject} onChange={(e) => set({ subject: e.target.value })} />
        </Field>
        <Field label="Corps (HTML)">
          <Textarea rows={14} value={tpl.body} onChange={(e) => set({ body: e.target.value })} />
        </Field>
      </div>
      {preview && (
        <Modal open wide onClose={() => setPreview(null)} title={preview.subject}>
          <iframe title="Aperçu" sandbox="" className="h-[60vh] w-full rounded border bg-white" srcDoc={preview.body} />
        </Modal>
      )}
    </Card>
  );
}

interface Webhook {
  id: string;
  name: string;
  kind: string;
  events: string[];
  enabled: boolean;
  createdAt: string;
  url?: string;
}

function WebhooksTab() {
  const list = useQuery({ queryKey: ["webhooks"], queryFn: () => api.get<Webhook[]>("/admin/webhooks") });
  const events = useQuery({ queryKey: ["notif-events"], queryFn: () => api.get<{ event: string; label: string }[]>("/notifications/events") });
  const [editing, setEditing] = useState<Webhook | null>(null);
  const columns = useMemo<ColumnDef<Webhook, unknown>[]>(
    () => [
      { id: "name", header: "Nom", accessorKey: "name", size: 200 },
      { id: "kind", header: "Type", accessorKey: "kind", size: 100, meta: { filter: "multi" } },
      { id: "events", header: "Événements", accessorFn: (w) => w.events.length, size: 110 },
      { id: "enabled", header: "Actif", accessorFn: (w) => (w.enabled ? "oui" : "non"), size: 80, meta: { filter: "multi" } },
    ],
    [],
  );
  return (
    <div className="h-[calc(100vh-220px)]">
      <DataTable
        id="admin-webhooks"
        data={list.data ?? []}
        columns={columns}
        onRowClick={setEditing}
        getRowId={(w) => w.id}
        toolbar={
          <Button size="sm" variant="primary" icon={<Plus className="h-3.5 w-3.5" />} onClick={() => setEditing({ id: "", name: "", kind: "teams", events: [], enabled: true, createdAt: "" })}>
            Nouveau webhook
          </Button>
        }
      />
      {editing && (
        <Modal
          open
          onClose={() => setEditing(null)}
          title={editing.id ? editing.name : "Nouveau webhook"}
          footer={
            <>
              {editing.id && (
                <Button variant="danger" onClick={() => void api.del(`/admin/webhooks/${editing.id}`).then(() => (setEditing(null), list.refetch()))}>
                  Supprimer
                </Button>
              )}
              <span className="flex-1" />
              <Button
                variant="primary"
                onClick={() =>
                  void (editing.id ? api.put(`/admin/webhooks/${editing.id}`, editing) : api.post("/admin/webhooks", editing)).then(() => (setEditing(null), list.refetch()), toast.error)
                }
              >
                Enregistrer
              </Button>
            </>
          }
        >
          <div className="space-y-3">
            <Field label="Nom">
              <Input value={editing.name} onChange={(e) => setEditing({ ...editing, name: e.target.value })} />
            </Field>
            <Field label="Type">
              <Select value={editing.kind} onChange={(e) => setEditing({ ...editing, kind: e.target.value })}>
                <option value="teams">Microsoft Teams</option>
                <option value="slack">Slack</option>
                <option value="generic">Générique (JSON)</option>
              </Select>
            </Field>
            <Field label="URL" help="Stockée chiffrée. Vide en modification = inchangée.">
              <Input value={editing.url ?? ""} onChange={(e) => setEditing({ ...editing, url: e.target.value })} />
            </Field>
            <Toggle checked={editing.enabled} onChange={(v) => setEditing({ ...editing, enabled: v })} label="Actif" />
            <Field label="Événements">
              <div className="grid gap-1 md:grid-cols-2">
                {(events.data ?? []).map((e) => (
                  <label key={e.event} className="flex items-center gap-2 text-sm">
                    <input type="checkbox" checked={editing.events.includes(e.event)} onChange={(x) => setEditing({ ...editing, events: x.target.checked ? [...editing.events, e.event] : editing.events.filter((v) => v !== e.event) })} />
                    {e.label}
                  </label>
                ))}
              </div>
            </Field>
          </div>
        </Modal>
      )}
    </div>
  );
}

interface OutboxRow {
  id: number;
  channel: string;
  recipient: string;
  subject: string;
  event: string;
  status: string;
  attempts: number;
  error: string;
  createdAt: string;
  sentAt: string | null;
}

function OutboxTab() {
  const q = useQuery({ queryKey: ["outbox"], queryFn: () => api.get<OutboxRow[]>("/admin/outbox"), refetchInterval: 15000 });
  const columns = useMemo<ColumnDef<OutboxRow, unknown>[]>(
    () => [
      { id: "createdAt", header: "Date", accessorKey: "createdAt", size: 160, cell: (c) => formatDate(c.getValue() as string), meta: { text: (r) => formatDate(r.createdAt) } },
      { id: "channel", header: "Canal", accessorKey: "channel", size: 90, meta: { filter: "multi" } },
      { id: "recipient", header: "Destinataire", accessorKey: "recipient", size: 220 },
      { id: "event", header: "Événement", accessorKey: "event", size: 160, meta: { filter: "multi" } },
      { id: "subject", header: "Sujet", accessorKey: "subject", size: 300 },
      {
        id: "status",
        header: "Statut",
        accessorKey: "status",
        size: 100,
        cell: (c) => <Badge tone={c.getValue() === "sent" || c.getValue() === "digested" ? "green" : c.getValue() === "failed" ? "red" : "gray"}>{c.getValue() as string}</Badge>,
        meta: { filter: "multi" },
      },
      { id: "attempts", header: "Essais", accessorKey: "attempts", size: 70 },
      { id: "error", header: "Erreur", accessorKey: "error", size: 260 },
    ],
    [],
  );
  return (
    <div className="h-[calc(100vh-220px)]">
      <DataTable id="admin-outbox" title="Notifications envoyées" data={q.data ?? []} columns={columns} onRefresh={() => void q.refetch()} getRowId={(r) => String(r.id)} />
    </div>
  );
}
