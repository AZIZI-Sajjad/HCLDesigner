// Rôles personnalisés (matrice de permissions par domaine) et attributions (utilisateur ou équipe,
// portée globale, projet ou environnement).
import { useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import type { ColumnDef } from "@tanstack/react-table";
import { Plus } from "lucide-react";
import { api } from "@/api/client";
import type { ProjectListItem } from "@/types/api";
import { DataTable } from "@/components/table/DataTable";
import { Badge, Button, ErrorBox, Field, Input, Modal, PageHeader, Select, Tabs, toast } from "@/components/ui";
import type { BindingRow } from "../project/Sharing";

interface Role {
  id: string;
  name: string;
  description: string;
  builtin: boolean;
  permissions: string[];
  bindings: number;
}
interface PermGroup {
  domain: string;
  label: string;
  perms: { name: string; label: string; scope: string }[];
}

export default function Roles() {
  const [tab, setTab] = useState<"roles" | "bindings">("roles");
  return (
    <div className="p-6">
      <PageHeader title="Rôles & attributions" />
      <Tabs
        tabs={[
          { id: "roles", label: "Rôles" },
          { id: "bindings", label: "Attributions" },
        ]}
        value={tab}
        onChange={setTab}
      />
      <div className="pt-3">{tab === "roles" ? <RolesTab /> : <BindingsTab />}</div>
    </div>
  );
}

function RolesTab() {
  const roles = useQuery({ queryKey: ["roles"], queryFn: () => api.get<Role[]>("/admin/roles") });
  const groups = useQuery({ queryKey: ["perm-groups"], queryFn: () => api.get<PermGroup[]>("/admin/permissions") });
  const [editing, setEditing] = useState<Role | null>(null);
  const columns = useMemo<ColumnDef<Role, unknown>[]>(
    () => [
      { id: "name", header: "Rôle", accessorKey: "name", size: 180 },
      { id: "description", header: "Description", accessorKey: "description", size: 280 },
      { id: "type", header: "Type", size: 110, accessorFn: (r) => (r.builtin ? "prédéfini" : "personnalisé"), cell: (c) => <Badge tone={c.getValue() === "prédéfini" ? "gray" : "indigo"}>{c.getValue() as string}</Badge>, meta: { filter: "multi" } },
      { id: "perms", header: "Permissions", accessorFn: (r) => (r.permissions.includes("*") ? "toutes" : r.permissions.length), size: 110 },
      { id: "bindings", header: "Attributions", accessorKey: "bindings", size: 110 },
    ],
    [],
  );
  return (
    <div className="h-[calc(100vh-200px)]">
      <DataTable
        id="admin-roles"
        data={roles.data ?? []}
        columns={columns}
        onRowClick={setEditing}
        getRowId={(r) => r.id}
        toolbar={
          <Button size="sm" variant="primary" icon={<Plus className="h-3.5 w-3.5" />} onClick={() => setEditing({ id: "", name: "", description: "", builtin: false, permissions: [], bindings: 0 })}>
            Nouveau rôle
          </Button>
        }
      />
      {editing && <RoleMatrix role={editing} groups={groups.data ?? []} onClose={() => setEditing(null)} onSaved={() => (setEditing(null), void roles.refetch())} />}
    </div>
  );
}

const scopeLabel: Record<string, string> = { global: "globale", project: "projet", environment: "environnement" };

function RoleMatrix({ role, groups, onClose, onSaved }: { role: Role; groups: PermGroup[]; onClose: () => void; onSaved: () => void }) {
  const [r, setR] = useState(role);
  const [error, setError] = useState<unknown>(null);
  const all = r.permissions.includes("*");
  const toggle = (p: string, on: boolean) => setR((cur) => ({ ...cur, permissions: on ? [...new Set([...cur.permissions, p])] : cur.permissions.filter((x) => x !== p) }));
  const save = async () => {
    try {
      if (r.id) await api.put(`/admin/roles/${r.id}`, r);
      else await api.post("/admin/roles", r);
      toast.success("Rôle enregistré");
      onSaved();
    } catch (e) {
      setError(e);
    }
  };
  return (
    <Modal
      open
      wide
      onClose={onClose}
      title={r.builtin ? `Rôle prédéfini « ${r.name} » (lecture seule)` : r.id ? `Rôle « ${r.name} »` : "Nouveau rôle"}
      footer={
        <>
          {r.id && !r.builtin && (
            <Button variant="danger" onClick={() => void api.del(`/admin/roles/${r.id}`).then(onSaved, toast.error)}>
              Supprimer
            </Button>
          )}
          <span className="flex-1" />
          <Button onClick={onClose}>Fermer</Button>
          {!r.builtin && (
            <Button variant="primary" onClick={save}>
              Enregistrer
            </Button>
          )}
        </>
      }
    >
      <div className="space-y-3">
        <ErrorBox error={error} />
        <div className="grid gap-3 md:grid-cols-2">
          <Field label="Nom">
            <Input value={r.name} disabled={r.builtin} onChange={(e) => setR({ ...r, name: e.target.value })} />
          </Field>
          <Field label="Description">
            <Input value={r.description} disabled={r.builtin} onChange={(e) => setR({ ...r, description: e.target.value })} />
          </Field>
        </div>
        {all && <Badge tone="red">Toutes les permissions (*)</Badge>}
        <div className="grid gap-3 md:grid-cols-2">
          {groups.map((g) => {
            const allInGroup = g.perms.every((p) => r.permissions.includes(p.name));
            return (
              <fieldset key={g.domain} className="rounded-md border border-slate-200 p-2 dark:border-slate-700">
                <legend className="px-1 text-xs font-semibold">
                  <label className="flex items-center gap-1">
                    <input type="checkbox" disabled={r.builtin} checked={all || allInGroup} onChange={(e) => {
                        const names = g.perms.map((p) => p.name);
                        const on = e.target.checked;
                        setR((cur) => ({ ...cur, permissions: on ? [...new Set([...cur.permissions, ...names])] : cur.permissions.filter((x) => !names.includes(x)) }));
                      }} />
                    {g.label}
                  </label>
                </legend>
                {g.perms.map((p) => (
                  <label key={p.name} className="flex items-center gap-2 py-0.5 text-sm">
                    <input
                      type="checkbox"
                      disabled={r.builtin}
                      checked={all || r.permissions.includes(p.name)}
                      onChange={(e) => toggle(p.name, e.target.checked)}
                    />
                    <span className="flex-1">{p.label}</span>
                    <span className="text-[10px] text-slate-400">{scopeLabel[p.scope]}</span>
                  </label>
                ))}
              </fieldset>
            );
          })}
        </div>
      </div>
    </Modal>
  );
}

function BindingsTab() {
  const bindings = useQuery({ queryKey: ["bindings-all"], queryFn: () => api.get<BindingRow[]>("/admin/bindings") });
  const roles = useQuery({ queryKey: ["roles"], queryFn: () => api.get<Role[]>("/admin/roles") });
  const users = useQuery({ queryKey: ["directory"], queryFn: () => api.get<{ id: string; username: string }[]>("/directory/users") });
  const teams = useQuery({ queryKey: ["teams"], queryFn: () => api.get<{ id: string; name: string }[]>("/admin/teams") });
  const projects = useQuery({ queryKey: ["projects"], queryFn: () => api.get<ProjectListItem[]>("/projects") });
  const [f, setF] = useState({ who: "", roleId: "", scope: "global", projectId: "", environment: "" });
  const columns = useMemo<ColumnDef<BindingRow, unknown>[]>(
    () => [
      { id: "who", header: "Utilisateur / équipe", accessorFn: (b) => b.username || `équipe ${b.teamName}`, size: 200, meta: { filter: "multi" } },
      { id: "role", header: "Rôle", accessorKey: "roleName", size: 160, meta: { filter: "multi" } },
      { id: "scope", header: "Portée", accessorFn: (b) => scopeLabel[b.scope] ?? b.scope, size: 120, meta: { filter: "multi" } },
      { id: "project", header: "Projet", accessorKey: "projectName", size: 180, meta: { filter: "multi" } },
      { id: "env", header: "Environnement", accessorKey: "environment", size: 120, meta: { filter: "multi" } },
    ],
    [],
  );
  const add = async () => {
    const [kind, id] = f.who.split(":");
    try {
      await api.post("/admin/bindings", { roleId: f.roleId, userId: kind === "u" ? id : null, teamId: kind === "t" ? id : null, scope: f.scope, projectId: f.scope === "global" ? null : f.projectId, environment: f.environment });
      void bindings.refetch();
      toast.success("Attribution créée");
    } catch (e) {
      toast.error(e);
    }
  };
  return (
    <div className="space-y-3">
      <div className="flex flex-wrap items-end gap-2 rounded-lg border border-slate-200 bg-white p-3 dark:border-slate-800 dark:bg-slate-900">
        <Field label="Qui">
          <Select className="w-52" value={f.who} onChange={(e) => setF({ ...f, who: e.target.value })}>
            <option value="">—</option>
            <optgroup label="Utilisateurs">
              {(users.data ?? []).map((u) => (
                <option key={u.id} value={`u:${u.id}`}>
                  {u.username}
                </option>
              ))}
            </optgroup>
            <optgroup label="Équipes">
              {(teams.data ?? []).map((t) => (
                <option key={t.id} value={`t:${t.id}`}>
                  {t.name}
                </option>
              ))}
            </optgroup>
          </Select>
        </Field>
        <Field label="Rôle">
          <Select className="w-44" value={f.roleId} onChange={(e) => setF({ ...f, roleId: e.target.value })}>
            <option value="">—</option>
            {(roles.data ?? []).map((r) => (
              <option key={r.id} value={r.id}>
                {r.name}
              </option>
            ))}
          </Select>
        </Field>
        <Field label="Portée">
          <Select value={f.scope} onChange={(e) => setF({ ...f, scope: e.target.value })}>
            <option value="global">Globale</option>
            <option value="project">Projet</option>
            <option value="environment">Environnement</option>
          </Select>
        </Field>
        {f.scope !== "global" && (
          <Field label="Projet">
            <Select className="w-44" value={f.projectId} onChange={(e) => setF({ ...f, projectId: e.target.value })}>
              <option value="">—</option>
              {(projects.data ?? []).map((p) => (
                <option key={p.id} value={p.id}>
                  {p.name}
                </option>
              ))}
            </Select>
          </Field>
        )}
        {f.scope === "environment" && (
          <Field label="Environnement">
            <Input className="w-32" value={f.environment} onChange={(e) => setF({ ...f, environment: e.target.value })} placeholder="prod" />
          </Field>
        )}
        <Button variant="primary" disabled={!f.who || !f.roleId} onClick={add}>
          Attribuer
        </Button>
      </div>
      <div className="h-[calc(100vh-300px)]">
        <DataTable
          id="admin-bindings"
          data={bindings.data ?? []}
          columns={columns}
          onRefresh={() => void bindings.refetch()}
          getRowId={(b) => b.id}
          bulkActions={(rows, clear) => (
            <Button
              size="sm"
              variant="danger"
              onClick={async () => {
                await Promise.allSettled(rows.map((b) => api.del(`/admin/bindings/${b.id}`)));
                clear();
                void bindings.refetch();
              }}
            >
              Retirer
            </Button>
          )}
        />
      </div>
    </div>
  );
}
