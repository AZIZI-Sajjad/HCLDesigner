import { PageHeader } from "@/components/ui";
import SchedulesTable from "./SchedulesTable";

export default function Schedules() {
  return (
    <div className="p-6">
      <PageHeader title="Tâches planifiées" subtitle="Drift, plans et applies planifiés, destroy d'environnements éphémères, sauvegardes, conformité, rapports" />
      <SchedulesTable />
    </div>
  );
}
