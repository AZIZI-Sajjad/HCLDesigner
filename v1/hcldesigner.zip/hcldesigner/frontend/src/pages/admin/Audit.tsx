// Journal d'audit (lecture seule) : filtres serveur, tableau personnalisable, export CSV complet.
import { useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import type { ColumnDef } from "@tanstack/react-table";
import { api, download, qs } from "@/api/client";
import { useCan } from "@/lib/auth";
import { DataTable } from "@/components/table/DataTable";
import { Button, Field, Input, Modal, PageHeader, formatDate } from "@/components/ui";

interface AuditRow {
  id: number;
  ts: string;
  username: string;
  ip: string;
  action: string;
  objectType: string;
  objectId: string;
  details: unknown;
}

export default function Audit() {
  const can = useCan();
  const [filters, setFilters] = useState({ user: "", action: "", from: "", to: "" });
  const [applied, setApplied] = useState(filters);
  const q = useQuery({ queryKey: ["audit", applied], queryFn: () => api.get<AuditRow[]>("/admin/audit" + qs(applied)) });
  const [detail, setDetail] = useState<AuditRow | null>(null);
  const columns = useMemo<ColumnDef<AuditRow, unknown>[]>(
    () => [
      { id: "ts", header: "Date", accessorKey: "ts", size: 170, cell: (c) => formatDate(c.getValue() as string), meta: { text: (r) => formatDate(r.ts) } },
      { id: "username", header: "Utilisateur", accessorKey: "username", size: 140, meta: { filter: "multi" } },
      { id: "ip", header: "IP", accessorKey: "ip", size: 130 },
      { id: "action", header: "Action", accessorKey: "action", size: 220, meta: { filter: "multi" } },
      { id: "objectType", header: "Objet", accessorKey: "objectType", size: 130, meta: { filter: "multi" } },
      { id: "objectId", header: "Identifiant", accessorKey: "objectId", size: 280 },
      { id: "details", header: "Détails", accessorFn: (r) => JSON.stringify(r.details), size: 360 },
    ],
    [],
  );
  return (
    <div className="p-6">
      <PageHeader title="Audit" subtitle="Journal immuable de toutes les actions (2 000 dernières lignes affichées ; l'export applique les mêmes filtres sans limite)." />
      <div className="mb-3 flex flex-wrap items-end gap-2">
        <Field label="Utilisateur">
          <Input value={filters.user} onChange={(e) => setFilters({ ...filters, user: e.target.value })} />
        </Field>
        <Field label="Action (préfixe)">
          <Input value={filters.action} onChange={(e) => setFilters({ ...filters, action: e.target.value })} placeholder="run." />
        </Field>
        <Field label="Du">
          <Input type="datetime-local" value={filters.from} onChange={(e) => setFilters({ ...filters, from: e.target.value })} />
        </Field>
        <Field label="Au">
          <Input type="datetime-local" value={filters.to} onChange={(e) => setFilters({ ...filters, to: e.target.value })} />
        </Field>
        <Button variant="primary" onClick={() => setApplied(filters)}>
          Filtrer
        </Button>
        {can("audit.export") && <Button onClick={() => download("/admin/audit/export" + qs(applied))}>Export CSV complet</Button>}
      </div>
      <div className="h-[calc(100vh-230px)]">
        <DataTable id="audit" title="Audit" data={q.data ?? []} columns={columns} loading={q.isFetching} onRefresh={() => void q.refetch()} onRowClick={setDetail} getRowId={(r) => String(r.id)} />
      </div>
      {detail && (
        <Modal open wide onClose={() => setDetail(null)} title={`${detail.action} — ${formatDate(detail.ts)}`}>
          <pre className="overflow-auto rounded bg-slate-100 p-3 text-xs dark:bg-slate-800">{JSON.stringify(detail, null, 2)}</pre>
        </Modal>
      )}
    </div>
  );
}
