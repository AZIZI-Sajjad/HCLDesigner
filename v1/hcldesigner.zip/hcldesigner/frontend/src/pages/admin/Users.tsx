// Utilisateurs et équipes : création, activation, expiration, réinitialisation du mot de passe
// et de la MFA, sessions actives, permissions effectives.
import { useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import type { ColumnDef } from "@tanstack/react-table";
import { Plus } from "lucide-react";
import { api } from "@/api/client";
import { DataTable } from "@/components/table/DataTable";
import { Badge, Button, ErrorBox, Field, Input, Modal, PageHeader, Tabs, Toggle, formatDate, toast } from "@/components/ui";

interface User {
  id: string;
  username: string;
  email: string;
  displayName: string;
  active: boolean;
  isSuper: boolean;
  totpEnabled: boolean;
  expiresAt: string | null;
  lastLoginAt: string | null;
  lastLoginIp: string;
  teams: string[];
  createdAt: string;
}

interface Team {
  id: string;
  name: string;
  description: string;
  members: string[];
}

export default function Users() {
  const [tab, setTab] = useState<"users" | "teams">("users");
  return (
    <div className="p-6">
      <PageHeader title="Utilisateurs & équipes" />
      <Tabs
        tabs={[
          { id: "users", label: "Utilisateurs" },
          { id: "teams", label: "Équipes" },
        ]}
        value={tab}
        onChange={setTab}
      />
      <div className="pt-3">{tab === "users" ? <UsersTab /> : <TeamsTab />}</div>
    </div>
  );
}

function UsersTab() {
  const users = useQuery({ queryKey: ["admin-users"], queryFn: () => api.get<User[]>("/admin/users") });
  const [editing, setEditing] = useState<User | "new" | null>(null);
  const columns = useMemo<ColumnDef<User, unknown>[]>(
    () => [
      { id: "username", header: "Identifiant", accessorKey: "username", size: 150 },
      { id: "displayName", header: "Nom", accessorKey: "displayName", size: 180 },
      { id: "email", header: "Mail", accessorKey: "email", size: 220 },
      { id: "teams", header: "Équipes", accessorFn: (u) => u.teams.join(", "), size: 160 },
      { id: "active", header: "Statut", size: 100, accessorFn: (u) => (u.active ? "actif" : "désactivé"), cell: (c) => <Badge tone={c.getValue() === "actif" ? "green" : "gray"}>{c.getValue() as string}</Badge>, meta: { filter: "multi" } },
      { id: "mfa", header: "MFA", size: 70, accessorFn: (u) => (u.totpEnabled ? "oui" : "non"), meta: { filter: "multi" } },
      { id: "super", header: "Super admin", size: 100, accessorFn: (u) => (u.isSuper ? "oui" : ""), meta: { filter: "multi" } },
      { id: "lastLogin", header: "Dernière connexion", accessorKey: "lastLoginAt", size: 160, cell: (c) => formatDate(c.getValue() as string), meta: { text: (u) => formatDate(u.lastLoginAt) } },
      { id: "ip", header: "IP", accessorKey: "lastLoginIp", size: 120 },
      { id: "expires", header: "Expiration", accessorKey: "expiresAt", size: 140, cell: (c) => formatDate(c.getValue() as string) },
    ],
    [],
  );
  return (
    <div className="h-[calc(100vh-200px)]">
      <DataTable
        id="admin-users"
        title="Utilisateurs"
        data={users.data ?? []}
        columns={columns}
        onRefresh={() => void users.refetch()}
        onRowClick={(u) => setEditing(u)}
        getRowId={(u) => u.id}
        toolbar={
          <Button size="sm" variant="primary" icon={<Plus className="h-3.5 w-3.5" />} onClick={() => setEditing("new")}>
            Nouvel utilisateur
          </Button>
        }
        bulkActions={(rows, clear) => (
          <>
            {[false, true].map((active) => (
              <Button
                key={String(active)}
                size="sm"
                onClick={async () => {
                  await Promise.allSettled(rows.map((u) => api.put(`/admin/users/${u.id}`, { email: u.email, displayName: u.displayName, active, expiresAt: u.expiresAt })));
                  clear();
                  void users.refetch();
                }}
              >
                {active ? "Activer" : "Désactiver"}
              </Button>
            ))}
          </>
        )}
      />
      {editing && <UserForm user={editing === "new" ? null : editing} onClose={() => setEditing(null)} onSaved={() => (setEditing(null), void users.refetch())} />}
    </div>
  );
}

function UserForm({ user, onClose, onSaved }: { user: User | null; onClose: () => void; onSaved: () => void }) {
  const [f, setF] = useState({ username: user?.username ?? "", email: user?.email ?? "", displayName: user?.displayName ?? "", password: "", active: user?.active ?? true, expiresAt: user?.expiresAt?.slice(0, 10) ?? "", resetMfa: false });
  const [error, setError] = useState<unknown>(null);
  const sessions = useQuery({ queryKey: ["sessions", user?.id], queryFn: () => api.get<{ id: string; ip: string; userAgent: string; lastSeen: string }[]>(`/admin/users/${user!.id}/sessions`), enabled: !!user });
  const effective = useQuery({ queryKey: ["effective", user?.id], queryFn: () => api.get<{ isSuper: boolean; bindings: { roleName: string; scope: string; projectId?: string; environment?: string; viaTeam?: string; perms: string[] }[] | null }>(`/admin/users/${user!.id}/effective`), enabled: !!user, retry: false });
  const save = async () => {
    const body = { ...f, expiresAt: f.expiresAt ? new Date(f.expiresAt).toISOString() : null };
    try {
      if (user) await api.put(`/admin/users/${user.id}`, body);
      else await api.post("/admin/users", body);
      toast.success("Utilisateur enregistré");
      onSaved();
    } catch (e) {
      setError(e);
    }
  };
  return (
    <Modal
      open
      wide
      onClose={onClose}
      title={user ? `Utilisateur ${user.username}` : "Nouvel utilisateur"}
      footer={
        <>
          {user && (
            <Button variant="danger" onClick={() => window.confirm("Supprimer cet utilisateur ?") && void api.del(`/admin/users/${user.id}`).then(onSaved, toast.error)}>
              Supprimer
            </Button>
          )}
          <span className="flex-1" />
          <Button onClick={onClose}>Annuler</Button>
          <Button variant="primary" onClick={save}>
            Enregistrer
          </Button>
        </>
      }
    >
      <div className="space-y-3">
        <ErrorBox error={error} />
        <div className="grid gap-3 md:grid-cols-2">
          <Field label="Identifiant" required>
            <Input value={f.username} disabled={!!user} onChange={(e) => setF({ ...f, username: e.target.value })} />
          </Field>
          <Field label="Nom affiché">
            <Input value={f.displayName} onChange={(e) => setF({ ...f, displayName: e.target.value })} />
          </Field>
          <Field label="Mail">
            <Input type="email" value={f.email} onChange={(e) => setF({ ...f, email: e.target.value })} />
          </Field>
          <Field label={user ? "Nouveau mot de passe (vide = inchangé)" : "Mot de passe"} required={!user}>
            <Input type="password" value={f.password} onChange={(e) => setF({ ...f, password: e.target.value })} />
          </Field>
          <Field label="Expiration du compte">
            <Input type="date" value={f.expiresAt} onChange={(e) => setF({ ...f, expiresAt: e.target.value })} />
          </Field>
          <div className="space-y-2 pt-5">
            <Toggle checked={f.active} onChange={(v) => setF({ ...f, active: v })} label="Compte actif" />
            {user?.totpEnabled && <Toggle checked={f.resetMfa} onChange={(v) => setF({ ...f, resetMfa: v })} label="Réinitialiser la MFA" />}
          </div>
        </div>
        {user && (
          <>
            <div>
              <div className="flex items-center justify-between">
                <h4 className="text-sm font-semibold">Sessions actives ({sessions.data?.length ?? 0})</h4>
                <Button size="sm" onClick={() => void api.del(`/admin/users/${user.id}/sessions`).then(() => sessions.refetch())}>
                  Révoquer toutes
                </Button>
              </div>
              {(sessions.data ?? []).map((s) => (
                <div key={s.id} className="text-xs text-slate-500">
                  {s.ip} — {formatDate(s.lastSeen)} — {s.userAgent.slice(0, 80)}
                </div>
              ))}
            </div>
            <div>
              <h4 className="text-sm font-semibold">Permissions effectives</h4>
              {effective.data?.isSuper && <Badge tone="red">super admin : tous les droits</Badge>}
              {(effective.data?.bindings ?? []).map((b, i) => (
                <div key={i} className="mt-1 text-xs">
                  <b>{b.roleName}</b> — {b.scope}
                  {b.environment ? ` ${b.environment}` : ""}
                  {b.viaTeam ? ` (via équipe ${b.viaTeam})` : ""} : <span className="text-slate-500">{b.perms.join(", ")}</span>
                </div>
              ))}
            </div>
          </>
        )}
      </div>
    </Modal>
  );
}

function TeamsTab() {
  const teams = useQuery({ queryKey: ["teams"], queryFn: () => api.get<Team[]>("/admin/teams") });
  const users = useQuery({ queryKey: ["admin-users"], queryFn: () => api.get<User[]>("/admin/users") });
  const [editing, setEditing] = useState<Team | null>(null);
  const columns = useMemo<ColumnDef<Team, unknown>[]>(
    () => [
      { id: "name", header: "Équipe", accessorKey: "name", size: 200 },
      { id: "description", header: "Description", accessorKey: "description", size: 300 },
      { id: "members", header: "Membres", accessorFn: (t) => t.members.length, size: 100 },
    ],
    [],
  );
  return (
    <div className="h-[calc(100vh-200px)]">
      <DataTable
        id="admin-teams"
        data={teams.data ?? []}
        columns={columns}
        onRowClick={setEditing}
        getRowId={(t) => t.id}
        toolbar={
          <Button size="sm" variant="primary" icon={<Plus className="h-3.5 w-3.5" />} onClick={() => setEditing({ id: "", name: "", description: "", members: [] })}>
            Nouvelle équipe
          </Button>
        }
      />
      {editing && (
        <Modal
          open
          onClose={() => setEditing(null)}
          title={editing.id ? `Équipe ${editing.name}` : "Nouvelle équipe"}
          footer={
            <>
              {editing.id && (
                <Button variant="danger" onClick={() => void api.del(`/admin/teams/${editing.id}`).then(() => (setEditing(null), teams.refetch()))}>
                  Supprimer
                </Button>
              )}
              <span className="flex-1" />
              <Button
                variant="primary"
                onClick={async () => {
                  try {
                    if (editing.id) await api.put(`/admin/teams/${editing.id}`, editing);
                    else await api.post("/admin/teams", editing);
                    setEditing(null);
                    void teams.refetch();
                  } catch (e) {
                    toast.error(e);
                  }
                }}
              >
                Enregistrer
              </Button>
            </>
          }
        >
          <div className="space-y-3">
            <Field label="Nom">
              <Input value={editing.name} onChange={(e) => setEditing({ ...editing, name: e.target.value })} />
            </Field>
            <Field label="Description">
              <Input value={editing.description} onChange={(e) => setEditing({ ...editing, description: e.target.value })} />
            </Field>
            <Field label="Membres">
              <div className="grid max-h-64 grid-cols-2 gap-1 overflow-y-auto">
                {(users.data ?? []).map((u) => (
                  <label key={u.id} className="flex items-center gap-2 text-sm">
                    <input
                      type="checkbox"
                      checked={editing.members.includes(u.id)}
                      onChange={(e) => setEditing({ ...editing, members: e.target.checked ? [...editing.members, u.id] : editing.members.filter((m) => m !== u.id) })}
                    />
                    {u.displayName || u.username}
                  </label>
                ))}
              </div>
            </Field>
          </div>
        </Modal>
      )}
    </div>
  );
}
