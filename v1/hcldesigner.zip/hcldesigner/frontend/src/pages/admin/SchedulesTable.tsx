// Tâches planifiées : liste, création (assistant cron + aperçu des prochaines exécutions),
// activation, exécution immédiate, historique des exécutions.
import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import type { ColumnDef } from "@tanstack/react-table";
import { Plus } from "lucide-react";
import { api, qs } from "@/api/client";
import type { Environment, ProjectListItem } from "@/types/api";
import { DataTable } from "@/components/table/DataTable";
import { Badge, Button, ErrorBox, Field, Input, Modal, Select, Toggle, formatDate, toast } from "@/components/ui";

interface Schedule {
  id: string;
  name: string;
  kind: string;
  cron: string;
  timezone: string;
  projectId: string | null;
  projectName: string;
  environmentId: string | null;
  environmentName: string;
  params: Record<string, unknown>;
  enabled: boolean;
  timeoutS: number;
  maxRetries: number;
  nextRunAt: string | null;
  lastRunAt: string | null;
  lastStatus: string;
}

interface Kind {
  kind: string;
  label: string;
  needsEnv: boolean;
  description: string;
}

const statusTone = (s: string) => (s === "succeeded" ? "green" : s === "failed" ? "red" : s === "running" ? "blue" : "gray");

export default function SchedulesTable({ projectId }: { projectId?: string }) {
  const list = useQuery({ queryKey: ["schedules", projectId], queryFn: () => api.get<Schedule[]>("/schedules" + qs({ project: projectId })), refetchInterval: 15000 });
  const kinds = useQuery({ queryKey: ["schedule-kinds"], queryFn: () => api.get<Kind[]>("/schedules/kinds") });
  const [editing, setEditing] = useState<Schedule | "new" | null>(null);
  const [history, setHistory] = useState<Schedule | null>(null);
  const kindLabel = (k: string) => kinds.data?.find((x) => x.kind === k)?.label ?? k;

  const toggle = async (s: Schedule) => {
    try {
      await api.put(`/schedules/${s.id}`, { ...s, enabled: !s.enabled });
      void list.refetch();
    } catch (e) {
      toast.error(e);
    }
  };

  const columns = useMemo<ColumnDef<Schedule, unknown>[]>(
    () => [
      { id: "name", header: "Nom", accessorKey: "name", size: 200 },
      { id: "kind", header: "Type", size: 200, accessorFn: (s) => kindLabel(s.kind), meta: { filter: "multi" } },
      ...(projectId ? [] : [{ id: "project", header: "Projet", accessorKey: "projectName", size: 150, meta: { filter: "multi" as const } }]),
      { id: "env", header: "Environnement", accessorKey: "environmentName", size: 120, meta: { filter: "multi" } },
      { id: "cron", header: "Cron", accessorKey: "cron", size: 120, cell: (c) => <code className="text-xs">{c.getValue() as string}</code> },
      { id: "next", header: "Prochaine", accessorKey: "nextRunAt", size: 150, cell: (c) => formatDate(c.getValue() as string), meta: { text: (s) => formatDate(s.nextRunAt) } },
      { id: "last", header: "Dernière", accessorKey: "lastRunAt", size: 150, cell: (c) => formatDate(c.getValue() as string), meta: { text: (s) => formatDate(s.lastRunAt) } },
      { id: "status", header: "Statut", accessorKey: "lastStatus", size: 100, cell: (c) => (c.getValue() ? <Badge tone={statusTone(c.getValue() as string)}>{c.getValue() as string}</Badge> : null), meta: { filter: "multi" } },
      {
        id: "enabled",
        header: "Active",
        size: 80,
        accessorFn: (s) => (s.enabled ? "oui" : "non"),
        cell: ({ row }) => (
          <span onClick={(e) => e.stopPropagation()}>
            <Toggle checked={row.original.enabled} onChange={() => void toggle(row.original)} />
          </span>
        ),
        meta: { filter: "multi" },
      },
      {
        id: "actions",
        header: "Actions",
        size: 230,
        enableSorting: false,
        cell: ({ row }) => (
          <div className="flex gap-1" onClick={(e) => e.stopPropagation()}>
            <Button
              size="sm"
              onClick={async () => {
                try {
                  await api.post(`/schedules/${row.original.id}/run`);
                  toast.success("Exécution lancée");
                  void list.refetch();
                } catch (e) {
                  toast.error(e);
                }
              }}
            >
              Exécuter
            </Button>
            <Button size="sm" onClick={() => setHistory(row.original)}>
              Historique
            </Button>
          </div>
        ),
      },
    ],
    [projectId, kinds.data], // eslint-disable-line react-hooks/exhaustive-deps
  );

  return (
    <div className="h-[calc(100vh-180px)] min-h-[400px]">
      <DataTable
        id={projectId ? "project-schedules" : "schedules"}
        title="Tâches planifiées"
        data={list.data ?? []}
        columns={columns}
        loading={list.isFetching}
        onRefresh={() => void list.refetch()}
        onRowClick={(s) => setEditing(s)}
        getRowId={(s) => s.id}
        toolbar={
          <Button size="sm" variant="primary" icon={<Plus className="h-3.5 w-3.5" />} onClick={() => setEditing("new")}>
            Nouvelle tâche
          </Button>
        }
        bulkActions={(rows, clear) => (
          <>
            {[true, false].map((en) => (
              <Button
                key={String(en)}
                size="sm"
                onClick={async () => {
                  await Promise.allSettled(rows.map((s) => api.put(`/schedules/${s.id}`, { ...s, enabled: en })));
                  clear();
                  void list.refetch();
                }}
              >
                {en ? "Activer" : "Désactiver"}
              </Button>
            ))}
          </>
        )}
      />
      {editing && <ScheduleForm schedule={editing === "new" ? null : editing} kinds={kinds.data ?? []} projectId={projectId} onClose={() => setEditing(null)} onSaved={() => (setEditing(null), void list.refetch())} />}
      {history && <HistoryDialog schedule={history} onClose={() => setHistory(null)} />}
    </div>
  );
}

const presets = [
  { label: "Toutes les nuits à 2 h", cron: "0 2 * * *" },
  { label: "Toutes les heures", cron: "0 * * * *" },
  { label: "Du lundi au vendredi à 7 h", cron: "0 7 * * 1-5" },
  { label: "Vendredi à 20 h", cron: "0 20 * * 5" },
  { label: "Le 1er du mois à 6 h", cron: "0 6 1 * *" },
];

function ScheduleForm({ schedule, kinds, projectId, onClose, onSaved }: { schedule: Schedule | null; kinds: Kind[]; projectId?: string; onClose: () => void; onSaved: () => void }) {
  const [s, setS] = useState<Partial<Schedule>>(
    schedule ?? { name: "", kind: "drift", cron: "0 2 * * *", timezone: "Europe/Paris", projectId: projectId ?? null, environmentId: null, params: {}, enabled: true, timeoutS: 3600, maxRetries: 0 },
  );
  const [preview, setPreview] = useState<string[]>([]);
  const [error, setError] = useState<unknown>(null);
  const projects = useQuery({ queryKey: ["projects"], queryFn: () => api.get<ProjectListItem[]>("/projects") });
  const envs = useQuery({ queryKey: ["envs", s.projectId], queryFn: () => api.get<Environment[]>(`/projects/${s.projectId}/environments`), enabled: !!s.projectId });
  const kind = kinds.find((k) => k.kind === s.kind);
  const params = (s.params ?? {}) as Record<string, unknown>;
  const setParam = (k: string, v: unknown) => setS({ ...s, params: { ...params, [k]: v } });
  const plans = useQuery({
    queryKey: ["planned", s.environmentId],
    queryFn: () => api.get<{ id: string; createdAt: string }[]>("/runs" + qs({ environment: s.environmentId, status: "planned" })),
    enabled: s.kind === "apply_plan" && !!s.environmentId,
  });

  useEffect(() => {
    const t = setTimeout(() => {
      api
        .post<string[]>("/schedules/preview", { cron: s.cron, timezone: s.timezone })
        .then((r) => setPreview(r.map((d) => formatDate(d))))
        .catch((e: Error) => setPreview([e.message]));
    }, 300);
    return () => clearTimeout(t);
  }, [s.cron, s.timezone]);

  const save = async () => {
    try {
      if (schedule) await api.put(`/schedules/${schedule.id}`, s);
      else await api.post("/schedules", s);
      toast.success("Tâche enregistrée");
      onSaved();
    } catch (e) {
      setError(e);
    }
  };
  const remove = async () => {
    if (!schedule || !window.confirm("Supprimer cette tâche ?")) return;
    await api.del(`/schedules/${schedule.id}`).catch(toast.error);
    onSaved();
  };

  return (
    <Modal
      open
      wide
      onClose={onClose}
      title={schedule ? `Tâche « ${schedule.name} »` : "Nouvelle tâche planifiée"}
      footer={
        <>
          {schedule && (
            <Button variant="danger" onClick={remove}>
              Supprimer
            </Button>
          )}
          <span className="flex-1" />
          <Button onClick={onClose}>Annuler</Button>
          <Button variant="primary" onClick={save}>
            Enregistrer
          </Button>
        </>
      }
    >
      <div className="space-y-3">
        <ErrorBox error={error} />
        <div className="grid gap-3 md:grid-cols-2">
          <Field label="Nom" required>
            <Input value={s.name ?? ""} onChange={(e) => setS({ ...s, name: e.target.value })} />
          </Field>
          <Field label="Type" help={kind?.description}>
            <Select value={s.kind} onChange={(e) => setS({ ...s, kind: e.target.value })}>
              {kinds.map((k) => (
                <option key={k.kind} value={k.kind}>
                  {k.label}
                </option>
              ))}
            </Select>
          </Field>
          <Field label="Projet" help={kind && !kind.needsEnv ? "Vide = tous les projets (admin.settings requis)" : undefined}>
            <Select value={s.projectId ?? ""} disabled={!!projectId} onChange={(e) => setS({ ...s, projectId: e.target.value || null, environmentId: null })}>
              <option value="">{kind?.needsEnv ? "— choisir —" : "Tous les projets"}</option>
              {(projects.data ?? []).map((p) => (
                <option key={p.id} value={p.id}>
                  {p.name}
                </option>
              ))}
            </Select>
          </Field>
          {kind?.needsEnv && (
            <Field label="Environnement" required>
              <Select value={s.environmentId ?? ""} onChange={(e) => setS({ ...s, environmentId: e.target.value || null })}>
                <option value="">— choisir —</option>
                {(envs.data ?? []).map((e) => (
                  <option key={e.id} value={e.id}>
                    {e.name}
                  </option>
                ))}
              </Select>
            </Field>
          )}
        </div>

        <div className="grid gap-3 md:grid-cols-3">
          <Field label="Expression cron" help="minute heure jour mois jour-semaine">
            <Input className="font-mono" value={s.cron ?? ""} onChange={(e) => setS({ ...s, cron: e.target.value })} />
          </Field>
          <Field label="Modèle">
            <Select value="" onChange={(e) => e.target.value && setS({ ...s, cron: e.target.value })}>
              <option value="">— choisir un modèle —</option>
              {presets.map((p) => (
                <option key={p.cron} value={p.cron}>
                  {p.label}
                </option>
              ))}
            </Select>
          </Field>
          <Field label="Fuseau horaire">
            <Input value={s.timezone ?? ""} onChange={(e) => setS({ ...s, timezone: e.target.value })} />
          </Field>
        </div>
        <div className="rounded bg-slate-100 p-2 text-xs dark:bg-slate-800">
          Prochaines exécutions : {preview.join(" · ")}
        </div>

        {s.kind === "plan" && <Toggle checked={params.autoApply === true} onChange={(v) => setParam("autoApply", v)} label="Apply automatique si aucune approbation n'est requise" />}
        {s.kind === "apply_plan" && (
          <Field label="Plan approuvé à appliquer">
            <Select value={String(params.planRunId ?? "")} onChange={(e) => setParam("planRunId", e.target.value)}>
              <option value="">— choisir —</option>
              {(plans.data ?? []).map((p) => (
                <option key={p.id} value={p.id}>
                  {formatDate(p.createdAt)} — {p.id.slice(0, 8)}
                </option>
              ))}
            </Select>
          </Field>
        )}
        {(s.kind === "compliance_scan" || s.kind === "report_export") && (
          <div className="grid gap-3 md:grid-cols-2">
            <Field label="Destinataires (séparés par des virgules)">
              <Input
                value={((params.recipients as string[]) ?? []).join(", ")}
                onChange={(e) => setParam("recipients", e.target.value.split(",").map((x) => x.trim()).filter(Boolean))}
              />
            </Field>
            {s.kind === "report_export" && (
              <Field label="Période (jours)">
                <Input type="number" value={Number(params.days ?? 7)} onChange={(e) => setParam("days", Number(e.target.value))} />
              </Field>
            )}
          </div>
        )}
        <div className="grid gap-3 md:grid-cols-3">
          <Field label="Délai max (secondes)">
            <Input type="number" value={s.timeoutS ?? 3600} onChange={(e) => setS({ ...s, timeoutS: Number(e.target.value) })} />
          </Field>
          <Field label="Nouvelles tentatives en cas d'échec">
            <Input type="number" min={0} max={5} value={s.maxRetries ?? 0} onChange={(e) => setS({ ...s, maxRetries: Number(e.target.value) })} />
          </Field>
          <div className="pt-6">
            <Toggle checked={s.enabled ?? true} onChange={(v) => setS({ ...s, enabled: v })} label="Active" />
          </div>
        </div>
      </div>
    </Modal>
  );
}

function HistoryDialog({ schedule, onClose }: { schedule: Schedule; onClose: () => void }) {
  const navigate = useNavigate();
  const q = useQuery({
    queryKey: ["schedule-exec", schedule.id],
    queryFn: () => api.get<{ id: string; status: string; runId: string | null; message: string; manual: boolean; startedAt: string; durationS: number }[]>(`/schedules/${schedule.id}/executions`),
    refetchInterval: 5000,
  });
  return (
    <Modal open wide onClose={onClose} title={`Historique — ${schedule.name}`}>
      <table className="w-full text-sm">
        <thead className="text-left text-xs text-slate-500">
          <tr>
            <th>Début</th>
            <th>Statut</th>
            <th>Durée</th>
            <th>Message</th>
            <th />
          </tr>
        </thead>
        <tbody>
          {(q.data ?? []).map((e) => (
            <tr key={e.id} className="border-t border-slate-100 dark:border-slate-800">
              <td className="py-1">{formatDate(e.startedAt)}</td>
              <td>
                <Badge tone={statusTone(e.status)}>{e.status}</Badge> {e.manual && <Badge>manuel</Badge>}
              </td>
              <td>{e.durationS ? `${Math.round(e.durationS)} s` : ""}</td>
              <td className="max-w-xs truncate" title={e.message}>
                {e.message}
              </td>
              <td>
                {e.runId && (
                  <Button size="sm" variant="ghost" onClick={() => navigate(`/runs/${e.runId}`)}>
                    Voir le run
                  </Button>
                )}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </Modal>
  );
}
