// Coffre de credentials : les valeurs sont chiffrées côté serveur et ne sont jamais renvoyées ;
// seuls les noms des champs renseignés sont affichés.
import { useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import type { ColumnDef } from "@tanstack/react-table";
import { Plus } from "lucide-react";
import { api } from "@/api/client";
import type { CredentialKind } from "@/types/api";
import { DataTable } from "@/components/table/DataTable";
import { FieldsForm } from "@/components/FieldsForm";
import { Button, ErrorBox, Field, Input, Modal, PageHeader, Select, formatDate, toast } from "@/components/ui";

interface Credential {
  id: string;
  name: string;
  kind: string;
  description: string;
  fields: string[] | null;
  createdBy: string;
  updatedAt: string;
  usedBy: number;
}

export default function Credentials() {
  const list = useQuery({ queryKey: ["credentials-admin"], queryFn: () => api.get<Credential[]>("/credentials") });
  const kinds = useQuery({ queryKey: ["credential-kinds"], queryFn: () => api.get<CredentialKind[]>("/credential-kinds") });
  const [editing, setEditing] = useState<Credential | null>(null);
  const columns = useMemo<ColumnDef<Credential, unknown>[]>(
    () => [
      { id: "name", header: "Nom", accessorKey: "name", size: 220 },
      { id: "kind", header: "Type", accessorKey: "kind", size: 120, meta: { filter: "multi" } },
      { id: "description", header: "Description", accessorKey: "description", size: 260 },
      { id: "fields", header: "Champs renseignés", accessorFn: (c) => (c.fields ?? []).join(", "), size: 260 },
      { id: "usedBy", header: "Environnements", accessorKey: "usedBy", size: 120 },
      { id: "updatedAt", header: "Modifié", accessorKey: "updatedAt", size: 150, cell: (c) => formatDate(c.getValue() as string) },
    ],
    [],
  );
  return (
    <div className="p-6">
      <PageHeader title="Credentials" subtitle="Injectés en variables d'environnement dans le runner, masqués dans les logs, chiffrés AES-256-GCM." />
      <div className="h-[calc(100vh-150px)]">
        <DataTable
          id="credentials"
          data={list.data ?? []}
          columns={columns}
          onRowClick={setEditing}
          getRowId={(c) => c.id}
          toolbar={
            <Button size="sm" variant="primary" icon={<Plus className="h-3.5 w-3.5" />} onClick={() => setEditing({ id: "", name: "", kind: "aws", description: "", fields: [], createdBy: "", updatedAt: "", usedBy: 0 })}>
              Nouveau credential
            </Button>
          }
        />
      </div>
      {editing && <CredentialForm cred={editing} kinds={(kinds.data ?? []).filter((k) => k.kind !== "backend")} onClose={() => setEditing(null)} onSaved={() => (setEditing(null), void list.refetch())} />}
    </div>
  );
}

function CredentialForm({ cred, kinds, onClose, onSaved }: { cred: Credential; kinds: CredentialKind[]; onClose: () => void; onSaved: () => void }) {
  const [name, setName] = useState(cred.name);
  const [kind, setKind] = useState(cred.kind);
  const [description, setDescription] = useState(cred.description);
  const [data, setData] = useState<Record<string, unknown>>({});
  const [error, setError] = useState<unknown>(null);
  const k = kinds.find((x) => x.kind === kind);
  const save = async () => {
    const body = { name, kind, description, data: Object.fromEntries(Object.entries(data).map(([key, v]) => [key, String(v ?? "")])) };
    try {
      if (cred.id) await api.put(`/credentials/${cred.id}`, body);
      else await api.post("/credentials", body);
      toast.success("Credential enregistré");
      onSaved();
    } catch (e) {
      setError(e);
    }
  };
  return (
    <Modal
      open
      wide
      onClose={onClose}
      title={cred.id ? cred.name : "Nouveau credential"}
      footer={
        <>
          {cred.id && (
            <Button variant="danger" onClick={() => void api.del(`/credentials/${cred.id}`).then(onSaved, toast.error)}>
              Supprimer
            </Button>
          )}
          <span className="flex-1" />
          <Button onClick={onClose}>Annuler</Button>
          <Button variant="primary" onClick={save}>
            Enregistrer
          </Button>
        </>
      }
    >
      <div className="space-y-3">
        <ErrorBox error={error} />
        <div className="grid gap-3 md:grid-cols-3">
          <Field label="Nom" required>
            <Input value={name} onChange={(e) => setName(e.target.value)} />
          </Field>
          <Field label="Type">
            <Select value={kind} disabled={!!cred.id} onChange={(e) => (setKind(e.target.value), setData({}))}>
              {kinds.map((x) => (
                <option key={x.kind} value={x.kind}>
                  {x.label}
                </option>
              ))}
            </Select>
          </Field>
          <Field label="Description">
            <Input value={description} onChange={(e) => setDescription(e.target.value)} />
          </Field>
        </div>
        {k && <FieldsForm fields={k.fields.map((f) => ({ ...f, secret: f.secret || !!cred.id }))} values={data} onChange={setData} secretsSet={cred.fields ?? []} />}
        {cred.id && <p className="text-xs text-slate-500">Les champs laissés vides conservent leur valeur.</p>}
      </div>
    </Modal>
  );
}
