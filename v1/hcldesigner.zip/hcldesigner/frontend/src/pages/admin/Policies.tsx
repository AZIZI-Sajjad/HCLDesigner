// Règles de conformité : création sans code (tags, valeurs, régions, nommage, ouverture réseau...),
// sévérité (info, avertissement, bloquant) et portée (tous les projets ou un projet).
import { useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import type { ColumnDef } from "@tanstack/react-table";
import { Plus } from "lucide-react";
import { api } from "@/api/client";
import type { ProjectListItem } from "@/types/api";
import { DataTable } from "@/components/table/DataTable";
import { Badge, Button, ErrorBox, Field, Input, Modal, PageHeader, Select, Toggle, toast } from "@/components/ui";

interface Policy {
  id: string;
  name: string;
  kind: string;
  severity: "info" | "warning" | "blocking";
  enabled: boolean;
  params: Record<string, unknown>;
  projectId: string | null;
}
interface Kind {
  kind: string;
  label: string;
  params: string[];
}

const sevTone = { info: "gray", warning: "yellow", blocking: "red" } as const;
const sevLabel = { info: "info", warning: "avertissement", blocking: "bloquant" };

const paramMeta: Record<string, { label: string; list?: boolean; help?: string }> = {
  types: { label: "Types concernés (glob)", help: "ex. aws_instance ou aws_* — vide = tous" },
  tags: { label: "Tags obligatoires", list: true },
  attribute: { label: "Attribut (chemin)", help: "ex. instance_type ou root_block_device.encrypted" },
  values: { label: "Valeurs autorisées", list: true },
  value: { label: "Valeur imposée", help: "ex. true" },
  regex: { label: "Expression régulière du nom" },
  ports: { label: "Ports surveillés (vide = tous)", list: true },
  regions: { label: "Régions autorisées", list: true },
  source: { label: "Provider (source)", help: "ex. hashicorp/aws" },
  min: { label: "Version minimale", help: "ex. 5.30.0" },
};

export default function Policies() {
  const list = useQuery({ queryKey: ["policies"], queryFn: () => api.get<Policy[]>("/policies") });
  const kinds = useQuery({ queryKey: ["policy-kinds"], queryFn: () => api.get<Kind[]>("/policies/kinds") });
  const projects = useQuery({ queryKey: ["projects"], queryFn: () => api.get<ProjectListItem[]>("/projects") });
  const [editing, setEditing] = useState<Policy | null>(null);
  const kindLabel = (k: string) => kinds.data?.find((x) => x.kind === k)?.label ?? k;
  const columns = useMemo<ColumnDef<Policy, unknown>[]>(
    () => [
      { id: "name", header: "Nom", accessorKey: "name", size: 220 },
      { id: "kind", header: "Type", accessorFn: (p) => kindLabel(p.kind), size: 240, meta: { filter: "multi" } },
      { id: "severity", header: "Sévérité", accessorFn: (p) => sevLabel[p.severity], size: 120, cell: ({ row }) => <Badge tone={sevTone[row.original.severity]}>{sevLabel[row.original.severity]}</Badge>, meta: { filter: "multi" } },
      { id: "scope", header: "Portée", accessorFn: (p) => projects.data?.find((x) => x.id === p.projectId)?.name ?? "tous les projets", size: 180, meta: { filter: "multi" } },
      { id: "enabled", header: "Active", accessorFn: (p) => (p.enabled ? "oui" : "non"), size: 80, meta: { filter: "multi" } },
      { id: "params", header: "Paramètres", accessorFn: (p) => JSON.stringify(p.params), size: 320 },
    ],
    [kinds.data, projects.data], // eslint-disable-line react-hooks/exhaustive-deps
  );
  return (
    <div className="p-6">
      <PageHeader title="Conformité" subtitle="Évaluée en continu sur le canvas et sur chaque plan ; une règle bloquante empêche l'apply." />
      <div className="h-[calc(100vh-150px)]">
        <DataTable
          id="policies"
          data={list.data ?? []}
          columns={columns}
          onRowClick={setEditing}
          getRowId={(p) => p.id}
          toolbar={
            <Button size="sm" variant="primary" icon={<Plus className="h-3.5 w-3.5" />} onClick={() => setEditing({ id: "", name: "", kind: "required_tags", severity: "warning", enabled: true, params: {}, projectId: null })}>
              Nouvelle règle
            </Button>
          }
        />
      </div>
      {editing && <PolicyForm policy={editing} kinds={kinds.data ?? []} projects={projects.data ?? []} onClose={() => setEditing(null)} onSaved={() => (setEditing(null), void list.refetch())} />}
    </div>
  );
}

function PolicyForm({ policy, kinds, projects, onClose, onSaved }: { policy: Policy; kinds: Kind[]; projects: ProjectListItem[]; onClose: () => void; onSaved: () => void }) {
  const [p, setP] = useState(policy);
  const [error, setError] = useState<unknown>(null);
  const kind = kinds.find((k) => k.kind === p.kind);
  const setParam = (name: string, raw: string) => {
    const meta = paramMeta[name];
    let v: unknown = raw;
    if (meta?.list) v = raw.split(",").map((x) => x.trim()).filter(Boolean).map((x) => (name === "ports" ? Number(x) : x));
    else if (name === "value") v = raw === "true" ? true : raw === "false" ? false : isNaN(Number(raw)) || raw === "" ? raw : Number(raw);
    setP({ ...p, params: { ...p.params, [name]: v } });
  };
  const save = async () => {
    try {
      if (p.id) await api.put(`/policies/${p.id}`, p);
      else await api.post("/policies", p);
      toast.success("Règle enregistrée");
      onSaved();
    } catch (e) {
      setError(e);
    }
  };
  return (
    <Modal
      open
      onClose={onClose}
      title={p.id ? p.name : "Nouvelle règle"}
      footer={
        <>
          {p.id && (
            <Button variant="danger" onClick={() => void api.del(`/policies/${p.id}`).then(onSaved, toast.error)}>
              Supprimer
            </Button>
          )}
          <span className="flex-1" />
          <Button onClick={onClose}>Annuler</Button>
          <Button variant="primary" onClick={save}>
            Enregistrer
          </Button>
        </>
      }
    >
      <div className="space-y-3">
        <ErrorBox error={error} />
        <Field label="Nom" required>
          <Input value={p.name} onChange={(e) => setP({ ...p, name: e.target.value })} />
        </Field>
        <Field label="Type de règle">
          <Select value={p.kind} onChange={(e) => setP({ ...p, kind: e.target.value, params: {} })}>
            {kinds.map((k) => (
              <option key={k.kind} value={k.kind}>
                {k.label}
              </option>
            ))}
          </Select>
        </Field>
        {kind?.params.map((name) => {
          const meta = paramMeta[name] ?? { label: name };
          const v = p.params[name];
          return (
            <Field key={name} label={meta.label + (meta.list ? " (séparés par des virgules)" : "")} help={meta.help}>
              <Input value={Array.isArray(v) ? v.join(", ") : v === undefined ? "" : String(v)} onChange={(e) => setParam(name, e.target.value)} />
            </Field>
          );
        })}
        <div className="grid gap-3 md:grid-cols-2">
          <Field label="Sévérité">
            <Select value={p.severity} onChange={(e) => setP({ ...p, severity: e.target.value as Policy["severity"] })}>
              <option value="info">Information</option>
              <option value="warning">Avertissement</option>
              <option value="blocking">Bloquant (empêche l'apply)</option>
            </Select>
          </Field>
          <Field label="Portée">
            <Select value={p.projectId ?? ""} onChange={(e) => setP({ ...p, projectId: e.target.value || null })}>
              <option value="">Tous les projets</option>
              {projects.map((x) => (
                <option key={x.id} value={x.id}>
                  {x.name}
                </option>
              ))}
            </Select>
          </Field>
        </div>
        <Toggle checked={p.enabled} onChange={(v) => setP({ ...p, enabled: v })} label="Active" />
      </div>
    </Modal>
  );
}
