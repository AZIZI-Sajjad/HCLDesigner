// Cache des schémas de providers : versions résolues, nombre de ressources, résolution manuelle.
import { useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import type { ColumnDef } from "@tanstack/react-table";
import { api } from "@/api/client";
import type { ProviderSchemaRow } from "@/types/api";
import { DataTable } from "@/components/table/DataTable";
import { Button, Card, Field, Input, PageHeader, Select, formatDate, toast } from "@/components/ui";

export default function Providers() {
  const list = useQuery({ queryKey: ["provider-schemas"], queryFn: () => api.get<ProviderSchemaRow[]>("/providers") });
  const [source, setSource] = useState("");
  const [version, setVersion] = useState("");
  const [engine, setEngine] = useState("terraform");
  const [busy, setBusy] = useState(false);
  const columns = useMemo<ColumnDef<ProviderSchemaRow, unknown>[]>(
    () => [
      { id: "source", header: "Source", accessorKey: "source", size: 240, meta: { filter: "multi" } },
      { id: "version", header: "Version", accessorKey: "version", size: 120 },
      { id: "resources", header: "Ressources", accessorKey: "resources", size: 110 },
      { id: "dataSources", header: "Data sources", accessorKey: "dataSources", size: 110 },
      { id: "address", header: "Adresse", accessorKey: "address", size: 320 },
      { id: "fetchedAt", header: "Résolu le", accessorKey: "fetchedAt", size: 160, cell: (c) => formatDate(c.getValue() as string) },
    ],
    [],
  );
  const resolve = async () => {
    setBusy(true);
    try {
      const { jobId } = await api.post<{ jobId: string }>("/providers/resolve", { source, version, engine });
      for (;;) {
        await new Promise((r) => setTimeout(r, 2000));
        const j = await api.get<{ status: string; version: string; error: string }>(`/providers/jobs/${jobId}`);
        if (j.status === "succeeded") {
          toast.success(`${source} ${j.version} résolu`);
          break;
        }
        if (j.status === "failed") throw new Error(j.error);
      }
      void list.refetch();
    } catch (e) {
      toast.error(e);
    } finally {
      setBusy(false);
    }
  };
  return (
    <div className="space-y-4 p-6">
      <PageHeader title="Providers" subtitle="Schémas obtenus par terraform providers schema -json, mis en cache par version exacte." />
      <Card title="Résoudre un provider">
        <div className="flex flex-wrap items-end gap-2">
          <Field label="Source">
            <Input className="w-64" value={source} onChange={(e) => setSource(e.target.value.trim())} placeholder="hashicorp/aws" />
          </Field>
          <Field label="Contrainte">
            <Input className="w-36" value={version} onChange={(e) => setVersion(e.target.value)} placeholder="~> 5.0" />
          </Field>
          <Field label="Moteur">
            <Select value={engine} onChange={(e) => setEngine(e.target.value)}>
              <option value="terraform">Terraform</option>
              <option value="opentofu">OpenTofu</option>
            </Select>
          </Field>
          <Button variant="primary" loading={busy} disabled={!source.includes("/")} onClick={resolve}>
            Résoudre
          </Button>
        </div>
      </Card>
      <div className="h-[calc(100vh-320px)]">
        <DataTable id="provider-schemas" data={list.data ?? []} columns={columns} onRefresh={() => void list.refetch()} getRowId={(r) => `${r.source}@${r.version}`} />
      </div>
    </div>
  );
}
