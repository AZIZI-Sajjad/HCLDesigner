// Génération et contrôle de conformité en temps réel (différés) du modèle en cours d'édition.
import { useEffect, useState } from "react";
import { api } from "@/api/client";
import type { GenerateResult, Violation } from "@/types/api";
import type { Project } from "@/types/model";
import { useEditor } from "@/store/editor";

/** endpoint : /projects/:id/generate ou /modules/:id/generate ; bodyKey : "model" ou "draft". */
export function useLiveGenerate(endpoint: string, model: Project | null, bodyKey: "model" | "draft" = "model", policiesEndpoint?: string) {
  const [result, setResult] = useState<GenerateResult | null>(null);
  const setDiagnostics = useEditor((s) => s.setDiagnostics);
  const setViolations = useEditor((s) => s.setViolations);

  useEffect(() => {
    if (!model) return;
    const t = setTimeout(() => {
      api
        .post<GenerateResult>(endpoint, { [bodyKey]: model })
        .then((r) => {
          setResult(r);
          setDiagnostics(r.diagnostics ?? []);
        })
        .catch(() => undefined);
      if (policiesEndpoint)
        api
          .post<{ violations: Violation[] | null }>(policiesEndpoint, { model })
          .then((r) => setViolations(r.violations ?? []))
          .catch(() => undefined);
    }, 700);
    return () => clearTimeout(t);
  }, [endpoint, model, bodyKey, policiesEndpoint, setDiagnostics, setViolations]);

  return result;
}
