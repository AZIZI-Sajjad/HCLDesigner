// Opérations pures sur le modèle de projet (sans état React) : liens dérivés,
// adresses, labels uniques, application/suppression de références.
import type { Edge, Project, Ref, TfNode, Value } from "@/types/model";

export function nodeAddress(n: TfNode): string {
  switch (n.kind) {
    case "resource":
      return `${n.type}.${n.label}`;
    case "data":
      return `data.${n.type}.${n.label}`;
    case "module":
      return `module.${n.label}`;
    case "variable":
      return `var.${n.label}`;
    case "local":
      return `local.${n.label}`;
    case "output":
      return `output.${n.label}`;
  }
}

const exprAddrRe = /[A-Za-z_][A-Za-z0-9_-]*(?:\.[A-Za-z_][A-Za-z0-9_-]*)+/g;

/** Ids des nœuds cités dans une expression brute (même règle que model.ExprRefs côté Go). */
export function exprRefs(expr: string, byAddr: Map<string, string>): string[] {
  const out: string[] = [];
  for (const m of expr.match(exprAddrRe) ?? []) {
    const parts = m.split(".");
    const n = parts[0] === "data" ? 3 : 2;
    if (parts.length < n) continue;
    const id = byAddr.get(parts.slice(0, n).join("."));
    if (id && !out.includes(id)) out.push(id);
  }
  return out;
}

/** Liens dérivés des références (même algorithme que model.Edges côté Go). */
export function deriveEdges(p: Project): Edge[] {
  const out: Edge[] = [];
  const byAddr = new Map(p.nodes.filter((n) => n.kind !== "output").map((n) => [nodeAddress(n), n.id]));
  for (const n of p.nodes) {
    const walk = (path: string, v?: Value) => {
      if (!v) return;
      if (v.mode === "ref" && v.ref?.node) {
        out.push({ id: `${v.ref.node}:${v.ref.attr}->${n.id}:${path}`, source: v.ref.node, sourceAttr: v.ref.attr, target: n.id, targetPath: path, kind: "ref" });
      } else if (v.mode === "list") {
        v.items?.forEach((it, i) => walk(`${path}[${i}]`, it));
      } else if (v.mode === "expr" && v.expr) {
        for (const src of exprRefs(v.expr, byAddr)) {
          if (src !== n.id) out.push({ id: `${src}:expr->${n.id}:${path}`, source: src, sourceAttr: "", target: n.id, targetPath: path, kind: "expr" });
        }
      }
    };
    for (const [k, v] of Object.entries(n.attrs)) walk(k, v);
    const walkBlocks = (prefix: string, blocks?: Record<string, { attrs: Record<string, Value>; blocks?: Record<string, never> }[]>) => {
      for (const [bn, list] of Object.entries(blocks ?? {})) {
        list.forEach((b, i) => {
          const p2 = `${prefix}${bn}[${i}]`;
          for (const [k, v] of Object.entries(b.attrs ?? {})) walk(`${p2}.${k}`, v);
          walkBlocks(`${p2}.`, b.blocks);
        });
      }
    };
    walkBlocks("", n.blocks as never);
    walk("count", n.meta.count);
    walk("for_each", n.meta.forEach);
    for (const d of n.meta.dependsOn ?? []) out.push({ id: `${d}->${n.id}:depends_on`, source: d, sourceAttr: "", target: n.id, targetPath: "depends_on", kind: "depends_on" });
  }
  return out;
}

/** L'ajout du lien source -> target créerait-il un cycle ? */
export function wouldCycle(p: Project, source: string, target: string): boolean {
  if (source === target) return true;
  const adj = new Map<string, string[]>();
  for (const e of deriveEdges(p)) adj.set(e.source, [...(adj.get(e.source) ?? []), e.target]);
  const seen = new Set<string>();
  const queue = [target];
  while (queue.length) {
    const u = queue.shift()!;
    if (u === source) return true;
    if (seen.has(u)) continue;
    seen.add(u);
    queue.push(...(adj.get(u) ?? []));
  }
  return false;
}

export const LABEL_RE = /^[a-zA-Z_][a-zA-Z0-9_-]*$/;

/** Label HCL unique pour un nouveau nœud. */
export function uniqueLabel(p: Project, kind: TfNode["kind"], type: string, base: string): string {
  const clean = base.replace(/[^a-zA-Z0-9_-]/g, "_").replace(/^([0-9-])/, "_$1") || "main";
  const taken = new Set(
    p.nodes.filter((n) => n.kind === kind && (kind === "resource" || kind === "data" ? n.type === type : true)).map((n) => n.label),
  );
  if (!taken.has(clean)) return clean;
  for (let i = 2; ; i++) if (!taken.has(`${clean}_${i}`)) return `${clean}_${i}`;
}

/**
 * UUID v4. crypto.randomUUID() n'existe qu'en contexte sécurisé (HTTPS ou localhost) :
 * en http://<ip> on le construit à partir de crypto.getRandomValues(), disponible partout.
 */
export function newId(): string {
  if (typeof crypto.randomUUID === "function") return crypto.randomUUID();
  const b = crypto.getRandomValues(new Uint8Array(16));
  b[6] = (b[6] & 0x0f) | 0x40; // version 4
  b[8] = (b[8] & 0x3f) | 0x80; // variante RFC 4122
  const h = Array.from(b, (x) => x.toString(16).padStart(2, "0")).join("");
  return `${h.slice(0, 8)}-${h.slice(8, 12)}-${h.slice(12, 16)}-${h.slice(16, 20)}-${h.slice(20)}`;
}

export function literal(v: unknown): Value {
  return { mode: "literal", value: v };
}

export function refValue(ref: Ref): Value {
  return { mode: "ref", ref };
}

/** Applique une valeur à un chemin de schéma ("vpc_config.subnet_ids") en créant les blocs manquants.
 *  En cardinalité "list", la référence est ajoutée à la liste existante. */
export function applyAtPath(node: TfNode, path: string, value: Value, cardinality: "single" | "list" = "single"): TfNode {
  const parts = path.split(".");
  const attr = parts.pop()!;
  const n: TfNode = structuredClone(node);
  let attrs = n.attrs;
  let blocks = (n.blocks ??= {});
  for (const bn of parts) {
    const list = (blocks[bn] ??= []);
    if (!list.length) list.push({ attrs: {} });
    attrs = list[0].attrs;
    blocks = list[0].blocks ??= {};
  }
  const current = attrs[attr];
  if (cardinality === "list" && current && current.mode !== "null") {
    const items = current.mode === "list" ? current.items ?? [] : [current];
    if (!items.some((i) => sameRef(i, value))) items.push(value);
    attrs[attr] = { mode: "list", items };
  } else {
    attrs[attr] = value;
  }
  return n;
}

function sameRef(a: Value, b: Value): boolean {
  return a.mode === "ref" && b.mode === "ref" && a.ref?.node === b.ref?.node && a.ref?.attr === b.ref?.attr && a.ref?.index === b.ref?.index;
}

/** Supprime toute référence d'un nœud vers sourceId (suppression d'un lien ou du nœud source). */
export function removeRefsTo(node: TfNode, sourceId: string, targetPath?: string): TfNode {
  const n: TfNode = structuredClone(node);
  const clean = (path: string, v?: Value): Value | undefined => {
    if (!v) return v;
    if (v.mode === "ref" && v.ref?.node === sourceId && (!targetPath || targetPath === path || targetPath.startsWith(path + "["))) return undefined;
    if (v.mode === "list") {
      const items = (v.items ?? []).filter((it, i) => clean(`${path}[${i}]`, it) !== undefined);
      return items.length ? { mode: "list", items } : undefined;
    }
    return v;
  };
  for (const k of Object.keys(n.attrs)) {
    const v = clean(k, n.attrs[k]);
    if (v === undefined) delete n.attrs[k];
    else n.attrs[k] = v;
  }
  const walkBlocks = (prefix: string, blocks?: TfNode["blocks"]) => {
    for (const [bn, list] of Object.entries(blocks ?? {})) {
      list.forEach((b, i) => {
        const p = `${prefix}${bn}[${i}]`;
        for (const k of Object.keys(b.attrs)) {
          const v = clean(`${p}.${k}`, b.attrs[k]);
          if (v === undefined) delete b.attrs[k];
          else b.attrs[k] = v;
        }
        walkBlocks(`${p}.`, b.blocks);
      });
    }
  };
  walkBlocks("", n.blocks);
  if (n.meta.count && clean("count", n.meta.count) === undefined) delete n.meta.count;
  if (n.meta.forEach && clean("for_each", n.meta.forEach) === undefined) delete n.meta.forEach;
  if (!targetPath || targetPath === "depends_on") n.meta.dependsOn = (n.meta.dependsOn ?? []).filter((d) => d !== sourceId);
  return n;
}

/** Texte court d'une valeur (affichage). */
export function valueText(v: Value | undefined, nodes: Map<string, TfNode>): string {
  if (!v) return "";
  switch (v.mode) {
    case "literal":
      return typeof v.value === "string" ? v.value : JSON.stringify(v.value);
    case "expr":
      return v.expr ?? "";
    case "ref": {
      const n = v.ref ? nodes.get(v.ref.node) : undefined;
      if (!n) return "(référence cassée)";
      return refExpression(v.ref!, n);
    }
    case "list":
      return `[${(v.items ?? []).map((i) => valueText(i, nodes)).join(", ")}]`;
    default:
      return "null";
  }
}

/** Expression Terraform produite par une référence (même règles que hclgen.refAddress). */
export function refExpression(ref: Ref, n: TfNode): string {
  if (n.kind === "variable") return `var.${n.label}`;
  if (n.kind === "local") return `local.${n.label}`;
  const base = n.kind === "data" ? `data.${n.type}.${n.label}` : n.kind === "module" ? `module.${n.label}` : `${n.type}.${n.label}`;
  const suffix = ref.attr ? (ref.attr.startsWith("[") ? ref.attr : `.${ref.attr}`) : "";
  switch (ref.indexMode) {
    case "index":
      return `${base}[${ref.index || "0"}]${suffix}`;
    case "splat":
      return `${base}[*]${suffix}`;
    case "values":
      return `values(${base})[*]${suffix}`;
    case "each":
      return `${base}[each.key]${suffix}`;
    case "key":
      return `${base}["${ref.index ?? ""}"]${suffix}`;
  }
  return base + suffix;
}

/** Le nœud utilise-t-il count ou for_each ? */
export function multiOf(n: TfNode): "" | "count" | "for_each" {
  if (n.meta.count && n.meta.count.mode !== "null") return "count";
  if (n.meta.forEach && n.meta.forEach.mode !== "null") return "for_each";
  return "";
}

/** Copie dans le presse-papiers ; repli execCommand quand navigator.clipboard est absent (HTTP non sécurisé). */
export async function copyText(text: string): Promise<void> {
  if (navigator.clipboard) return navigator.clipboard.writeText(text);
  const ta = document.createElement("textarea");
  ta.value = text;
  ta.style.position = "fixed";
  ta.style.opacity = "0";
  document.body.appendChild(ta);
  ta.select();
  try {
    if (!document.execCommand("copy")) throw new Error("copie refusée par le navigateur");
  } finally {
    ta.remove();
  }
}
