// Disposition automatique du graphe (ELK, algorithme en couches, de gauche à droite).
import type { Project } from "@/types/model";
import { deriveEdges } from "./model";

export async function autoLayout(p: Project): Promise<Record<string, { x: number; y: number }>> {
  // ELK (~1,5 Mo) n'est chargé qu'au premier usage de la disposition automatique.
  const { default: ELK } = await import("elkjs/lib/elk.bundled.js");
  const elk = new ELK();
  const graph = {
    id: "root",
    layoutOptions: {
      "elk.algorithm": "layered",
      "elk.direction": "RIGHT",
      "elk.spacing.nodeNode": "40",
      "elk.layered.spacing.nodeNodeBetweenLayers": "90",
      "elk.layered.nodePlacement.strategy": "BRANDES_KOEPF",
    },
    children: p.nodes.map((n) => ({ id: n.id, width: 224, height: 72 })),
    edges: deriveEdges(p)
      .filter((e) => p.nodes.some((n) => n.id === e.source))
      .map((e, i) => ({ id: `e${i}`, sources: [e.source], targets: [e.target] })),
  };
  const res = await elk.layout(graph);
  const out: Record<string, { x: number; y: number }> = {};
  for (const c of res.children ?? []) out[c.id] = { x: c.x ?? 0, y: c.y ?? 0 };
  return out;
}
