// Mode clair / sombre, mémorisé dans le navigateur (préférence d'affichage locale).
const KEY = "hcld-theme";

function readTheme(): "light" | "dark" {
  try {
    const t = localStorage.getItem(KEY);
    if (t === "light" || t === "dark") return t;
  } catch {
    /* stockage indisponible : thème du système */
  }
  return window.matchMedia?.("(prefers-color-scheme: dark)").matches ? "dark" : "light";
}

export function initTheme() {
  document.documentElement.classList.toggle("dark", readTheme() === "dark");
}

export function toggleTheme(): "light" | "dark" {
  const next = document.documentElement.classList.contains("dark") ? "light" : "dark";
  document.documentElement.classList.toggle("dark", next === "dark");
  try {
    localStorage.setItem(KEY, next);
  } catch {
    /* ignoré */
  }
  return next;
}
