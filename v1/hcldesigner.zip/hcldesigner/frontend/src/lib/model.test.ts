import { describe, expect, it } from "vitest";
import { applyAtPath, deriveEdges, exprRefs, refExpression, removeRefsTo, uniqueLabel, wouldCycle } from "./model";
import { emptyProject, type Project, type TfNode } from "@/types/model";

const node = (id: string, type: string, label: string, attrs: TfNode["attrs"] = {}): TfNode => ({ id, kind: "resource", type, label, attrs, meta: {}, position: { x: 0, y: 0 } });

function project(): Project {
  const p = emptyProject();
  p.nodes = [
    node("vpc", "aws_vpc", "main"),
    node("sub", "aws_subnet", "public", { vpc_id: { mode: "ref", ref: { node: "vpc", attr: "id" } } }),
    node("sg", "aws_security_group", "web"),
    node("ec2", "aws_instance", "web"),
  ];
  return p;
}

describe("modèle", () => {
  it("dérive les liens des références", () => {
    const e = deriveEdges(project());
    expect(e).toHaveLength(1);
    expect(e[0]).toMatchObject({ source: "vpc", target: "sub", targetPath: "vpc_id" });
  });

  it("détecte les cycles", () => {
    const p = project();
    expect(wouldCycle(p, "sub", "vpc")).toBe(true);
    expect(wouldCycle(p, "sub", "ec2")).toBe(false);
  });

  it("ajoute une référence à une liste sans écraser", () => {
    const p = project();
    let ec2 = applyAtPath(p.nodes[3], "vpc_security_group_ids", { mode: "ref", ref: { node: "sg", attr: "id" } }, "list");
    ec2 = applyAtPath(ec2, "vpc_security_group_ids", { mode: "ref", ref: { node: "sg2", attr: "id" } }, "list");
    expect(ec2.attrs.vpc_security_group_ids.mode).toBe("list");
    expect(ec2.attrs.vpc_security_group_ids.items).toHaveLength(2);
  });

  it("crée les blocs imbriqués manquants", () => {
    const n = applyAtPath(node("eks", "aws_eks_cluster", "k"), "vpc_config.subnet_ids", { mode: "ref", ref: { node: "sub", attr: "id" } }, "list");
    expect(n.blocks?.vpc_config[0].attrs.subnet_ids).toBeDefined();
  });

  it("supprime les références vers un nœud", () => {
    const sub = removeRefsTo(project().nodes[1], "vpc");
    expect(sub.attrs.vpc_id).toBeUndefined();
  });

  it("produit des labels uniques", () => {
    expect(uniqueLabel(project(), "resource", "aws_instance", "web")).toBe("web_2");
    expect(uniqueLabel(project(), "resource", "aws_vpc", "1bad name")).toBe("_1bad_name");
  });

  it("écrit les références avec index", () => {
    const sub = project().nodes[1];
    expect(refExpression({ node: "sub", attr: "id", indexMode: "index", index: "0" }, sub)).toBe("aws_subnet.public[0].id");
    expect(refExpression({ node: "sub", attr: "id", indexMode: "splat" }, sub)).toBe("aws_subnet.public[*].id");
  });
});

describe("liens issus des expressions", () => {
  it("relie les adresses citées dans une expression brute, sans faux positif", () => {
    const p = project();
    p.nodes[3].attrs.user_data = { mode: "expr", expr: '"${aws_vpc.main.cidr_block}-${aws_subnet.public.id}-${each.key}-${aws_vpc.other.id}"' };
    const edges = deriveEdges(p).filter((e) => e.kind === "expr");
    expect(edges.map((e) => e.source).sort()).toEqual(["sub", "vpc"]);
    expect(edges.every((e) => e.target === "ec2" && e.targetPath === "user_data")).toBe(true);
  });

  it("gère les data sources (adresse à trois segments)", () => {
    expect(exprRefs("lookup(data.aws_ami.debian.tags, \"a\")", new Map([["data.aws_ami.debian", "ami"]]))).toEqual(["ami"]);
  });
});
