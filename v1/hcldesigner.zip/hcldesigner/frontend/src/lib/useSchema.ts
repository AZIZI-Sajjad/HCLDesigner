// Chargement paresseux des schémas : un type n'est demandé au backend qu'à son premier usage.
import { useEffect } from "react";
import { api, qs } from "@/api/client";
import { schemaKey, useEditor, type SchemaEntry } from "@/store/editor";
import type { SchemaBlock } from "@/types/api";
import type { Project, ProviderConfig, TfNode } from "@/types/model";

const inflight = new Map<string, Promise<void>>();

/** Provider d'un nœud : clé explicite, sinon provider sans alias du même préfixe (même règle que le Go). */
export function providerFor(p: Project, n: Pick<TfNode, "type" | "provider">): ProviderConfig | undefined {
  if (n.provider) {
    const pc = p.providers.find((x) => (x.alias ? `${x.localName}.${x.alias}` : x.localName) === n.provider);
    if (pc) return pc;
  }
  const prefix = n.type.split("_")[0];
  return p.providers.find((x) => x.localName === prefix && !x.alias) ?? p.providers.find((x) => x.localName === prefix);
}

export function nodeSchemaKey(p: Project, n: TfNode): string | undefined {
  if (n.kind !== "resource" && n.kind !== "data") return undefined;
  const pc = providerFor(p, n);
  if (!pc) return undefined;
  return schemaKey(pc.source, pc.resolved, n.kind, n.type);
}

export function loadSchema(source: string, version: string, kind: string, type: string): Promise<void> {
  const key = schemaKey(source, version, kind, type);
  const { schemas, setSchema } = useEditor.getState();
  if (schemas[key]) return Promise.resolve();
  const existing = inflight.get(key);
  if (existing) return existing;
  const p = api
    .get<{ block: SchemaBlock | null; defaults: Record<string, unknown> | null }>("/schemas/block" + qs({ source, version, kind, type }))
    .then((r) => setSchema(key, { block: r.block ?? undefined, defaults: r.defaults ?? {} }))
    .catch((e: Error) => setSchema(key, { error: e.message }))
    .finally(() => inflight.delete(key));
  inflight.set(key, p);
  return p;
}

/** Schéma d'un nœud (déclenche le chargement si nécessaire). */
export function useNodeSchema(model: Project | null, node: TfNode | undefined): SchemaEntry | undefined {
  const key = model && node ? nodeSchemaKey(model, node) : undefined;
  const entry = useEditor((s) => (key ? s.schemas[key] : undefined));
  useEffect(() => {
    if (!model || !node || !key || entry) return;
    const pc = providerFor(model, node);
    if (pc) void loadSchema(pc.source, pc.resolved, node.kind, node.type);
  }, [key, entry, model, node]);
  return entry;
}
