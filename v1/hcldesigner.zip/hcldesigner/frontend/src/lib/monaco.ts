// Monaco servi localement (aucun CDN : compatible air-gap) et langage HCL minimal.
import * as monaco from "monaco-editor";
import { loader } from "@monaco-editor/react";
import editorWorker from "monaco-editor/esm/vs/editor/editor.worker?worker";

self.MonacoEnvironment = { getWorker: () => new editorWorker() };
loader.config({ monaco });

let registered = false;

/** Coloration syntaxique HCL (blocs, chaînes, interpolations, commentaires, heredocs). */
export function registerHCL() {
  if (registered) return;
  registered = true;
  monaco.languages.register({ id: "hcl", extensions: [".tf", ".hcl"] });
  monaco.languages.setMonarchTokensProvider("hcl", {
    keywords: ["resource", "data", "module", "variable", "output", "locals", "provider", "terraform", "backend", "required_providers", "lifecycle", "dynamic", "moved", "import", "for", "in", "if", "true", "false", "null"],
    tokenizer: {
      root: [
        [/#.*$/, "comment"],
        [/\/\/.*$/, "comment"],
        [/\/\*/, "comment", "@comment"],
        [/<<-?\s*([A-Z]+)/, { token: "string", next: "@heredoc.$1" }],
        [/"/, "string", "@string"],
        [/[a-zA-Z_][\w-]*(?=\s*=)/, "variable"],
        [/[a-zA-Z_][\w-]*/, { cases: { "@keywords": "keyword", "@default": "identifier" } }],
        [/\d+(\.\d+)?/, "number"],
        [/[{}[\]()]/, "@brackets"],
      ],
      comment: [
        [/\*\//, "comment", "@pop"],
        [/./, "comment"],
      ],
      string: [
        [/\$\{/, "delimiter", "@interp"],
        [/[^"$\\]+/, "string"],
        [/\\./, "string.escape"],
        [/"/, "string", "@pop"],
        [/./, "string"],
      ],
      interp: [
        [/\}/, "delimiter", "@pop"],
        [/[^}]+/, "identifier"],
      ],
      heredoc: [
        [/^\s*([A-Z]+)$/, { cases: { "$1==$S2": { token: "string", next: "@pop" }, "@default": "string" } }],
        [/.*$/, "string"],
      ],
    },
  });
}

export { monaco };
