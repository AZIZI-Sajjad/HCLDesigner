// Helpers sur les schémas de providers (miroir des fonctions Go de internal/schema).
import type { SchemaAttribute, SchemaBlock } from "@/types/api";
import type { TfNode, Value } from "@/types/model";

/** Représentation lisible d'un type cty : string, list(string), object({...}). */
export function typeString(raw: unknown): string {
  if (raw === undefined || raw === null) return "dynamic";
  if (typeof raw === "string") return raw;
  if (Array.isArray(raw) && raw.length > 0) {
    const [kind, inner] = raw as [string, unknown];
    if (kind === "list" || kind === "set" || kind === "map") return `${kind}(${typeString(inner)})`;
    if (kind === "object" && inner && typeof inner === "object") {
      const parts = Object.keys(inner as object)
        .sort()
        .map((k) => `${k}=${typeString((inner as Record<string, unknown>)[k])}`);
      return `object({${parts.join(", ")}})`;
    }
    if (kind === "tuple" && Array.isArray(inner)) return `tuple([${inner.map(typeString).join(", ")}])`;
    return kind;
  }
  return "dynamic";
}

export function attrType(a: SchemaAttribute): string {
  if (a.nested_type) return `nested(${a.nested_type.nesting_mode})`;
  return typeString(a.type);
}

export const isCollection = (t: string) => t.startsWith("list(") || t.startsWith("set(");
export const isMap = (t: string) => t.startsWith("map(") || t.startsWith("object(");
export const elemType = (t: string) => (t.includes("(") && t.endsWith(")") ? t.slice(t.indexOf("(") + 1, -1) : t);

/** Un attribut est-il écrivable (non calculé seul) ? */
export const writable = (a: SchemaAttribute) => !!(a.required || a.optional);

/** Valeur vide au sens du modèle. */
export function isEmptyValue(v?: Value): boolean {
  if (!v) return true;
  switch (v.mode) {
    case "literal":
      return v.value === undefined || v.value === null || v.value === "";
    case "expr":
      return !v.expr?.trim();
    case "ref":
      return !v.ref?.node;
    case "list":
      return !v.items?.length;
    default:
      return true;
  }
}

/** Arguments et blocs obligatoires non renseignés d'un nœud (badge du canvas, panneau). */
export function missingRequired(node: TfNode, block?: SchemaBlock): string[] {
  if (!block) return [];
  const out: string[] = [];
  for (const [name, a] of Object.entries(block.attributes ?? {})) {
    if (a.required && isEmptyValue(node.attrs[name])) out.push(name);
  }
  for (const [name, bt] of Object.entries(block.block_types ?? {})) {
    if ((bt.min_items ?? 0) > 0 && !(node.blocks?.[name]?.length ?? 0)) out.push(name);
  }
  return out;
}

const categoryRules: [string, string[]][] = [
  ["security", ["security_group", "firewall", "waf", "network_security", "kms", "key_vault", "secret", "certificate", "acm"]],
  ["iam", ["iam", "role", "policy", "user", "group", "service_account", "identity"]],
  ["network", ["vpc", "subnet", "route", "gateway", "network", "vnet", "peering", "eip", "nat", "vpn", "lb", "load_balancer", "interface", "public_ip", "endpoint", "nsxt", "edge"]],
  ["dns", ["route53", "dns", "record", "zone", "domain"]],
  ["compute", ["instance", "virtual_machine", "vm", "compute", "launch", "autoscaling", "lambda", "function", "container", "ecs", "lxc", "vapp"]],
  ["kubernetes", ["eks", "aks", "gke", "kubernetes", "cluster", "deployment", "namespace", "helm"]],
  ["database", ["db_", "rds", "database", "sql", "dynamodb", "redis", "elasticache", "cosmos", "postgres", "mysql"]],
  ["storage", ["s3", "bucket", "storage", "disk", "volume", "ebs", "efs", "blob", "datastore", "backup", "snapshot"]],
  ["monitoring", ["cloudwatch", "monitor", "log", "alarm", "metric", "sns", "alert"]],
];

/** Catégorie fonctionnelle déduite du type (même logique que le backend). */
export function category(tfType: string): string {
  const t = tfType.includes("_") ? tfType.slice(tfType.indexOf("_") + 1) : tfType;
  for (const [cat, keys] of categoryRules) if (keys.some((k) => t.includes(k))) return cat;
  return "other";
}

export const categoryLabels: Record<string, string> = {
  security: "Sécurité",
  iam: "IAM",
  network: "Réseau",
  dns: "DNS",
  compute: "Calcul",
  kubernetes: "Kubernetes",
  database: "Bases de données",
  storage: "Stockage",
  monitoring: "Supervision",
  messaging: "Messagerie",
  other: "Autres",
};
