// Contexte d'authentification et contrôle des permissions côté interface
// (même règle que rbac.Subject.Can : le backend reste la référence, ceci ne sert qu'à l'affichage).
import { createContext, useContext, type ReactNode } from "react";
import type { Me } from "@/types/api";

const AuthContext = createContext<{ me: Me; refresh: () => void } | null>(null);

export function AuthProvider({ me, refresh, children }: { me: Me; refresh: () => void; children: ReactNode }) {
  return <AuthContext.Provider value={{ me, refresh }}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth hors AuthProvider");
  return ctx;
}

const viewPerms = new Set(["projects.view", "code.view"]);

export function can(me: Me, perm: string, projectId = "", env = ""): boolean {
  if (me.isSuper) return true;
  for (const b of me.bindings ?? []) {
    if (!b.perms.includes(perm) && !b.perms.includes("*")) continue;
    if (b.scope === "global") return true;
    if (b.scope === "project" && projectId && b.projectId === projectId) return true;
    if (b.scope === "environment" && projectId && b.projectId === projectId && (b.environment === env || (!env && viewPerms.has(perm)))) return true;
  }
  return false;
}

/** La permission est-elle détenue sur au moins une portée (affichage des menus) ? */
export function canAny(me: Me, perm: string): boolean {
  return me.isSuper || (me.bindings ?? []).some((b) => b.perms.includes(perm) || b.perms.includes("*"));
}

export function useCan() {
  const { me } = useAuth();
  return (perm: string, projectId?: string, env?: string) => can(me, perm, projectId, env);
}
