// Export d'une vue de tableau (colonnes visibles dans l'ordre affiché, lignes filtrées et triées).

export interface ExportColumn {
  id: string;
  header: string;
}

function save(content: string, filename: string, mime: string) {
  const blob = new Blob([content], { type: mime });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

const csvCell = (v: string) => (/[;"\n\r]/.test(v) ? `"${v.replace(/"/g, '""')}"` : v);

/** CSV séparé par des points-virgules (ouverture directe dans Excel FR), avec BOM UTF-8. */
export function exportCSV(name: string, cols: ExportColumn[], rows: string[][]) {
  const lines = [cols.map((c) => csvCell(c.header)).join(";"), ...rows.map((r) => r.map(csvCell).join(";"))];
  save("﻿" + lines.join("\r\n"), `${name}.csv`, "text/csv;charset=utf-8");
}

const esc = (s: string) => s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");

/** Page HTML autonome et lisible (impression, envoi par mail). */
export function exportHTML(name: string, title: string, cols: ExportColumn[], rows: string[][]) {
  const html = `<!doctype html><html lang="fr"><head><meta charset="utf-8"><title>${esc(title)}</title>
<style>body{font-family:Segoe UI,Arial,sans-serif;font-size:13px;margin:24px;color:#1f2937}h1{font-size:18px}
table{border-collapse:collapse;width:100%}th,td{border:1px solid #e5e7eb;padding:6px 8px;text-align:left;vertical-align:top}
th{background:#f3f4f6;position:sticky;top:0}tr:nth-child(even) td{background:#fafafa}</style></head><body>
<h1>${esc(title)}</h1><p>Export du ${new Date().toLocaleString("fr-FR")} — ${rows.length} ligne(s)</p>
<table><thead><tr>${cols.map((c) => `<th>${esc(c.header)}</th>`).join("")}</tr></thead>
<tbody>${rows.map((r) => `<tr>${r.map((v) => `<td>${esc(v)}</td>`).join("")}</tr>`).join("\n")}</tbody></table></body></html>`;
  save(html, `${name}.html`, "text/html;charset=utf-8");
}

export function exportJSON(name: string, cols: ExportColumn[], rows: string[][]) {
  const data = rows.map((r) => Object.fromEntries(cols.map((c, i) => [c.header, r[i]])));
  save(JSON.stringify(data, null, 2), `${name}.json`, "application/json");
}
