// Formulaire construit à partir des définitions de champs envoyées par l'API
// (backends de state, types de credentials) : une seule source de vérité côté serveur.
import type { FieldDef } from "@/types/api";
import { Field, Input, Select, Textarea, Toggle } from "@/components/ui";

export function FieldsForm({
  fields,
  values,
  onChange,
  secretsSet = [],
  disabled,
}: {
  fields: FieldDef[];
  values: Record<string, unknown>;
  onChange: (v: Record<string, unknown>) => void;
  secretsSet?: string[]; // champs secrets déjà enregistrés (affichés « inchangé »)
  disabled?: boolean;
}) {
  const set = (name: string, v: unknown) => onChange({ ...values, [name]: v });
  return (
    <div className="grid gap-3 md:grid-cols-2">
      {fields.map((f) => {
        const v = values[f.name] ?? (f.secret ? "" : f.default ?? "");
        const placeholder = f.secret && secretsSet.includes(f.name) ? "•••••• (inchangé si vide)" : f.secret ? "secret (stocké chiffré)" : undefined;
        return (
          <Field key={f.name} label={f.label} required={f.required} help={f.help} className={f.type === "text" ? "md:col-span-2" : undefined}>
            {f.type === "bool" ? (
              <Toggle checked={v === true} disabled={disabled} onChange={(b) => set(f.name, b)} />
            ) : f.type === "select" ? (
              <Select value={String(v)} disabled={disabled} onChange={(e) => set(f.name, e.target.value)}>
                {(f.options ?? []).map((o) => (
                  <option key={o}>{o}</option>
                ))}
              </Select>
            ) : f.type === "text" ? (
              <Textarea rows={4} value={String(v)} disabled={disabled} placeholder={placeholder} onChange={(e) => set(f.name, e.target.value)} />
            ) : (
              <Input
                type={f.secret ? "password" : f.type === "number" ? "number" : "text"}
                autoComplete="off"
                value={String(v)}
                disabled={disabled}
                placeholder={placeholder}
                onChange={(e) => set(f.name, f.type === "number" ? Number(e.target.value) : e.target.value)}
              />
            )}
          </Field>
        );
      })}
    </div>
  );
}
