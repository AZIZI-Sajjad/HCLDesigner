import type { ReactNode } from "react";
import { NavLink, useNavigate } from "react-router-dom";
import { useQueryClient } from "@tanstack/react-query";
import {
  Activity,
  Blocks,
  CalendarClock,
  FolderKanban,
  KeyRound,
  LayoutDashboard,
  LogOut,
  Mail,
  Moon,
  Package,
  ScrollText,
  Settings as SettingsIcon,
  ShieldCheck,
  Sun,
  UserCog,
  Users as UsersIcon,
} from "lucide-react";
import { api } from "@/api/client";
import { canAny, useAuth } from "@/lib/auth";
import { toggleTheme } from "@/lib/theme";
import { IconButton, cx } from "@/components/ui";

interface NavItem {
  to: string;
  label: string;
  icon: ReactNode;
  perm?: string;
}

const main: NavItem[] = [
  { to: "/", label: "Tableau de bord", icon: <LayoutDashboard className="h-4 w-4" /> },
  { to: "/projects", label: "Projets", icon: <FolderKanban className="h-4 w-4" /> },
  { to: "/runs", label: "Exécutions", icon: <Activity className="h-4 w-4" /> },
  { to: "/modules", label: "Modules", icon: <Package className="h-4 w-4" /> },
];

const admin: NavItem[] = [
  { to: "/admin/users", label: "Utilisateurs & équipes", icon: <UsersIcon className="h-4 w-4" />, perm: "admin.users" },
  { to: "/admin/roles", label: "Rôles & attributions", icon: <UserCog className="h-4 w-4" />, perm: "admin.roles" },
  { to: "/admin/notifications", label: "Notifications", icon: <Mail className="h-4 w-4" />, perm: "admin.smtp" },
  { to: "/admin/schedules", label: "Tâches planifiées", icon: <CalendarClock className="h-4 w-4" />, perm: "schedules.manage" },
  { to: "/admin/policies", label: "Conformité", icon: <ShieldCheck className="h-4 w-4" />, perm: "policies.manage" },
  { to: "/admin/credentials", label: "Credentials", icon: <KeyRound className="h-4 w-4" />, perm: "credentials.manage" },
  { to: "/admin/providers", label: "Providers", icon: <Blocks className="h-4 w-4" />, perm: "providers.add" },
  { to: "/admin/settings", label: "Paramètres", icon: <SettingsIcon className="h-4 w-4" />, perm: "admin.settings" },
  { to: "/admin/audit", label: "Audit", icon: <ScrollText className="h-4 w-4" />, perm: "audit.view" },
];

function Item({ item }: { item: NavItem }) {
  return (
    <NavLink
      to={item.to}
      end={item.to === "/"}
      className={({ isActive }) =>
        cx(
          "flex items-center gap-2.5 rounded-md px-2.5 py-1.5 text-sm",
          isActive ? "bg-indigo-600 text-white" : "text-slate-300 hover:bg-slate-800 hover:text-white",
        )
      }
    >
      {item.icon}
      {item.label}
    </NavLink>
  );
}

export default function Layout({ children }: { children: ReactNode }) {
  const { me } = useAuth();
  const qc = useQueryClient();
  const navigate = useNavigate();
  const adminItems = admin.filter((i) => !i.perm || canAny(me, i.perm));
  const logout = async () => {
    await api.post("/auth/logout").catch(() => undefined);
    qc.clear();
    navigate("/");
    window.location.reload();
  };
  return (
    <div className="flex h-full">
      <aside className="flex w-60 shrink-0 flex-col bg-slate-900 text-slate-200">
        <div className="flex items-center gap-2 px-4 py-4">
          <img src={me.branding.logoUrl || "/favicon.svg"} alt="" className="h-7 w-7" />
          <span className="text-base font-semibold text-white">{me.branding.name || "HCLDesigner"}</span>
        </div>
        <nav className="flex-1 space-y-0.5 overflow-y-auto px-2">
          {main.map((i) => (
            <Item key={i.to} item={i} />
          ))}
          {adminItems.length > 0 && <div className="px-2.5 pb-1 pt-4 text-[11px] font-semibold uppercase tracking-wide text-slate-500">Control panel</div>}
          {adminItems.map((i) => (
            <Item key={i.to} item={i} />
          ))}
        </nav>
        <div className="flex items-center gap-2 border-t border-slate-800 p-3">
          <NavLink to="/account" className="flex-1 truncate text-sm hover:text-white" title="Mon compte">
            {me.displayName || me.username}
          </NavLink>
          <IconButton title="Thème clair / sombre" className="text-slate-400 hover:bg-slate-800" onClick={() => toggleTheme()}>
            <Sun className="hidden h-4 w-4 dark:block" />
            <Moon className="h-4 w-4 dark:hidden" />
          </IconButton>
          <IconButton title="Déconnexion" className="text-slate-400 hover:bg-slate-800" onClick={logout}>
            <LogOut className="h-4 w-4" />
          </IconButton>
        </div>
      </aside>
      <main className="min-w-0 flex-1 overflow-y-auto">{children}</main>
    </div>
  );
}
