// Filet de sécurité : une erreur de rendu affiche un message exploitable au lieu d'une page vide.
import { Component, type ErrorInfo, type ReactNode } from "react";

interface State {
  error: Error | null;
}

export class ErrorBoundary extends Component<{ children: ReactNode }, State> {
  state: State = { error: null };

  static getDerivedStateFromError(error: Error): State {
    return { error };
  }

  componentDidCatch(error: Error, info: ErrorInfo) {
    console.error("Erreur d'affichage HCLDesigner", error, info.componentStack);
  }

  render() {
    const { error } = this.state;
    if (!error) return this.props.children;
    return (
      <div className="flex min-h-screen items-center justify-center bg-slate-950 p-6 text-slate-100">
        <div className="max-w-2xl space-y-4">
          <h1 className="text-lg font-semibold">Erreur d'affichage</h1>
          <p className="text-sm text-slate-400">La page a rencontré une erreur. Les données enregistrées ne sont pas affectées.</p>
          <pre className="max-h-64 overflow-auto rounded-md bg-slate-900 p-3 text-xs text-red-300">{error.message}</pre>
          <div className="flex gap-2">
            <button className="rounded-md bg-indigo-600 px-3 py-1.5 text-sm" onClick={() => location.reload()}>
              Recharger
            </button>
            <button className="rounded-md border border-slate-600 px-3 py-1.5 text-sm" onClick={() => location.assign("/")}>
              Tableau de bord
            </button>
          </div>
        </div>
      </div>
    );
  }
}
