// Tableau générique utilisé par tous les écrans en liste :
// réorganisation des colonnes (glisser l'en-tête), redimensionnement manuel (double-clic : ajustement
// au contenu), masquage, épinglage, tri multi-colonnes, recherche globale, filtres par colonne
// (texte ou multichoix), pagination, sélection multiple et actions groupées, préférences persistées
// côté serveur par utilisateur, vues enregistrées partageables, export CSV / HTML / JSON.
import {
  flexRender,
  getCoreRowModel,
  getFacetedUniqueValues,
  getFilteredRowModel,
  getPaginationRowModel,
  getSortedRowModel,
  useReactTable,
  type ColumnDef,
  type ColumnFiltersState,
  type ColumnOrderState,
  type ColumnPinningState,
  type ColumnSizingState,
  type FilterFn,
  type Header,
  type Row,
  type SortingState,
  type Table,
  type VisibilityState,
} from "@tanstack/react-table";
import { DndContext, KeyboardSensor, PointerSensor, closestCenter, useSensor, useSensors, type DragEndEvent } from "@dnd-kit/core";
import { SortableContext, arrayMove, horizontalListSortingStrategy, useSortable } from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { ArrowDown, ArrowUp, ChevronLeft, ChevronRight, Columns3, Download, Filter, GripVertical, Pin, PinOff, RefreshCw, RotateCcw, Save, Search, Trash2 } from "lucide-react";
import { useCallback, useEffect, useMemo, useRef, useState, type CSSProperties, type ReactNode } from "react";
import { api } from "@/api/client";
import { exportCSV, exportHTML, exportJSON } from "@/lib/exportTable";
import { Button, IconButton, Input, Modal, Toggle, cx, toast } from "@/components/ui";

declare module "@tanstack/react-table" {
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  interface ColumnMeta<TData, TValue> {
    /** Type de filtre de la colonne. */
    filter?: "text" | "multi";
    /** Texte utilisé pour la recherche, le filtre et l'export (sinon valeur brute). */
    text?: (row: TData) => string;
  }
}

/** Préférences persistées d'un tableau. */
interface TablePrefs {
  columnOrder: ColumnOrderState;
  columnSizing: ColumnSizingState;
  columnVisibility: VisibilityState;
  columnPinning: ColumnPinningState;
  sorting: SortingState;
  columnFilters: ColumnFiltersState;
  globalFilter: string;
  pageSize: number;
}

interface SavedView {
  id: string;
  name: string;
  prefs: TablePrefs;
  shared: boolean;
  mine: boolean;
  owner: string;
}

export interface DataTableProps<T> {
  /** Identifiant stable : clé de persistance des préférences. */
  id: string;
  title?: string;
  data: T[];
  columns: ColumnDef<T, unknown>[];
  loading?: boolean;
  onRefresh?: () => void;
  onRowClick?: (row: T) => void;
  getRowId?: (row: T) => string;
  /** Actions groupées sur la sélection ; la sélection est désactivée si absent. */
  bulkActions?: (rows: T[], clear: () => void) => ReactNode;
  toolbar?: ReactNode;
  defaultHidden?: string[];
  defaultSort?: SortingState;
  emptyText?: string;
}

/** Filtre multichoix : la valeur de la cellule doit figurer dans la liste sélectionnée. */
const multiFilter: FilterFn<unknown> = (row, columnId, filterValue: string[]) => {
  if (!filterValue?.length) return true;
  return filterValue.includes(cellText(row, columnId));
};

function cellText<T>(row: Row<T>, columnId: string): string {
  const col = row._getAllCellsByColumnId()[columnId]?.column;
  const fn = col?.columnDef.meta?.text;
  if (fn) return fn(row.original);
  const v = row.getValue(columnId);
  if (v === null || v === undefined) return "";
  if (Array.isArray(v)) return v.join(", ");
  if (typeof v === "object") return JSON.stringify(v);
  return String(v);
}

const textFilter: FilterFn<unknown> = (row, columnId, filterValue: string) => cellText(row, columnId).toLowerCase().includes(String(filterValue ?? "").toLowerCase());

const globalFilterFn: FilterFn<unknown> = (row, _columnId, filterValue: string) => {
  const q = String(filterValue ?? "").toLowerCase();
  if (!q) return true;
  return row.getAllCells().some((c) => c.column.id !== "_select" && cellText(row, c.column.id).toLowerCase().includes(q));
};

const SELECT_COL = "_select";

export function DataTable<T>({
  id,
  title,
  data,
  columns,
  loading,
  onRefresh,
  onRowClick,
  getRowId,
  bulkActions,
  toolbar,
  defaultHidden = [],
  defaultSort = [],
  emptyText = "Aucun élément",
}: DataTableProps<T>) {
  const allColumns = useMemo<ColumnDef<T, unknown>[]>(() => {
    const cols = columns.map((c) => ({ filterFn: (c.meta?.filter === "multi" ? multiFilter : textFilter) as FilterFn<T>, ...c }));
    if (!bulkActions) return cols;
    return [
      {
        id: SELECT_COL,
        size: 36,
        enableResizing: false,
        enableSorting: false,
        enableHiding: false,
        header: ({ table }) => (
          <input type="checkbox" aria-label="Tout sélectionner" checked={table.getIsAllPageRowsSelected()} onChange={table.getToggleAllPageRowsSelectedHandler()} />
        ),
        cell: ({ row }) => <input type="checkbox" aria-label="Sélectionner" checked={row.getIsSelected()} onClick={(e) => e.stopPropagation()} onChange={row.getToggleSelectedHandler()} />,
      },
      ...cols,
    ];
  }, [columns, bulkActions]);

  const defaults = useMemo<TablePrefs>(
    () => ({
      columnOrder: allColumns.map((c) => c.id ?? (c as { accessorKey?: string }).accessorKey ?? ""),
      columnSizing: {},
      columnVisibility: Object.fromEntries(defaultHidden.map((h) => [h, false])),
      columnPinning: { left: bulkActions ? [SELECT_COL] : [], right: [] },
      sorting: defaultSort,
      columnFilters: [],
      globalFilter: "",
      pageSize: 50,
    }),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [id],
  );
  const [prefs, setPrefs] = useState<TablePrefs>(defaults);
  const [loaded, setLoaded] = useState(false);
  const [rowSelection, setRowSelection] = useState({});

  // Chargement des préférences enregistrées
  useEffect(() => {
    let alive = true;
    api
      .get<TablePrefs | null>(`/prefs/tables/${id}`)
      .then((p) => alive && p && setPrefs({ ...defaults, ...p, columnOrder: mergeOrder(p.columnOrder, defaults.columnOrder) }))
      .catch(() => undefined)
      .finally(() => alive && setLoaded(true));
    return () => {
      alive = false;
    };
  }, [id, defaults]);

  // Sauvegarde différée à chaque changement
  const saveTimer = useRef<number>();
  useEffect(() => {
    if (!loaded) return;
    window.clearTimeout(saveTimer.current);
    saveTimer.current = window.setTimeout(() => void api.put(`/prefs/tables/${id}`, prefs).catch(() => undefined), 600);
    return () => window.clearTimeout(saveTimer.current);
  }, [prefs, loaded, id]);

  const patch = useCallback(<K extends keyof TablePrefs>(key: K, updater: TablePrefs[K] | ((old: TablePrefs[K]) => TablePrefs[K])) => {
    setPrefs((p) => ({ ...p, [key]: typeof updater === "function" ? (updater as (o: TablePrefs[K]) => TablePrefs[K])(p[key]) : updater }));
  }, []);

  const [pageIndex, setPageIndex] = useState(0);
  const table = useReactTable({
    data,
    columns: allColumns,
    getRowId,
    columnResizeMode: "onChange",
    enableMultiSort: true,
    enableRowSelection: !!bulkActions,
    globalFilterFn: globalFilterFn as FilterFn<T>,
    state: {
      columnOrder: prefs.columnOrder,
      columnSizing: prefs.columnSizing,
      columnVisibility: prefs.columnVisibility,
      columnPinning: prefs.columnPinning,
      sorting: prefs.sorting,
      columnFilters: prefs.columnFilters,
      globalFilter: prefs.globalFilter,
      pagination: { pageIndex, pageSize: prefs.pageSize },
      rowSelection,
    },
    onColumnOrderChange: (u) => patch("columnOrder", u as never),
    onColumnSizingChange: (u) => patch("columnSizing", u as never),
    onColumnVisibilityChange: (u) => patch("columnVisibility", u as never),
    onColumnPinningChange: (u) => patch("columnPinning", u as never),
    onSortingChange: (u) => patch("sorting", u as never),
    onColumnFiltersChange: (u) => {
      patch("columnFilters", u as never);
      setPageIndex(0);
    },
    onGlobalFilterChange: (u) => {
      patch("globalFilter", u as never);
      setPageIndex(0);
    },
    onPaginationChange: (u) => {
      const next = typeof u === "function" ? u({ pageIndex, pageSize: prefs.pageSize }) : u;
      setPageIndex(next.pageIndex);
      if (next.pageSize !== prefs.pageSize) patch("pageSize", next.pageSize);
    },
    onRowSelectionChange: setRowSelection,
    getCoreRowModel: getCoreRowModel(),
    getFilteredRowModel: getFilteredRowModel(),
    getSortedRowModel: getSortedRowModel(),
    getPaginationRowModel: getPaginationRowModel(),
    getFacetedUniqueValues: getFacetedUniqueValues(),
  });

  // Glisser-déposer des en-têtes
  const sensors = useSensors(useSensor(PointerSensor, { activationConstraint: { distance: 6 } }), useSensor(KeyboardSensor));
  const onDragEnd = (e: DragEndEvent) => {
    const { active, over } = e;
    if (!over || active.id === over.id) return;
    patch("columnOrder", (order) => {
      const from = order.indexOf(String(active.id));
      const to = order.indexOf(String(over.id));
      return from < 0 || to < 0 ? order : arrayMove(order, from, to);
    });
  };

  /** Double-clic sur la poignée : largeur ajustée au contenu de la colonne (en-tête inclus). */
  const autoSize = (columnId: string) => {
    const col = table.getColumn(columnId);
    if (!col) return;
    const header = typeof col.columnDef.header === "string" ? col.columnDef.header : columnId;
    const longest = Math.max(header.length + 4, ...table.getFilteredRowModel().rows.slice(0, 500).map((r) => cellText(r, columnId).length));
    patch("columnSizing", (s) => ({ ...s, [columnId]: Math.min(600, Math.max(60, longest * 7.2 + 24)) }));
  };

  const [showColumns, setShowColumns] = useState(false);
  const [showViews, setShowViews] = useState(false);
  const [showFilters, setShowFilters] = useState(prefs.columnFilters.length > 0);
  const selected = table.getSelectedRowModel().rows.map((r) => r.original);
  const filteredCount = table.getFilteredRowModel().rows.length;

  const exportRows = (format: "csv" | "html" | "json") => {
    const cols = table.getVisibleLeafColumns().filter((c) => c.id !== SELECT_COL);
    const headers = cols.map((c) => ({ id: c.id, header: typeof c.columnDef.header === "string" ? c.columnDef.header : c.id }));
    const rows = table.getPrePaginationRowModel().rows.map((r) => cols.map((c) => cellText(r, c.id)));
    const name = `${id}-${new Date().toISOString().slice(0, 10)}`;
    if (format === "csv") exportCSV(name, headers, rows);
    else if (format === "html") exportHTML(name, title ?? id, headers, rows);
    else exportJSON(name, headers, rows);
  };

  const pinnedStyle = (h: { column: ReturnType<Table<T>["getColumn"]> }): CSSProperties => {
    const c = h.column!;
    const pinned = c.getIsPinned();
    if (!pinned) return {};
    return {
      position: "sticky",
      left: pinned === "left" ? c.getStart("left") : undefined,
      right: pinned === "right" ? c.getAfter("right") : undefined,
      zIndex: 2,
    };
  };

  return (
    <div className="flex min-h-0 flex-col rounded-lg border border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900">
      {/* Barre d'outils */}
      <div className="flex flex-wrap items-center gap-2 border-b border-slate-200 p-2 dark:border-slate-800">
        <div className="relative w-64">
          <Search className="pointer-events-none absolute left-2 top-2 h-4 w-4 text-slate-400" />
          <Input className="pl-8" placeholder="Rechercher dans toutes les colonnes" value={prefs.globalFilter} onChange={(e) => table.setGlobalFilter(e.target.value)} />
        </div>
        <Button size="sm" variant={showFilters ? "primary" : "secondary"} icon={<Filter className="h-3.5 w-3.5" />} onClick={() => setShowFilters((v) => !v)}>
          Filtres{prefs.columnFilters.length ? ` (${prefs.columnFilters.length})` : ""}
        </Button>
        <Button size="sm" icon={<Columns3 className="h-3.5 w-3.5" />} onClick={() => setShowColumns(true)}>
          Colonnes
        </Button>
        <Button size="sm" icon={<Save className="h-3.5 w-3.5" />} onClick={() => setShowViews(true)}>
          Vues
        </Button>
        <ExportMenu onExport={exportRows} />
        {onRefresh && (
          <IconButton title="Rafraîchir" onClick={onRefresh}>
            <RefreshCw className={cx("h-4 w-4", loading && "animate-spin")} />
          </IconButton>
        )}
        <IconButton
          title="Réinitialiser l'affichage (ordre, largeurs, filtres)"
          onClick={() => {
            setPrefs(defaults);
            void api.del(`/prefs/tables/${id}`).catch(() => undefined);
          }}
        >
          <RotateCcw className="h-4 w-4" />
        </IconButton>
        {toolbar}
        <div className="ml-auto text-xs text-slate-500">
          {filteredCount} / {data.length} ligne(s)
        </div>
      </div>

      {bulkActions && selected.length > 0 && (
        <div className="flex items-center gap-2 border-b border-slate-200 bg-indigo-50 px-3 py-1.5 text-sm dark:border-slate-800 dark:bg-indigo-950/40">
          <span className="font-medium">{selected.length} sélectionné(s)</span>
          {bulkActions(selected, () => setRowSelection({}))}
        </div>
      )}

      <div className="min-h-0 flex-1 overflow-auto">
        <DndContext sensors={sensors} collisionDetection={closestCenter} onDragEnd={onDragEnd}>
          <table className="border-separate border-spacing-0 text-sm" style={{ width: table.getTotalSize(), minWidth: "100%" }}>
            <thead className="sticky top-0 z-10 bg-slate-50 dark:bg-slate-800">
              {table.getHeaderGroups().map((hg) => (
                <tr key={hg.id}>
                  <SortableContext items={prefs.columnOrder} strategy={horizontalListSortingStrategy}>
                    {hg.headers.map((h) => (
                      <HeaderCell key={h.id} header={h} style={pinnedStyle(h)} onAutoSize={() => autoSize(h.column.id)} />
                    ))}
                  </SortableContext>
                </tr>
              ))}
              {showFilters && (
                <tr>
                  {table.getVisibleLeafColumns().map((c) => (
                    <th key={c.id} className="border-b border-slate-200 bg-slate-50 px-1.5 py-1 dark:border-slate-700 dark:bg-slate-800" style={{ width: c.getSize() }}>
                      {c.id !== SELECT_COL && c.getCanFilter() && <ColumnFilter table={table} columnId={c.id} />}
                    </th>
                  ))}
                </tr>
              )}
            </thead>
            <tbody>
              {table.getRowModel().rows.map((row) => (
                <tr
                  key={row.id}
                  onClick={() => onRowClick?.(row.original)}
                  className={cx("group", onRowClick && "cursor-pointer", row.getIsSelected() ? "bg-indigo-50 dark:bg-indigo-950/30" : "hover:bg-slate-50 dark:hover:bg-slate-800/50")}
                >
                  {row.getVisibleCells().map((cell) => (
                    <td
                      key={cell.id}
                      className="truncate border-b border-slate-100 bg-inherit px-3 py-1.5 dark:border-slate-800"
                      style={{ width: cell.column.getSize(), maxWidth: cell.column.getSize(), ...pinnedStyle(cell) }}
                    >
                      {flexRender(cell.column.columnDef.cell, cell.getContext())}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </DndContext>
        {!loading && filteredCount === 0 && <div className="p-8 text-center text-sm text-slate-500">{emptyText}</div>}
      </div>

      {/* Pagination */}
      <div className="flex items-center justify-end gap-2 border-t border-slate-200 px-3 py-1.5 text-xs dark:border-slate-800">
        <span>Lignes par page</span>
        <select className="rounded border border-slate-300 bg-transparent px-1 py-0.5 dark:border-slate-600" value={prefs.pageSize} onChange={(e) => table.setPageSize(Number(e.target.value))}>
          {[25, 50, 100, 250, 1000].map((n) => (
            <option key={n} value={n}>
              {n}
            </option>
          ))}
        </select>
        <span>
          Page {table.getState().pagination.pageIndex + 1} / {Math.max(1, table.getPageCount())}
        </span>
        <IconButton title="Page précédente" disabled={!table.getCanPreviousPage()} onClick={() => table.previousPage()}>
          <ChevronLeft className="h-4 w-4" />
        </IconButton>
        <IconButton title="Page suivante" disabled={!table.getCanNextPage()} onClick={() => table.nextPage()}>
          <ChevronRight className="h-4 w-4" />
        </IconButton>
      </div>

      <ColumnsDialog open={showColumns} onClose={() => setShowColumns(false)} table={table} />
      <ViewsDialog open={showViews} onClose={() => setShowViews(false)} tableId={id} prefs={prefs} onApply={(p) => setPrefs({ ...defaults, ...p })} />
    </div>
  );
}

/** Conserve l'ordre enregistré et ajoute les colonnes apparues depuis. */
function mergeOrder(saved: string[] | undefined, current: string[]): string[] {
  if (!saved?.length) return current;
  const known = saved.filter((c) => current.includes(c));
  return [...known, ...current.filter((c) => !known.includes(c))];
}

function HeaderCell<T>({ header, style, onAutoSize }: { header: Header<T, unknown>; style: CSSProperties; onAutoSize: () => void }) {
  const { column } = header;
  const sortable = useSortable({ id: column.id, disabled: column.id === SELECT_COL || !!column.getIsPinned() });
  const sorted = column.getIsSorted();
  const dndStyle: CSSProperties = {
    transform: CSS.Translate.toString(sortable.transform),
    transition: sortable.transition,
    opacity: sortable.isDragging ? 0.6 : 1,
    width: header.getSize(),
    ...style,
  };
  return (
    <th
      ref={sortable.setNodeRef}
      style={dndStyle}
      className="group/h relative select-none border-b border-slate-200 bg-slate-50 px-3 py-2 text-left text-xs font-semibold text-slate-600 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-300"
    >
      {header.isPlaceholder ? null : (
        <div className="flex items-center gap-1">
          {column.id !== SELECT_COL && !column.getIsPinned() && (
            <span {...sortable.attributes} {...sortable.listeners} className="cursor-grab text-slate-300 hover:text-slate-500 active:cursor-grabbing" title="Glisser pour déplacer la colonne">
              <GripVertical className="h-3.5 w-3.5" />
            </span>
          )}
          <span
            className={cx("flex-1 truncate", column.getCanSort() && "cursor-pointer")}
            onClick={column.getToggleSortingHandler()}
            title={column.getCanSort() ? "Trier (Maj+clic : tri multiple)" : undefined}
          >
            {flexRender(column.columnDef.header, header.getContext())}
          </span>
          {sorted === "asc" && <ArrowUp className="h-3 w-3" />}
          {sorted === "desc" && <ArrowDown className="h-3 w-3" />}
          {sorted && column.getSortIndex() > 0 && <span className="text-[10px]">{column.getSortIndex() + 1}</span>}
          {column.id !== SELECT_COL && (
            <button
              className="hidden text-slate-400 hover:text-slate-700 group-hover/h:block"
              title={column.getIsPinned() ? "Désépingler" : "Épingler à gauche"}
              onClick={() => column.pin(column.getIsPinned() ? false : "left")}
            >
              {column.getIsPinned() ? <PinOff className="h-3 w-3" /> : <Pin className="h-3 w-3" />}
            </button>
          )}
        </div>
      )}
      {column.getCanResize() && (
        <div
          onMouseDown={header.getResizeHandler()}
          onTouchStart={header.getResizeHandler()}
          onDoubleClick={onAutoSize}
          className={cx("col-resizer", column.getIsResizing() && "resizing")}
          title="Glisser pour redimensionner — double-clic : ajuster au contenu"
        />
      )}
    </th>
  );
}

function ColumnFilter<T>({ table, columnId }: { table: Table<T>; columnId: string }) {
  const column = table.getColumn(columnId)!;
  const kind = column.columnDef.meta?.filter ?? "text";
  const value = column.getFilterValue();
  const [open, setOpen] = useState(false);
  const options = useMemo(() => {
    if (kind !== "multi") return [];
    const set = new Set<string>();
    table.getPreFilteredRowModel().rows.forEach((r) => set.add(cellText(r, columnId)));
    return [...set].sort();
  }, [kind, table, columnId, table.getPreFilteredRowModel().rows.length]); // eslint-disable-line react-hooks/exhaustive-deps

  if (kind === "multi") {
    const sel = (value as string[]) ?? [];
    return (
      <div className="relative">
        <button
          className="w-full truncate rounded border border-slate-300 bg-white px-1.5 py-0.5 text-left text-xs font-normal dark:border-slate-600 dark:bg-slate-900"
          onClick={() => setOpen((o) => !o)}
        >
          {sel.length ? `${sel.length} choisi(s)` : "Tous"}
        </button>
        {open && (
          <div className="absolute left-0 top-full z-20 mt-1 max-h-64 w-56 overflow-auto rounded-md border border-slate-200 bg-white p-1 shadow-lg dark:border-slate-700 dark:bg-slate-900" onMouseLeave={() => setOpen(false)}>
            {options.map((o) => (
              <label key={o} className="flex cursor-pointer items-center gap-2 rounded px-2 py-1 text-xs font-normal hover:bg-slate-100 dark:hover:bg-slate-800">
                <input
                  type="checkbox"
                  checked={sel.includes(o)}
                  onChange={(e) => column.setFilterValue(e.target.checked ? [...sel, o] : sel.filter((x) => x !== o))}
                />
                <span className="truncate">{o || "(vide)"}</span>
              </label>
            ))}
            {sel.length > 0 && (
              <button className="mt-1 w-full rounded px-2 py-1 text-left text-xs text-indigo-600 hover:bg-slate-100" onClick={() => column.setFilterValue(undefined)}>
                Effacer le filtre
              </button>
            )}
          </div>
        )}
      </div>
    );
  }
  return (
    <input
      className="w-full rounded border border-slate-300 bg-white px-1.5 py-0.5 text-xs font-normal dark:border-slate-600 dark:bg-slate-900"
      placeholder="Filtrer…"
      value={(value as string) ?? ""}
      onChange={(e) => column.setFilterValue(e.target.value || undefined)}
    />
  );
}

function ColumnsDialog<T>({ open, onClose, table }: { open: boolean; onClose: () => void; table: Table<T> }) {
  return (
    <Modal open={open} onClose={onClose} title="Colonnes affichées">
      <div className="space-y-2">
        {table
          .getAllLeafColumns()
          .filter((c) => c.id !== SELECT_COL)
          .map((c) => (
            <div key={c.id} className="flex items-center justify-between gap-2">
              <Toggle checked={c.getIsVisible()} disabled={!c.getCanHide()} onChange={(v) => c.toggleVisibility(v)} label={typeof c.columnDef.header === "string" ? c.columnDef.header : c.id} />
              <div className="flex gap-1 text-xs">
                {(["left", "right", false] as const).map((p) => (
                  <button
                    key={String(p)}
                    className={cx("rounded px-1.5 py-0.5", c.getIsPinned() === p ? "bg-indigo-600 text-white" : "bg-slate-100 dark:bg-slate-800")}
                    onClick={() => c.pin(p)}
                  >
                    {p === "left" ? "Gauche" : p === "right" ? "Droite" : "Libre"}
                  </button>
                ))}
              </div>
            </div>
          ))}
      </div>
    </Modal>
  );
}

function ViewsDialog({ open, onClose, tableId, prefs, onApply }: { open: boolean; onClose: () => void; tableId: string; prefs: TablePrefs; onApply: (p: TablePrefs) => void }) {
  const qc = useQueryClient();
  const views = useQuery({ queryKey: ["views", tableId], queryFn: () => api.get<SavedView[]>(`/prefs/views/${tableId}`), enabled: open });
  const [name, setName] = useState("");
  const [shared, setShared] = useState(false);
  const save = async () => {
    try {
      await api.post(`/prefs/views/${tableId}`, { name, prefs, shared });
      setName("");
      await qc.invalidateQueries({ queryKey: ["views", tableId] });
      toast.success("Vue enregistrée");
    } catch (e) {
      toast.error(e);
    }
  };
  return (
    <Modal open={open} onClose={onClose} title="Vues enregistrées">
      <div className="space-y-4">
        <div className="space-y-2">
          {(views.data ?? []).map((v) => (
            <div key={v.id} className="flex items-center gap-2 rounded border border-slate-200 px-2 py-1.5 dark:border-slate-700">
              <span className="flex-1 text-sm">
                {v.name}
                {v.shared && <span className="ml-2 text-xs text-slate-500">partagée par {v.owner}</span>}
              </span>
              <Button size="sm" onClick={() => (onApply(v.prefs), onClose())}>
                Appliquer
              </Button>
              {v.mine && (
                <IconButton title="Supprimer" onClick={() => void api.del(`/prefs/views/${tableId}/${v.id}`).then(() => qc.invalidateQueries({ queryKey: ["views", tableId] }))}>
                  <Trash2 className="h-4 w-4" />
                </IconButton>
              )}
            </div>
          ))}
          {views.data?.length === 0 && <p className="text-sm text-slate-500">Aucune vue enregistrée.</p>}
        </div>
        <div className="space-y-2 border-t border-slate-200 pt-3 dark:border-slate-700">
          <p className="text-xs text-slate-500">Enregistrer l'affichage actuel (colonnes, largeurs, tris, filtres) :</p>
          <div className="flex gap-2">
            <Input placeholder="Nom de la vue" value={name} onChange={(e) => setName(e.target.value)} />
            <Button variant="primary" disabled={!name.trim()} onClick={save}>
              Enregistrer
            </Button>
          </div>
          <Toggle checked={shared} onChange={setShared} label="Partager avec les autres utilisateurs" />
        </div>
      </div>
    </Modal>
  );
}

function ExportMenu({ onExport }: { onExport: (f: "csv" | "html" | "json") => void }) {
  const [open, setOpen] = useState(false);
  return (
    <div className="relative" onMouseLeave={() => setOpen(false)}>
      <Button size="sm" icon={<Download className="h-3.5 w-3.5" />} onClick={() => setOpen((o) => !o)}>
        Exporter
      </Button>
      {open && (
        <div className="absolute left-0 top-full z-20 mt-1 w-40 rounded-md border border-slate-200 bg-white p-1 shadow-lg dark:border-slate-700 dark:bg-slate-900">
          {(["csv", "html", "json"] as const).map((f) => (
            <button key={f} className="block w-full rounded px-2 py-1 text-left text-sm hover:bg-slate-100 dark:hover:bg-slate-800" onClick={() => (onExport(f), setOpen(false))}>
              {f.toUpperCase()} (vue courante)
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
