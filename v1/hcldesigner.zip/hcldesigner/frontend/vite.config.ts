/// <reference types="vitest" />
import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import tailwindcss from "@tailwindcss/vite";
import { fileURLToPath, URL } from "node:url";

// En développement, l'API Go tourne sur :8080 ; le frontend Vite sur :5173.
export default defineConfig({
  plugins: [react(), tailwindcss()],
  resolve: { alias: { "@": fileURLToPath(new URL("./src", import.meta.url)) } },
  server: {
    port: 5173,
    proxy: { "/api": { target: "http://localhost:8080", ws: true, changeOrigin: false } },
  },
  build: {
    chunkSizeWarningLimit: 4000,
    rollupOptions: {
      output: {
        manualChunks: { monaco: ["monaco-editor"], flow: ["@xyflow/react"], charts: ["recharts"] },
      },
    },
  },
  test: { environment: "node", include: ["src/**/*.test.ts"] },
});
