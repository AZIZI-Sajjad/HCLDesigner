import { defineConfig } from "@playwright/test";

// E2E contre une instance HCLDesigner démarrée (BASE_URL), avec un compte administrateur.
export default defineConfig({
  testDir: "./e2e",
  timeout: 120_000,
  use: {
    baseURL: process.env.BASE_URL ?? "http://localhost:8080",
    viewport: { width: 1600, height: 950 },
    launchOptions: process.env.CHROME_PATH ? { executablePath: process.env.CHROME_PATH } : {},
    screenshot: "only-on-failure",
  },
  reporter: [["list"]],
});
