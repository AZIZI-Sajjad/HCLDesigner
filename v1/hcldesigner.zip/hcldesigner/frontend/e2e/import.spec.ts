import { expect, test } from "@playwright/test";

// Import d'un dépôt Terraform (.zip) depuis la liste des projets, jusqu'au canvas.
test("import Terraform : zip -> rapport -> projet -> canvas", async ({ page }) => {
  const errs: string[] = [];
  page.on("pageerror", (e) => errs.push(e.message));
  await page.goto("/");
  await page.getByLabel("Identifiant").fill(process.env.E2E_USER ?? "admin");
  await page.getByLabel("Mot de passe").fill(process.env.E2E_PASS ?? "");
  await page.getByRole("button", { name: "Se connecter" }).click();
  await expect(page.getByText("Tableau de bord").first()).toBeVisible();
  await page.goto("/projects");

  await page.locator('input[type=file][accept=".tf,.zip"]').setInputFiles(new URL("./fixtures/terraform-repo.zip", import.meta.url).pathname);
  await expect(page.getByText("Importer du code Terraform")).toBeVisible();
  await expect(page.getByText("dossier infra/modules/net non importé")).toBeVisible();

  await page.getByLabel("Nom").fill(`import-${Date.now()}`);
  await page.getByRole("button", { name: "Créer" }).click();
  await expect(page.locator(".react-flow")).toBeVisible();
  await expect(page.locator(".react-flow__node")).toHaveCount(4);
  await expect(page.locator(".react-flow__edge")).toHaveCount(3); // var->pet (ref), pet->null (expr), pet->output (ref)

  await page.getByRole("button", { name: "Code", exact: true }).click();
  await page.getByRole("button", { name: "main.tf", exact: true }).click();
  await expect(page.getByText('name = "${random_pet.name.id}-x"').first()).toBeVisible();
  expect(errs).toEqual([]);
});

// Régression : un import sans aucun diagnostic plantait le rendu (diagnostics null -> page vide).
test("import Terraform sans avertissement : dialogue affiché", async ({ page }) => {
  const errs: string[] = [];
  page.on("pageerror", (e) => errs.push(e.message));
  await page.goto("/");
  await page.getByLabel("Identifiant").fill(process.env.E2E_USER ?? "admin");
  await page.getByLabel("Mot de passe").fill(process.env.E2E_PASS ?? "");
  await page.getByRole("button", { name: "Se connecter" }).click();
  await expect(page.getByText("Tableau de bord").first()).toBeVisible();
  await page.goto("/projects");
  await page.locator('input[type=file][accept=".tf,.zip"]').setInputFiles(new URL("./fixtures/clean.tf", import.meta.url).pathname);
  await expect(page.getByText("Importer du code Terraform")).toBeVisible();
  await expect(page.getByText("Modèle importé : 1 objet(s)")).toBeVisible();
  expect(errs).toEqual([]);
});
