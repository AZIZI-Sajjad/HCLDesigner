#!/usr/bin/env bash
# Test de bout en bout de l'API HCLDesigner (providers null/random/local, sans cloud).
# Usage : BASE=http://localhost:8080 USER=admin PASS='...' ENGINE=opentofu ./scripts/smoke.sh
set -euo pipefail

BASE="${BASE:-http://localhost:8080}"
USER_NAME="${USER_NAME:-admin}"
PASS="${PASS:?mot de passe admin requis (PASS)}"
ENGINE="${ENGINE:-terraform}"
JAR="$(mktemp)"
trap 'rm -f "$JAR"' EXIT

api() { # api METHODE CHEMIN [JSON]
  local method="$1" path="$2" body="${3:-}"
  if [[ -n "$body" ]]; then
    curl -sS -f -b "$JAR" -c "$JAR" -X "$method" -H 'Content-Type: application/json' -H 'X-Requested-With: hcldesigner' "$BASE/api$path" -d "$body"
  else
    curl -sS -f -b "$JAR" -c "$JAR" -X "$method" -H 'X-Requested-With: hcldesigner' "$BASE/api$path"
  fi
}

step() { printf '\n\033[1;34m==> %s\033[0m\n' "$*"; }

wait_run() { # attend la fin d'un run et affiche son statut
  local id="$1" status
  for _ in $(seq 1 180); do
    status=$(api GET "/runs/$id" | jq -r .run.status)
    case "$status" in queued|running) sleep 2 ;; *) echo "$status"; return ;; esac
  done
  echo "timeout"
}

step "Connexion"
api POST /auth/login "{\"username\":\"$USER_NAME\",\"password\":\"$PASS\"}" >/dev/null
api GET /auth/me | jq -r '"utilisateur : " + .username'

if [[ -n "${MIRROR_PATH:-}" ]]; then
  step "Mirror de providers : $MIRROR_PATH"
  SETTINGS=$(api GET /admin/settings | jq --arg p "$MIRROR_PATH" '.mirror = {mode: "filesystem", path: $p, url: ""}')
  api PUT /admin/settings "$SETTINGS" >/dev/null
fi

step "Résolution des providers"
for p in hashicorp/null hashicorp/random; do
  job=$(api POST /providers/resolve "{\"source\":\"$p\",\"engine\":\"$ENGINE\"}" | jq -r .jobId)
  for _ in $(seq 1 120); do
    st=$(api GET "/providers/jobs/$job")
    case "$(jq -r .status <<<"$st")" in
      succeeded) echo "$p $(jq -r .version <<<"$st")"; break ;;
      failed) echo "échec : $(jq -r .error <<<"$st")"; exit 1 ;;
      *) sleep 2 ;;
    esac
  done
done
NULL_V=$(api GET /providers | jq -r '[.[]|select(.source=="hashicorp/null")][0].version')
RANDOM_V=$(api GET /providers | jq -r '[.[]|select(.source=="hashicorp/random")][0].version')

step "Catalogue"
api GET "/catalog?sources=hashicorp/random&q=pet" | jq -r '.[].type'

step "Création du projet"
PID=$(api POST /projects "{\"name\":\"smoke-$(date +%s)\",\"description\":\"test\"}" | jq -r .id)
echo "projet $PID"

MODEL=$(jq -n --arg nv "$NULL_V" --arg rv "$RANDOM_V" --arg engine "$ENGINE" '{
  schemaVersion: 1, engine: $engine, engineVersion: "", requiredVersion: ">= 1.5.0",
  providers: [
    {localName: "null", source: "hashicorp/null", version: "~> 3.2", resolved: $nv, alias: "", config: {}},
    {localName: "random", source: "hashicorp/random", version: "~> 3.6", resolved: $rv, alias: "", config: {}}
  ],
  fileLayout: {mode: "service", rules: [], customFiles: []},
  settings: {includeDefaults: false},
  nodes: [
    {id: "v1", kind: "variable", type: "", label: "prefix", attrs: {type: {mode: "literal", value: "string"}, default: {mode: "literal", value: "demo"}}, meta: {}, position: {x: 0, y: 0}},
    {id: "pet", kind: "resource", type: "random_pet", label: "name", attrs: {prefix: {mode: "ref", ref: {node: "v1", attr: ""}}, length: {mode: "literal", value: 2}}, meta: {}, position: {x: 300, y: 0}},
    {id: "nr", kind: "resource", type: "null_resource", label: "hello", attrs: {triggers: {mode: "expr", expr: "{ name = random_pet.name.id }"}}, meta: {}, position: {x: 600, y: 0}},
    {id: "out", kind: "output", type: "", label: "pet_name", attrs: {value: {mode: "ref", ref: {node: "pet", attr: "id"}}}, meta: {}, position: {x: 900, y: 0}}
  ]}')
api PUT "/projects/$PID/model" "{\"version\":1,\"model\":$MODEL,\"message\":\"smoke\"}" | jq -c '{version, diagnostics}'

step "Code généré"
api POST "/projects/$PID/generate" '{}' | jq -r '.files | to_entries[] | "### \(.key)\n\(.value)"'

step "Liaison suggérée random_pet -> null_resource"
api POST /connections/suggest "{\"providers\":$(jq -c .providers <<<"$MODEL"),\"source\":{\"id\":\"pet\",\"kind\":\"resource\",\"type\":\"random_pet\",\"label\":\"name\"},\"target\":{\"id\":\"nr\",\"kind\":\"resource\",\"type\":\"null_resource\",\"label\":\"hello\"}}" | jq -c '{suggestions: [.suggestions[]|{sourceAttr,targetPath,score}][:3], required: [.targetArgs[]|select(.required)|.path]}'

ENV=$(api GET "/projects/$PID/environments" | jq -r '.[0].id')

step "Validate"
RUN=$(api POST "/projects/$PID/runs" "{\"environmentId\":\"$ENV\",\"operation\":\"validate\"}" | jq -r .id)
echo "validate : $(wait_run "$RUN")"

step "Plan"
PLAN=$(api POST "/projects/$PID/runs" "{\"environmentId\":\"$ENV\",\"operation\":\"plan\"}" | jq -r .id)
echo "plan : $(wait_run "$PLAN")"
api GET "/runs/$PLAN" | jq -c '.run.summary | {add, change, destroy, byNode}'

step "Apply"
APPLY=$(api POST "/projects/$PID/runs" "{\"environmentId\":\"$ENV\",\"operation\":\"apply\",\"planRunId\":\"$PLAN\"}" | jq -r .id)
echo "apply : $(wait_run "$APPLY")"
api GET "/runs/$APPLY/logs" | jq -r .content | tail -n 8

step "State"
api GET "/environments/$ENV/state/resources" | jq -c '{serial, resources: [.resources[].address]}'

step "Plan -destroy puis apply"
DPLAN=$(api POST "/projects/$PID/runs" "{\"environmentId\":\"$ENV\",\"operation\":\"plan\",\"destroy\":true}" | jq -r .id)
echo "plan destroy : $(wait_run "$DPLAN")"
DAPPLY=$(api POST "/projects/$PID/runs" "{\"environmentId\":\"$ENV\",\"operation\":\"apply\",\"planRunId\":\"$DPLAN\"}" | jq -r .id)
echo "destroy : $(wait_run "$DAPPLY")"
api GET "/environments/$ENV/state/resources" | jq -c '{serial, resources: [.resources[].address]}'

step "Export ZIP"
curl -sS -f -b "$JAR" "$BASE/api/projects/$PID/export" -o /tmp/smoke-export.zip && unzip -l /tmp/smoke-export.zip | tail -n +4 | head -20

step "Audit (5 dernières actions)"
api GET /admin/audit | jq -r '.[:5][] | "\(.ts) \(.username) \(.action)"'
echo -e "\n\033[1;32mOK\033[0m"
