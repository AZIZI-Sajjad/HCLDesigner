// Package rules embarque les règles de connexion et les valeurs par défaut par provider
// (fichiers *.yaml de ce dossier). Pour ajouter un provider : créer <provider>.yaml, rien d'autre.
package rules

import (
	"embed"
	"encoding/json"
	"fmt"
	"sort"
	"strings"
	"sync"

	"github.com/goccy/go-yaml"
)

//go:embed *.yaml
var files embed.FS

// Connection décrit une liaison connue : source.attr alimente target.arg.
type Connection struct {
	Source     string `yaml:"source" json:"source"`
	Attr       string `yaml:"attr" json:"attr"`
	Target     string `yaml:"target" json:"target"` // "*" = tout type du même provider
	Arg        string `yaml:"arg" json:"arg"`       // chemin, ex: vpc_config.subnet_ids
	SourceKind string `yaml:"sourceKind" json:"sourceKind,omitempty"`
}

type providerFile struct {
	Provider    string                    `yaml:"provider"`
	Connections []Connection              `yaml:"connections"`
	Defaults    map[string]map[string]any `yaml:"defaults"`
}

// Set regroupe toutes les règles chargées.
type Set struct {
	Connections []Connection
	defaults    map[string]map[string]json.RawMessage
}

var (
	once    sync.Once
	loaded  *Set
	errLoad error
)

// Load charge (une seule fois) les fichiers embarqués.
func Load() (*Set, error) {
	once.Do(func() {
		loaded, errLoad = parse()
	})
	return loaded, errLoad
}

// MustLoad panique si les règles embarquées sont invalides (erreur de build, pas d'exécution).
func MustLoad() *Set {
	s, err := Load()
	if err != nil {
		panic(err)
	}
	return s
}

func parse() (*Set, error) {
	entries, err := files.ReadDir(".")
	if err != nil {
		return nil, err
	}
	s := &Set{defaults: map[string]map[string]json.RawMessage{}}
	for _, e := range entries {
		raw, err := files.ReadFile(e.Name())
		if err != nil {
			return nil, err
		}
		var pf providerFile
		if err := yaml.Unmarshal(raw, &pf); err != nil {
			return nil, fmt.Errorf("%s : %w", e.Name(), err)
		}
		for _, c := range pf.Connections {
			if c.Source == "" || c.Target == "" || c.Arg == "" {
				return nil, fmt.Errorf("%s : règle incomplète %+v", e.Name(), c)
			}
			s.Connections = append(s.Connections, c)
		}
		for t, attrs := range pf.Defaults {
			m := map[string]json.RawMessage{}
			for k, v := range attrs {
				b, err := json.Marshal(v)
				if err != nil {
					return nil, fmt.Errorf("%s : défaut %s.%s : %w", e.Name(), t, k, err)
				}
				m[k] = b
			}
			s.defaults[t] = m
		}
	}
	sort.SliceStable(s.Connections, func(i, j int) bool { return s.Connections[i].Source < s.Connections[j].Source })
	return s, nil
}

// Defaults implémente hclgen.DefaultsProvider.
func (s *Set) Defaults(tfType string) map[string]json.RawMessage {
	return s.defaults[tfType]
}

// AllDefaults renvoie la table complète (exposée au frontend).
func (s *Set) AllDefaults() map[string]map[string]json.RawMessage { return s.defaults }

// Match renvoie les règles applicables entre deux types.
func (s *Set) Match(sourceType, targetType string) []Connection {
	var out []Connection
	for _, c := range s.Connections {
		if c.Source != sourceType {
			continue
		}
		if c.Target == targetType || (c.Target == "*" && samePrefix(sourceType, targetType)) {
			out = append(out, c)
		}
	}
	return out
}

func samePrefix(a, b string) bool {
	pa, pb := a, b
	if i := strings.Index(a, "_"); i > 0 {
		pa = a[:i]
	}
	if i := strings.Index(b, "_"); i > 0 {
		pb = b[:i]
	}
	return pa == pb || (pa == "kubernetes" && pb == "helm")
}
