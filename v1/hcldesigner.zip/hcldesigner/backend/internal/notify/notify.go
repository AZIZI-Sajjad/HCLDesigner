// Package notify produit les notifications (mail, webhooks) à partir des événements
// de la plateforme. Les messages passent par une table outbox : l'émission est
// transactionnellement simple et l'envoi est retenté par le scheduler.
package notify

import (
	"bytes"
	"context"
	"crypto/tls"
	"encoding/json"
	"fmt"
	htmltpl "html/template"
	"log/slog"
	"net"
	"net/http"
	"net/smtp"
	"strings"
	texttpl "text/template"
	"time"

	"github.com/jackc/pgx/v5/pgxpool"

	"github.com/AZIZI-Sajjad/hcldesigner/internal/rbac"
	"github.com/AZIZI-Sajjad/hcldesigner/internal/settings"
	"github.com/AZIZI-Sajjad/hcldesigner/internal/vault"
)

// Événements notifiables.
const (
	EvPlanFinished     = "plan.finished"
	EvRunFailed        = "run.failed"
	EvApplySucceeded   = "apply.succeeded"
	EvApplyFailed      = "apply.failed"
	EvDestroyFinished  = "destroy.finished"
	EvApprovalRequest  = "approval.requested"
	EvApprovalGranted  = "approval.granted"
	EvApprovalRejected = "approval.rejected"
	EvDrift            = "drift.detected"
	EvCompliance       = "compliance.violation"
	EvTaskFailed       = "task.failed"
	EvStateLockStuck   = "state.lock_stuck"
	EvNewIP            = "security.new_ip"
	EvRoleChanged      = "role.changed"
	EvReport           = "report.ready"
)

// Catalog : libellés des événements (exposés au frontend pour les abonnements).
var Catalog = []struct {
	Event string `json:"event"`
	Label string `json:"label"`
}{
	{EvPlanFinished, "Plan terminé (résumé des changements)"},
	{EvRunFailed, "Exécution en échec"},
	{EvApplySucceeded, "Apply réussi"},
	{EvApplyFailed, "Apply en échec"},
	{EvDestroyFinished, "Destroy exécuté"},
	{EvApprovalRequest, "Approbation demandée"},
	{EvApprovalGranted, "Approbation accordée"},
	{EvApprovalRejected, "Approbation refusée"},
	{EvDrift, "Drift détecté"},
	{EvCompliance, "Non-conformité détectée"},
	{EvTaskFailed, "Tâche planifiée en échec"},
	{EvStateLockStuck, "Verrou de state bloqué"},
	{EvNewIP, "Connexion depuis une nouvelle IP"},
	{EvRoleChanged, "Modification de rôle"},
	{EvReport, "Rapport planifié"},
}

// Event décrit ce qui s'est passé.
type Event struct {
	Type        string         `json:"event"`
	ProjectID   string         `json:"projectId,omitempty"`
	Project     string         `json:"project,omitempty"`
	Environment string         `json:"environment,omitempty"`
	Actor       string         `json:"actor,omitempty"`
	Summary     string         `json:"summary"`
	Link        string         `json:"link,omitempty"`
	Data        map[string]any `json:"data,omitempty"`
	// Recipients : utilisateurs notifiés quelles que soient leurs règles (ex. alerte de sécurité personnelle).
	Recipients []string `json:"-"`
}

type Template struct {
	Subject string `json:"subject"`
	Body    string `json:"body"` // HTML
}

// DefaultTemplates : un modèle générique suffit, le résumé porte l'information propre à l'événement.
var DefaultTemplates = map[string]Template{
	"default": {
		Subject: `[{{.Brand}}] {{.Label}}{{if .Project}} — {{.Project}}{{end}}{{if .Environment}} / {{.Environment}}{{end}}`,
		Body: `<div style="font-family:Segoe UI,Arial,sans-serif;font-size:14px;color:#1f2937">
<h2 style="margin:0 0 12px;font-size:18px">{{.Label}}</h2>
<table style="border-collapse:collapse;margin-bottom:12px">
{{if .Project}}<tr><td style="padding:2px 12px 2px 0;color:#6b7280">Projet</td><td>{{.Project}}</td></tr>{{end}}
{{if .Environment}}<tr><td style="padding:2px 12px 2px 0;color:#6b7280">Environnement</td><td>{{.Environment}}</td></tr>{{end}}
{{if .Actor}}<tr><td style="padding:2px 12px 2px 0;color:#6b7280">Par</td><td>{{.Actor}}</td></tr>{{end}}
<tr><td style="padding:2px 12px 2px 0;color:#6b7280">Date</td><td>{{.Time}}</td></tr>
</table>
<pre style="background:#f3f4f6;padding:10px;border-radius:6px;white-space:pre-wrap">{{.Summary}}</pre>
{{if .Link}}<p><a href="{{.Link}}" style="background:#4f46e5;color:#fff;padding:8px 14px;border-radius:6px;text-decoration:none">Ouvrir dans {{.Brand}}</a></p>{{end}}
</div>`,
	},
}

type Notifier struct {
	pool     *pgxpool.Pool
	settings *settings.Store
	vault    *vault.Vault
	baseURL  string
	http     *http.Client
}

func New(pool *pgxpool.Pool, st *settings.Store, v *vault.Vault, baseURL string) *Notifier {
	return &Notifier{pool: pool, settings: st, vault: v, baseURL: strings.TrimRight(baseURL, "/"), http: &http.Client{Timeout: 15 * time.Second}}
}

func label(ev string) string {
	for _, c := range Catalog {
		if c.Event == ev {
			return c.Label
		}
	}
	return ev
}

// Emit enregistre les messages à envoyer pour un événement. N'échoue jamais bruyamment.
func (n *Notifier) Emit(ctx context.Context, ev Event) {
	if err := n.emit(ctx, ev); err != nil {
		slog.Error("notification non émise", "event", ev.Type, "err", err)
	}
}

func (n *Notifier) emit(ctx context.Context, ev Event) error {
	if ev.Link != "" && strings.HasPrefix(ev.Link, "/") {
		ev.Link = n.baseURL + ev.Link
	}
	subject, body, err := n.render(ctx, ev)
	if err != nil {
		return err
	}
	type recipient struct {
		id, email, digest string
	}
	recipients := map[string]recipient{}
	rows, err := n.pool.Query(ctx, `
		SELECT u.id, u.email, u.username, u.is_super, nr.digest
		FROM notification_rules nr JOIN users u ON u.id = nr.user_id
		WHERE u.active AND u.email <> '' AND $1 = ANY(nr.events)
		  AND (nr.project_id IS NULL OR nr.project_id::text = $2)`, ev.Type, ev.ProjectID)
	if err != nil {
		return err
	}
	type cand struct {
		id, email, username, digest string
		super                       bool
	}
	var cands []cand
	for rows.Next() {
		var c cand
		if err := rows.Scan(&c.id, &c.email, &c.username, &c.super, &c.digest); err != nil {
			rows.Close()
			return err
		}
		cands = append(cands, c)
	}
	rows.Close()
	for _, c := range cands {
		// Un abonné ne reçoit que ce qu'il a le droit de voir.
		if ev.ProjectID != "" {
			subj, err := rbac.Load(ctx, n.pool, c.id, c.username, c.super)
			if err != nil || !subj.Can("projects.view", ev.ProjectID, "") {
				continue
			}
		}
		recipients[c.id] = recipient{c.id, c.email, c.digest}
	}
	for _, uid := range ev.Recipients {
		var email string
		if err := n.pool.QueryRow(ctx, `SELECT email FROM users WHERE id=$1 AND active AND email<>''`, uid).Scan(&email); err == nil {
			recipients[uid] = recipient{uid, email, "none"}
		}
	}
	for _, r := range recipients {
		status := "pending"
		if r.digest != "none" && r.digest != "" {
			status = "digest"
		}
		if _, err := n.pool.Exec(ctx, `INSERT INTO notification_outbox(channel, recipient, subject, body, event, user_id, digest, status) VALUES ('email',$1,$2,$3,$4,$5,$6,$7)`,
			r.email, subject, body, ev.Type, r.id, r.digest, status); err != nil {
			return err
		}
	}
	return n.queueWebhooks(ctx, ev)
}

func (n *Notifier) queueWebhooks(ctx context.Context, ev Event) error {
	rows, err := n.pool.Query(ctx, `SELECT id, kind, url_enc FROM webhooks WHERE enabled AND $1 = ANY(events)`, ev.Type)
	if err != nil {
		return err
	}
	defer rows.Close()
	type hook struct {
		id, kind string
		url      []byte
	}
	var hooks []hook
	for rows.Next() {
		var h hook
		if err := rows.Scan(&h.id, &h.kind, &h.url); err != nil {
			return err
		}
		hooks = append(hooks, h)
	}
	rows.Close()
	for _, h := range hooks {
		payload, err := webhookPayload(h.kind, ev)
		if err != nil {
			return err
		}
		if _, err := n.pool.Exec(ctx, `INSERT INTO notification_outbox(channel, recipient, body, event) VALUES ('webhook',$1,$2,$3)`, h.id, payload, ev.Type); err != nil {
			return err
		}
	}
	return nil
}

func webhookPayload(kind string, ev Event) (string, error) {
	text := fmt.Sprintf("**%s**", label(ev.Type))
	if ev.Project != "" {
		text += fmt.Sprintf(" — %s", ev.Project)
		if ev.Environment != "" {
			text += " / " + ev.Environment
		}
	}
	text += "\n\n" + ev.Summary
	if ev.Link != "" {
		text += "\n\n" + ev.Link
	}
	var v any
	switch kind {
	case "teams", "slack":
		v = map[string]string{"text": text}
	default:
		type generic struct {
			Event
			Label string    `json:"label"`
			Time  time.Time `json:"time"`
		}
		v = generic{Event: ev, Label: label(ev.Type), Time: time.Now().UTC()}
	}
	b, err := json.Marshal(v)
	return string(b), err
}

// render applique le modèle (personnalisé par événement, sinon "default").
func (n *Notifier) render(ctx context.Context, ev Event) (string, string, error) {
	custom := map[string]Template{}
	_ = n.settings.Get(ctx, settings.KeyTemplates, &custom)
	tpl, ok := custom[ev.Type]
	if !ok {
		tpl, ok = custom["default"]
	}
	if !ok {
		tpl = DefaultTemplates["default"]
	}
	var brand settings.Branding
	_ = n.settings.Get(ctx, settings.KeyBranding, &brand)
	data := map[string]any{
		"Brand": brand.Name, "Event": ev.Type, "Label": label(ev.Type), "Project": ev.Project, "Environment": ev.Environment,
		"Actor": ev.Actor, "Summary": ev.Summary, "Link": ev.Link, "Data": ev.Data,
		"Time": time.Now().Format("02/01/2006 15:04:05"),
	}
	return RenderTemplate(tpl, data)
}

// RenderTemplate est exposé pour la prévisualisation dans le control panel.
func RenderTemplate(tpl Template, data map[string]any) (string, string, error) {
	st, err := texttpl.New("s").Parse(tpl.Subject)
	if err != nil {
		return "", "", fmt.Errorf("sujet : %w", err)
	}
	bt, err := htmltpl.New("b").Parse(tpl.Body)
	if err != nil {
		return "", "", fmt.Errorf("corps : %w", err)
	}
	var s, b bytes.Buffer
	if err := st.Execute(&s, data); err != nil {
		return "", "", err
	}
	if err := bt.Execute(&b, data); err != nil {
		return "", "", err
	}
	return strings.TrimSpace(s.String()), b.String(), nil
}

// ProcessOutbox envoie les messages en attente (appelé périodiquement par le scheduler).
func (n *Notifier) ProcessOutbox(ctx context.Context) {
	rows, err := n.pool.Query(ctx, `SELECT id, channel, recipient, subject, body FROM notification_outbox
		WHERE status='pending' AND attempts < 5 ORDER BY id LIMIT 50`)
	if err != nil {
		slog.Error("outbox", "err", err)
		return
	}
	type msg struct {
		id                                int64
		channel, recipient, subject, body string
	}
	var msgs []msg
	for rows.Next() {
		var m msg
		if err := rows.Scan(&m.id, &m.channel, &m.recipient, &m.subject, &m.body); err == nil {
			msgs = append(msgs, m)
		}
	}
	rows.Close()
	for _, m := range msgs {
		var err error
		if m.channel == "webhook" {
			err = n.postWebhook(ctx, m.recipient, m.body)
		} else {
			err = n.SendMail(ctx, []string{m.recipient}, m.subject, m.body, nil, "")
		}
		if err != nil {
			_, _ = n.pool.Exec(ctx, `UPDATE notification_outbox SET attempts=attempts+1, error=$2, status=CASE WHEN attempts+1>=5 THEN 'failed' ELSE status END WHERE id=$1`, m.id, err.Error())
			continue
		}
		_, _ = n.pool.Exec(ctx, `UPDATE notification_outbox SET status='sent', sent_at=now(), attempts=attempts+1, error='' WHERE id=$1`, m.id)
	}
}

// SendDigests regroupe les messages "digest" par utilisateur (daily ou weekly).
func (n *Notifier) SendDigests(ctx context.Context, period string) {
	rows, err := n.pool.Query(ctx, `SELECT recipient, array_agg(subject ORDER BY id), array_agg(id) FROM notification_outbox
		WHERE status='digest' AND digest=$1 GROUP BY recipient`, period)
	if err != nil {
		return
	}
	type d struct {
		to       string
		subjects []string
		ids      []int64
	}
	var ds []d
	for rows.Next() {
		var x d
		if rows.Scan(&x.to, &x.subjects, &x.ids) == nil {
			ds = append(ds, x)
		}
	}
	rows.Close()
	for _, x := range ds {
		var b strings.Builder
		b.WriteString("<h2>Résumé HCLDesigner</h2><ul>")
		for _, s := range x.subjects {
			b.WriteString("<li>" + htmltpl.HTMLEscapeString(s) + "</li>")
		}
		b.WriteString("</ul>")
		subj := "[HCLDesigner] Résumé quotidien"
		if period == "weekly" {
			subj = "[HCLDesigner] Résumé hebdomadaire"
		}
		if err := n.SendMail(ctx, []string{x.to}, subj, b.String(), nil, ""); err == nil {
			_, _ = n.pool.Exec(ctx, `UPDATE notification_outbox SET status='digested', sent_at=now() WHERE id = ANY($1)`, x.ids)
		}
	}
}

func (n *Notifier) postWebhook(ctx context.Context, hookID, payload string) error {
	var enc []byte
	if err := n.pool.QueryRow(ctx, `SELECT url_enc FROM webhooks WHERE id=$1`, hookID).Scan(&enc); err != nil {
		return err
	}
	url, err := n.vault.Decrypt(enc)
	if err != nil {
		return err
	}
	req, _ := http.NewRequestWithContext(ctx, http.MethodPost, string(url), strings.NewReader(payload))
	req.Header.Set("Content-Type", "application/json")
	resp, err := n.http.Do(req)
	if err != nil {
		return err
	}
	resp.Body.Close()
	if resp.StatusCode >= 300 {
		return fmt.Errorf("webhook : HTTP %d", resp.StatusCode)
	}
	return nil
}

// SendMail envoie un mail HTML (avec pièce jointe optionnelle) via le SMTP configuré.
func (n *Notifier) SendMail(ctx context.Context, to []string, subject, html string, attachment []byte, attachName string) error {
	var cfg settings.SMTP
	if err := n.settings.Get(ctx, settings.KeySMTP, &cfg); err != nil {
		return err
	}
	if cfg.Host == "" {
		return fmt.Errorf("SMTP non configuré")
	}
	password := ""
	if len(cfg.PasswordEnc) > 0 {
		p, err := n.vault.Decrypt(cfg.PasswordEnc)
		if err != nil {
			return err
		}
		password = string(p)
	}
	msg := buildMIME(cfg.From, to, subject, html, attachment, attachName)
	addr := net.JoinHostPort(cfg.Host, fmt.Sprint(cfg.Port))
	tlsCfg := &tls.Config{ServerName: cfg.Host, InsecureSkipVerify: cfg.SkipVerify} // #nosec G402 option explicite de l'admin
	var conn net.Conn
	var err error
	dialer := &net.Dialer{Timeout: 15 * time.Second}
	if cfg.Security == "tls" {
		conn, err = tls.DialWithDialer(dialer, "tcp", addr, tlsCfg)
	} else {
		conn, err = dialer.DialContext(ctx, "tcp", addr)
	}
	if err != nil {
		return err
	}
	c, err := smtp.NewClient(conn, cfg.Host)
	if err != nil {
		conn.Close()
		return err
	}
	defer c.Close()
	if cfg.Security == "starttls" {
		if err := c.StartTLS(tlsCfg); err != nil {
			return err
		}
	}
	if cfg.Username != "" {
		if err := c.Auth(smtp.PlainAuth("", cfg.Username, password, cfg.Host)); err != nil {
			return err
		}
	}
	if err := c.Mail(extractAddr(cfg.From)); err != nil {
		return err
	}
	for _, r := range to {
		if err := c.Rcpt(r); err != nil {
			return err
		}
	}
	w, err := c.Data()
	if err != nil {
		return err
	}
	if _, err := w.Write(msg); err != nil {
		return err
	}
	if err := w.Close(); err != nil {
		return err
	}
	return c.Quit()
}

func extractAddr(from string) string {
	if i := strings.Index(from, "<"); i >= 0 {
		return strings.Trim(from[i:], "<> ")
	}
	return from
}
