package hclgen

import (
	"encoding/json"
	"flag"
	"os"
	"path/filepath"
	"sort"
	"strings"
	"testing"

	"github.com/AZIZI-Sajjad/hcldesigner/internal/model"
	"github.com/AZIZI-Sajjad/hcldesigner/internal/schema"
)

var update = flag.Bool("update", false, "met à jour les fichiers golden")

// testLookup charge le schéma AWS réduit de testdata.
func testLookup(t *testing.T) LookupFunc {
	t.Helper()
	raw, err := os.ReadFile("testdata/aws_schema.json")
	if err != nil {
		t.Fatal(err)
	}
	var ps schema.ProviderSchema
	if err := json.Unmarshal(raw, &ps); err != nil {
		t.Fatal(err)
	}
	return func(source, version, kind, tfType string) *schema.Block {
		var s *schema.Schema
		switch kind {
		case "resource":
			s = ps.ResourceSchemas[tfType]
		case "data":
			s = ps.DataSourceSchemas[tfType]
		case "provider":
			s = ps.Provider
		}
		if s == nil {
			return nil
		}
		return s.Block
	}
}

func lit(v any) model.Value {
	b, _ := json.Marshal(v)
	return model.Value{Mode: model.ModeLiteral, Value: b}
}

func ref(node, attr, mode string) model.Value {
	return model.Value{Mode: model.ModeRef, Ref: &model.Ref{NodeID: node, Attr: attr, IndexMode: mode}}
}

func expr(e string) model.Value { return model.Value{Mode: model.ModeExpr, Expr: e} }

// acceptanceProject reproduit le scénario du critère d'acceptation.
func acceptanceProject(layout string) *model.Project {
	p := model.New()
	p.FileLayout.Mode = layout
	p.Providers = []model.ProviderConfig{{LocalName: "aws", Source: "hashicorp/aws", Version: "~> 5.0", Config: map[string]model.Value{"region": ref("v_region", "", "")}}}
	count := lit(2)
	p.Nodes = []model.Node{
		{ID: "v_region", Kind: model.KindVariable, Label: "region", Attrs: map[string]model.Value{"type": lit("string"), "default": lit("eu-west-3"), "description": lit("Région AWS")}},
		{ID: "v_type", Kind: model.KindVariable, Label: "instance_type", Attrs: map[string]model.Value{"type": lit("string"), "default": lit("t3.micro")}},
		{ID: "vpc", Kind: model.KindResource, Type: "aws_vpc", Label: "main", Attrs: map[string]model.Value{"cidr_block": lit("10.0.0.0/16"), "tags": lit(map[string]string{"Name": "main"})}},
		{ID: "sub", Kind: model.KindResource, Type: "aws_subnet", Label: "public", Meta: model.Meta{Count: &count}, Attrs: map[string]model.Value{
			"vpc_id":     ref("vpc", "id", ""),
			"cidr_block": expr(`cidrsubnet(aws_vpc.main.cidr_block, 8, count.index)`),
		}},
		{ID: "sg", Kind: model.KindResource, Type: "aws_security_group", Label: "web", Attrs: map[string]model.Value{"name": lit("web"), "vpc_id": ref("vpc", "id", "")},
			Blocks: map[string][]model.Block{"ingress": {{Attrs: map[string]model.Value{"from_port": lit(443), "to_port": lit(443), "protocol": lit("tcp"), "cidr_blocks": lit([]string{"0.0.0.0/0"})}}}}},
		{ID: "ami", Kind: model.KindData, Type: "aws_ami", Label: "debian", Attrs: map[string]model.Value{"most_recent": lit(true), "owners": lit([]string{"136693071363"})}},
		{ID: "ec2", Kind: model.KindResource, Type: "aws_instance", Label: "web", Attrs: map[string]model.Value{
			"ami":                    ref("ami", "id", ""),
			"instance_type":          ref("v_type", "", ""),
			"subnet_id":              {Mode: model.ModeRef, Ref: &model.Ref{NodeID: "sub", Attr: "id", IndexMode: "index", Index: "0"}},
			"vpc_security_group_ids": ref("sg", "id", ""),
			"user_data":              lit("#!/bin/bash\necho ${HOSTNAME}\n"),
		}, Blocks: map[string][]model.Block{"root_block_device": {{Attrs: map[string]model.Value{"volume_size": lit(20), "encrypted": lit(true)}}}},
			Meta: model.Meta{Lifecycle: &model.Lifecycle{CreateBeforeDestroy: true, IgnoreChanges: []string{"ami"}}}},
		{ID: "s3", Kind: model.KindResource, Type: "aws_s3_bucket", Label: "assets", Attrs: map[string]model.Value{"bucket": lit("assets-demo")}, Meta: model.Meta{DependsOn: []string{"ec2"}}},
		{ID: "l_tags", Kind: model.KindLocal, Label: "common_tags", Attrs: map[string]model.Value{"value": lit(map[string]string{"env": "dev"})}},
		{ID: "out", Kind: model.KindOutput, Label: "instance_ip", Attrs: map[string]model.Value{"value": ref("ec2", "public_ip", ""), "description": lit("IP publique")}},
	}
	return &p
}

func render(r *Result) string {
	names := make([]string, 0, len(r.Files))
	for n := range r.Files {
		names = append(names, n)
	}
	sort.Strings(names)
	var b strings.Builder
	for _, n := range names {
		b.WriteString("### " + n + "\n" + r.Files[n])
	}
	return b.String()
}

func TestGolden(t *testing.T) {
	look := testLookup(t)
	for _, layout := range []string{model.LayoutSingle, model.LayoutStandard, model.LayoutService, model.LayoutCategory} {
		t.Run(layout, func(t *testing.T) {
			p := acceptanceProject(layout)
			res := Generate(p, ProjectResolver{Project: p, Lookup: look}, Options{
				Backend: &Backend{Type: "s3", Partial: true},
			})
			if len(res.Diags) > 0 {
				t.Fatalf("diagnostics inattendus : %+v", res.Diags)
			}
			got := render(res)
			golden := filepath.Join("testdata", "golden_"+layout+".txt")
			if *update {
				if err := os.WriteFile(golden, []byte(got), 0o644); err != nil {
					t.Fatal(err)
				}
			}
			want, err := os.ReadFile(golden)
			if err != nil {
				t.Fatalf("golden absent (lancer go test -update) : %v", err)
			}
			if string(want) != got {
				t.Errorf("sortie différente du golden %s :\n%s", golden, got)
			}
			// Déterminisme : deux générations successives identiques.
			if again := render(Generate(p, ProjectResolver{Project: p, Lookup: look}, Options{Backend: &Backend{Type: "s3", Partial: true}})); again != got {
				t.Error("génération non déterministe")
			}
		})
	}
}

func TestServiceFiles(t *testing.T) {
	p := acceptanceProject(model.LayoutService)
	res := Generate(p, ProjectResolver{Project: p, Lookup: testLookup(t)}, Options{Backend: &Backend{Type: "s3", Partial: true}})
	for _, f := range []string{"versions.tf", "providers.tf", "backend.tf", "variables.tf", "vpc.tf", "security.tf", "ec2.tf", "s3.tf", "outputs.tf", "locals.tf"} {
		if _, ok := res.Files[f]; !ok {
			t.Errorf("fichier %s attendu, obtenu %v", f, keys(res.Files))
		}
	}
	ec2 := res.Files["ec2.tf"]
	for _, want := range []string{
		"subnet_id              = aws_subnet.public[0].id",
		"vpc_security_group_ids = [aws_security_group.web.id]",
		"instance_type          = var.instance_type",
		"ami                    = data.aws_ami.debian.id",
		"$${HOSTNAME}",
	} {
		if !strings.Contains(ec2, want) {
			t.Errorf("ec2.tf ne contient pas %q :\n%s", want, ec2)
		}
	}
}

func TestRangesPointToNodes(t *testing.T) {
	p := acceptanceProject(model.LayoutStandard)
	res := Generate(p, ProjectResolver{Project: p, Lookup: testLookup(t)}, Options{})
	for _, r := range res.Ranges {
		lines := strings.Split(res.Files[r.File], "\n")
		if r.Start < 1 || r.End > len(lines) {
			t.Fatalf("plage hors fichier : %+v", r)
		}
		first := lines[r.Start-1]
		if !(strings.HasPrefix(first, "resource ") || strings.HasPrefix(first, "data ") || strings.HasPrefix(first, "variable ") || strings.HasPrefix(first, "output ") || strings.HasPrefix(first, "module ") || strings.HasPrefix(first, "import ") || strings.HasPrefix(first, "moved ")) {
			t.Errorf("la plage %+v ne commence pas sur un bloc : %q", r, first)
		}
	}
}

func TestInvalidExpressionIsReported(t *testing.T) {
	p := acceptanceProject(model.LayoutSingle)
	p.Nodes[2].Attrs["cidr_block"] = expr("cidrsubnet(")
	res := Generate(p, ProjectResolver{Project: p, Lookup: testLookup(t)}, Options{})
	if len(res.Diags) == 0 || res.Diags[0].NodeID != "vpc" {
		t.Fatalf("diagnostic attendu sur le nœud vpc, obtenu %+v", res.Diags)
	}
}

func TestInternalModule(t *testing.T) {
	mod := model.New()
	mod.Providers = []model.ProviderConfig{{LocalName: "aws", Source: "hashicorp/aws", Version: "~> 5.0"}}
	mod.Nodes = []model.Node{
		{ID: "cidr", Kind: model.KindVariable, Label: "cidr", Attrs: map[string]model.Value{"type": lit("string")}},
		{ID: "vpc", Kind: model.KindResource, Type: "aws_vpc", Label: "this", Attrs: map[string]model.Value{"cidr_block": ref("cidr", "", "")}},
		{ID: "o", Kind: model.KindOutput, Label: "vpc_id", Attrs: map[string]model.Value{"value": ref("vpc", "id", "")}},
	}
	p := model.New()
	p.Providers = mod.Providers
	p.Nodes = []model.Node{
		{ID: "m", Kind: model.KindModule, Label: "network", Module: &model.ModuleRef{SourceKind: "internal", ModuleID: "mod1"}, Attrs: map[string]model.Value{"cidr": lit("10.1.0.0/16")}},
		{ID: "o", Kind: model.KindOutput, Label: "vpc", Attrs: map[string]model.Value{"value": ref("m", "vpc_id", "")}},
	}
	res := Generate(&p, ProjectResolver{Project: &p, Lookup: testLookup(t)}, Options{Modules: map[string]*ModuleDef{"mod1": {ID: "mod1", Name: "network", Version: "1.0.0", Model: &mod}}})
	if len(res.Diags) > 0 {
		t.Fatal(res.Diags)
	}
	if !strings.Contains(res.Files["main.tf"], `source = "./modules/network"`) {
		t.Errorf("source du module absente :\n%s", res.Files["main.tf"])
	}
	if !strings.Contains(res.Files["outputs.tf"], "module.network.vpc_id") {
		t.Errorf("référence au module absente :\n%s", res.Files["outputs.tf"])
	}
	if !strings.Contains(res.Files["modules/network/main.tf"], "cidr_block = var.cidr") {
		t.Errorf("module non généré : %v", keys(res.Files))
	}
	if strings.Contains(res.Files["modules/network/versions.tf"], "provider \"aws\"") {
		t.Error("un module ne doit pas contenir de bloc provider")
	}
}

func keys(m map[string]string) []string {
	var out []string
	for k := range m {
		out = append(out, k)
	}
	sort.Strings(out)
	return out
}
