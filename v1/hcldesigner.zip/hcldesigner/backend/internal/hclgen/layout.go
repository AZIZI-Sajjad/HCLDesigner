package hclgen

import (
	"path"
	"strings"

	"github.com/AZIZI-Sajjad/hcldesigner/internal/model"
	"github.com/AZIZI-Sajjad/hcldesigner/internal/schema"
)

// serviceRules associe un préfixe/motif de type à un nom de fichier "service".
var serviceRules = []struct{ pattern, file string }{
	// AWS
	{"aws_instance*", "ec2"}, {"aws_launch_template*", "ec2"}, {"aws_ami*", "ec2"}, {"aws_key_pair*", "ec2"},
	{"aws_ebs_*", "ec2"}, {"aws_volume_attachment*", "ec2"}, {"aws_eip*", "ec2"}, {"aws_placement_group*", "ec2"},
	{"aws_security_group*", "security"}, {"aws_vpc_security_group*", "security"}, {"aws_network_acl*", "security"},
	{"aws_wafv2_*", "security"}, {"aws_kms_*", "kms"},
	{"aws_vpc*", "vpc"}, {"aws_subnet*", "vpc"}, {"aws_route*", "vpc"}, {"aws_internet_gateway*", "vpc"},
	{"aws_nat_gateway*", "vpc"}, {"aws_egress_only_internet_gateway*", "vpc"}, {"aws_default_route_table*", "vpc"},
	{"aws_s3_*", "s3"}, {"aws_db_*", "rds"}, {"aws_rds_*", "rds"}, {"aws_iam_*", "iam"},
	{"aws_lb*", "alb"}, {"aws_alb*", "alb"}, {"aws_elb*", "alb"}, {"aws_route53_*", "route53"},
	{"aws_lambda_*", "lambda"}, {"aws_cloudwatch_*", "cloudwatch"}, {"aws_eks_*", "eks"}, {"aws_ecs_*", "ecs"},
	{"aws_ecr_*", "ecr"}, {"aws_sns_*", "sns"}, {"aws_sqs_*", "sqs"}, {"aws_dynamodb_*", "dynamodb"},
	{"aws_autoscaling_*", "autoscaling"}, {"aws_acm_*", "acm"}, {"aws_cloudfront_*", "cloudfront"},
	{"aws_efs_*", "efs"}, {"aws_elasticache_*", "elasticache"}, {"aws_secretsmanager_*", "secrets"},
	// Azure
	{"azurerm_resource_group*", "resource_group"}, {"azurerm_network_security*", "security"},
	{"azurerm_virtual_network*", "network"}, {"azurerm_subnet*", "network"}, {"azurerm_public_ip*", "network"},
	{"azurerm_network_interface*", "network"}, {"azurerm_route*", "network"}, {"azurerm_nat_gateway*", "network"},
	{"azurerm_lb*", "network"}, {"azurerm_*virtual_machine*", "vm"}, {"azurerm_managed_disk*", "vm"},
	{"azurerm_storage_*", "storage"}, {"azurerm_key_vault*", "keyvault"}, {"azurerm_kubernetes_*", "aks"},
	{"azurerm_mssql_*", "database"}, {"azurerm_postgresql*", "database"}, {"azurerm_mysql*", "database"},
	{"azurerm_dns_*", "dns"}, {"azurerm_role_*", "iam"},
	// Google
	{"google_compute_firewall*", "security"}, {"google_compute_network*", "network"},
	{"google_compute_subnetwork*", "network"}, {"google_compute_router*", "network"}, {"google_compute_address*", "network"},
	{"google_compute_instance*", "compute"}, {"google_compute_disk*", "compute"}, {"google_storage_*", "storage"},
	{"google_container_*", "gke"}, {"google_sql_*", "sql"}, {"google_project_iam*", "iam"},
	{"google_service_account*", "iam"}, {"google_dns_*", "dns"},
	// VMware / Proxmox
	{"vsphere_virtual_machine*", "vm"}, {"vsphere_*", "vsphere"}, {"vcd_vapp*", "vapp"}, {"vcd_vm*", "vm"},
	{"vcd_network*", "network"}, {"vcd_nsxt_*", "nsxt"}, {"proxmox_virtual_environment_vm*", "vm"},
	{"proxmox_virtual_environment_container*", "lxc"}, {"proxmox_virtual_environment_*", "proxmox"},
	// Kubernetes
	{"kubernetes_*", "kubernetes"}, {"helm_*", "helm"}, {"cloudflare_*", "cloudflare"}, {"ovh_*", "ovh"},
}

func globMatch(pattern, s string) bool {
	ok, err := path.Match(pattern, s)
	return err == nil && ok
}

// ServiceFile renvoie le fichier "service" d'un type.
func ServiceFile(tfType string) string {
	for _, r := range serviceRules {
		if globMatch(r.pattern, tfType) {
			return r.file + ".tf"
		}
	}
	parts := strings.Split(tfType, "_")
	// Pour les grands providers, le 2e segment désigne le service (aws_lambda_function -> lambda.tf) ;
	// pour les petits (random, null, tls, local...), le provider lui-même est le bon regroupement.
	if len(parts) >= 2 && largeProviders[parts[0]] {
		return parts[1] + ".tf"
	}
	return parts[0] + ".tf"
}

var largeProviders = map[string]bool{
	"aws": true, "azurerm": true, "azuread": true, "google": true, "vsphere": true, "vcd": true, "nsxt": true,
	"kubernetes": true, "oci": true, "alicloud": true, "ibm": true, "openstack": true, "ovh": true, "scaleway": true,
}

// FileFor détermine le fichier cible d'un nœud selon le découpage choisi.
func FileFor(n *model.Node, layout model.FileLayout) string {
	if layout.Mode == model.LayoutSingle {
		return "main.tf"
	}
	switch n.Kind {
	case model.KindVariable:
		return "variables.tf"
	case model.KindOutput:
		return "outputs.tf"
	case model.KindLocal:
		if layout.Mode == model.LayoutCustom && n.File != "" {
			return normalizeFile(n.File)
		}
		return "locals.tf"
	}
	if layout.Mode == model.LayoutCustom && n.File != "" {
		return normalizeFile(n.File)
	}
	for _, r := range layout.Rules {
		if r.Pattern != "" && r.File != "" && (globMatch(r.Pattern, n.Type) || (n.Kind == model.KindModule && globMatch(r.Pattern, "module."+n.Label))) {
			return normalizeFile(r.File)
		}
	}
	switch layout.Mode {
	case model.LayoutService:
		if n.Kind == model.KindModule {
			return "modules.tf"
		}
		return ServiceFile(n.Type)
	case model.LayoutCategory:
		if n.Kind == model.KindModule {
			return "modules.tf"
		}
		return schema.Category(n.Type) + ".tf"
	}
	return "main.tf"
}

func normalizeFile(f string) string {
	f = strings.TrimSpace(path.Base(f))
	if f == "" || f == "." || f == "/" {
		return "main.tf"
	}
	if !strings.HasSuffix(f, ".tf") {
		f += ".tf"
	}
	return f
}
