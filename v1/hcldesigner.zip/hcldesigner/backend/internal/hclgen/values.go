package hclgen

import (
	"encoding/json"
	"fmt"
	"sort"
	"strings"

	"github.com/hashicorp/hcl/v2"
	"github.com/hashicorp/hcl/v2/hclsyntax"
	"github.com/hashicorp/hcl/v2/hclwrite"
	"github.com/zclconf/go-cty/cty"
	ctyjson "github.com/zclconf/go-cty/cty/json"

	"github.com/AZIZI-Sajjad/hcldesigner/internal/model"
	"github.com/AZIZI-Sajjad/hcldesigner/internal/schema"
)

// ParseExpr transforme une expression HCL en tokens et vérifie sa syntaxe.
func ParseExpr(src string) (hclwrite.Tokens, error) {
	src = strings.TrimSpace(src)
	if src == "" {
		return nil, fmt.Errorf("expression vide")
	}
	if strings.HasPrefix(src, "<<") {
		src += "\n" // un heredoc doit se terminer par un saut de ligne après le marqueur
	}
	if _, diags := hclsyntax.ParseExpression([]byte(src), "expr.hcl", hcl.InitialPos); diags.HasErrors() {
		return nil, fmt.Errorf("expression HCL invalide %q : %s", src, diags.Error())
	}
	f, diags := hclwrite.ParseConfig([]byte("x = "+src+"\n"), "expr.hcl", hcl.InitialPos)
	if diags.HasErrors() {
		return nil, fmt.Errorf("expression HCL invalide %q : %s", src, diags.Error())
	}
	attr := f.Body().GetAttribute("x")
	if attr == nil {
		return nil, fmt.Errorf("expression HCL invalide %q", src)
	}
	return attr.Expr().BuildTokens(nil), nil
}

// ctyTypeOf convertit le type d'un attribut de schéma en cty.Type.
func ctyTypeOf(a *schema.Attribute) (cty.Type, bool) {
	if a == nil {
		return cty.DynamicPseudoType, false
	}
	if a.NestedType != nil {
		return nestedType(a.NestedType), true
	}
	if len(a.Type) == 0 {
		return cty.DynamicPseudoType, false
	}
	t, err := ctyjson.UnmarshalType(a.Type)
	if err != nil {
		return cty.DynamicPseudoType, false
	}
	return t, true
}

func nestedType(nt *schema.NestedType) cty.Type {
	attrs := map[string]cty.Type{}
	var optional []string
	for name, a := range nt.Attributes {
		t, _ := ctyTypeOf(a)
		attrs[name] = t
		if !a.Required {
			optional = append(optional, name)
		}
	}
	obj := cty.ObjectWithOptionalAttrs(attrs, optional)
	switch nt.NestingMode {
	case "list":
		return cty.List(obj)
	case "set":
		return cty.Set(obj)
	case "map":
		return cty.Map(obj)
	}
	return obj
}

// literalTokens convertit une valeur littérale JSON en tokens HCL.
func literalTokens(raw json.RawMessage, a *schema.Attribute) (hclwrite.Tokens, error) {
	if len(raw) == 0 || string(raw) == "null" {
		return hclwrite.TokensForValue(cty.NullVal(cty.DynamicPseudoType)), nil
	}
	var val cty.Value
	var err error
	if t, ok := ctyTypeOf(a); ok && t != cty.DynamicPseudoType {
		val, err = ctyjson.Unmarshal(raw, t)
		if err != nil {
			// Les nombres saisis en texte, etc. : on retombe sur le type implicite.
			val, err = impliedValue(raw)
		}
	} else {
		val, err = impliedValue(raw)
	}
	if err != nil {
		return nil, fmt.Errorf("valeur littérale invalide %s : %w", string(raw), err)
	}
	if val.Type() == cty.String && strings.Contains(val.AsString(), "\n") {
		return heredocTokens(val.AsString())
	}
	return hclwrite.TokensForValue(val), nil
}

func impliedValue(raw json.RawMessage) (cty.Value, error) {
	t, err := ctyjson.ImpliedType(raw)
	if err != nil {
		return cty.NilVal, err
	}
	return ctyjson.Unmarshal(raw, t)
}

func heredocTokens(s string) (hclwrite.Tokens, error) {
	esc := strings.NewReplacer("${", "$${", "%{", "%%{").Replace(s)
	esc = strings.TrimSuffix(esc, "\n")
	marker := "EOT"
	for strings.Contains(esc, "\n"+marker) || strings.HasPrefix(esc, marker) {
		marker += "X"
	}
	return ParseExpr("<<-" + marker + "\n" + esc + "\n" + marker + "\n")
}

// refAddress construit l'adresse Terraform d'une référence.
func refAddress(ref *model.Ref, nodes map[string]*model.Node) (string, error) {
	n, ok := nodes[ref.NodeID]
	if !ok {
		return "", fmt.Errorf("référence vers un nœud inexistant (%s)", ref.NodeID)
	}
	var base string
	switch n.Kind {
	case model.KindVariable:
		return "var." + n.Label, nil
	case model.KindLocal:
		return "local." + n.Label, nil
	case model.KindResource:
		base = n.Type + "." + n.Label
	case model.KindData:
		base = "data." + n.Type + "." + n.Label
	case model.KindModule:
		base = "module." + n.Label
	case model.KindOutput:
		return "", fmt.Errorf("un output ne peut pas être référencé")
	}
	attr := ref.Attr
	suffix := ""
	if attr != "" {
		if strings.HasPrefix(attr, "[") {
			suffix = attr
		} else {
			suffix = "." + attr
		}
	}
	switch ref.IndexMode {
	case "index":
		idx := ref.Index
		if idx == "" {
			idx = "0"
		}
		return base + "[" + idx + "]" + suffix, nil
	case "splat":
		return base + "[*]" + suffix, nil
	case "values":
		return "values(" + base + ")[*]" + suffix, nil
	case "each":
		return base + "[each.key]" + suffix, nil
	case "key":
		return base + "[\"" + ref.Index + "\"]" + suffix, nil
	}
	return base + suffix, nil
}

// valueTokens convertit une model.Value en tokens.
func (g *generator) valueTokens(v model.Value, a *schema.Attribute) (hclwrite.Tokens, error) {
	switch v.Mode {
	case model.ModeLiteral:
		return literalTokens(v.Value, a)
	case model.ModeExpr:
		return ParseExpr(v.Expr)
	case model.ModeRef:
		addr, err := refAddress(v.Ref, g.nodes)
		if err != nil {
			return nil, err
		}
		toks, err := ParseExpr(addr)
		if err != nil {
			return nil, err
		}
		// Un argument liste alimenté par une seule référence scalaire est encapsulé : [x.id]
		if a != nil && v.Ref != nil && v.Ref.IndexMode != "splat" && v.Ref.IndexMode != "values" {
			if t, ok := ctyTypeOf(a); ok && (t.IsListType() || t.IsSetType()) && t.ElementType() == cty.String && !refIsCollection(v.Ref, g.nodes, g.res) {
				return hclwrite.TokensForTuple([]hclwrite.Tokens{toks}), nil
			}
		}
		return toks, nil
	case model.ModeList:
		var elemAttr *schema.Attribute
		if a != nil {
			if t, ok := ctyTypeOf(a); ok && (t.IsListType() || t.IsSetType()) {
				b, _ := ctyjson.MarshalType(t.ElementType())
				elemAttr = &schema.Attribute{Type: b}
			}
		}
		elems := make([]hclwrite.Tokens, 0, len(v.Items))
		for _, it := range v.Items {
			if it.IsEmpty() {
				continue
			}
			var t hclwrite.Tokens
			var err error
			if it.Mode == model.ModeRef {
				t, err = g.valueTokens(it, nil)
			} else {
				t, err = g.valueTokens(it, elemAttr)
			}
			if err != nil {
				return nil, err
			}
			elems = append(elems, t)
		}
		return hclwrite.TokensForTuple(elems), nil
	case model.ModeNull, "":
		return hclwrite.TokensForValue(cty.NullVal(cty.DynamicPseudoType)), nil
	}
	return nil, fmt.Errorf("mode de valeur inconnu %q", v.Mode)
}

// refIsCollection : l'attribut source référencé est-il déjà une liste ?
func refIsCollection(ref *model.Ref, nodes map[string]*model.Node, res SchemaResolver) bool {
	n := nodes[ref.NodeID]
	if n == nil || res == nil || (n.Kind != model.KindResource && n.Kind != model.KindData) {
		return false
	}
	blk := res.NodeBlock(n)
	if blk == nil {
		return false
	}
	a := blk.Attributes[ref.Attr]
	if a == nil {
		return false
	}
	t := schema.TypeString(a.Type)
	return schema.IsCollection(t)
}

func sortedKeys[V any](m map[string]V) []string {
	keys := make([]string, 0, len(m))
	for k := range m {
		keys = append(keys, k)
	}
	sort.Strings(keys)
	return keys
}
