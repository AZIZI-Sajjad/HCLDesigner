// Package hclgen génère le code Terraform à partir du modèle interne, de façon
// déterministe (même modèle = même code octet pour octet), avec hclwrite.
package hclgen

import (
	"encoding/json"
	"fmt"
	"sort"
	"strings"

	"github.com/hashicorp/hcl/v2"
	"github.com/hashicorp/hcl/v2/hclwrite"
	"github.com/zclconf/go-cty/cty"

	"github.com/AZIZI-Sajjad/hcldesigner/internal/model"
	"github.com/AZIZI-Sajjad/hcldesigner/internal/schema"
)

// SchemaResolver fournit le schéma d'un nœud ou d'un provider.
type SchemaResolver interface {
	NodeBlock(n *model.Node) *schema.Block
	ProviderBlock(p *model.ProviderConfig) *schema.Block
}

// DefaultsProvider fournit les valeurs par défaut connues d'un type (fichiers defaults/*.yaml).
type DefaultsProvider interface {
	Defaults(tfType string) map[string]json.RawMessage
}

type ModuleDef struct {
	ID      string
	Name    string
	Version string
	Model   *model.Project
}

type Backend struct {
	Type    string                     `json:"type"`
	Config  map[string]json.RawMessage `json:"config"` // valeurs littérales
	Exprs   map[string]string          `json:"exprs"`  // valeurs saisies comme expression HCL (objets)
	Partial bool                       `json:"partial"`
}

type Options struct {
	Backend  *Backend
	Modules  map[string]*ModuleDef // par id de module
	Defaults DefaultsProvider
	// IsModule : génération d'un module (pas de blocs provider ni backend).
	IsModule bool
	// ModulesPrefix : chemin relatif vers le dossier des modules internes ("./modules" à la racine, ".." dans un module).
	ModulesPrefix string
}

type NodeRange struct {
	NodeID string `json:"nodeId"`
	File   string `json:"file"`
	Start  int    `json:"start"`
	End    int    `json:"end"`
}

type Result struct {
	Files  map[string]string  `json:"files"`
	Ranges []NodeRange        `json:"ranges"`
	Diags  []model.Diagnostic `json:"diagnostics"`
}

type generator struct {
	p     *model.Project
	nodes map[string]*model.Node
	res   SchemaResolver
	opts  Options
	diags []model.Diagnostic
}

type chunk struct {
	order  int
	sortBy string
	nodeID string
	text   string
}

// Generate produit l'arborescence de fichiers d'un projet (et de ses modules internes).
func Generate(p *model.Project, res SchemaResolver, opts Options) *Result {
	if opts.ModulesPrefix == "" {
		opts.ModulesPrefix = "./modules"
	}
	g := &generator{p: p, nodes: p.NodeByID(), res: res, opts: opts}
	files := map[string][]chunk{}
	add := func(file string, c chunk) { files[file] = append(files[file], c) }
	single := p.FileLayout.Mode == model.LayoutSingle
	pick := func(def string) string {
		if single {
			return "main.tf"
		}
		return def
	}

	// terraform {} : required_version + required_providers (+ backend en mode fichier unique)
	if txt := g.terraformBlock(single); txt != "" {
		add(pick("versions.tf"), chunk{order: 0, sortBy: "terraform", text: txt})
	}
	if !opts.IsModule && !single && opts.Backend != nil && opts.Backend.Type != "" && opts.Backend.Type != "internal" {
		add("backend.tf", chunk{order: 0, sortBy: "backend", text: g.backendBlock()})
	}
	if !opts.IsModule {
		provs := append([]model.ProviderConfig{}, p.Providers...)
		sort.SliceStable(provs, func(i, j int) bool { return provs[i].Key() < provs[j].Key() })
		for i := range provs {
			if provs[i].Alias == "" && len(provs[i].Config) == 0 && len(provs[i].ConfigBlks) == 0 {
				continue // bloc provider vide : inutile, required_providers suffit
			}
			txt, err := g.providerBlock(&provs[i])
			if err != nil {
				g.diags = append(g.diags, model.Diagnostic{Severity: "error", Summary: fmt.Sprintf("provider %s : %v", provs[i].Key(), err)})
				continue
			}
			add(pick("providers.tf"), chunk{order: 1, sortBy: provs[i].Key(), text: txt})
		}
	}

	// locals regroupés par fichier
	localsByFile := map[string][]*model.Node{}
	for i := range p.Nodes {
		n := &p.Nodes[i]
		file := FileFor(n, p.FileLayout)
		switch n.Kind {
		case model.KindLocal:
			localsByFile[file] = append(localsByFile[file], n)
			continue
		}
		txt, err := g.nodeBlock(n)
		if err != nil {
			g.diags = append(g.diags, model.Diagnostic{Severity: "error", NodeID: n.ID, Summary: err.Error()})
			continue
		}
		add(file, chunk{order: kindOrder(n.Kind), sortBy: n.Type + "." + n.Label, nodeID: n.ID, text: txt})
		if n.ImportID != "" && (n.Kind == model.KindResource) {
			f := file
			if !single {
				f = "imports.tf"
			}
			add(f, chunk{order: 8, sortBy: n.Address(), nodeID: n.ID, text: importBlock(n)})
		}
		if n.MovedFrom != "" && n.MovedFrom != n.Address() {
			f := file
			if !single {
				f = "moved.tf"
			}
			add(f, chunk{order: 9, sortBy: n.Address(), nodeID: n.ID, text: movedBlock(n)})
		}
	}
	for file, locals := range localsByFile {
		sort.Slice(locals, func(i, j int) bool { return locals[i].Label < locals[j].Label })
		f := hclwrite.NewEmptyFile()
		blk := f.Body().AppendNewBlock("locals", nil)
		ok := false
		for _, n := range locals {
			v, has := n.Attrs["value"]
			if !has || v.IsEmpty() {
				g.diags = append(g.diags, model.Diagnostic{Severity: "error", NodeID: n.ID, Summary: "local sans valeur"})
				continue
			}
			toks, err := g.valueTokens(v, nil)
			if err != nil {
				g.diags = append(g.diags, model.Diagnostic{Severity: "error", NodeID: n.ID, Summary: err.Error()})
				continue
			}
			blk.Body().SetAttributeRaw(n.Label, toks)
			ok = true
		}
		if ok {
			add(file, chunk{order: 3, sortBy: "locals", text: string(hclwrite.Format(f.Bytes()))})
		}
	}

	res2 := &Result{Files: map[string]string{}, Diags: g.diags}
	for file, chunks := range files {
		sort.SliceStable(chunks, func(i, j int) bool {
			if chunks[i].order != chunks[j].order {
				return chunks[i].order < chunks[j].order
			}
			return chunks[i].sortBy < chunks[j].sortBy
		})
		var b strings.Builder
		line := 1
		for i, c := range chunks {
			if i > 0 {
				b.WriteString("\n")
				line++
			}
			txt := strings.TrimRight(c.text, "\n") + "\n"
			n := strings.Count(txt, "\n")
			if c.nodeID != "" {
				res2.Ranges = append(res2.Ranges, NodeRange{NodeID: c.nodeID, File: file, Start: line, End: line + n - 1})
			}
			b.WriteString(txt)
			line += n
		}
		res2.Files[file] = string(hclwrite.Format([]byte(b.String())))
	}
	sort.Slice(res2.Ranges, func(i, j int) bool {
		if res2.Ranges[i].File != res2.Ranges[j].File {
			return res2.Ranges[i].File < res2.Ranges[j].File
		}
		return res2.Ranges[i].Start < res2.Ranges[j].Start
	})

	// Modules internes utilisés : générés dans modules/<nom>/ (à la racine uniquement)
	if !opts.IsModule {
		g.generateModules(res2)
	}
	return res2
}

func kindOrder(kind string) int {
	switch kind {
	case model.KindVariable:
		return 2
	case model.KindData:
		return 4
	case model.KindResource:
		return 5
	case model.KindModule:
		return 6
	case model.KindOutput:
		return 7
	}
	return 5
}

func (g *generator) terraformBlock(single bool) string {
	f := hclwrite.NewEmptyFile()
	tb := f.Body().AppendNewBlock("terraform", nil)
	if g.p.RequiredVer != "" {
		tb.Body().SetAttributeValue("required_version", cty.StringVal(g.p.RequiredVer))
	}
	// un seul required_providers par nom local (les alias partagent l'entrée)
	seen := map[string]model.ProviderConfig{}
	var names []string
	for _, p := range g.p.Providers {
		if _, ok := seen[p.LocalName]; !ok {
			names = append(names, p.LocalName)
			seen[p.LocalName] = p
		}
		if p.Alias != "" {
			cur := seen[p.LocalName]
			cur.Alias = "" // marqueur : des alias existent
			seen[p.LocalName] = cur
		}
	}
	sort.Strings(names)
	if len(names) > 0 {
		rp := tb.Body().AppendNewBlock("required_providers", nil)
		for _, name := range names {
			p := seen[name]
			attrs := map[string]cty.Value{"source": cty.StringVal(p.Source)}
			if p.Version != "" {
				attrs["version"] = cty.StringVal(p.Version)
			}
			toks := hclwrite.TokensForValue(cty.ObjectVal(attrs))
			if g.opts.IsModule {
				var aliases []hclwrite.Tokens
				for _, q := range g.p.Providers {
					if q.LocalName == name && q.Alias != "" {
						aliases = append(aliases, hclwrite.TokensForTraversal(travOf(name, q.Alias)))
					}
				}
				if len(aliases) > 0 {
					obj := []hclwrite.ObjectAttrTokens{
						{Name: hclwrite.TokensForIdentifier("source"), Value: hclwrite.TokensForValue(cty.StringVal(p.Source))},
					}
					if p.Version != "" {
						obj = append(obj, hclwrite.ObjectAttrTokens{Name: hclwrite.TokensForIdentifier("version"), Value: hclwrite.TokensForValue(cty.StringVal(p.Version))})
					}
					obj = append(obj, hclwrite.ObjectAttrTokens{Name: hclwrite.TokensForIdentifier("configuration_aliases"), Value: hclwrite.TokensForTuple(aliases)})
					toks = hclwrite.TokensForObject(obj)
				}
			}
			rp.Body().SetAttributeRaw(name, toks)
		}
	}
	if single && !g.opts.IsModule && g.opts.Backend != nil && g.opts.Backend.Type != "" && g.opts.Backend.Type != "internal" {
		g.fillBackend(tb.Body())
	}
	if len(tb.Body().Attributes()) == 0 && len(tb.Body().Blocks()) == 0 {
		return ""
	}
	return string(hclwrite.Format(f.Bytes()))
}

func (g *generator) backendBlock() string {
	f := hclwrite.NewEmptyFile()
	tb := f.Body().AppendNewBlock("terraform", nil)
	g.fillBackend(tb.Body())
	return string(hclwrite.Format(f.Bytes()))
}

func (g *generator) fillBackend(body *hclwrite.Body) {
	b := g.opts.Backend
	bb := body.AppendNewBlock("backend", []string{b.Type})
	if b.Partial {
		return // configuration fournie par -backend-config=backend.hcl
	}
	g.diags = append(g.diags, writeBackendAttrs(bb.Body(), b)...)
}

// writeBackendAttrs écrit la configuration d'un backend (littéraux puis expressions, triés).
func writeBackendAttrs(body *hclwrite.Body, b *Backend) []model.Diagnostic {
	var diags []model.Diagnostic
	keys := sortedKeys(b.Config)
	for k := range b.Exprs {
		if _, dup := b.Config[k]; !dup {
			keys = append(keys, k)
		}
	}
	sort.Strings(keys)
	for _, k := range keys {
		var toks hclwrite.Tokens
		var err error
		if e, ok := b.Exprs[k]; ok {
			toks, err = ParseExpr(e)
		} else {
			toks, err = literalTokens(b.Config[k], nil)
		}
		if err != nil {
			diags = append(diags, model.Diagnostic{Severity: "error", Summary: "backend." + k + " : " + err.Error()})
			continue
		}
		body.SetAttributeRaw(k, toks)
	}
	return diags
}

// BackendConfigFile produit le contenu d'un fichier -backend-config (format HCL clé = valeur).
func BackendConfigFile(b *Backend) (string, error) {
	f := hclwrite.NewEmptyFile()
	if diags := writeBackendAttrs(f.Body(), b); len(diags) > 0 {
		return "", fmt.Errorf("%s", diags[0].Summary)
	}
	return string(hclwrite.Format(f.Bytes())), nil
}

func (g *generator) providerBlock(p *model.ProviderConfig) (string, error) {
	f := hclwrite.NewEmptyFile()
	blk := f.Body().AppendNewBlock("provider", []string{p.LocalName})
	if p.Alias != "" {
		blk.Body().SetAttributeValue("alias", cty.StringVal(p.Alias))
	}
	var sb *schema.Block
	if g.res != nil {
		sb = g.res.ProviderBlock(p)
	}
	if err := g.writeBody(blk.Body(), sb, p.Config, p.ConfigBlks, ""); err != nil {
		return "", err
	}
	return string(hclwrite.Format(f.Bytes())), nil
}

func travOf(parts ...string) hcl.Traversal {
	return makeTraversal(parts...)
}

func makeTraversal(parts ...string) hcl.Traversal {
	t := hcl.Traversal{hcl.TraverseRoot{Name: parts[0]}}
	for _, p := range parts[1:] {
		t = append(t, hcl.TraverseAttr{Name: p})
	}
	return t
}

func (g *generator) nodeBlock(n *model.Node) (string, error) {
	if !model.LabelRegexp.MatchString(n.Label) {
		return "", fmt.Errorf("label HCL invalide %q", n.Label)
	}
	f := hclwrite.NewEmptyFile()
	body := f.Body()
	switch n.Kind {
	case model.KindResource, model.KindData:
		kw := "resource"
		if n.Kind == model.KindData {
			kw = "data"
		}
		blk := body.AppendNewBlock(kw, []string{n.Type, n.Label})
		var sb *schema.Block
		if g.res != nil {
			sb = g.res.NodeBlock(n)
		}
		if err := g.writeMeta(blk.Body(), n, true); err != nil {
			return "", err
		}
		attrs := n.Attrs
		if g.opts.Defaults != nil && g.p.Settings.IncludeDefaults {
			attrs = mergeDefaults(attrs, g.opts.Defaults.Defaults(n.Type))
		}
		if err := g.writeBody(blk.Body(), sb, attrs, n.Blocks, n.ID); err != nil {
			return "", err
		}
		g.writeLifecycle(blk.Body(), n)
		if err := g.writeDependsOn(blk.Body(), n); err != nil {
			return "", err
		}
	case model.KindModule:
		blk := body.AppendNewBlock("module", []string{n.Label})
		src, ver, err := g.moduleSource(n)
		if err != nil {
			return "", err
		}
		blk.Body().SetAttributeValue("source", cty.StringVal(src))
		if ver != "" {
			blk.Body().SetAttributeValue("version", cty.StringVal(ver))
		}
		if err := g.writeMeta(blk.Body(), n, false); err != nil {
			return "", err
		}
		if n.Provider != "" && strings.Contains(n.Provider, ".") {
			parts := strings.SplitN(n.Provider, ".", 2)
			obj := []hclwrite.ObjectAttrTokens{{
				Name:  hclwrite.TokensForTraversal(makeTraversal(parts[0])),
				Value: hclwrite.TokensForTraversal(makeTraversal(parts[0], parts[1])),
			}}
			blk.Body().SetAttributeRaw("providers", hclwrite.TokensForObject(obj))
		}
		for _, k := range sortedKeys(n.Attrs) {
			v := n.Attrs[k]
			if v.IsEmpty() {
				continue
			}
			toks, err := g.valueTokens(v, nil)
			if err != nil {
				return "", fmt.Errorf("%s : %w", k, err)
			}
			blk.Body().SetAttributeRaw(k, toks)
		}
		if err := g.writeDependsOn(blk.Body(), n); err != nil {
			return "", err
		}
	case model.KindVariable:
		blk := body.AppendNewBlock("variable", []string{n.Label})
		for _, k := range []string{"type", "default", "description", "sensitive", "nullable", "ephemeral"} {
			v, ok := n.Attrs[k]
			if !ok || v.IsEmpty() {
				continue
			}
			var toks hclwrite.Tokens
			var err error
			if k == "type" && v.Mode == model.ModeLiteral {
				var s string
				if json.Unmarshal(v.Value, &s) == nil {
					toks, err = ParseExpr(s)
				}
			}
			if toks == nil && err == nil {
				toks, err = g.valueTokens(v, nil)
			}
			if err != nil {
				return "", fmt.Errorf("%s : %w", k, err)
			}
			blk.Body().SetAttributeRaw(k, toks)
		}
		for _, vb := range n.Blocks["validation"] {
			b := blk.Body().AppendNewBlock("validation", nil)
			if c, ok := vb.Attrs["condition"]; ok && !c.IsEmpty() {
				toks, err := g.valueTokens(c, nil)
				if err != nil {
					return "", err
				}
				b.Body().SetAttributeRaw("condition", toks)
			}
			if m, ok := vb.Attrs["error_message"]; ok && !m.IsEmpty() {
				toks, err := g.valueTokens(m, nil)
				if err != nil {
					return "", err
				}
				b.Body().SetAttributeRaw("error_message", toks)
			}
		}
	case model.KindOutput:
		blk := body.AppendNewBlock("output", []string{n.Label})
		v, ok := n.Attrs["value"]
		if !ok || v.IsEmpty() {
			return "", fmt.Errorf("output %q sans valeur", n.Label)
		}
		toks, err := g.valueTokens(v, nil)
		if err != nil {
			return "", err
		}
		blk.Body().SetAttributeRaw("value", toks)
		for _, k := range []string{"description", "sensitive", "ephemeral"} {
			if v, ok := n.Attrs[k]; ok && !v.IsEmpty() {
				toks, err := g.valueTokens(v, nil)
				if err != nil {
					return "", err
				}
				blk.Body().SetAttributeRaw(k, toks)
			}
		}
		if err := g.writeDependsOn(blk.Body(), n); err != nil {
			return "", err
		}
	default:
		return "", fmt.Errorf("type de nœud inconnu %q", n.Kind)
	}
	return string(hclwrite.Format(f.Bytes())), nil
}

func mergeDefaults(attrs map[string]model.Value, defs map[string]json.RawMessage) map[string]model.Value {
	if len(defs) == 0 {
		return attrs
	}
	out := make(map[string]model.Value, len(attrs)+len(defs))
	for k, v := range defs {
		out[k] = model.Value{Mode: model.ModeLiteral, Value: v}
	}
	for k, v := range attrs {
		if v.Mode == model.ModeNull {
			continue
		}
		out[k] = v
	}
	return out
}

func (g *generator) writeMeta(body *hclwrite.Body, n *model.Node, withProvider bool) error {
	if n.Meta.Count != nil && !n.Meta.Count.IsEmpty() {
		toks, err := g.valueTokens(*n.Meta.Count, nil)
		if err != nil {
			return fmt.Errorf("count : %w", err)
		}
		body.SetAttributeRaw("count", toks)
	}
	if n.Meta.ForEach != nil && !n.Meta.ForEach.IsEmpty() {
		toks, err := g.valueTokens(*n.Meta.ForEach, nil)
		if err != nil {
			return fmt.Errorf("for_each : %w", err)
		}
		body.SetAttributeRaw("for_each", toks)
	}
	if withProvider && n.Provider != "" && strings.Contains(n.Provider, ".") {
		parts := strings.SplitN(n.Provider, ".", 2)
		body.SetAttributeTraversal("provider", makeTraversal(parts[0], parts[1]))
	}
	if len(body.Attributes()) > 0 {
		body.AppendNewline() // méta-arguments séparés du reste, comme le veut le style Terraform
	}
	return nil
}

// writeBody écrit attributs (triés) puis blocs imbriqués (triés), selon le schéma.
func (g *generator) writeBody(body *hclwrite.Body, sb *schema.Block, attrs map[string]model.Value, blocks map[string][]model.Block, nodeID string) error {
	for _, k := range sortedKeys(attrs) {
		v := attrs[k]
		if v.IsEmpty() {
			continue
		}
		var a *schema.Attribute
		if sb != nil {
			a = sb.Attributes[k]
			if a != nil && a.Computed && !a.Optional && !a.Required {
				continue // attribut en lecture seule : jamais écrit
			}
		}
		toks, err := g.valueTokens(v, a)
		if err != nil {
			return fmt.Errorf("%s : %w", k, err)
		}
		body.SetAttributeRaw(k, toks)
	}
	if len(blocks) > 0 && len(body.Attributes()) > 0 {
		body.AppendNewline()
	}
	for _, bn := range sortedKeys(blocks) {
		var bt *schema.BlockType
		if sb != nil {
			bt = sb.BlockTypes[bn]
		}
		list := blocks[bn]
		if bt != nil && bt.NestingMode == "map" {
			list = append([]model.Block{}, list...)
			sort.SliceStable(list, func(i, j int) bool { return list[i].Key < list[j].Key })
		}
		for _, b := range list {
			var labels []string
			if bt != nil && bt.NestingMode == "map" {
				labels = []string{b.Key}
			}
			nb := body.AppendNewBlock(bn, labels)
			var inner *schema.Block
			if bt != nil {
				inner = bt.Block
			}
			if err := g.writeBody(nb.Body(), inner, b.Attrs, b.Blocks, nodeID); err != nil {
				return fmt.Errorf("%s : %w", bn, err)
			}
		}
	}
	return nil
}

func (g *generator) writeLifecycle(body *hclwrite.Body, n *model.Node) {
	lc := n.Meta.Lifecycle
	if lc == nil && len(n.Meta.Conditions) == 0 {
		return
	}
	b := hclwrite.NewEmptyFile().Body().AppendNewBlock("lifecycle", nil)
	used := false
	if lc != nil {
		if lc.CreateBeforeDestroy {
			b.Body().SetAttributeValue("create_before_destroy", cty.True)
			used = true
		}
		if lc.PreventDestroy {
			b.Body().SetAttributeValue("prevent_destroy", cty.True)
			used = true
		}
		if lc.IgnoreAll {
			b.Body().SetAttributeRaw("ignore_changes", hclwrite.TokensForIdentifier("all"))
			used = true
		} else if len(lc.IgnoreChanges) > 0 {
			var elems []hclwrite.Tokens
			for _, ic := range lc.IgnoreChanges {
				if t, err := ParseExpr(ic); err == nil {
					elems = append(elems, t)
				} else {
					g.diags = append(g.diags, model.Diagnostic{Severity: "error", NodeID: n.ID, Path: "lifecycle.ignore_changes", Summary: err.Error()})
				}
			}
			b.Body().SetAttributeRaw("ignore_changes", hclwrite.TokensForTuple(elems))
			used = true
		}
		if len(lc.ReplaceTriggeredBy) > 0 {
			var elems []hclwrite.Tokens
			for _, r := range lc.ReplaceTriggeredBy {
				if t, err := ParseExpr(r); err == nil {
					elems = append(elems, t)
				}
			}
			b.Body().SetAttributeRaw("replace_triggered_by", hclwrite.TokensForTuple(elems))
			used = true
		}
	}
	for _, c := range n.Meta.Conditions {
		if c.Kind != "precondition" && c.Kind != "postcondition" {
			continue
		}
		cb := b.Body().AppendNewBlock(c.Kind, nil)
		if t, err := ParseExpr(c.Condition); err == nil {
			cb.Body().SetAttributeRaw("condition", t)
		} else {
			g.diags = append(g.diags, model.Diagnostic{Severity: "error", NodeID: n.ID, Path: "lifecycle." + c.Kind, Summary: err.Error()})
		}
		cb.Body().SetAttributeValue("error_message", cty.StringVal(c.ErrorMessage))
		used = true
	}
	if used {
		body.AppendNewline()
		body.AppendBlock(b)
	}
}

func (g *generator) writeDependsOn(body *hclwrite.Body, n *model.Node) error {
	if len(n.Meta.DependsOn) == 0 {
		return nil
	}
	var elems []hclwrite.Tokens
	ids := append([]string{}, n.Meta.DependsOn...)
	sort.Slice(ids, func(i, j int) bool {
		a, b := g.nodes[ids[i]], g.nodes[ids[j]]
		if a == nil || b == nil {
			return ids[i] < ids[j]
		}
		return a.Address() < b.Address()
	})
	for _, id := range ids {
		dn, ok := g.nodes[id]
		if !ok {
			return fmt.Errorf("depends_on vers un nœud inexistant")
		}
		addr := dn.Address()
		if dn.Kind == model.KindVariable || dn.Kind == model.KindLocal || dn.Kind == model.KindOutput {
			continue
		}
		t, err := ParseExpr(addr)
		if err != nil {
			return err
		}
		elems = append(elems, t)
	}
	if len(elems) > 0 {
		body.AppendNewline()
		body.SetAttributeRaw("depends_on", hclwrite.TokensForTuple(elems))
	}
	return nil
}

func (g *generator) moduleSource(n *model.Node) (string, string, error) {
	if n.Module == nil {
		return "", "", fmt.Errorf("module %q sans source", n.Label)
	}
	switch n.Module.SourceKind {
	case "internal":
		def := g.opts.Modules[n.Module.ModuleID]
		if def == nil {
			return "", "", fmt.Errorf("module interne introuvable (%s)", n.Module.ModuleID)
		}
		return g.opts.ModulesPrefix + "/" + def.Name, "", nil
	case "registry":
		return n.Module.Source, n.Module.Version, nil
	case "git", "local":
		return n.Module.Source, "", nil
	}
	return "", "", fmt.Errorf("type de source de module inconnu %q", n.Module.SourceKind)
}

func importBlock(n *model.Node) string {
	f := hclwrite.NewEmptyFile()
	b := f.Body().AppendNewBlock("import", nil)
	b.Body().SetAttributeTraversal("to", makeTraversal(n.Type, n.Label))
	b.Body().SetAttributeValue("id", cty.StringVal(n.ImportID))
	return string(hclwrite.Format(f.Bytes()))
}

func movedBlock(n *model.Node) string {
	f := hclwrite.NewEmptyFile()
	b := f.Body().AppendNewBlock("moved", nil)
	from, _ := ParseExpr(n.MovedFrom)
	to, _ := ParseExpr(strings.TrimPrefix(n.Address(), "output."))
	b.Body().SetAttributeRaw("from", from)
	b.Body().SetAttributeRaw("to", to)
	return string(hclwrite.Format(f.Bytes()))
}

// generateModules génère les modules internes référencés (récursivement) sous modules/<nom>/.
func (g *generator) generateModules(out *Result) {
	done := map[string]bool{}
	var visit func(p *model.Project)
	visit = func(p *model.Project) {
		for _, n := range p.Nodes {
			if n.Kind != model.KindModule || n.Module == nil || n.Module.SourceKind != "internal" {
				continue
			}
			def := g.opts.Modules[n.Module.ModuleID]
			if def == nil || done[def.ID] || def.Model == nil {
				continue
			}
			done[def.ID] = true
			sub := *def.Model
			sub.FileLayout = model.FileLayout{Mode: model.LayoutStandard}
			sub.RequiredVer = ""
			res := g.res
			if rb, ok := res.(interface {
				WithProject(*model.Project) SchemaResolver
			}); ok {
				res = rb.WithProject(&sub)
			}
			r := Generate(&sub, res, Options{IsModule: true, Modules: g.opts.Modules, Defaults: g.opts.Defaults, ModulesPrefix: ".."})
			for f, c := range r.Files {
				out.Files["modules/"+def.Name+"/"+f] = c
			}
			for _, d := range r.Diags {
				d.Summary = "module " + def.Name + " : " + d.Summary
				out.Diags = append(out.Diags, d)
			}
			out.Files["modules/"+def.Name+"/README.md"] = ModuleReadme(def)
			visit(def.Model)
		}
	}
	visit(g.p)
}

// ModuleReadme génère la documentation d'un module (inputs/outputs).
func ModuleReadme(def *ModuleDef) string {
	var b strings.Builder
	fmt.Fprintf(&b, "# Module %s\n\nVersion : %s\n\n## Inputs\n\n| Nom | Type | Défaut | Obligatoire | Description |\n|---|---|---|---|---|\n", def.Name, def.Version)
	vars, outs := ModuleInterface(def.Model)
	for _, v := range vars {
		req := "non"
		if v.Required {
			req = "oui"
		}
		fmt.Fprintf(&b, "| %s | `%s` | %s | %s | %s |\n", v.Name, v.Type, mdCode(v.Default), req, v.Description)
	}
	b.WriteString("\n## Outputs\n\n| Nom | Description |\n|---|---|\n")
	for _, o := range outs {
		fmt.Fprintf(&b, "| %s | %s |\n", o.Name, o.Description)
	}
	return b.String()
}

func mdCode(s string) string {
	if s == "" {
		return ""
	}
	return "`" + s + "`"
}

// ModuleInterface extrait variables et outputs d'un modèle de module.
func ModuleInterface(p *model.Project) ([]model.ModuleVar, []model.ModuleOutput) {
	vars := []model.ModuleVar{}
	outs := []model.ModuleOutput{}
	if p == nil {
		return vars, outs
	}
	str := func(v model.Value) string {
		switch v.Mode {
		case model.ModeLiteral:
			var s string
			if json.Unmarshal(v.Value, &s) == nil {
				return s
			}
			return string(v.Value)
		case model.ModeExpr:
			return v.Expr
		}
		return ""
	}
	for _, n := range p.Nodes {
		switch n.Kind {
		case model.KindVariable:
			mv := model.ModuleVar{Name: n.Label, Type: "any"}
			if t, ok := n.Attrs["type"]; ok && !t.IsEmpty() {
				mv.Type = str(t)
			}
			d, hasDefault := n.Attrs["default"]
			mv.Required = !hasDefault || d.Mode == "" || (d.Mode == model.ModeLiteral && len(d.Value) == 0)
			if hasDefault && !mv.Required {
				if d.Mode == model.ModeLiteral {
					mv.Default = string(d.Value)
				} else {
					mv.Default = str(d)
				}
			}
			if desc, ok := n.Attrs["description"]; ok {
				mv.Description = str(desc)
			}
			if s, ok := n.Attrs["sensitive"]; ok && string(s.Value) == "true" {
				mv.Sensitive = true
			}
			vars = append(vars, mv)
		case model.KindOutput:
			mo := model.ModuleOutput{Name: n.Label}
			if desc, ok := n.Attrs["description"]; ok {
				mo.Description = str(desc)
			}
			outs = append(outs, mo)
		}
	}
	sort.Slice(vars, func(i, j int) bool { return vars[i].Name < vars[j].Name })
	sort.Slice(outs, func(i, j int) bool { return outs[i].Name < outs[j].Name })
	return vars, outs
}
