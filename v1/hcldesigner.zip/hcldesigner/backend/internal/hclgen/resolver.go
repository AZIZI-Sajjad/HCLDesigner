package hclgen

import (
	"github.com/AZIZI-Sajjad/hcldesigner/internal/model"
	"github.com/AZIZI-Sajjad/hcldesigner/internal/schema"
)

// LookupFunc renvoie le bloc de schéma d'un type pour un provider (source + version résolue).
// kind vaut "resource", "data" ou "provider".
type LookupFunc func(source, version, kind, tfType string) *schema.Block

// ProjectResolver relie les nœuds d'un projet à leur provider puis au cache de schémas.
type ProjectResolver struct {
	Project *model.Project
	Lookup  LookupFunc
}

// ProviderFor renvoie le provider d'un nœud : clé explicite, sinon provider sans alias de même préfixe.
func ProviderFor(p *model.Project, n *model.Node) *model.ProviderConfig {
	if n.Provider != "" {
		if pc := p.ProviderByKey(n.Provider); pc != nil {
			return pc
		}
	}
	prefix := schema.ProviderPrefix(n.Type)
	for i := range p.Providers {
		if p.Providers[i].LocalName == prefix && p.Providers[i].Alias == "" {
			return &p.Providers[i]
		}
	}
	for i := range p.Providers {
		if p.Providers[i].LocalName == prefix {
			return &p.Providers[i]
		}
	}
	return nil
}

func (r ProjectResolver) NodeBlock(n *model.Node) *schema.Block {
	if r.Lookup == nil || (n.Kind != model.KindResource && n.Kind != model.KindData) {
		return nil
	}
	pc := ProviderFor(r.Project, n)
	if pc == nil {
		return nil
	}
	return r.Lookup(pc.Source, pc.Resolved, n.Kind, n.Type)
}

func (r ProjectResolver) ProviderBlock(p *model.ProviderConfig) *schema.Block {
	if r.Lookup == nil {
		return nil
	}
	return r.Lookup(p.Source, p.Resolved, "provider", p.LocalName)
}

// WithProject renvoie un résolveur lié à un autre modèle (utilisé pour les modules internes).
func (r ProjectResolver) WithProject(p *model.Project) SchemaResolver {
	return ProjectResolver{Project: p, Lookup: r.Lookup}
}
