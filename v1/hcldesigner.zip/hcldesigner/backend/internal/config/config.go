// Package config charge la configuration depuis les variables d'environnement.
package config

import (
	"encoding/base64"
	"fmt"
	"os"
	"strconv"
	"time"
)

type Config struct {
	DatabaseURL       string
	Listen            string
	DataDir           string
	MasterKey         []byte
	BaseURL           string
	StaticDir         string
	SessionTTL        time.Duration
	AdminUser         string
	AdminPassword     string
	AdminEmail        string
	WorkerConcurrency int
	RunTimeout        time.Duration
	SecureCookies     bool
	TrustedProxies    bool
}

// Load lit l'environnement et valide les valeurs obligatoires.
func Load() (*Config, error) {
	c := &Config{
		DatabaseURL:    env("HCLD_DATABASE_URL", "postgres://hcldesigner:hcldesigner@localhost:5432/hcldesigner?sslmode=disable"),
		Listen:         env("HCLD_LISTEN", ":8080"),
		DataDir:        env("HCLD_DATA_DIR", "/data"),
		BaseURL:        env("HCLD_BASE_URL", "http://localhost:8080"),
		StaticDir:      os.Getenv("HCLD_STATIC_DIR"),
		AdminUser:      env("HCLD_ADMIN_USER", "admin"),
		AdminPassword:  os.Getenv("HCLD_ADMIN_PASSWORD"),
		AdminEmail:     env("HCLD_ADMIN_EMAIL", "admin@localhost"),
		SecureCookies:  env("HCLD_SECURE_COOKIES", "false") == "true",
		TrustedProxies: env("HCLD_TRUST_PROXY", "true") == "true",
	}
	var err error
	if c.SessionTTL, err = time.ParseDuration(env("HCLD_SESSION_TTL", "12h")); err != nil {
		return nil, fmt.Errorf("HCLD_SESSION_TTL : %w", err)
	}
	if c.RunTimeout, err = time.ParseDuration(env("HCLD_RUN_TIMEOUT", "2h")); err != nil {
		return nil, fmt.Errorf("HCLD_RUN_TIMEOUT : %w", err)
	}
	if c.WorkerConcurrency, err = strconv.Atoi(env("HCLD_WORKER_CONCURRENCY", "2")); err != nil || c.WorkerConcurrency < 1 {
		return nil, fmt.Errorf("HCLD_WORKER_CONCURRENCY invalide")
	}
	key := os.Getenv("HCLD_MASTER_KEY")
	if key == "" {
		return nil, fmt.Errorf("HCLD_MASTER_KEY obligatoire (32 octets en base64 : openssl rand -base64 32)")
	}
	if c.MasterKey, err = base64.StdEncoding.DecodeString(key); err != nil || len(c.MasterKey) != 32 {
		return nil, fmt.Errorf("HCLD_MASTER_KEY doit faire 32 octets encodés en base64")
	}
	return c, nil
}

func env(k, d string) string {
	if v := os.Getenv(k); v != "" {
		return v
	}
	return d
}
