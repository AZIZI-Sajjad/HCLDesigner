-- Schéma initial HCLDesigner

CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- Utilisateurs, équipes, sessions, jetons -----------------------------------
CREATE TABLE users (
    id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    username      text NOT NULL UNIQUE,
    email         text NOT NULL DEFAULT '',
    display_name  text NOT NULL DEFAULT '',
    password_hash text NOT NULL DEFAULT '',
    totp_secret   bytea,                 -- chiffré (vault)
    totp_enabled  boolean NOT NULL DEFAULT false,
    is_super      boolean NOT NULL DEFAULT false,
    active        boolean NOT NULL DEFAULT true,
    expires_at    timestamptz,
    last_login_at timestamptz,
    last_login_ip text NOT NULL DEFAULT '',
    known_ips     text[] NOT NULL DEFAULT '{}',
    created_at    timestamptz NOT NULL DEFAULT now(),
    updated_at    timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE teams (
    id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    name        text NOT NULL UNIQUE,
    description text NOT NULL DEFAULT '',
    created_at  timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE team_members (
    team_id uuid NOT NULL REFERENCES teams(id) ON DELETE CASCADE,
    user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    PRIMARY KEY (team_id, user_id)
);

CREATE TABLE sessions (
    token_hash text PRIMARY KEY,
    user_id    uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    ip         text NOT NULL DEFAULT '',
    user_agent text NOT NULL DEFAULT '',
    mfa_ok     boolean NOT NULL DEFAULT false,
    created_at timestamptz NOT NULL DEFAULT now(),
    last_seen  timestamptz NOT NULL DEFAULT now(),
    expires_at timestamptz NOT NULL
);
CREATE INDEX sessions_user ON sessions(user_id);

CREATE TABLE api_tokens (
    id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id    uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    name       text NOT NULL,
    token_hash text NOT NULL UNIQUE,
    prefix     text NOT NULL,
    expires_at timestamptz,
    last_used  timestamptz,
    created_at timestamptz NOT NULL DEFAULT now()
);

-- RBAC ---------------------------------------------------------------------
CREATE TABLE roles (
    id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    name        text NOT NULL UNIQUE,
    description text NOT NULL DEFAULT '',
    builtin     boolean NOT NULL DEFAULT false,
    permissions text[] NOT NULL DEFAULT '{}',
    created_at  timestamptz NOT NULL DEFAULT now()
);

-- Attribution d'un rôle à un utilisateur ou une équipe, sur une portée.
CREATE TABLE role_bindings (
    id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    role_id     uuid NOT NULL REFERENCES roles(id) ON DELETE CASCADE,
    user_id     uuid REFERENCES users(id) ON DELETE CASCADE,
    team_id     uuid REFERENCES teams(id) ON DELETE CASCADE,
    scope       text NOT NULL CHECK (scope IN ('global','project','environment')),
    project_id  uuid,
    environment text NOT NULL DEFAULT '',
    created_at  timestamptz NOT NULL DEFAULT now(),
    CHECK ((user_id IS NULL) <> (team_id IS NULL))
);

-- Providers : cache des schémas -------------------------------------------
CREATE TABLE provider_schemas (
    source     text NOT NULL,
    version    text NOT NULL,
    address    text NOT NULL,
    schema     jsonb NOT NULL,
    fetched_at timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (source, version)
);

CREATE TABLE catalog_entries (
    source      text NOT NULL,
    version     text NOT NULL,
    kind        text NOT NULL,
    type        text NOT NULL,
    category    text NOT NULL,
    description text NOT NULL DEFAULT '',
    deprecated  boolean NOT NULL DEFAULT false,
    PRIMARY KEY (source, version, kind, type),
    FOREIGN KEY (source, version) REFERENCES provider_schemas(source, version) ON DELETE CASCADE
);
CREATE INDEX catalog_type ON catalog_entries(type text_pattern_ops);

CREATE TABLE schema_jobs (
    id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    engine     text NOT NULL DEFAULT 'terraform',
    engine_version text NOT NULL DEFAULT '',
    local_name text NOT NULL DEFAULT '',
    source     text NOT NULL,
    constraint_ text NOT NULL DEFAULT '',
    status     text NOT NULL DEFAULT 'queued',
    version    text NOT NULL DEFAULT '',
    error      text NOT NULL DEFAULT '',
    created_by uuid REFERENCES users(id) ON DELETE SET NULL,
    created_at timestamptz NOT NULL DEFAULT now(),
    finished_at timestamptz
);

-- Projets -----------------------------------------------------------------
CREATE TABLE projects (
    id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    name        text NOT NULL UNIQUE,
    description text NOT NULL DEFAULT '',
    team_id     uuid REFERENCES teams(id) ON DELETE SET NULL,
    model       jsonb NOT NULL,
    version     integer NOT NULL DEFAULT 1,
    lock_file   text NOT NULL DEFAULT '',
    created_by  uuid REFERENCES users(id) ON DELETE SET NULL,
    created_at  timestamptz NOT NULL DEFAULT now(),
    updated_at  timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE project_versions (
    project_id uuid NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    version    integer NOT NULL,
    model      jsonb NOT NULL,
    message    text NOT NULL DEFAULT '',
    author_id  uuid REFERENCES users(id) ON DELETE SET NULL,
    created_at timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (project_id, version)
);

-- Coffre de credentials (data chiffré AES-256-GCM)
CREATE TABLE credentials (
    id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    name        text NOT NULL UNIQUE,
    kind        text NOT NULL,
    description text NOT NULL DEFAULT '',
    data_enc    bytea NOT NULL,
    created_by  uuid REFERENCES users(id) ON DELETE SET NULL,
    created_at  timestamptz NOT NULL DEFAULT now(),
    updated_at  timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE environments (
    id                uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    project_id        uuid NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    name              text NOT NULL,
    backend_type      text NOT NULL DEFAULT 'internal',
    backend_config    jsonb NOT NULL DEFAULT '{}',
    backend_secret_id uuid REFERENCES credentials(id) ON DELETE SET NULL,
    tfvars            text NOT NULL DEFAULT '',
    workspace         text NOT NULL DEFAULT '',
    credential_ids    uuid[] NOT NULL DEFAULT '{}',
    protected         boolean NOT NULL DEFAULT false,
    require_approvals integer NOT NULL DEFAULT 0,
    allow_destroy     boolean NOT NULL DEFAULT true,
    change_window     jsonb NOT NULL DEFAULT '{}',
    created_at        timestamptz NOT NULL DEFAULT now(),
    UNIQUE (project_id, name)
);

-- Modules -----------------------------------------------------------------
CREATE TABLE modules (
    id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    name        text NOT NULL UNIQUE,
    description text NOT NULL DEFAULT '',
    scope       text NOT NULL DEFAULT 'global' CHECK (scope IN ('project','team','global')),
    project_id  uuid REFERENCES projects(id) ON DELETE CASCADE,
    team_id     uuid REFERENCES teams(id) ON DELETE SET NULL,
    tags        text[] NOT NULL DEFAULT '{}',
    draft       jsonb NOT NULL,
    created_by  uuid REFERENCES users(id) ON DELETE SET NULL,
    created_at  timestamptz NOT NULL DEFAULT now(),
    updated_at  timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE module_versions (
    module_id  uuid NOT NULL REFERENCES modules(id) ON DELETE CASCADE,
    version    text NOT NULL,
    model      jsonb NOT NULL,
    changelog  text NOT NULL DEFAULT '',
    created_by uuid REFERENCES users(id) ON DELETE SET NULL,
    created_at timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (module_id, version)
);

-- Exécutions --------------------------------------------------------------
CREATE TABLE runs (
    id                uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    project_id        uuid NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    environment_id    uuid NOT NULL REFERENCES environments(id) ON DELETE CASCADE,
    operation         text NOT NULL,      -- init | validate | plan | apply | state
    destroy           boolean NOT NULL DEFAULT false,
    status            text NOT NULL DEFAULT 'queued',
    options           jsonb NOT NULL DEFAULT '{}',
    snapshot          jsonb NOT NULL DEFAULT '{}',  -- fichiers générés figés
    snapshot_hash     text NOT NULL DEFAULT '',
    project_version   integer NOT NULL DEFAULT 0,
    plan_run_id       uuid REFERENCES runs(id) ON DELETE SET NULL,
    summary           jsonb NOT NULL DEFAULT '{}',
    diagnostics       jsonb NOT NULL DEFAULT '[]',
    policy_report     jsonb NOT NULL DEFAULT '{}',
    state_serial      bigint,
    state_lineage     text NOT NULL DEFAULT '',
    approvals_required integer NOT NULL DEFAULT 0,
    plan_expires_at   timestamptz,
    exit_code         integer,
    error             text NOT NULL DEFAULT '',
    cancel_requested  boolean NOT NULL DEFAULT false,
    worker            text NOT NULL DEFAULT '',
    triggered_by      text NOT NULL DEFAULT 'user', -- user | schedule | api
    task_id           uuid,
    created_by        uuid REFERENCES users(id) ON DELETE SET NULL,
    created_at        timestamptz NOT NULL DEFAULT now(),
    started_at        timestamptz,
    finished_at       timestamptz
);
CREATE INDEX runs_queue ON runs(status, created_at);
CREATE INDEX runs_project ON runs(project_id, created_at DESC);

CREATE TABLE approvals (
    run_id     uuid NOT NULL REFERENCES runs(id) ON DELETE CASCADE,
    user_id    uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    decision   text NOT NULL CHECK (decision IN ('approve','reject')),
    comment    text NOT NULL DEFAULT '',
    created_at timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (run_id, user_id)
);

CREATE TABLE state_versions (
    id             uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    environment_id uuid NOT NULL REFERENCES environments(id) ON DELETE CASCADE,
    serial         bigint NOT NULL,
    lineage        text NOT NULL DEFAULT '',
    resources      integer NOT NULL DEFAULT 0,
    path           text NOT NULL,          -- fichier chiffré sur le volume de données
    run_id         uuid REFERENCES runs(id) ON DELETE SET NULL,
    reason         text NOT NULL DEFAULT '',
    created_at     timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX state_versions_env ON state_versions(environment_id, created_at DESC);

-- Planification -----------------------------------------------------------
CREATE TABLE scheduled_tasks (
    id             uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    name           text NOT NULL,
    kind           text NOT NULL,
    cron           text NOT NULL,
    timezone       text NOT NULL DEFAULT 'Europe/Paris',
    project_id     uuid REFERENCES projects(id) ON DELETE CASCADE,
    environment_id uuid REFERENCES environments(id) ON DELETE CASCADE,
    params         jsonb NOT NULL DEFAULT '{}',
    enabled        boolean NOT NULL DEFAULT true,
    timeout_s      integer NOT NULL DEFAULT 3600,
    max_retries    integer NOT NULL DEFAULT 0,
    next_run_at    timestamptz,
    last_run_at    timestamptz,
    last_status    text NOT NULL DEFAULT '',
    created_by     uuid REFERENCES users(id) ON DELETE SET NULL,
    created_at     timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE task_executions (
    id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    task_id     uuid NOT NULL REFERENCES scheduled_tasks(id) ON DELETE CASCADE,
    status      text NOT NULL DEFAULT 'running',
    attempt     integer NOT NULL DEFAULT 1,
    run_id      uuid REFERENCES runs(id) ON DELETE SET NULL,
    message     text NOT NULL DEFAULT '',
    manual      boolean NOT NULL DEFAULT false,
    started_at  timestamptz NOT NULL DEFAULT now(),
    finished_at timestamptz
);
CREATE INDEX task_executions_task ON task_executions(task_id, started_at DESC);

-- Conformité --------------------------------------------------------------
CREATE TABLE policies (
    id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    name       text NOT NULL,
    kind       text NOT NULL,
    severity   text NOT NULL DEFAULT 'warning' CHECK (severity IN ('info','warning','blocking')),
    params     jsonb NOT NULL DEFAULT '{}',
    enabled    boolean NOT NULL DEFAULT true,
    project_id uuid REFERENCES projects(id) ON DELETE CASCADE,  -- NULL = toutes
    created_at timestamptz NOT NULL DEFAULT now()
);

-- Notifications -----------------------------------------------------------
CREATE TABLE notification_rules (
    id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id    uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    project_id uuid REFERENCES projects(id) ON DELETE CASCADE,  -- NULL = tous les projets
    events     text[] NOT NULL DEFAULT '{}',
    digest     text NOT NULL DEFAULT 'none' CHECK (digest IN ('none','daily','weekly')),
    created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE webhooks (
    id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    name       text NOT NULL,
    kind       text NOT NULL DEFAULT 'generic' CHECK (kind IN ('generic','teams','slack')),
    url_enc    bytea NOT NULL,
    events     text[] NOT NULL DEFAULT '{}',
    enabled    boolean NOT NULL DEFAULT true,
    created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE notification_outbox (
    id         bigserial PRIMARY KEY,
    channel    text NOT NULL DEFAULT 'email',   -- email | webhook
    recipient  text NOT NULL,
    subject    text NOT NULL DEFAULT '',
    body       text NOT NULL,
    event      text NOT NULL DEFAULT '',
    user_id    uuid REFERENCES users(id) ON DELETE SET NULL,
    digest     text NOT NULL DEFAULT 'none',
    status     text NOT NULL DEFAULT 'pending',  -- pending | sent | failed | digested
    attempts   integer NOT NULL DEFAULT 0,
    error      text NOT NULL DEFAULT '',
    created_at timestamptz NOT NULL DEFAULT now(),
    sent_at    timestamptz
);
CREATE INDEX outbox_pending ON notification_outbox(status, created_at);

-- Paramètres (clé/valeur) : smtp, templates, mirror, rétention, branding...
CREATE TABLE settings (
    key        text PRIMARY KEY,
    value      jsonb NOT NULL,
    updated_at timestamptz NOT NULL DEFAULT now()
);

-- Préférences de tableaux et vues enregistrées -----------------------------
CREATE TABLE table_prefs (
    user_id  uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    table_id text NOT NULL,
    prefs    jsonb NOT NULL,
    PRIMARY KEY (user_id, table_id)
);

CREATE TABLE saved_views (
    id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id    uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    table_id   text NOT NULL,
    name       text NOT NULL,
    prefs      jsonb NOT NULL,
    shared     boolean NOT NULL DEFAULT false,
    created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE user_settings (
    user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    key     text NOT NULL,
    value   jsonb NOT NULL,
    PRIMARY KEY (user_id, key)
);

-- Audit (append-only : aucune route ne permet de modifier ou supprimer) -----
CREATE TABLE audit_events (
    id          bigserial PRIMARY KEY,
    ts          timestamptz NOT NULL DEFAULT now(),
    user_id     uuid,
    username    text NOT NULL DEFAULT '',
    ip          text NOT NULL DEFAULT '',
    action      text NOT NULL,
    object_type text NOT NULL DEFAULT '',
    object_id   text NOT NULL DEFAULT '',
    details     jsonb NOT NULL DEFAULT '{}'
);
CREATE INDEX audit_ts ON audit_events(ts DESC);

CREATE OR REPLACE FUNCTION audit_immutable() RETURNS trigger AS $$
BEGIN
    IF TG_OP = 'DELETE' AND current_setting('hcldesigner.retention', true) = 'on' THEN
        RETURN OLD;
    END IF;
    RAISE EXCEPTION 'audit_events est en ajout seul';
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER audit_no_update BEFORE UPDATE OR DELETE ON audit_events
    FOR EACH ROW EXECUTE FUNCTION audit_immutable();
