// Package connection détermine les liaisons possibles entre deux objets du canvas
// et ce qu'elles produisent dans le HCL. Trois niveaux : règles explicites (rules/*.yaml),
// inférence générique par nom/type, liaison manuelle filtrée par compatibilité.
package connection

import (
	"encoding/json"
	"sort"
	"strings"

	"github.com/AZIZI-Sajjad/hcldesigner/internal/model"
	"github.com/AZIZI-Sajjad/hcldesigner/internal/schema"
	"github.com/AZIZI-Sajjad/hcldesigner/rules"
)

// Endpoint décrit une extrémité de liaison, avec son schéma résolu.
type Endpoint struct {
	Kind          string               `json:"kind"`
	Type          string               `json:"type"`
	Label         string               `json:"label"`
	Block         *schema.Block        `json:"-"`
	ModuleVars    []model.ModuleVar    `json:"-"`
	ModuleOutputs []model.ModuleOutput `json:"-"`
	Multi         string               `json:"multi,omitempty"` // "" | count | for_each
}

// Arg est un argument cible aplati (chemin pointé pour les blocs imbriqués).
type Arg struct {
	Path        string          `json:"path"`
	Type        string          `json:"type"`
	Required    bool            `json:"required"`
	Computed    bool            `json:"computed"`
	Sensitive   bool            `json:"sensitive"`
	Deprecated  bool            `json:"deprecated"`
	Description string          `json:"description,omitempty"`
	Default     json.RawMessage `json:"default,omitempty"`
	DefaultFrom string          `json:"defaultFrom,omitempty"` // hcldesigner | module | ""
	InBlock     string          `json:"inBlock,omitempty"`
}

// Suggestion est une liaison proposée.
type Suggestion struct {
	SourceAttr  string `json:"sourceAttr"`
	TargetPath  string `json:"targetPath"`
	TargetType  string `json:"targetType"`
	Cardinality string `json:"cardinality"` // single | list
	Score       int    `json:"score"`
	Origin      string `json:"origin"` // rule | inference
	Reason      string `json:"reason"`
	IndexMode   string `json:"indexMode,omitempty"` // forme proposée si la source est multiple
}

// Result est la réponse complète utilisée par le panneau de liaison.
type Result struct {
	Suggestions []Suggestion      `json:"suggestions"`
	SourceAttrs []schema.AttrInfo `json:"sourceAttrs"`
	TargetArgs  []Arg             `json:"targetArgs"`
	Allowed     bool              `json:"allowed"`
	Message     string            `json:"message,omitempty"`
}

// Engine applique les règles chargées.
type Engine struct {
	Rules *rules.Set
}

const maxDepth = 3

// Suggest calcule les liaisons possibles de src vers dst.
func (e Engine) Suggest(src, dst Endpoint) Result {
	res := Result{Allowed: true, Suggestions: []Suggestion{}, SourceAttrs: []schema.AttrInfo{}, TargetArgs: []Arg{}}
	switch dst.Kind {
	case model.KindVariable:
		return Result{Allowed: false, Message: "une variable ne reçoit pas de référence : reliez la variable vers l'objet qui l'utilise"}
	}
	if src.Kind == model.KindOutput {
		return Result{Allowed: false, Message: "un output ne peut pas être une source"}
	}
	if a := sourceAttrs(src); a != nil {
		res.SourceAttrs = a
	}
	if a := e.targetArgs(dst); a != nil {
		res.TargetArgs = a
	}
	if len(res.TargetArgs) == 0 {
		res.Message = "aucun argument configurable sur la cible"
		return res
	}
	argByPath := map[string]Arg{}
	for _, a := range res.TargetArgs {
		argByPath[a.Path] = a
	}
	seen := map[string]bool{}
	add := func(s Suggestion) {
		key := s.SourceAttr + "->" + s.TargetPath
		if seen[key] {
			return
		}
		seen[key] = true
		s.IndexMode = defaultIndexMode(src.Multi, s.Cardinality)
		res.Suggestions = append(res.Suggestions, s)
	}

	// 1. Règles explicites
	if isSchemaKind(src.Kind) && isSchemaKind(dst.Kind) && e.Rules != nil {
		for _, r := range e.Rules.Match(src.Type, dst.Type) {
			if r.SourceKind != "" && r.SourceKind != src.Kind {
				continue
			}
			a, ok := argByPath[r.Arg]
			if !ok && dst.Block != nil {
				continue // argument absent de cette version du provider
			}
			if !ok {
				a = Arg{Path: r.Arg, Type: "string"}
			}
			add(Suggestion{SourceAttr: r.Attr, TargetPath: r.Arg, TargetType: a.Type, Cardinality: cardinality(a.Type), Score: 100, Origin: "rule", Reason: "règle " + src.Type + " → " + dst.Type})
		}
	}

	// 2. Inférence
	for _, s := range infer(src, res.SourceAttrs, res.TargetArgs) {
		add(s)
	}
	sort.SliceStable(res.Suggestions, func(i, j int) bool {
		if res.Suggestions[i].Score != res.Suggestions[j].Score {
			return res.Suggestions[i].Score > res.Suggestions[j].Score
		}
		return res.Suggestions[i].TargetPath < res.Suggestions[j].TargetPath
	})
	if len(res.Suggestions) > 30 {
		res.Suggestions = res.Suggestions[:30]
	}
	return res
}

// Compatible indique rapidement si au moins une liaison existe (surlignage pendant le drag).
func (e Engine) Compatible(src, dst Endpoint) bool {
	r := e.Suggest(src, dst)
	return r.Allowed && len(r.Suggestions) > 0
}

func isSchemaKind(k string) bool { return k == model.KindResource || k == model.KindData }

func cardinality(t string) string {
	if schema.IsCollection(t) {
		return "list"
	}
	return "single"
}

// defaultIndexMode propose la forme de référence quand la source utilise count/for_each.
func defaultIndexMode(multi, card string) string {
	switch {
	case multi == "count" && card == "list":
		return "splat"
	case multi == "count":
		return "index"
	case multi == "for_each" && card == "list":
		return "values"
	case multi == "for_each":
		return "key"
	}
	return ""
}

// sourceAttrs liste ce que la source exporte.
func sourceAttrs(src Endpoint) []schema.AttrInfo {
	switch src.Kind {
	case model.KindVariable, model.KindLocal:
		return []schema.AttrInfo{{Name: "", Type: "dynamic", Description: "valeur de " + src.Label}}
	case model.KindModule:
		out := make([]schema.AttrInfo, 0, len(src.ModuleOutputs))
		for _, o := range src.ModuleOutputs {
			out = append(out, schema.AttrInfo{Name: o.Name, Type: "dynamic", Computed: true, Description: o.Description})
		}
		return out
	}
	if src.Block == nil {
		return []schema.AttrInfo{{Name: "id", Type: "string", Computed: true}}
	}
	attrs := src.Block.Attrs()
	// id en tête : c'est l'attribut le plus référencé.
	sort.SliceStable(attrs, func(i, j int) bool { return attrs[i].Name == "id" && attrs[j].Name != "id" })
	return attrs
}

// targetArgs aplatit les arguments configurables de la cible.
func (e Engine) targetArgs(dst Endpoint) []Arg {
	switch dst.Kind {
	case model.KindOutput, model.KindLocal:
		return []Arg{{Path: "value", Type: "dynamic", Required: true}}
	case model.KindModule:
		out := make([]Arg, 0, len(dst.ModuleVars))
		for _, v := range dst.ModuleVars {
			a := Arg{Path: v.Name, Type: v.Type, Required: v.Required, Sensitive: v.Sensitive, Description: v.Description}
			if v.Default != "" {
				a.Default, a.DefaultFrom = json.RawMessage(v.Default), "module"
			}
			out = append(out, a)
		}
		return out
	}
	var defs map[string]json.RawMessage
	if e.Rules != nil {
		defs = e.Rules.Defaults(dst.Type)
	}
	var out []Arg
	flatten(dst.Block, "", "", 0, defs, &out)
	return out
}

func flatten(b *schema.Block, prefix, inBlock string, depth int, defs map[string]json.RawMessage, out *[]Arg) {
	if b == nil || depth > maxDepth {
		return
	}
	for _, a := range b.Attrs() {
		if a.Computed && !a.Optional && !a.Required {
			continue // lecture seule
		}
		if a.Name == "id" && !a.Required && depth == 0 {
			continue
		}
		arg := Arg{Path: prefix + a.Name, Type: a.Type, Required: a.Required, Computed: a.Computed, Sensitive: a.Sensitive, Deprecated: a.Deprecated, Description: a.Description, InBlock: inBlock}
		if depth == 0 {
			if d, ok := defs[a.Name]; ok {
				arg.Default, arg.DefaultFrom = d, "hcldesigner"
			}
		}
		*out = append(*out, arg)
	}
	names := make([]string, 0, len(b.BlockTypes))
	for n := range b.BlockTypes {
		names = append(names, n)
	}
	sort.Strings(names)
	for _, n := range names {
		bt := b.BlockTypes[n]
		flatten(bt.Block, prefix+n+".", prefix+n, depth+1, nil, out)
	}
}

// typeSuffix : aws_security_group -> security_group ; google_compute_network -> compute_network.
func typeSuffix(t string) string {
	if i := strings.Index(t, "_"); i > 0 {
		return t[i+1:]
	}
	return t
}

func lastToken(t string) string {
	parts := strings.Split(t, "_")
	return parts[len(parts)-1]
}

// infer applique l'inférence par nom et type.
func infer(src Endpoint, srcAttrs []schema.AttrInfo, args []Arg) []Suggestion {
	var out []Suggestion
	attrType := map[string]string{}
	for _, a := range srcAttrs {
		attrType[a.Name] = a.Type
	}
	switch src.Kind {
	case model.KindVariable, model.KindLocal:
		for _, a := range args {
			score := 15
			name := lastSegment(a.Path)
			switch {
			case name == src.Label:
				score = 90
			case strings.Contains(name, src.Label) || strings.Contains(src.Label, name):
				score = 60
			case a.Required:
				score = 20
			case a.Type == "string":
				score = 18 // une variable alimente le plus souvent un argument scalaire
			}
			out = append(out, Suggestion{SourceAttr: "", TargetPath: a.Path, TargetType: a.Type, Cardinality: cardinality(a.Type), Score: score, Origin: "inference", Reason: "valeur de " + src.Kind + "." + src.Label})
		}
		return out
	case model.KindModule:
		for _, o := range srcAttrs {
			for _, a := range args {
				name := lastSegment(a.Path)
				score := 0
				switch {
				case name == o.Name:
					score = 85
				case strings.Contains(name, o.Name) || strings.Contains(o.Name, name):
					score = 55
				case a.Path == "value":
					score = 40
				}
				if score > 0 {
					out = append(out, Suggestion{SourceAttr: o.Name, TargetPath: a.Path, TargetType: a.Type, Cardinality: cardinality(a.Type), Score: score, Origin: "inference", Reason: "output de module " + o.Name})
				}
			}
		}
		return out
	}

	suffix := typeSuffix(src.Type)
	last := lastToken(src.Type)
	try := func(a Arg, attr string, score int, reason string) {
		t, ok := attrType[attr]
		if !ok {
			return
		}
		if !schema.Compatible(t, a.Type) {
			return
		}
		out = append(out, Suggestion{SourceAttr: attr, TargetPath: a.Path, TargetType: a.Type, Cardinality: cardinality(a.Type), Score: score, Origin: "inference", Reason: reason})
	}
	for _, a := range args {
		name := lastSegment(a.Path)
		if a.Path == "value" { // output / local : on propose les attributs principaux
			for _, attr := range []string{"id", "arn", "name"} {
				try(a, attr, map[string]int{"id": 60, "arn": 50, "name": 45}[attr], "attribut principal")
			}
			continue
		}
		switch {
		case name == suffix+"_id" || name == suffix+"_ids" || name == suffix+"s" || strings.HasSuffix(name, "_"+suffix+"_ids") || strings.HasSuffix(name, "_"+suffix+"_id"):
			try(a, "id", 80, "nom d'argument dérivé du type source")
		case strings.HasSuffix(name, "_arn") && strings.Contains(name, suffix):
			try(a, "arn", 70, "ARN de "+src.Type)
		case (strings.HasSuffix(name, "_name") || strings.HasSuffix(name, "_names")) && strings.Contains(name, suffix):
			try(a, "name", 65, "nom de "+src.Type)
		case name == last || name == suffix:
			try(a, "id", 50, "argument portant le nom du type source")
			try(a, "self_link", 45, "self_link de "+src.Type)
			try(a, "name", 40, "nom de "+src.Type)
		case strings.HasSuffix(name, "_"+last+"_id") || strings.HasSuffix(name, "_"+last+"_ids"):
			try(a, "id", 35, "suffixe "+last)
		}
	}
	return out
}

func lastSegment(path string) string {
	if i := strings.LastIndex(path, "."); i >= 0 {
		return path[i+1:]
	}
	return path
}
