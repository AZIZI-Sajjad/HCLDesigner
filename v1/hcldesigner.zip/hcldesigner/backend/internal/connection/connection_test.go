package connection

import (
	"encoding/json"
	"os"
	"testing"

	"github.com/AZIZI-Sajjad/hcldesigner/internal/model"
	"github.com/AZIZI-Sajjad/hcldesigner/internal/schema"
	"github.com/AZIZI-Sajjad/hcldesigner/rules"
)

func loadAWS(t *testing.T) *schema.ProviderSchema {
	t.Helper()
	raw, err := os.ReadFile("../hclgen/testdata/aws_schema.json")
	if err != nil {
		t.Fatal(err)
	}
	var ps schema.ProviderSchema
	if err := json.Unmarshal(raw, &ps); err != nil {
		t.Fatal(err)
	}
	return &ps
}

func res(ps *schema.ProviderSchema, typ string) Endpoint {
	return Endpoint{Kind: model.KindResource, Type: typ, Label: "x", Block: ps.ResourceSchemas[typ].Block}
}

// Matrice source/cible -> meilleure liaison attendue.
func TestSuggestMatrix(t *testing.T) {
	ps := loadAWS(t)
	e := Engine{Rules: rules.MustLoad()}
	cases := []struct {
		src, dst, attr, arg, origin string
	}{
		{"aws_vpc", "aws_subnet", "id", "vpc_id", "rule"},
		{"aws_subnet", "aws_instance", "id", "subnet_id", "rule"},
		{"aws_security_group", "aws_instance", "id", "vpc_security_group_ids", "rule"},
		{"aws_vpc", "aws_security_group", "id", "vpc_id", "rule"},
	}
	for _, c := range cases {
		r := e.Suggest(res(ps, c.src), res(ps, c.dst))
		if len(r.Suggestions) == 0 {
			t.Fatalf("%s -> %s : aucune suggestion", c.src, c.dst)
		}
		top := r.Suggestions[0]
		if top.SourceAttr != c.attr || top.TargetPath != c.arg || top.Origin != c.origin {
			t.Errorf("%s -> %s : obtenu %+v", c.src, c.dst, top)
		}
	}
}

func TestInferenceWithoutRule(t *testing.T) {
	ps := loadAWS(t)
	// Sans règles, l'inférence doit trouver vpc_id depuis aws_vpc.id
	r := Engine{}.Suggest(res(ps, "aws_vpc"), res(ps, "aws_subnet"))
	if len(r.Suggestions) == 0 || r.Suggestions[0].TargetPath != "vpc_id" || r.Suggestions[0].Origin != "inference" {
		t.Fatalf("inférence attendue sur vpc_id : %+v", r.Suggestions)
	}
	// security_group -> instance : vpc_security_group_ids (set(string)) par suffixe
	r = Engine{}.Suggest(res(ps, "aws_security_group"), res(ps, "aws_instance"))
	if len(r.Suggestions) == 0 || r.Suggestions[0].TargetPath != "vpc_security_group_ids" || r.Suggestions[0].Cardinality != "list" {
		t.Fatalf("inférence attendue sur vpc_security_group_ids : %+v", r.Suggestions)
	}
}

func TestTargetArgsExposeRequiredAndDefaults(t *testing.T) {
	ps := loadAWS(t)
	r := Engine{Rules: rules.MustLoad()}.Suggest(res(ps, "aws_vpc"), res(ps, "aws_subnet"))
	var vpcID, mapIP *Arg
	for i := range r.TargetArgs {
		switch r.TargetArgs[i].Path {
		case "vpc_id":
			vpcID = &r.TargetArgs[i]
		case "map_public_ip_on_launch":
			mapIP = &r.TargetArgs[i]
		}
	}
	if vpcID == nil || !vpcID.Required {
		t.Error("vpc_id doit être exposé comme obligatoire")
	}
	if mapIP == nil || string(mapIP.Default) != "false" || mapIP.DefaultFrom != "hcldesigner" {
		t.Errorf("défaut de map_public_ip_on_launch attendu : %+v", mapIP)
	}
	for _, a := range r.TargetArgs {
		if a.Path == "id" {
			t.Error("id ne doit pas être proposé comme argument")
		}
	}
}

func TestCountSourceProposesIndex(t *testing.T) {
	ps := loadAWS(t)
	src := res(ps, "aws_subnet")
	src.Multi = "count"
	r := Engine{Rules: rules.MustLoad()}.Suggest(src, res(ps, "aws_instance"))
	if r.Suggestions[0].IndexMode != "index" {
		t.Errorf("indexMode index attendu : %+v", r.Suggestions[0])
	}
}

func TestVariableTargetRefused(t *testing.T) {
	ps := loadAWS(t)
	r := Engine{}.Suggest(res(ps, "aws_vpc"), Endpoint{Kind: model.KindVariable, Label: "v"})
	if r.Allowed {
		t.Error("une variable ne doit pas recevoir de liaison")
	}
}

func TestVariableSource(t *testing.T) {
	ps := loadAWS(t)
	r := Engine{}.Suggest(Endpoint{Kind: model.KindVariable, Label: "instance_type"}, res(ps, "aws_instance"))
	if r.Suggestions[0].TargetPath != "instance_type" || r.Suggestions[0].Score != 90 {
		t.Errorf("instance_type attendu en tête : %+v", r.Suggestions[0])
	}
}
