// Package policy évalue les règles de conformité sur le modèle (contrôle statique,
// coloration du canvas) et sur le plan JSON (contrôle avant apply).
package policy

import (
	"encoding/json"
	"fmt"
	"path"
	"regexp"
	"sort"
	"strings"

	"github.com/AZIZI-Sajjad/hcldesigner/internal/model"
)

// Kinds de règles disponibles sans code.
const (
	KindRequiredTags   = "required_tags"
	KindAllowedValues  = "allowed_values"
	KindAttributeEq    = "attribute_equals"
	KindNamingRegex    = "naming_regex"
	KindOpenIngress    = "forbid_open_ingress"
	KindAllowedRegions = "allowed_regions"
	KindProviderMinVer = "provider_min_version"
)

// Severity : info, warning, blocking. Une violation blocking empêche l'apply.
const (
	SevInfo     = "info"
	SevWarning  = "warning"
	SevBlocking = "blocking"
)

type Policy struct {
	ID       string          `json:"id"`
	Name     string          `json:"name"`
	Kind     string          `json:"kind"`
	Severity string          `json:"severity"`
	Enabled  bool            `json:"enabled"`
	Params   json.RawMessage `json:"params"`
}

type params struct {
	Types     string   `json:"types"`     // glob sur le type, vide = tous
	Tags      []string `json:"tags"`      // required_tags
	Attribute string   `json:"attribute"` // chemin pointé
	Values    []any    `json:"values"`    // allowed_values
	Value     any      `json:"value"`     // attribute_equals
	Regex     string   `json:"regex"`     // naming_regex
	Ports     []int    `json:"ports"`     // forbid_open_ingress (vide = tous)
	Regions   []string `json:"regions"`   // allowed_regions
	Source    string   `json:"source"`    // provider_min_version
	Min       string   `json:"min"`
}

// Instance est une ressource évaluable (depuis le modèle ou depuis le plan).
type Instance struct {
	NodeID  string
	Address string
	Type    string
	Label   string
	Values  map[string]any
	Unknown map[string]bool // attributs non connus (références, valeurs calculées)
}

type Violation struct {
	PolicyID string `json:"policyId"`
	Policy   string `json:"policy"`
	Severity string `json:"severity"`
	NodeID   string `json:"nodeId,omitempty"`
	Address  string `json:"address"`
	Path     string `json:"path,omitempty"`
	Message  string `json:"message"`
}

type Report struct {
	Violations []Violation `json:"violations"`
	Blocking   bool        `json:"blocking"`
	Checked    int         `json:"checked"`
}

// Evaluate applique les règles actives aux instances (et aux providers pour les règles de version/région).
func Evaluate(policies []Policy, instances []Instance, providers []model.ProviderConfig) Report {
	rep := Report{Checked: len(instances)}
	for _, pol := range policies {
		if !pol.Enabled {
			continue
		}
		var prm params
		_ = json.Unmarshal(pol.Params, &prm)
		viol := func(inst *Instance, p, msg string) {
			v := Violation{PolicyID: pol.ID, Policy: pol.Name, Severity: pol.Severity, Path: p, Message: msg}
			if inst != nil {
				v.NodeID, v.Address = inst.NodeID, inst.Address
			}
			rep.Violations = append(rep.Violations, v)
			if pol.Severity == SevBlocking {
				rep.Blocking = true
			}
		}
		switch pol.Kind {
		case KindProviderMinVer:
			for _, pc := range providers {
				if !strings.EqualFold(pc.Source, prm.Source) || pc.Resolved == "" {
					continue
				}
				if compareVersions(pc.Resolved, prm.Min) < 0 {
					viol(nil, "", fmt.Sprintf("provider %s %s < version minimale %s", pc.Source, pc.Resolved, prm.Min))
				}
			}
			continue
		case KindAllowedRegions:
			for _, pc := range providers {
				if v, ok := pc.Config["region"]; ok && v.Mode == model.ModeLiteral {
					var r string
					if json.Unmarshal(v.Value, &r) == nil && !contains(prm.Regions, r) {
						viol(nil, "provider."+pc.Key()+".region", fmt.Sprintf("région %q non autorisée pour le provider %s", r, pc.Key()))
					}
				}
			}
		}
		for i := range instances {
			inst := &instances[i]
			if prm.Types != "" && !globMatch(prm.Types, inst.Type) {
				continue
			}
			switch pol.Kind {
			case KindRequiredTags:
				if inst.Unknown["tags"] {
					continue
				}
				tags, _ := inst.Values["tags"].(map[string]any)
				if _, has := inst.Values["tags"]; !has && !hasTagsAttr(inst) {
					continue
				}
				var missing []string
				for _, t := range prm.Tags {
					if _, ok := tags[t]; !ok {
						missing = append(missing, t)
					}
				}
				if len(missing) > 0 {
					viol(inst, "tags", "tags obligatoires manquants : "+strings.Join(missing, ", "))
				}
			case KindAllowedValues:
				for _, v := range lookup(inst.Values, prm.Attribute) {
					if !containsAny(prm.Values, v) {
						viol(inst, prm.Attribute, fmt.Sprintf("valeur %v non autorisée pour %s", v, prm.Attribute))
					}
				}
			case KindAttributeEq:
				if inst.Unknown[rootOf(prm.Attribute)] {
					continue
				}
				vals := lookup(inst.Values, prm.Attribute)
				if len(vals) == 0 {
					viol(inst, prm.Attribute, fmt.Sprintf("%s doit valoir %v (non défini)", prm.Attribute, prm.Value))
				}
				for _, v := range vals {
					if !equal(v, prm.Value) {
						viol(inst, prm.Attribute, fmt.Sprintf("%s doit valoir %v (actuel : %v)", prm.Attribute, prm.Value, v))
					}
				}
			case KindNamingRegex:
				re, err := regexp.Compile(prm.Regex)
				if err != nil {
					viol(inst, "", "regex invalide dans la règle : "+err.Error())
					continue
				}
				if !re.MatchString(inst.Label) {
					viol(inst, "", fmt.Sprintf("le nom %q ne respecte pas %s", inst.Label, prm.Regex))
				}
			case KindOpenIngress:
				for _, msg := range openIngress(inst, prm.Ports) {
					viol(inst, "ingress", msg)
				}
			case KindAllowedRegions:
				for _, attr := range []string{"region", "location"} {
					if r, ok := inst.Values[attr].(string); ok && !contains(prm.Regions, r) {
						viol(inst, attr, fmt.Sprintf("%s %q non autorisée", attr, r))
					}
				}
			}
		}
	}
	sort.SliceStable(rep.Violations, func(i, j int) bool { return rep.Violations[i].Address < rep.Violations[j].Address })
	return rep
}

func hasTagsAttr(inst *Instance) bool {
	// Les ressources AWS/Azure/GCP taggables : on ne contrôle que celles dont le nom laisse supposer des tags.
	p := strings.SplitN(inst.Type, "_", 2)[0]
	return p == "aws" || p == "azurerm"
}

func rootOf(p string) string { return strings.SplitN(p, ".", 2)[0] }

// openIngress détecte les ouvertures 0.0.0.0/0 sur les principaux providers.
func openIngress(inst *Instance, ports []int) []string {
	var out []string
	open := func(cidr any) bool {
		s, _ := cidr.(string)
		return s == "0.0.0.0/0" || s == "::/0" || s == "*" || s == "Internet"
	}
	portMatch := func(from, to any) bool {
		if len(ports) == 0 {
			return true
		}
		f, fok := toInt(from)
		t, tok := toInt(to)
		if !fok || !tok {
			return true
		}
		for _, p := range ports {
			if p >= f && p <= t {
				return true
			}
		}
		return false
	}
	switch inst.Type {
	case "aws_security_group":
		for _, ing := range asList(inst.Values["ingress"]) {
			m, _ := ing.(map[string]any)
			for _, c := range asList(m["cidr_blocks"]) {
				if open(c) && portMatch(m["from_port"], m["to_port"]) {
					out = append(out, fmt.Sprintf("ingress ouvert à %v sur %v-%v", c, m["from_port"], m["to_port"]))
				}
			}
		}
	case "aws_vpc_security_group_ingress_rule":
		if open(inst.Values["cidr_ipv4"]) && portMatch(inst.Values["from_port"], inst.Values["to_port"]) {
			out = append(out, "règle d'entrée ouverte à 0.0.0.0/0")
		}
	case "aws_security_group_rule":
		if inst.Values["type"] == "ingress" {
			for _, c := range asList(inst.Values["cidr_blocks"]) {
				if open(c) && portMatch(inst.Values["from_port"], inst.Values["to_port"]) {
					out = append(out, "règle d'entrée ouverte à 0.0.0.0/0")
				}
			}
		}
	case "azurerm_network_security_rule":
		if inst.Values["direction"] == "Inbound" && inst.Values["access"] == "Allow" && open(inst.Values["source_address_prefix"]) {
			out = append(out, "règle NSG entrante ouverte à Internet")
		}
	case "google_compute_firewall":
		for _, c := range asList(inst.Values["source_ranges"]) {
			if open(c) {
				out = append(out, "pare-feu ouvert à 0.0.0.0/0")
			}
		}
	}
	return out
}

// lookup renvoie les valeurs trouvées au chemin pointé (les listes sont parcourues).
func lookup(v any, p string) []any {
	if p == "" {
		return []any{v}
	}
	head, rest, _ := strings.Cut(p, ".")
	switch t := v.(type) {
	case map[string]any:
		child, ok := t[head]
		if !ok || child == nil {
			return nil
		}
		return lookup(child, rest)
	case []any:
		var out []any
		for _, e := range t {
			out = append(out, lookup(e, p)...)
		}
		return out
	}
	return nil
}

func asList(v any) []any {
	switch t := v.(type) {
	case []any:
		return t
	case nil:
		return nil
	}
	return []any{v}
}

func toInt(v any) (int, bool) {
	switch t := v.(type) {
	case float64:
		return int(t), true
	case int:
		return t, true
	case json.Number:
		i, err := t.Int64()
		return int(i), err == nil
	}
	return 0, false
}

func equal(a, b any) bool {
	return fmt.Sprint(a) == fmt.Sprint(b)
}

func contains(list []string, s string) bool {
	for _, x := range list {
		if x == s {
			return true
		}
	}
	return false
}

func containsAny(list []any, v any) bool {
	for _, x := range list {
		if equal(x, v) {
			return true
		}
	}
	return false
}

func globMatch(pattern, s string) bool {
	ok, err := path.Match(pattern, s)
	return err == nil && ok
}

// compareVersions compare deux versions semver simples (x.y.z).
func compareVersions(a, b string) int {
	pa, pb := strings.Split(strings.TrimPrefix(a, "v"), "."), strings.Split(strings.TrimPrefix(b, "v"), ".")
	for i := 0; i < 3; i++ {
		var x, y int
		if i < len(pa) {
			fmt.Sscanf(pa[i], "%d", &x)
		}
		if i < len(pb) {
			fmt.Sscanf(pb[i], "%d", &y)
		}
		if x != y {
			if x < y {
				return -1
			}
			return 1
		}
	}
	return 0
}

// HasViolations indique si le rapport contient au moins une violation.
func (r *Report) HasViolations() bool { return r != nil && len(r.Violations) > 0 }
