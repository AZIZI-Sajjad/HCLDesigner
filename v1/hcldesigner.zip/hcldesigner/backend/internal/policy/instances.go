package policy

import (
	"encoding/json"
	"strings"

	"github.com/AZIZI-Sajjad/hcldesigner/internal/model"
)

// FromModel construit les instances à partir du modèle : seules les valeurs littérales sont connues.
func FromModel(p *model.Project) []Instance {
	var out []Instance
	for _, n := range p.Nodes {
		if n.Kind != model.KindResource {
			continue
		}
		inst := Instance{NodeID: n.ID, Address: n.Address(), Type: n.Type, Label: n.Label, Values: map[string]any{}, Unknown: map[string]bool{}}
		fillValues(inst.Values, inst.Unknown, n.Attrs, n.Blocks)
		out = append(out, inst)
	}
	return out
}

func fillValues(values map[string]any, unknown map[string]bool, attrs map[string]model.Value, blocks map[string][]model.Block) {
	for k, v := range attrs {
		switch v.Mode {
		case model.ModeLiteral:
			var x any
			if json.Unmarshal(v.Value, &x) == nil {
				values[k] = x
			}
		case model.ModeNull, "":
		default:
			if unknown != nil {
				unknown[k] = true
			}
		}
	}
	for name, list := range blocks {
		items := make([]any, 0, len(list))
		for _, b := range list {
			m := map[string]any{}
			fillValues(m, nil, b.Attrs, b.Blocks)
			items = append(items, m)
		}
		values[name] = items
	}
}

// planJSON reprend le sous-ensemble utile de `terraform show -json plan`.
type planJSON struct {
	ResourceChanges []struct {
		Address string `json:"address"`
		Mode    string `json:"mode"`
		Type    string `json:"type"`
		Name    string `json:"name"`
		Change  struct {
			Actions      []string        `json:"actions"`
			After        json.RawMessage `json:"after"`
			AfterUnknown json.RawMessage `json:"after_unknown"`
		} `json:"change"`
	} `json:"resource_changes"`
}

// FromPlan construit les instances depuis le plan JSON (valeurs "after"), reliées aux nœuds du modèle.
func FromPlan(planRaw []byte, p *model.Project) ([]Instance, error) {
	var pj planJSON
	if err := json.Unmarshal(planRaw, &pj); err != nil {
		return nil, err
	}
	byAddr := map[string]string{}
	if p != nil {
		for _, n := range p.Nodes {
			if n.Kind == model.KindResource {
				byAddr[n.Type+"."+n.Label] = n.ID
			}
		}
	}
	var out []Instance
	for _, rc := range pj.ResourceChanges {
		if rc.Mode != "managed" || isOnly(rc.Change.Actions, "delete") || isOnly(rc.Change.Actions, "no-op") {
			continue
		}
		inst := Instance{Address: rc.Address, Type: rc.Type, Label: rc.Name, Values: map[string]any{}, Unknown: map[string]bool{}}
		if !strings.HasPrefix(rc.Address, "module.") {
			inst.NodeID = byAddr[rc.Type+"."+rc.Name]
		}
		_ = json.Unmarshal(rc.Change.After, &inst.Values)
		var unk map[string]any
		if json.Unmarshal(rc.Change.AfterUnknown, &unk) == nil {
			for k, v := range unk {
				if b, ok := v.(bool); ok && b {
					inst.Unknown[k] = true
				}
			}
		}
		out = append(out, inst)
	}
	return out, nil
}

func isOnly(actions []string, a string) bool {
	return len(actions) == 1 && actions[0] == a
}
