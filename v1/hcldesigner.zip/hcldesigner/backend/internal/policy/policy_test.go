package policy

import (
	"encoding/json"
	"testing"

	"github.com/AZIZI-Sajjad/hcldesigner/internal/model"
)

func lit(v any) model.Value {
	b, _ := json.Marshal(v)
	return model.Value{Mode: model.ModeLiteral, Value: b}
}

func pol(kind, sev string, prm any) Policy {
	b, _ := json.Marshal(prm)
	return Policy{ID: kind, Name: kind, Kind: kind, Severity: sev, Enabled: true, Params: b}
}

func project() *model.Project {
	p := model.New()
	p.Nodes = []model.Node{
		{ID: "sg", Kind: model.KindResource, Type: "aws_security_group", Label: "web", Attrs: map[string]model.Value{"tags": lit(map[string]string{"owner": "saz"})},
			Blocks: map[string][]model.Block{"ingress": {{Attrs: map[string]model.Value{"from_port": lit(22), "to_port": lit(22), "protocol": lit("tcp"), "cidr_blocks": lit([]string{"0.0.0.0/0"})}}}}},
		{ID: "ec2", Kind: model.KindResource, Type: "aws_instance", Label: "Web", Attrs: map[string]model.Value{"instance_type": lit("m5.4xlarge"), "subnet_id": {Mode: model.ModeExpr, Expr: "var.x"}}},
	}
	return &p
}

func TestModelPolicies(t *testing.T) {
	p := project()
	rep := Evaluate([]Policy{
		pol(KindRequiredTags, SevWarning, map[string]any{"tags": []string{"owner", "env"}}),
		pol(KindOpenIngress, SevBlocking, map[string]any{"ports": []int{22, 3389}}),
		pol(KindAllowedValues, SevBlocking, map[string]any{"types": "aws_instance", "attribute": "instance_type", "values": []string{"t3.micro", "t3.small"}}),
		pol(KindNamingRegex, SevInfo, map[string]any{"regex": "^[a-z0-9_]+$"}),
	}, FromModel(p), nil)
	if !rep.Blocking {
		t.Error("le rapport doit être bloquant")
	}
	count := map[string]int{}
	for _, v := range rep.Violations {
		count[v.PolicyID]++
	}
	if count[KindRequiredTags] != 2 || count[KindOpenIngress] != 1 || count[KindAllowedValues] != 1 || count[KindNamingRegex] != 1 {
		t.Errorf("violations inattendues : %+v", rep.Violations)
	}
}

func TestPlanPolicies(t *testing.T) {
	plan := `{"resource_changes":[{"address":"aws_s3_bucket.a","mode":"managed","type":"aws_s3_bucket","name":"a","change":{"actions":["create"],"after":{"bucket":"a","tags":{"env":"dev"}},"after_unknown":{"id":true}}},
	{"address":"aws_s3_bucket.old","mode":"managed","type":"aws_s3_bucket","name":"old","change":{"actions":["delete"],"after":null}}]}`
	inst, err := FromPlan([]byte(plan), project())
	if err != nil || len(inst) != 1 {
		t.Fatalf("instances : %v %v", inst, err)
	}
	rep := Evaluate([]Policy{pol(KindRequiredTags, SevBlocking, map[string]any{"tags": []string{"owner"}})}, inst, nil)
	if !rep.Blocking || len(rep.Violations) != 1 {
		t.Errorf("violation attendue : %+v", rep)
	}
}
