package runner

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"strconv"
	"time"

	"github.com/AZIZI-Sajjad/hcldesigner/internal/core"
	"github.com/AZIZI-Sajjad/hcldesigner/internal/hclgen"
	"github.com/AZIZI-Sajjad/hcldesigner/internal/model"
	"github.com/AZIZI-Sajjad/hcldesigner/internal/notify"
	"github.com/AZIZI-Sajjad/hcldesigner/internal/settings"
	"github.com/AZIZI-Sajjad/hcldesigner/internal/tfbin"
)

// outcome est le résultat d'une exécution, écrit en base à la fin.
type outcome struct {
	status      string
	exitCode    int
	errMsg      string
	summary     any
	diagnostics any
	policy      any
	serial      *int64
	lineage     string
	planExpires *time.Time
}

// execute traite un run de bout en bout. Toute erreur aboutit à un statut "failed" explicite.
func (w *Worker) execute(ctx context.Context, runID string) {
	c := w.core
	run, err := c.GetRun(ctx, runID)
	if err != nil {
		logErr(runID, err)
		return
	}
	rs := c.Settings.Runs(ctx)
	timeout := time.Duration(rs.TimeoutMinutes) * time.Minute
	if timeout <= 0 {
		timeout = c.Cfg.RunTimeout
	}
	rctx, cancel := context.WithTimeout(ctx, timeout)
	defer cancel()

	logPath := filepath.Join(c.Cfg.DataDir, "logs", runID+".log")
	lf, err := os.OpenFile(logPath, os.O_CREATE|os.O_WRONLY|os.O_APPEND, 0o600)
	if err != nil {
		w.finish(ctx, run, outcome{status: core.StatusFailed, exitCode: -1, errMsg: err.Error()})
		return
	}
	defer lf.Close()

	out, err := w.prepareAndRun(rctx, run, lf, rs)
	if err != nil {
		if err == ErrCanceled {
			out = outcome{status: core.StatusCanceled, exitCode: -1, errMsg: "annulé"}
		} else {
			fmt.Fprintf(lf, "\n\x1b[31m[hcldesigner] échec : %s\x1b[0m\n", err)
			out = outcome{status: core.StatusFailed, exitCode: -1, errMsg: err.Error()}
		}
	}
	w.finish(ctx, run, out)
}

func (w *Worker) prepareAndRun(ctx context.Context, run *core.Run, lf *os.File, rs settings.Runs) (outcome, error) {
	c := w.core
	proj, err := c.GetProject(ctx, run.ProjectID)
	if err != nil {
		return outcome{}, err
	}
	env, err := c.GetEnvironment(ctx, run.EnvironmentID)
	if err != nil {
		return outcome{}, err
	}
	env = run.Options.Backend.ApplyTo(env) // backend tel qu'il était à la création du run
	snap, err := c.RunSnapshot(ctx, run.ID)
	if err != nil {
		return outcome{}, err
	}
	dir := filepath.Join(c.Cfg.DataDir, "work", run.ID)
	if err := os.MkdirAll(dir, 0o700); err != nil {
		return outcome{}, err
	}
	defer os.RemoveAll(dir)

	// Binaire et configuration CLI
	bin, err := c.TF.Resolve(ctx, proj.Model.Engine, proj.Model.EngineVersion)
	if err != nil {
		return outcome{}, err
	}
	var mirror tfbin.MirrorConfig
	_ = c.Settings.Get(ctx, settings.KeyMirror, &mirror)
	cli, err := c.TF.CLIConfig(dir, mirror)
	if err != nil {
		return outcome{}, err
	}
	credEnv, secrets, err := c.CredentialEnv(ctx, env.CredentialIDs, dir)
	if err != nil {
		return outcome{}, err
	}
	envv := append(tfbin.BaseEnv(cli), credEnv...)
	if env.Workspace != "" {
		envv = append(envv, "TF_WORKSPACE="+env.Workspace)
	}

	// Fichiers du workspace
	if err := writeFiles(dir, snap.Files); err != nil {
		return outcome{}, err
	}
	if proj.LockFile != "" {
		if err := os.WriteFile(filepath.Join(dir, ".terraform.lock.hcl"), []byte(proj.LockFile), 0o600); err != nil {
			return outcome{}, err
		}
	}
	if env.TFVars != "" {
		if err := os.WriteFile(filepath.Join(dir, "terraform.tfvars"), []byte(env.TFVars), 0o600); err != nil {
			return outcome{}, err
		}
	}
	initArgs := []string{"init", "-input=false", "-no-color"}
	be, err := c.BackendFor(ctx, env, true)
	if err != nil {
		return outcome{}, err
	}
	internal := be == nil
	if !internal {
		content, err := hclgen.BackendConfigFile(be)
		if err != nil {
			return outcome{}, err
		}
		if err := os.WriteFile(filepath.Join(dir, "backend.hcl"), []byte(content), 0o600); err != nil {
			return outcome{}, err
		}
		initArgs = append(initArgs, "-backend-config=backend.hcl")
		for _, v := range be.Config {
			var s string
			if json.Unmarshal(v, &s) == nil {
				secrets = append(secrets, s)
			}
		}
	} else if st, err := c.LatestState(ctx, env.ID); err != nil {
		return outcome{}, err
	} else if st != nil {
		if err := os.WriteFile(filepath.Join(dir, "terraform.tfstate"), st, 0o600); err != nil {
			return outcome{}, err
		}
	}
	if run.Options.Upgrade {
		initArgs = append(initArgs, "-upgrade")
	}
	if run.Options.Reconfigure {
		initArgs = append(initArgs, "-reconfigure")
	}
	if run.Options.MigrateState {
		initArgs = append(initArgs, "-migrate-state", "-force-copy")
	}

	j := &job{runID: run.ID, dir: dir, bin: bin, env: envv, log: newMaskWriter(lf, secrets), logFile: lf,
		cancel: func() bool {
			var cr bool
			_ = c.DB.QueryRow(context.Background(), `SELECT cancel_requested FROM runs WHERE id=$1`, run.ID).Scan(&cr)
			return cr
		}}
	j.logf("run %s — %s sur %s/%s (%s)", run.ID, opLabel(run), run.ProjectName, run.EnvironmentName, filepath.Base(bin))

	if run.Operation == core.OpValidate {
		initArgs = []string{"init", "-input=false", "-no-color", "-backend=false"}
	}
	if code, err := j.run(ctx, nil, initArgs...); err != nil {
		return outcome{}, err
	} else if code != 0 {
		return outcome{status: core.StatusFailed, exitCode: code, errMsg: "terraform init en échec"}, nil
	}
	w.syncLockFile(ctx, proj, dir)

	stateFile := filepath.Join(dir, "terraform.tfstate")
	var out outcome
	switch run.Operation {
	case core.OpInit:
		out = outcome{status: core.StatusSucceeded}
	case core.OpValidate:
		out, err = w.doValidate(ctx, j, snap)
	case core.OpPlan:
		out, err = w.doPlan(ctx, j, run, proj, env, rs)
	case core.OpApply:
		out, err = w.doApply(ctx, j, run, rs)
	case core.OpState:
		out, err = w.doState(ctx, j, run)
	default:
		err = fmt.Errorf("opération inconnue %s", run.Operation)
	}
	if err != nil {
		return outcome{}, err
	}
	// State : historisation après toute opération qui peut le modifier.
	if run.Operation == core.OpApply || (run.Operation == core.OpState && mutatingState(run.Options.StateCmd)) {
		w.archiveState(ctx, j, env.ID, run.ID, internal, stateFile, opLabel(run))
	}
	return out, nil
}

func mutatingState(cmd string) bool {
	return cmd == "mv" || cmd == "rm" || cmd == "import" || cmd == "push"
}

func opLabel(r *core.Run) string {
	switch {
	case r.Operation == core.OpPlan && r.Destroy:
		return "plan -destroy"
	case r.Operation == core.OpApply && r.Destroy:
		return "destroy (apply du plan)"
	case r.Operation == core.OpState:
		return "state " + r.Options.StateCmd
	}
	return r.Operation
}

// syncLockFile recopie le .terraform.lock.hcl produit par init dans le projet s'il a changé.
func (w *Worker) syncLockFile(ctx context.Context, proj *core.Project, dir string) {
	b, err := os.ReadFile(filepath.Join(dir, ".terraform.lock.hcl"))
	if err != nil || string(b) == proj.LockFile {
		return
	}
	_, err = w.core.DB.Exec(ctx, `UPDATE projects SET lock_file=$2 WHERE id=$1`, proj.ID, string(b))
	logErr(proj.ID, err)
}

// statePull lit le state courant (tout backend) ; renvoie serial et lineage.
func (w *Worker) statePull(ctx context.Context, j *job) ([]byte, *core.StateMeta, error) {
	var buf bytes.Buffer
	code, err := j.run(ctx, &buf, "state", "pull")
	if err != nil {
		return nil, nil, err
	}
	if code != 0 {
		return nil, nil, fmt.Errorf("terraform state pull en échec (code %d)", code)
	}
	meta, err := core.ParseStateMeta(bytes.TrimSpace(buf.Bytes()))
	return buf.Bytes(), meta, err
}

// archiveState historise le state après modification (copie chiffrée, versionnée).
func (w *Worker) archiveState(ctx context.Context, j *job, envID, runID string, internal bool, stateFile, reason string) {
	var raw []byte
	var err error
	if internal {
		raw, err = os.ReadFile(stateFile)
	} else {
		raw, _, err = w.statePull(ctx, j)
	}
	if err != nil || len(bytes.TrimSpace(raw)) == 0 {
		j.logf("aucun state à archiver")
		return
	}
	sv, err := w.core.SaveStateVersion(ctx, envID, runID, reason, raw)
	if err != nil {
		j.logf("archivage du state impossible : %v", err)
		return
	}
	j.logf("state archivé (serial %d, %d ressources)", sv.Serial, sv.Resources)
}

// finish enregistre le résultat, déclenche notifications et suites (apply automatique).
func (w *Worker) finish(ctx context.Context, run *core.Run, out outcome) {
	c := w.core
	toJSON := func(v any, def string) []byte {
		if v == nil {
			return []byte(def)
		}
		b, err := json.Marshal(v)
		if err != nil {
			return []byte(def)
		}
		return b
	}
	_, err := c.DB.Exec(ctx, `UPDATE runs SET status=$2, exit_code=$3, error=$4, summary=$5, diagnostics=$6, policy_report=$7,
		state_serial=COALESCE($8, state_serial), state_lineage=CASE WHEN $9='' THEN state_lineage ELSE $9 END, plan_expires_at=$10, finished_at=now() WHERE id=$1`,
		run.ID, out.status, out.exitCode, out.errMsg, toJSON(out.summary, "{}"), toJSON(out.diagnostics, "[]"), toJSON(out.policy, "{}"),
		out.serial, out.lineage, out.planExpires)
	logErr(run.ID, err)
	if run.Operation == core.OpApply && run.PlanRunID != nil {
		st := core.StatusApplied
		if out.status != core.StatusApplied {
			st = core.StatusFailed
		}
		_, _ = c.DB.Exec(ctx, `UPDATE runs SET status=$2 WHERE id=$1`, *run.PlanRunID, st)
	}
	// Un nouveau plan rend obsolètes les plans précédents non appliqués du même environnement.
	if run.Operation == core.OpPlan && out.status == core.StatusPlanned {
		_, _ = c.DB.Exec(ctx, `UPDATE runs SET status='discarded' WHERE environment_id=$1 AND operation='plan' AND status='planned' AND id<>$2`, run.EnvironmentID, run.ID)
	}
	if run.TaskID != nil {
		w.finishTaskExecution(ctx, run, out)
	}
	w.notify(ctx, run, out)
	if run.Operation == core.OpPlan && out.status == core.StatusPlanned && run.Options.AutoApply && run.ApprovalsRequired == 0 {
		fresh, err := c.GetRun(ctx, run.ID)
		if err == nil {
			_, err = c.CreateRun(ctx, core.RunRequest{ProjectID: run.ProjectID, EnvironmentID: run.EnvironmentID, Operation: core.OpApply,
				PlanRunID: fresh.ID, TriggeredBy: fresh.TriggeredBy, TaskID: deref(fresh.TaskID)})
		}
		logErr(run.ID, err)
	}
}

func deref(s *string) string {
	if s == nil {
		return ""
	}
	return *s
}

func (w *Worker) finishTaskExecution(ctx context.Context, run *core.Run, out outcome) {
	status := "succeeded"
	if out.status == core.StatusFailed || out.status == core.StatusCanceled {
		status = "failed"
	}
	msg := out.errMsg
	if msg == "" {
		msg = "run " + out.status
	}
	_, _ = w.core.DB.Exec(ctx, `UPDATE task_executions SET status=$2, message=$3, finished_at=now() WHERE run_id=$1 AND finished_at IS NULL`, run.ID, status, msg)
	_, _ = w.core.DB.Exec(ctx, `UPDATE scheduled_tasks SET last_status=$2 WHERE id=$1`, *run.TaskID, status)
	if status == "failed" {
		w.core.Notifier.Emit(ctx, notify.Event{Type: notify.EvTaskFailed, ProjectID: run.ProjectID, Project: run.ProjectName, Environment: run.EnvironmentName,
			Summary: "Tâche planifiée en échec : " + msg, Link: "/runs/" + run.ID})
	}
}

func (w *Worker) notify(ctx context.Context, run *core.Run, out outcome) {
	ev := notify.Event{ProjectID: run.ProjectID, Project: run.ProjectName, Environment: run.EnvironmentName, Actor: run.CreatedByName, Link: "/runs/" + run.ID}
	summary := summaryText(out.summary)
	if rep, ok := out.policy.(interface{ HasViolations() bool }); ok && rep.HasViolations() {
		w.core.Notifier.Emit(ctx, notify.Event{Type: notify.EvCompliance, ProjectID: run.ProjectID, Project: run.ProjectName, Environment: run.EnvironmentName,
			Summary: "Le plan contient des non-conformités.", Link: ev.Link})
	}
	switch {
	case out.status == core.StatusFailed:
		ev.Type, ev.Summary = notify.EvRunFailed, opLabel(run)+" en échec : "+out.errMsg
		if run.Operation == core.OpApply {
			ev.Type = notify.EvApplyFailed
		}
	case run.Operation == core.OpApply && run.Destroy:
		ev.Type, ev.Summary = notify.EvDestroyFinished, "Destroy exécuté.\n"+summary
	case run.Operation == core.OpApply:
		ev.Type, ev.Summary = notify.EvApplySucceeded, "Apply réussi.\n"+summary
	case run.Operation == core.OpPlan && out.status == core.StatusChecked:
		if s, ok := out.summary.(*PlanSummary); ok && len(s.Drift) > 0 {
			ev.Type, ev.Summary = notify.EvDrift, fmt.Sprintf("%d ressource(s) modifiée(s) hors Terraform.\n%s", len(s.Drift), driftText(s))
		} else {
			return
		}
	case run.Operation == core.OpPlan && (out.status == core.StatusPlanned || out.status == core.StatusNoChanges):
		ev.Type, ev.Summary = notify.EvPlanFinished, summary
		w.core.Notifier.Emit(ctx, ev)
		if out.status == core.StatusPlanned && run.ApprovalsRequired > 0 {
			ev.Type = notify.EvApprovalRequest
			ev.Summary = fmt.Sprintf("%d approbation(s) requise(s).\n%s", run.ApprovalsRequired, summary)
		} else {
			return
		}
	default:
		return
	}
	w.core.Notifier.Emit(ctx, ev)
}

func summaryText(v any) string {
	s, ok := v.(*PlanSummary)
	if !ok || s == nil {
		return ""
	}
	return "à créer : " + strconv.Itoa(s.Add) + ", à modifier : " + strconv.Itoa(s.Change) + ", à remplacer : " + strconv.Itoa(s.Replace) + ", à détruire : " + strconv.Itoa(s.Destroy)
}

func driftText(s *PlanSummary) string {
	var b bytes.Buffer
	for _, d := range s.Drift {
		b.WriteString("- " + d.Address + "\n")
	}
	return b.String()
}

// nodeIndex associe une adresse Terraform (sans index) à un id de nœud.
func nodeIndex(m *model.Project) map[string]string {
	idx := map[string]string{}
	for _, n := range m.Nodes {
		switch n.Kind {
		case model.KindResource, model.KindData, model.KindModule:
			idx[n.Address()] = n.ID
		}
	}
	return idx
}
