// Package runner exécute les jobs Terraform (init, validate, plan, apply, state) et la
// résolution des schémas de providers. Chaque exécution a son workspace éphémère.
package runner

import (
	"context"
	"log/slog"
	"os"
	"path/filepath"
	"time"

	"github.com/jackc/pgx/v5/pgxpool"

	"github.com/AZIZI-Sajjad/hcldesigner/internal/core"
	"github.com/AZIZI-Sajjad/hcldesigner/internal/schema"
	"github.com/AZIZI-Sajjad/hcldesigner/internal/settings"
	"github.com/AZIZI-Sajjad/hcldesigner/internal/tfbin"
)

type Worker struct {
	core  *core.Core
	name  string
	slots chan struct{}
}

func New(c *core.Core, concurrency int) *Worker {
	host, _ := os.Hostname()
	return &Worker{core: c, name: host, slots: make(chan struct{}, concurrency)}
}

// Run boucle jusqu'à l'annulation du contexte.
func (w *Worker) Run(ctx context.Context) {
	for _, d := range []string{"work", "logs", "artifacts", "states"} {
		_ = os.MkdirAll(filepath.Join(w.core.Cfg.DataDir, d), 0o700)
	}
	w.recoverOrphans(ctx)
	slog.Info("worker démarré", "name", w.name, "slots", cap(w.slots))
	ticker := time.NewTicker(2 * time.Second)
	defer ticker.Stop()
	for {
		select {
		case <-ctx.Done():
			return
		case <-ticker.C:
		}
		for w.trySchemaJob(ctx) {
		}
		for {
			select {
			case w.slots <- struct{}{}:
			default:
				goto next // tous les slots sont occupés
			}
			id, lock, err := w.claim(ctx)
			if err != nil || id == "" {
				<-w.slots
				if err != nil {
					slog.Error("claim", "err", err)
				}
				break
			}
			go func() {
				defer func() { <-w.slots }()
				defer lock.release()
				w.execute(ctx, id)
			}()
		}
	next:
	}
}

// recoverOrphans marque en échec les runs restés "running" sur ce worker (redémarrage brutal).
func (w *Worker) recoverOrphans(ctx context.Context) {
	_, err := w.core.DB.Exec(ctx, `UPDATE runs SET status='failed', error='worker redémarré pendant l''exécution', finished_at=now()
		WHERE status='running' AND worker=$1`, w.name)
	if err != nil {
		slog.Error("reprise des runs orphelins", "err", err)
	}
}

// claim prend le plus ancien run en file dont l'environnement est libre, et pose un verrou
// consultatif PostgreSQL sur l'environnement pour toute la durée de l'exécution.
func (w *Worker) claim(ctx context.Context) (string, *envLock, error) {
	conn, err := w.core.DB.Acquire(ctx)
	if err != nil {
		return "", nil, err
	}
	rows, err := conn.Query(ctx, `SELECT r.id, r.environment_id FROM runs r WHERE r.status='queued'
		AND NOT EXISTS (SELECT 1 FROM runs x WHERE x.environment_id=r.environment_id AND x.status='running')
		ORDER BY r.created_at LIMIT 10`)
	if err != nil {
		conn.Release()
		return "", nil, err
	}
	type cand struct{ id, env string }
	var cands []cand
	for rows.Next() {
		var c cand
		if rows.Scan(&c.id, &c.env) == nil {
			cands = append(cands, c)
		}
	}
	rows.Close()
	for _, c := range cands {
		var locked bool
		if err := conn.QueryRow(ctx, `SELECT pg_try_advisory_lock(hashtext($1))`, c.env).Scan(&locked); err != nil || !locked {
			continue
		}
		tag, err := conn.Exec(ctx, `UPDATE runs SET status='running', started_at=now(), worker=$2 WHERE id=$1 AND status='queued'`, c.id, w.name)
		if err == nil && tag.RowsAffected() == 1 {
			return c.id, &envLock{conn: conn, env: c.env}, nil
		}
		_, _ = conn.Exec(ctx, `SELECT pg_advisory_unlock(hashtext($1))`, c.env)
	}
	conn.Release()
	return "", nil, nil
}

// envLock libère le verrou consultatif avant de rendre la connexion au pool.
type envLock struct {
	conn *pgxpool.Conn
	env  string
}

func (l *envLock) release() {
	_, _ = l.conn.Exec(context.Background(), `SELECT pg_advisory_unlock(hashtext($1))`, l.env)
	l.conn.Release()
}

// trySchemaJob traite une résolution de provider en attente. Renvoie true si un job a été traité.
func (w *Worker) trySchemaJob(ctx context.Context) bool {
	var id, engine, engineVersion, localName, source, constraint string
	err := w.core.DB.QueryRow(ctx, `UPDATE schema_jobs SET status='running' WHERE id = (
		SELECT id FROM schema_jobs WHERE status='queued' ORDER BY created_at FOR UPDATE SKIP LOCKED LIMIT 1)
		RETURNING id, engine, engine_version, local_name, source, constraint_`).Scan(&id, &engine, &engineVersion, &localName, &source, &constraint)
	if err != nil {
		return false
	}
	fail := func(e error) {
		slog.Error("résolution de provider", "source", source, "err", e)
		_, _ = w.core.DB.Exec(ctx, `UPDATE schema_jobs SET status='failed', error=$2, finished_at=now() WHERE id=$1`, id, e.Error())
	}
	bin, err := w.core.TF.Resolve(ctx, engine, engineVersion)
	if err != nil {
		fail(err)
		return true
	}
	tmp, err := os.MkdirTemp(filepath.Join(w.core.Cfg.DataDir, "work"), "schema-cli-*")
	if err != nil {
		fail(err)
		return true
	}
	defer os.RemoveAll(tmp)
	var mirror tfbin.MirrorConfig
	_ = w.core.Settings.Get(ctx, settings.KeyMirror, &mirror)
	cli, err := w.core.TF.CLIConfig(tmp, mirror)
	if err != nil {
		fail(err)
		return true
	}
	fctx, cancel := context.WithTimeout(ctx, 20*time.Minute)
	defer cancel()
	res, err := schema.Fetch(fctx, bin, tfbin.BaseEnv(cli), tmp, localName, source, constraint)
	if err != nil {
		fail(err)
		return true
	}
	if err := w.core.StoreSchema(ctx, res); err != nil {
		fail(err)
		return true
	}
	_, _ = w.core.DB.Exec(ctx, `UPDATE schema_jobs SET status='succeeded', version=$2, finished_at=now() WHERE id=$1`, id, res.Version)
	slog.Info("provider résolu", "source", res.Source, "version", res.Version)
	return true
}
