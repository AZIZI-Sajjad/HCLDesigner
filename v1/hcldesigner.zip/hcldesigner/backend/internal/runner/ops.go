package runner

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"regexp"
	"strconv"
	"strings"
	"time"

	"github.com/AZIZI-Sajjad/hcldesigner/internal/core"
	"github.com/AZIZI-Sajjad/hcldesigner/internal/model"
	"github.com/AZIZI-Sajjad/hcldesigner/internal/policy"
	"github.com/AZIZI-Sajjad/hcldesigner/internal/settings"
)

// PlanSummary est le résumé stocké dans runs.summary et affiché sur le canvas.
type PlanSummary struct {
	Add     int               `json:"add"`
	Change  int               `json:"change"`
	Destroy int               `json:"destroy"`
	Replace int               `json:"replace"`
	Import  int               `json:"import"`
	Changes []ChangeItem      `json:"changes"`
	Drift   []ChangeItem      `json:"drift"`
	Outputs []string          `json:"outputs"`
	ByNode  map[string]string `json:"byNode"` // nodeId -> action dominante (create|update|replace|delete)
}

type ChangeItem struct {
	Address string   `json:"address"`
	Type    string   `json:"type"`
	Actions []string `json:"actions"`
	NodeID  string   `json:"nodeId,omitempty"`
}

type planShow struct {
	ResourceChanges []struct {
		Address string `json:"address"`
		Mode    string `json:"mode"`
		Type    string `json:"type"`
		Change  struct {
			Actions   []string        `json:"actions"`
			Importing json.RawMessage `json:"importing"`
		} `json:"change"`
	} `json:"resource_changes"`
	ResourceDrift []struct {
		Address string `json:"address"`
		Type    string `json:"type"`
		Change  struct {
			Actions []string `json:"actions"`
		} `json:"change"`
	} `json:"resource_drift"`
	OutputChanges map[string]struct {
		Actions []string `json:"actions"`
	} `json:"output_changes"`
}

var indexRe = regexp.MustCompile(`\[[^\]]*\]`)

// baseAddress retire les index : aws_subnet.public[0] -> aws_subnet.public ; module.x.aws_y.z -> module.x
func baseAddress(addr string) string {
	a := indexRe.ReplaceAllString(addr, "")
	if strings.HasPrefix(a, "module.") {
		parts := strings.SplitN(a, ".", 3)
		return parts[0] + "." + parts[1]
	}
	return a
}

// ParsePlanSummary construit le résumé depuis `terraform show -json`.
func ParsePlanSummary(raw []byte, idx map[string]string) (*PlanSummary, error) {
	var ps planShow
	if err := json.Unmarshal(raw, &ps); err != nil {
		return nil, err
	}
	s := &PlanSummary{Changes: []ChangeItem{}, Drift: []ChangeItem{}, Outputs: []string{}, ByNode: map[string]string{}}
	rank := map[string]int{"read": 0, "update": 1, "create": 2, "replace": 3, "delete": 4}
	for _, rc := range ps.ResourceChanges {
		if rc.Mode == "data" {
			continue
		}
		acts := rc.Change.Actions
		action := ""
		switch {
		case len(acts) == 2:
			s.Replace++
			action = "replace"
		case len(acts) == 1 && acts[0] == "create":
			s.Add++
			action = "create"
		case len(acts) == 1 && acts[0] == "update":
			s.Change++
			action = "update"
		case len(acts) == 1 && acts[0] == "delete":
			s.Destroy++
			action = "delete"
		}
		if len(rc.Change.Importing) > 0 && string(rc.Change.Importing) != "null" {
			s.Import++
		}
		if action == "" {
			continue
		}
		item := ChangeItem{Address: rc.Address, Type: rc.Type, Actions: acts, NodeID: idx[baseAddress(rc.Address)]}
		s.Changes = append(s.Changes, item)
		if item.NodeID != "" && rank[action] >= rank[s.ByNode[item.NodeID]] {
			s.ByNode[item.NodeID] = action
		}
	}
	for _, d := range ps.ResourceDrift {
		s.Drift = append(s.Drift, ChangeItem{Address: d.Address, Type: d.Type, Actions: d.Change.Actions, NodeID: idx[baseAddress(d.Address)]})
	}
	for name, oc := range ps.OutputChanges {
		if len(oc.Actions) > 0 && oc.Actions[0] != "no-op" {
			s.Outputs = append(s.Outputs, name)
		}
	}
	return s, nil
}

func (w *Worker) artifactDir(runID string) string {
	return filepath.Join(w.core.Cfg.DataDir, "artifacts", runID)
}

func (w *Worker) doPlan(ctx context.Context, j *job, run *core.Run, proj *core.Project, env *core.Environment, rs settings.Runs) (outcome, error) {
	_, meta, err := w.statePull(ctx, j)
	if err != nil {
		return outcome{}, err
	}
	args := []string{"plan", "-input=false", "-no-color", "-out=plan.tfplan", "-detailed-exitcode", "-lock-timeout=120s"}
	if run.Destroy {
		args = append(args, "-destroy")
	}
	if run.Options.RefreshOnly {
		args = append(args, "-refresh-only")
	}
	for _, t := range run.Options.Targets {
		args = append(args, "-target="+t)
	}
	for _, r := range run.Options.Replace {
		args = append(args, "-replace="+r)
	}
	args = append(args, parallelism(run.Options.Parallelism, rs))
	code, err := j.run(ctx, nil, args...)
	if err != nil {
		return outcome{}, err
	}
	if code == 1 || code < 0 {
		return outcome{status: core.StatusFailed, exitCode: code, errMsg: "terraform plan en échec"}, nil
	}
	var show bytes.Buffer
	if c, err := j.run(ctx, &show, "show", "-json", "plan.tfplan"); err != nil || c != 0 {
		return outcome{status: core.StatusFailed, exitCode: c, errMsg: "terraform show -json en échec"}, err
	}
	m := w.modelAtVersion(ctx, proj, run.ProjectVersion)
	sum, err := ParsePlanSummary(show.Bytes(), nodeIndex(m))
	if err != nil {
		return outcome{}, err
	}
	rep, err := w.evaluatePolicies(ctx, proj.ID, show.Bytes(), m)
	if err != nil {
		j.logf("évaluation de conformité impossible : %v", err)
	}
	// Artefacts chiffrés : le plan binaire (pour l'apply) et sa version JSON (pour l'affichage).
	adir := w.artifactDir(run.ID)
	if err := os.MkdirAll(adir, 0o700); err != nil {
		return outcome{}, err
	}
	planBin, err := os.ReadFile(filepath.Join(j.dir, "plan.tfplan"))
	if err != nil {
		return outcome{}, err
	}
	if err := w.core.Vault.WriteFile(filepath.Join(adir, "plan.tfplan.enc"), planBin); err != nil {
		return outcome{}, err
	}
	if err := w.core.Vault.WriteFile(filepath.Join(adir, "plan.json.enc"), show.Bytes()); err != nil {
		return outcome{}, err
	}
	j.logf("résumé : %s", summaryText(sum))
	if rep != nil && len(rep.Violations) > 0 {
		j.logf("conformité : %d violation(s)%s", len(rep.Violations), map[bool]string{true: " dont bloquante(s)", false: ""}[rep.Blocking])
	}
	out := outcome{exitCode: code, summary: sum, policy: rep, serial: &meta.Serial, lineage: meta.Lineage}
	switch {
	case run.Options.Drift:
		out.status = core.StatusChecked
	case code == 2:
		out.status = core.StatusPlanned
		ttl := time.Duration(rs.PlanTTLMinutes) * time.Minute
		if ttl <= 0 {
			ttl = 24 * time.Hour
		}
		exp := time.Now().Add(ttl)
		out.planExpires = &exp
	default:
		out.status = core.StatusNoChanges
	}
	return out, nil
}

// modelAtVersion renvoie le modèle tel qu'il était lors de la création du run.
func (w *Worker) modelAtVersion(ctx context.Context, proj *core.Project, version int) *model.Project {
	var raw []byte
	if err := w.core.DB.QueryRow(ctx, `SELECT model FROM project_versions WHERE project_id=$1 AND version=$2`, proj.ID, version).Scan(&raw); err == nil {
		var m model.Project
		if json.Unmarshal(raw, &m) == nil {
			return &m
		}
	}
	return &proj.Model
}

// LoadPolicies renvoie les règles actives applicables à un projet.
func LoadPolicies(ctx context.Context, c *core.Core, projectID string) ([]policy.Policy, error) {
	rows, err := c.DB.Query(ctx, `SELECT id, name, kind, severity, enabled, params FROM policies WHERE enabled AND (project_id IS NULL OR project_id=$1)`, projectID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var out []policy.Policy
	for rows.Next() {
		var p policy.Policy
		if err := rows.Scan(&p.ID, &p.Name, &p.Kind, &p.Severity, &p.Enabled, &p.Params); err != nil {
			return nil, err
		}
		out = append(out, p)
	}
	return out, rows.Err()
}

func (w *Worker) evaluatePolicies(ctx context.Context, projectID string, planJSON []byte, m *model.Project) (*policy.Report, error) {
	pols, err := LoadPolicies(ctx, w.core, projectID)
	if err != nil || len(pols) == 0 {
		return nil, err
	}
	inst, err := policy.FromPlan(planJSON, m)
	if err != nil {
		return nil, err
	}
	rep := policy.Evaluate(pols, inst, m.Providers)
	return &rep, nil
}

func (w *Worker) doApply(ctx context.Context, j *job, run *core.Run, rs settings.Runs) (outcome, error) {
	if run.PlanRunID == nil {
		return outcome{}, fmt.Errorf("apply sans plan")
	}
	plan, err := w.core.GetRun(ctx, *run.PlanRunID)
	if err != nil {
		return outcome{}, err
	}
	bin, err := w.core.Vault.ReadFile(filepath.Join(w.artifactDir(plan.ID), "plan.tfplan.enc"))
	if err != nil {
		return outcome{}, fmt.Errorf("fichier de plan introuvable : %w", err)
	}
	if err := os.WriteFile(filepath.Join(j.dir, "plan.tfplan"), bin, 0o600); err != nil {
		return outcome{}, err
	}
	// Le state ne doit pas avoir changé depuis le plan.
	_, meta, err := w.statePull(ctx, j)
	if err != nil {
		return outcome{}, err
	}
	if plan.StateSerial != nil && (meta.Serial != *plan.StateSerial || meta.Lineage != plan.StateLineage) {
		_, _ = w.core.DB.Exec(ctx, `UPDATE runs SET status='discarded' WHERE id=$1`, plan.ID)
		return outcome{status: core.StatusFailed, exitCode: -1, errMsg: fmt.Sprintf("le state a changé depuis le plan (serial %d → %d) : relancez un plan", *plan.StateSerial, meta.Serial)}, nil
	}
	code, err := j.run(ctx, nil, "apply", "-input=false", "-no-color", "-lock-timeout=120s", parallelism(run.Options.Parallelism, rs), "plan.tfplan")
	if err != nil {
		return outcome{}, err
	}
	var sum PlanSummary
	_ = json.Unmarshal(plan.Summary, &sum)
	if code != 0 {
		return outcome{status: core.StatusFailed, exitCode: code, errMsg: "terraform apply en échec", summary: &sum}, nil
	}
	return outcome{status: core.StatusApplied, exitCode: 0, summary: &sum}, nil
}

func (w *Worker) doValidate(ctx context.Context, j *job, snap *core.Snapshot) (outcome, error) {
	var buf bytes.Buffer
	code, err := j.run(ctx, &buf, "validate", "-json", "-no-color")
	if err != nil {
		return outcome{}, err
	}
	var res struct {
		Valid       bool `json:"valid"`
		Diagnostics []struct {
			Severity string `json:"severity"`
			Summary  string `json:"summary"`
			Detail   string `json:"detail"`
			Range    *struct {
				Filename string `json:"filename"`
				Start    struct {
					Line int `json:"line"`
				} `json:"start"`
			} `json:"range"`
		} `json:"diagnostics"`
	}
	if err := json.Unmarshal(buf.Bytes(), &res); err != nil {
		return outcome{status: core.StatusFailed, exitCode: code, errMsg: "sortie de validate illisible"}, nil
	}
	diags := []model.Diagnostic{}
	for _, d := range res.Diagnostics {
		md := model.Diagnostic{Severity: d.Severity, Summary: d.Summary, Detail: d.Detail}
		if d.Range != nil {
			md.File, md.Line = d.Range.Filename, d.Range.Start.Line
			md.NodeID = nodeAt(snap, md.File, md.Line)
		}
		diags = append(diags, md)
		fmt.Fprintf(j.log, "%s: %s %s:%d %s\n", strings.ToUpper(d.Severity), d.Summary, md.File, md.Line, d.Detail)
	}
	status := core.StatusSucceeded
	msg := ""
	if !res.Valid {
		status, msg = core.StatusFailed, "configuration invalide"
	}
	j.logf("validate : %s (%d diagnostic(s))", map[bool]string{true: "valide", false: "invalide"}[res.Valid], len(diags))
	return outcome{status: status, exitCode: code, errMsg: msg, diagnostics: diags}, nil
}

// nodeAt retrouve le nœud qui couvre une ligne d'un fichier généré.
func nodeAt(snap *core.Snapshot, file string, line int) string {
	for _, r := range snap.Ranges {
		if r.File == file && line >= r.Start && line <= r.End {
			return r.NodeID
		}
	}
	return ""
}

func (w *Worker) doState(ctx context.Context, j *job, run *core.Run) (outcome, error) {
	o := run.Options
	if mutatingState(o.StateCmd) {
		if raw, _, err := w.statePull(ctx, j); err == nil && len(bytes.TrimSpace(raw)) > 0 {
			if _, err := w.core.SaveStateVersion(ctx, run.EnvironmentID, run.ID, "sauvegarde avant state "+o.StateCmd, raw); err != nil {
				return outcome{}, err
			}
			j.logf("sauvegarde du state effectuée avant modification")
		}
	}
	var args []string
	switch o.StateCmd {
	case "list":
		args = append([]string{"state", "list"}, o.StateArgs...)
	case "show":
		args = []string{"state", "show", "-no-color", o.StateArgs[0]}
	case "mv":
		args = []string{"state", "mv", "-lock-timeout=120s", o.StateArgs[0], o.StateArgs[1]}
	case "rm":
		args = append([]string{"state", "rm", "-lock-timeout=120s"}, o.StateArgs...)
	case "import":
		args = []string{"import", "-input=false", "-no-color", "-lock-timeout=120s", o.StateArgs[0], o.StateArgs[1]}
	case "unlock":
		args = []string{"force-unlock", "-force", o.StateArgs[0]}
	case "push":
		// Migration de backend : on pousse la sauvegarde faite par le run "pull" qui précède immédiatement.
		var prevOK bool
		_ = w.core.DB.QueryRow(ctx, `SELECT operation='state' AND options->>'stateCmd'='pull' AND status='succeeded' FROM runs
			WHERE environment_id=$1 AND created_at < $2 ORDER BY created_at DESC LIMIT 1`, run.EnvironmentID, run.CreatedAt).Scan(&prevOK)
		if !prevOK {
			return outcome{status: core.StatusFailed, exitCode: -1, errMsg: "la sauvegarde (state pull) préalable à la migration n'a pas réussi : push annulé"}, nil
		}
		raw, err := w.core.LatestState(ctx, run.EnvironmentID)
		if err != nil || raw == nil {
			return outcome{status: core.StatusFailed, exitCode: -1, errMsg: "aucune version de state archivée à pousser"}, nil
		}
		if err := os.WriteFile(filepath.Join(j.dir, "migrate.tfstate"), raw, 0o600); err != nil {
			return outcome{}, err
		}
		args = []string{"state", "push", "-lock-timeout=120s", "migrate.tfstate"}
	case "pull":
		raw, meta, err := w.statePull(ctx, j)
		if err != nil {
			return outcome{}, err
		}
		if _, err := w.core.SaveStateVersion(ctx, run.EnvironmentID, run.ID, "export (state pull)", raw); err != nil {
			return outcome{}, err
		}
		return outcome{status: core.StatusSucceeded, serial: &meta.Serial, lineage: meta.Lineage}, nil
	default:
		return outcome{}, fmt.Errorf("commande de state inconnue %q", o.StateCmd)
	}
	code, err := j.run(ctx, nil, args...)
	if err != nil {
		return outcome{}, err
	}
	if code != 0 {
		return outcome{status: core.StatusFailed, exitCode: code, errMsg: "terraform " + strings.Join(args[:2], " ") + " en échec"}, nil
	}
	return outcome{status: core.StatusSucceeded, exitCode: 0}, nil
}

func parallelism(n int, rs settings.Runs) string {
	if n <= 0 {
		n = rs.Parallelism
	}
	if n <= 0 {
		n = 10
	}
	return "-parallelism=" + strconv.Itoa(n)
}
