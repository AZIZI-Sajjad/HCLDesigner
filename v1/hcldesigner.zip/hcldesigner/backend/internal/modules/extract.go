// Package modules transforme une sélection de nœuds en module réutilisable.
package modules

import (
	"encoding/json"
	"fmt"
	"regexp"
	"sort"
	"strings"

	"github.com/google/uuid"

	"github.com/AZIZI-Sajjad/hcldesigner/internal/model"
)

// ExtractResult contient le module créé et le projet modifié.
type ExtractResult struct {
	Module       model.Project `json:"module"`
	Project      model.Project `json:"project"`
	ModuleNodeID string        `json:"moduleNodeId"`
	Warnings     []string      `json:"warnings"`
}

var (
	nonIdent = regexp.MustCompile(`[^a-zA-Z0-9_]+`)
	indexes  = regexp.MustCompile(`\[\d+\]`)
)

func ident(s string) string {
	s = strings.Trim(nonIdent.ReplaceAllString(s, "_"), "_")
	if s == "" || (s[0] >= '0' && s[0] <= '9') {
		s = "v_" + s
	}
	return strings.ToLower(s)
}

// Extract déplace les nœuds sélectionnés dans un module :
//   - les références sortant de la sélection deviennent des variables du module ;
//   - les références entrant depuis le reste du projet deviennent des outputs du module ;
//   - la sélection est remplacée par un nœud module (source interne moduleID).
func Extract(p *model.Project, selection []string, moduleID, moduleName, label string) (*ExtractResult, error) {
	sel := map[string]bool{}
	for _, id := range selection {
		sel[id] = true
	}
	nodes := p.NodeByID()
	for id := range sel {
		if _, ok := nodes[id]; !ok {
			return nil, fmt.Errorf("nœud %s introuvable", id)
		}
	}
	if len(sel) == 0 {
		return nil, fmt.Errorf("sélection vide")
	}
	res := &ExtractResult{}
	mod := model.New()
	mod.FileLayout = model.FileLayout{Mode: model.LayoutStandard, Rules: []model.LayoutRule{}, CustomFiles: []string{}}
	usedNames := map[string]bool{}
	unique := func(base string) string {
		name := ident(base)
		for i := 2; usedNames[name]; i++ {
			name = fmt.Sprintf("%s_%d", ident(base), i)
		}
		usedNames[name] = true
		return name
	}
	// Les nœuds variables/outputs déjà sélectionnés gardent leur nom.
	for id := range sel {
		n := nodes[id]
		if n.Kind == model.KindVariable || n.Kind == model.KindOutput {
			usedNames[n.Label] = true
		}
	}

	moduleNode := model.Node{
		ID: uuid.NewString(), Kind: model.KindModule, Label: label, Type: moduleName,
		Attrs:  map[string]model.Value{},
		Module: &model.ModuleRef{SourceKind: "internal", ModuleID: moduleID, Name: moduleName},
	}

	// 1. Copie des nœuds sélectionnés, références sortantes -> variables
	varForRef := map[string]string{} // clé de référence -> id du nœud variable dans le module
	var cx, cy float64
	for _, n := range p.Nodes {
		if !sel[n.ID] {
			continue
		}
		cx += n.Position.X
		cy += n.Position.Y
		cp := deepCopy(n)
		rewrite(&cp, func(path string, v model.Value) model.Value {
			if v.Ref == nil || sel[v.Ref.NodeID] {
				return v
			}
			src := nodes[v.Ref.NodeID]
			key := refKey(v.Ref)
			varID, ok := varForRef[key]
			if !ok {
				base := lastSegment(path)
				if src != nil && src.Kind == model.KindVariable {
					base = src.Label
				}
				name := unique(base)
				varID = uuid.NewString()
				varForRef[key] = varID
				attrs := map[string]model.Value{"description": literal(fmt.Sprintf("Valeur de %s", describeRef(v.Ref, nodes)))}
				if src != nil && src.Kind == model.KindVariable {
					if t, ok := src.Attrs["type"]; ok {
						attrs["type"] = t
					}
				}
				mod.Nodes = append(mod.Nodes, model.Node{ID: varID, Kind: model.KindVariable, Label: name, Attrs: attrs,
					Position: model.Position{X: cp.Position.X - 300, Y: cp.Position.Y}})
				moduleNode.Attrs[name] = model.Value{Mode: model.ModeRef, Ref: copyRef(v.Ref)}
			}
			return model.Value{Mode: model.ModeRef, Ref: &model.Ref{NodeID: varID}}
		})
		var deps []string
		for _, d := range cp.Meta.DependsOn {
			if sel[d] {
				deps = append(deps, d)
			} else {
				res.Warnings = append(res.Warnings, fmt.Sprintf("depends_on de %s vers un objet hors module supprimé : utilisez depends_on sur le module", n.Label))
			}
		}
		cp.Meta.DependsOn = deps
		mod.Nodes = append(mod.Nodes, cp)
	}

	// 2. Références entrantes -> outputs du module
	outForRef := map[string]string{} // clé -> nom de l'output
	newNodes := make([]model.Node, 0, len(p.Nodes))
	for _, n := range p.Nodes {
		if sel[n.ID] {
			continue
		}
		cp := deepCopy(n)
		rewrite(&cp, func(path string, v model.Value) model.Value {
			if v.Ref == nil || !sel[v.Ref.NodeID] {
				return v
			}
			src := nodes[v.Ref.NodeID]
			key := refKey(v.Ref)
			name, ok := outForRef[key]
			if !ok {
				if src.Kind == model.KindOutput {
					name = src.Label
				} else {
					name = unique(src.Label + "_" + strings.ReplaceAll(v.Ref.Attr, ".", "_"))
				}
				outForRef[key] = name
				if src.Kind != model.KindOutput {
					mod.Nodes = append(mod.Nodes, model.Node{ID: uuid.NewString(), Kind: model.KindOutput, Label: name,
						Attrs:    map[string]model.Value{"value": {Mode: model.ModeRef, Ref: copyRef(v.Ref)}},
						Position: model.Position{X: src.Position.X + 300, Y: src.Position.Y}})
				}
			}
			return model.Value{Mode: model.ModeRef, Ref: &model.Ref{NodeID: moduleNode.ID, Attr: name}}
		})
		var deps []string
		seenModule := false
		for _, d := range cp.Meta.DependsOn {
			if sel[d] {
				if !seenModule {
					deps = append(deps, moduleNode.ID)
					seenModule = true
				}
				continue
			}
			deps = append(deps, d)
		}
		cp.Meta.DependsOn = deps
		newNodes = append(newNodes, cp)
	}
	n := float64(len(sel))
	moduleNode.Position = model.Position{X: cx / n, Y: cy / n}
	newNodes = append(newNodes, moduleNode)

	// Providers : le module déclare ceux utilisés par ses ressources.
	used := map[string]bool{}
	for _, mn := range mod.Nodes {
		if mn.Kind == model.KindResource || mn.Kind == model.KindData {
			prefix := mn.Type
			if i := strings.Index(prefix, "_"); i > 0 {
				prefix = prefix[:i]
			}
			used[prefix] = true
			if mn.Provider != "" {
				used[strings.SplitN(mn.Provider, ".", 2)[0]] = true
			}
		}
	}
	for _, pc := range p.Providers {
		if used[pc.LocalName] {
			c := pc
			c.Config = map[string]model.Value{} // la configuration reste dans le projet appelant
			mod.Providers = append(mod.Providers, c)
		}
	}
	sort.SliceStable(mod.Nodes, func(i, j int) bool { return mod.Nodes[i].Kind < mod.Nodes[j].Kind })

	out := *p
	out.Nodes = newNodes
	res.Project = out
	res.Module = mod
	res.ModuleNodeID = moduleNode.ID
	return res, nil
}

func literal(s string) model.Value {
	b, _ := json.Marshal(s)
	return model.Value{Mode: model.ModeLiteral, Value: b}
}

func refKey(r *model.Ref) string {
	return r.NodeID + "|" + r.Attr + "|" + r.IndexMode + "|" + r.Index
}

func copyRef(r *model.Ref) *model.Ref {
	c := *r
	return &c
}

func describeRef(r *model.Ref, nodes map[string]*model.Node) string {
	if n, ok := nodes[r.NodeID]; ok {
		if r.Attr != "" {
			return n.Address() + "." + r.Attr
		}
		return n.Address()
	}
	return r.NodeID
}

func lastSegment(path string) string {
	path = indexes.ReplaceAllString(path, "")
	if i := strings.LastIndex(path, "."); i >= 0 {
		return path[i+1:]
	}
	return path
}

// deepCopy clone un nœud via JSON (les valeurs contiennent des maps et des slices imbriquées).
func deepCopy(n model.Node) model.Node {
	b, _ := json.Marshal(n)
	var c model.Node
	_ = json.Unmarshal(b, &c)
	if c.Attrs == nil {
		c.Attrs = map[string]model.Value{}
	}
	return c
}

// rewrite applique f à toutes les valeurs de référence d'un nœud (attributs, blocs, count, for_each).
func rewrite(n *model.Node, f func(path string, v model.Value) model.Value) {
	var walk func(path string, v model.Value) model.Value
	walk = func(path string, v model.Value) model.Value {
		switch v.Mode {
		case model.ModeRef:
			return f(path, v)
		case model.ModeList:
			for i := range v.Items {
				v.Items[i] = walk(path, v.Items[i])
			}
		}
		return v
	}
	for k, v := range n.Attrs {
		n.Attrs[k] = walk(k, v)
	}
	var walkBlocks func(prefix string, blocks map[string][]model.Block)
	walkBlocks = func(prefix string, blocks map[string][]model.Block) {
		for name, list := range blocks {
			for i := range list {
				for k, v := range list[i].Attrs {
					list[i].Attrs[k] = walk(prefix+name+"."+k, v)
				}
				walkBlocks(prefix+name+".", list[i].Blocks)
			}
		}
	}
	walkBlocks("", n.Blocks)
	if n.Meta.Count != nil {
		v := walk("count", *n.Meta.Count)
		n.Meta.Count = &v
	}
	if n.Meta.ForEach != nil {
		v := walk("for_each", *n.Meta.ForEach)
		n.Meta.ForEach = &v
	}
}
