// Package settings lit et écrit les paramètres de la plateforme (table settings, clé -> JSON),
// avec des valeurs par défaut typées.
package settings

import (
	"context"
	"encoding/json"
	"errors"

	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"

	"github.com/AZIZI-Sajjad/hcldesigner/internal/auth"
	"github.com/AZIZI-Sajjad/hcldesigner/internal/tfbin"
)

// Clés connues.
const (
	KeySMTP      = "smtp"
	KeyMirror    = "mirror"
	KeyRuns      = "runs"
	KeyBranding  = "branding"
	KeySecurity  = "security"
	KeySyslog    = "syslog"
	KeyTemplates = "mail_templates"
	KeyEngines   = "engines"
)

type SMTP struct {
	Host        string `json:"host"`
	Port        int    `json:"port"`
	Security    string `json:"security"` // none | starttls | tls
	Username    string `json:"username"`
	PasswordEnc []byte `json:"passwordEnc,omitempty"` // chiffré par le vault, jamais renvoyé au frontend
	From        string `json:"from"`
	SkipVerify  bool   `json:"skipVerify"`
}

type Runs struct {
	PlanTTLMinutes     int `json:"planTtlMinutes"`
	LogRetentionDays   int `json:"logRetentionDays"`
	PlanRetentionDays  int `json:"planRetentionDays"`
	StateVersionsKept  int `json:"stateVersionsKept"`
	AuditRetentionDays int `json:"auditRetentionDays"`
	TimeoutMinutes     int `json:"timeoutMinutes"`
	Parallelism        int `json:"parallelism"`
}

type Branding struct {
	Name     string `json:"name"`
	LogoURL  string `json:"logoUrl"`
	Language string `json:"language"`
}

type Security struct {
	PasswordPolicy auth.PasswordPolicy `json:"passwordPolicy"`
	BlockLocalExec bool                `json:"blockLocalExec"`
	BlockFileFuncs bool                `json:"blockFileFuncs"`
	RequireMFA     bool                `json:"requireMfa"`
}

type Syslog struct {
	Addr string `json:"addr"`
}

type EngineVersion struct {
	Engine  string `json:"engine"`
	Version string `json:"version"`
}

type Engines struct {
	Versions []EngineVersion `json:"versions"`
}

// Defaults : valeurs appliquées quand la clé n'existe pas en base.
var Defaults = map[string]any{
	KeySMTP:      SMTP{Port: 587, Security: "starttls", From: "hcldesigner@localhost"},
	KeyMirror:    tfbin.MirrorConfig{Mode: "none"},
	KeyRuns:      Runs{PlanTTLMinutes: 1440, LogRetentionDays: 90, PlanRetentionDays: 30, StateVersionsKept: 50, AuditRetentionDays: 365, TimeoutMinutes: 120, Parallelism: 10},
	KeyBranding:  Branding{Name: "HCLDesigner", Language: "fr"},
	KeySecurity:  Security{PasswordPolicy: auth.DefaultPolicy, BlockLocalExec: true, BlockFileFuncs: true},
	KeySyslog:    Syslog{},
	KeyTemplates: map[string]any{},
	KeyEngines:   Engines{Versions: []EngineVersion{}},
}

type Store struct{ pool *pgxpool.Pool }

func New(pool *pgxpool.Pool) *Store { return &Store{pool: pool} }

// Get remplit out avec la valeur de la clé ou sa valeur par défaut.
func (s *Store) Get(ctx context.Context, key string, out any) error {
	var raw []byte
	err := s.pool.QueryRow(ctx, `SELECT value FROM settings WHERE key=$1`, key).Scan(&raw)
	if errors.Is(err, pgx.ErrNoRows) {
		def, ok := Defaults[key]
		if !ok {
			return nil
		}
		b, _ := json.Marshal(def)
		return json.Unmarshal(b, out)
	}
	if err != nil {
		return err
	}
	// On part des défauts pour que les champs ajoutés dans une nouvelle version aient une valeur.
	if def, ok := Defaults[key]; ok {
		b, _ := json.Marshal(def)
		_ = json.Unmarshal(b, out)
	}
	return json.Unmarshal(raw, out)
}

func (s *Store) Set(ctx context.Context, key string, value any) error {
	b, err := json.Marshal(value)
	if err != nil {
		return err
	}
	_, err = s.pool.Exec(ctx, `INSERT INTO settings(key, value, updated_at) VALUES ($1,$2,now()) ON CONFLICT (key) DO UPDATE SET value=EXCLUDED.value, updated_at=now()`, key, b)
	return err
}

// Runs est un raccourci très utilisé.
func (s *Store) Runs(ctx context.Context) Runs {
	var r Runs
	_ = s.Get(ctx, KeyRuns, &r)
	return r
}
