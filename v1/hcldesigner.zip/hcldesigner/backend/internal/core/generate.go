package core

import (
	"context"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"regexp"
	"sort"
	"strings"

	"github.com/AZIZI-Sajjad/hcldesigner/internal/hclgen"
	"github.com/AZIZI-Sajjad/hcldesigner/internal/model"
	"github.com/AZIZI-Sajjad/hcldesigner/internal/settings"
)

// GenerateOptions contrôle la génération pour l'aperçu, l'export ou une exécution.
type GenerateOptions struct {
	Env *Environment
	// ForRunner : backend en configuration partielle (secrets fournis par backend.hcl).
	ForRunner bool
}

// Generate produit les fichiers d'un modèle de projet.
func (c *Core) Generate(ctx context.Context, m *model.Project, opts GenerateOptions) (*hclgen.Result, error) {
	mods, err := c.ModuleDefs(ctx, m)
	if err != nil {
		return nil, err
	}
	go2 := hclgen.Options{Modules: mods, Defaults: c.Rules}
	if opts.Env != nil {
		be, err := c.BackendFor(ctx, opts.Env, false)
		if err != nil {
			return nil, err
		}
		if be != nil && opts.ForRunner {
			be = &hclgen.Backend{Type: be.Type, Partial: true}
		}
		go2.Backend = be
	}
	res := hclgen.Generate(m, hclgen.ProjectResolver{Project: m, Lookup: c.Lookup(ctx)}, go2)
	return res, nil
}

// ModuleDefs charge les versions de modules internes référencées (récursivement).
func (c *Core) ModuleDefs(ctx context.Context, m *model.Project) (map[string]*hclgen.ModuleDef, error) {
	out := map[string]*hclgen.ModuleDef{}
	var visit func(p *model.Project, depth int) error
	visit = func(p *model.Project, depth int) error {
		if depth > 5 {
			return fmt.Errorf("imbrication de modules trop profonde (boucle ?)")
		}
		for _, n := range p.Nodes {
			if n.Kind != model.KindModule || n.Module == nil || n.Module.SourceKind != "internal" {
				continue
			}
			if _, ok := out[n.Module.ModuleID]; ok {
				continue
			}
			def, err := c.LoadModuleVersion(ctx, n.Module.ModuleID, n.Module.Version)
			if err != nil {
				return fmt.Errorf("module %s : %w", n.Label, err)
			}
			out[n.Module.ModuleID] = def
			if err := visit(def.Model, depth+1); err != nil {
				return err
			}
		}
		return nil
	}
	return out, visit(m, 0)
}

// LoadModuleVersion lit une version de module (la plus récente si version vide).
func (c *Core) LoadModuleVersion(ctx context.Context, moduleID, version string) (*hclgen.ModuleDef, error) {
	var name, ver string
	var raw []byte
	q := `SELECT m.name, v.version, v.model FROM modules m JOIN module_versions v ON v.module_id=m.id WHERE m.id=$1`
	args := []any{moduleID}
	if version != "" {
		q += ` AND v.version=$2`
		args = append(args, version)
	} else {
		q += ` ORDER BY v.created_at DESC LIMIT 1`
	}
	if err := c.DB.QueryRow(ctx, q, args...).Scan(&name, &ver, &raw); err != nil {
		return nil, fmt.Errorf("version de module introuvable : %w", err)
	}
	var mm model.Project
	if err := json.Unmarshal(raw, &mm); err != nil {
		return nil, err
	}
	normalize(&mm)
	return &hclgen.ModuleDef{ID: moduleID, Name: name, Version: ver, Model: &mm}, nil
}

// Snapshot est l'ensemble figé des fichiers exécutés par un run.
type Snapshot struct {
	Files  map[string]string  `json:"files"`
	Ranges []hclgen.NodeRange `json:"ranges"`
}

// Hash calcule l'empreinte stable d'un snapshot.
func (s Snapshot) Hash() string {
	names := make([]string, 0, len(s.Files))
	for n := range s.Files {
		names = append(names, n)
	}
	sort.Strings(names)
	h := sha256.New()
	for _, n := range names {
		h.Write([]byte(n + "\x00" + s.Files[n] + "\x00"))
	}
	return hex.EncodeToString(h.Sum(nil))
}

var (
	reLocalExec = regexp.MustCompile(`provisioner\s+"local-exec"`)
	reFileFunc  = regexp.MustCompile(`\b(file|filebase64|templatefile|filesha256|filemd5|fileexists|fileset)\s*\(\s*"(/|[^"]*\.\.)`)
)

// CheckForbidden applique les protections configurées (local-exec, fonctions file() hors workspace).
func (c *Core) CheckForbidden(ctx context.Context, files map[string]string) error {
	var sec settings.Security
	_ = c.Settings.Get(ctx, settings.KeySecurity, &sec)
	for name, content := range files {
		if sec.BlockLocalExec && reLocalExec.MatchString(content) {
			return fmt.Errorf("%s : provisioner local-exec interdit par la politique de sécurité", name)
		}
		if sec.BlockFileFuncs && reFileFunc.MatchString(content) {
			return fmt.Errorf("%s : lecture de fichier hors du workspace interdite (%s)", name, strings.TrimSpace(reFileFunc.FindString(content)))
		}
	}
	return nil
}
