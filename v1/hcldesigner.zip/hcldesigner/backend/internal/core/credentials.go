package core

import (
	"context"
	"fmt"
	"os"
	"path/filepath"
	"sort"
	"strings"
)

// CredentialKind décrit un type de credential et sa traduction en variables d'environnement
// injectées dans le runner (jamais écrites sur disque, sauf fichier temporaire du workspace
// pour les formats qui l'exigent, comme kubeconfig).
type CredentialKind struct {
	Kind   string            `json:"kind"`
	Label  string            `json:"label"`
	Fields []Field           `json:"fields"`
	Env    map[string]string `json:"-"` // champ -> variable d'environnement
	Files  map[string]string `json:"-"` // champ -> variable pointant vers un fichier temporaire
}

var CredentialKinds = []CredentialKind{
	{Kind: "aws", Label: "AWS", Fields: []Field{
		{Name: "access_key_id", Label: "Access key ID", Type: "string", Required: true},
		{Name: "secret_access_key", Label: "Secret access key", Type: "string", Secret: true, Required: true},
		{Name: "session_token", Label: "Session token", Type: "string", Secret: true},
		{Name: "region", Label: "Région par défaut", Type: "string"},
		{Name: "role_arn", Label: "Rôle à assumer (utilisé via le provider)", Type: "string"},
	}, Env: map[string]string{"access_key_id": "AWS_ACCESS_KEY_ID", "secret_access_key": "AWS_SECRET_ACCESS_KEY", "session_token": "AWS_SESSION_TOKEN", "region": "AWS_REGION", "role_arn": "TF_VAR_aws_role_arn"}},
	{Kind: "azure", Label: "Azure (service principal)", Fields: []Field{
		{Name: "client_id", Label: "Client ID", Type: "string", Required: true},
		{Name: "client_secret", Label: "Client secret", Type: "string", Secret: true},
		{Name: "client_certificate", Label: "Certificat client (PFX base64)", Type: "text", Secret: true},
		{Name: "tenant_id", Label: "Tenant ID", Type: "string", Required: true},
		{Name: "subscription_id", Label: "Subscription ID", Type: "string", Required: true},
	}, Env: map[string]string{"client_id": "ARM_CLIENT_ID", "client_secret": "ARM_CLIENT_SECRET", "tenant_id": "ARM_TENANT_ID", "subscription_id": "ARM_SUBSCRIPTION_ID"},
		Files: map[string]string{"client_certificate": "ARM_CLIENT_CERTIFICATE_PATH"}},
	{Kind: "gcp", Label: "Google Cloud (compte de service)", Fields: []Field{
		{Name: "credentials", Label: "Clé JSON", Type: "text", Secret: true, Required: true},
		{Name: "project", Label: "Projet par défaut", Type: "string"},
	}, Env: map[string]string{"credentials": "GOOGLE_CREDENTIALS", "project": "GOOGLE_PROJECT"}},
	{Kind: "vsphere", Label: "VMware vSphere", Fields: []Field{
		{Name: "server", Label: "vCenter", Type: "string", Required: true},
		{Name: "user", Label: "Utilisateur", Type: "string", Required: true},
		{Name: "password", Label: "Mot de passe", Type: "string", Secret: true, Required: true},
		{Name: "allow_unverified_ssl", Label: "Certificat non vérifié", Type: "bool"},
	}, Env: map[string]string{"server": "VSPHERE_SERVER", "user": "VSPHERE_USER", "password": "VSPHERE_PASSWORD", "allow_unverified_ssl": "VSPHERE_ALLOW_UNVERIFIED_SSL"}},
	{Kind: "vcd", Label: "VMware Cloud Director", Fields: []Field{
		{Name: "url", Label: "URL API (https://vcd/api)", Type: "string", Required: true},
		{Name: "org", Label: "Organisation", Type: "string", Required: true},
		{Name: "user", Label: "Utilisateur", Type: "string"},
		{Name: "password", Label: "Mot de passe", Type: "string", Secret: true},
		{Name: "api_token", Label: "Jeton API", Type: "string", Secret: true},
		{Name: "allow_unverified_ssl", Label: "Certificat non vérifié", Type: "bool"},
	}, Env: map[string]string{"url": "VCD_URL", "org": "VCD_ORG", "user": "VCD_USER", "password": "VCD_PASSWORD", "api_token": "VCD_API_TOKEN", "allow_unverified_ssl": "VCD_ALLOW_UNVERIFIED_SSL"}},
	{Kind: "proxmox", Label: "Proxmox VE (bpg/proxmox)", Fields: []Field{
		{Name: "endpoint", Label: "Endpoint (https://pve:8006/)", Type: "string", Required: true},
		{Name: "api_token", Label: "Jeton API (user@pam!id=secret)", Type: "string", Secret: true, Required: true},
		{Name: "insecure", Label: "Certificat non vérifié", Type: "bool"},
	}, Env: map[string]string{"endpoint": "PROXMOX_VE_ENDPOINT", "api_token": "PROXMOX_VE_API_TOKEN", "insecure": "PROXMOX_VE_INSECURE"}},
	{Kind: "kubernetes", Label: "Kubernetes (kubeconfig)", Fields: []Field{
		{Name: "kubeconfig", Label: "Contenu du kubeconfig", Type: "text", Secret: true, Required: true},
		{Name: "context", Label: "Contexte", Type: "string"},
	}, Env: map[string]string{"context": "KUBE_CTX"}, Files: map[string]string{"kubeconfig": "KUBE_CONFIG_PATH"}},
	{Kind: "cloudflare", Label: "Cloudflare", Fields: []Field{
		{Name: "api_token", Label: "Jeton API", Type: "string", Secret: true, Required: true},
	}, Env: map[string]string{"api_token": "CLOUDFLARE_API_TOKEN"}},
	{Kind: "ovh", Label: "OVHcloud", Fields: []Field{
		{Name: "endpoint", Label: "Endpoint", Type: "select", Options: []string{"ovh-eu", "ovh-ca", "ovh-us"}, Default: "ovh-eu"},
		{Name: "application_key", Label: "Application key", Type: "string", Required: true},
		{Name: "application_secret", Label: "Application secret", Type: "string", Secret: true, Required: true},
		{Name: "consumer_key", Label: "Consumer key", Type: "string", Secret: true, Required: true},
	}, Env: map[string]string{"endpoint": "OVH_ENDPOINT", "application_key": "OVH_APPLICATION_KEY", "application_secret": "OVH_APPLICATION_SECRET", "consumer_key": "OVH_CONSUMER_KEY"}},
	{Kind: "env", Label: "Variables d'environnement libres", Fields: []Field{
		{Name: "vars", Label: "VARIABLE=valeur (une par ligne ; TF_VAR_x pour les variables Terraform)", Type: "text", Secret: true, Required: true},
	}},
	{Kind: "backend", Label: "Secrets de backend (géré automatiquement)", Fields: []Field{}},
}

func credentialKind(kind string) (*CredentialKind, error) {
	for i := range CredentialKinds {
		if CredentialKinds[i].Kind == kind {
			return &CredentialKinds[i], nil
		}
	}
	return nil, fmt.Errorf("type de credential inconnu %q", kind)
}

// CredentialData déchiffre les données d'un credential.
func (c *Core) CredentialData(ctx context.Context, id string) (map[string]string, error) {
	var enc []byte
	if err := c.DB.QueryRow(ctx, `SELECT data_enc FROM credentials WHERE id=$1`, id).Scan(&enc); err != nil {
		return nil, err
	}
	out := map[string]string{}
	return out, c.Vault.DecryptJSON(enc, &out)
}

// SaveCredentialData chiffre et enregistre ; renvoie l'id (création si id vide).
func (c *Core) SaveCredentialData(ctx context.Context, id, name, kind, description, userID string, data map[string]string) (string, error) {
	if _, err := credentialKind(kind); err != nil {
		return "", err
	}
	enc, err := c.Vault.EncryptJSON(data)
	if err != nil {
		return "", err
	}
	if id == "" {
		err = c.DB.QueryRow(ctx, `INSERT INTO credentials(name, kind, description, data_enc, created_by) VALUES ($1,$2,$3,$4,$5) RETURNING id`,
			name, kind, description, enc, nullable(userID)).Scan(&id)
		return id, err
	}
	_, err = c.DB.Exec(ctx, `UPDATE credentials SET name=$2, description=$3, data_enc=$4, updated_at=now() WHERE id=$1`, id, name, description, enc)
	return id, err
}

// CredentialEnv convertit les credentials d'un environnement en variables d'environnement.
// Les fichiers nécessaires (kubeconfig...) sont écrits dans dir (workspace éphémère, 0600).
// Renvoie aussi la liste des valeurs secrètes à masquer dans les logs.
func (c *Core) CredentialEnv(ctx context.Context, ids []string, dir string) (env []string, secrets []string, err error) {
	for _, id := range ids {
		var kind, name string
		var enc []byte
		if err := c.DB.QueryRow(ctx, `SELECT kind, name, data_enc FROM credentials WHERE id=$1`, id).Scan(&kind, &name, &enc); err != nil {
			return nil, nil, fmt.Errorf("credential %s : %w", id, err)
		}
		data := map[string]string{}
		if err := c.Vault.DecryptJSON(enc, &data); err != nil {
			return nil, nil, err
		}
		ck, err := credentialKind(kind)
		if err != nil {
			return nil, nil, err
		}
		secretField := map[string]bool{}
		for _, f := range ck.Fields {
			secretField[f.Name] = f.Secret
		}
		if kind == "env" {
			for _, line := range strings.Split(data["vars"], "\n") {
				line = strings.TrimSpace(line)
				k, v, ok := strings.Cut(line, "=")
				if !ok || k == "" || strings.HasPrefix(line, "#") {
					continue
				}
				env = append(env, strings.TrimSpace(k)+"="+v)
				secrets = append(secrets, v)
			}
			continue
		}
		keys := make([]string, 0, len(data))
		for k := range data {
			keys = append(keys, k)
		}
		sort.Strings(keys)
		for _, field := range keys {
			val := data[field]
			if val == "" {
				continue
			}
			if secretField[field] {
				secrets = append(secrets, val)
			}
			if v, ok := ck.Env[field]; ok {
				env = append(env, v+"="+val)
			}
			if v, ok := ck.Files[field]; ok {
				p := filepath.Join(dir, ".cred-"+id+"-"+field)
				if err := os.WriteFile(p, []byte(val), 0o600); err != nil {
					return nil, nil, err
				}
				env = append(env, v+"="+p)
			}
		}
	}
	return env, secrets, nil
}
