package core

import (
	"context"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"time"

	"github.com/google/uuid"
)

// StateMeta reprend les champs utiles d'un fichier tfstate.
type StateMeta struct {
	Serial    int64  `json:"serial"`
	Lineage   string `json:"lineage"`
	Resources []struct {
		Mode      string `json:"mode"`
		Type      string `json:"type"`
		Name      string `json:"name"`
		Module    string `json:"module,omitempty"`
		Instances []struct {
			IndexKey any `json:"index_key,omitempty"`
		} `json:"instances"`
	} `json:"resources"`
}

// ParseStateMeta lit serial, lineage et ressources d'un state JSON (vide = state inexistant).
func ParseStateMeta(raw []byte) (*StateMeta, error) {
	m := &StateMeta{}
	if len(raw) == 0 {
		return m, nil
	}
	if err := json.Unmarshal(raw, m); err != nil {
		return nil, fmt.Errorf("state illisible : %w", err)
	}
	return m, nil
}

type StateVersion struct {
	ID            string    `json:"id"`
	EnvironmentID string    `json:"environmentId"`
	Serial        int64     `json:"serial"`
	Lineage       string    `json:"lineage"`
	Resources     int       `json:"resources"`
	RunID         *string   `json:"runId"`
	Reason        string    `json:"reason"`
	CreatedAt     time.Time `json:"createdAt"`
}

// SaveStateVersion chiffre et historise une copie du state.
func (c *Core) SaveStateVersion(ctx context.Context, envID, runID, reason string, raw []byte) (*StateVersion, error) {
	meta, err := ParseStateMeta(raw)
	if err != nil {
		return nil, err
	}
	dir := filepath.Join(c.Cfg.DataDir, "states", envID)
	if err := os.MkdirAll(dir, 0o700); err != nil {
		return nil, err
	}
	path := filepath.Join(dir, fmt.Sprintf("%06d-%s.tfstate.enc", meta.Serial, uuid.NewString()))
	if err := c.Vault.WriteFile(path, raw); err != nil {
		return nil, err
	}
	sv := &StateVersion{EnvironmentID: envID, Serial: meta.Serial, Lineage: meta.Lineage, Resources: len(meta.Resources), Reason: reason}
	err = c.DB.QueryRow(ctx, `INSERT INTO state_versions(environment_id, serial, lineage, resources, path, run_id, reason) VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING id, created_at`,
		envID, meta.Serial, meta.Lineage, sv.Resources, path, nullable(runID), reason).Scan(&sv.ID, &sv.CreatedAt)
	return sv, err
}

// LatestState renvoie le contenu de la dernière version de state d'un environnement (nil si aucune).
func (c *Core) LatestState(ctx context.Context, envID string) ([]byte, error) {
	var path string
	err := c.DB.QueryRow(ctx, `SELECT path FROM state_versions WHERE environment_id=$1 ORDER BY created_at DESC LIMIT 1`, envID).Scan(&path)
	if err != nil {
		return nil, nil
	}
	return c.Vault.ReadFile(path)
}

// StateVersionContent déchiffre une version précise.
func (c *Core) StateVersionContent(ctx context.Context, envID, versionID string) ([]byte, error) {
	var path string
	if err := c.DB.QueryRow(ctx, `SELECT path FROM state_versions WHERE id=$1 AND environment_id=$2`, versionID, envID).Scan(&path); err != nil {
		return nil, err
	}
	return c.Vault.ReadFile(path)
}

// PruneStateVersions ne garde que les keep versions les plus récentes par environnement.
func (c *Core) PruneStateVersions(ctx context.Context, keep int) error {
	if keep < 1 {
		return nil
	}
	rows, err := c.DB.Query(ctx, `SELECT id, path FROM (
		SELECT id, path, row_number() OVER (PARTITION BY environment_id ORDER BY created_at DESC) AS rn FROM state_versions) s WHERE rn > $1`, keep)
	if err != nil {
		return err
	}
	type item struct{ id, path string }
	var items []item
	for rows.Next() {
		var it item
		if rows.Scan(&it.id, &it.path) == nil {
			items = append(items, it)
		}
	}
	rows.Close()
	for _, it := range items {
		_ = os.Remove(it.path)
		_, _ = c.DB.Exec(ctx, `DELETE FROM state_versions WHERE id=$1`, it.id)
	}
	return nil
}
