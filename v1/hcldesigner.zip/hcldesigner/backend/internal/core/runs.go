package core

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"strings"
	"time"

	"github.com/jackc/pgx/v5"

	"github.com/AZIZI-Sajjad/hcldesigner/internal/db"
	"github.com/AZIZI-Sajjad/hcldesigner/internal/model"
)

// Opérations d'exécution.
const (
	OpInit     = "init"
	OpValidate = "validate"
	OpPlan     = "plan"
	OpApply    = "apply"
	OpState    = "state"
)

// Statuts d'exécution.
const (
	StatusQueued    = "queued"
	StatusRunning   = "running"
	StatusPlanned   = "planned"    // plan avec changements, en attente d'apply
	StatusNoChanges = "no_changes" // plan sans changement
	StatusChecked   = "checked"    // plan de détection de drift (non applicable)
	StatusApplied   = "applied"    // plan appliqué / apply terminé
	StatusSucceeded = "succeeded"  // init, validate, opérations de state
	StatusFailed    = "failed"
	StatusCanceled  = "canceled"
	StatusRejected  = "rejected"
	StatusDiscarded = "discarded" // plan expiré ou remplacé
)

// RunOptions : options passées à terraform.
type RunOptions struct {
	Targets      []string `json:"targets,omitempty"`
	Replace      []string `json:"replace,omitempty"`
	RefreshOnly  bool     `json:"refreshOnly,omitempty"`
	Upgrade      bool     `json:"upgrade,omitempty"`
	Reconfigure  bool     `json:"reconfigure,omitempty"`
	MigrateState bool     `json:"migrateState,omitempty"`
	Parallelism  int      `json:"parallelism,omitempty"`
	Drift        bool     `json:"drift,omitempty"`     // plan de détection de drift
	AutoApply    bool     `json:"autoApply,omitempty"` // apply automatique si aucune approbation requise
	StateCmd     string   `json:"stateCmd,omitempty"`  // list | show | mv | rm | import | unlock | pull | push
	StateArgs    []string `json:"stateArgs,omitempty"`
	// Backend figé à la création du run : l'exécution ne dépend pas d'une modification ultérieure de l'environnement.
	Backend *BackendSnapshot `json:"backend,omitempty"`
}

// BackendSnapshot : configuration non secrète du backend + référence du secret dans le coffre.
type BackendSnapshot struct {
	Type     string                     `json:"type"`
	Config   map[string]json.RawMessage `json:"config"`
	SecretID *string                    `json:"secretId,omitempty"`
}

// ApplyTo renvoie une copie de l'environnement utilisant le backend figé.
func (b *BackendSnapshot) ApplyTo(env *Environment) *Environment {
	if b == nil {
		return env
	}
	cp := *env
	cp.BackendType, cp.BackendConfig, cp.BackendSecretID = b.Type, b.Config, b.SecretID
	return &cp
}

type Run struct {
	ID                string          `json:"id"`
	ProjectID         string          `json:"projectId"`
	ProjectName       string          `json:"projectName"`
	EnvironmentID     string          `json:"environmentId"`
	EnvironmentName   string          `json:"environmentName"`
	Operation         string          `json:"operation"`
	Destroy           bool            `json:"destroy"`
	Status            string          `json:"status"`
	Options           RunOptions      `json:"options"`
	SnapshotHash      string          `json:"snapshotHash"`
	ProjectVersion    int             `json:"projectVersion"`
	PlanRunID         *string         `json:"planRunId"`
	Summary           json.RawMessage `json:"summary"`
	Diagnostics       json.RawMessage `json:"diagnostics"`
	PolicyReport      json.RawMessage `json:"policyReport"`
	StateSerial       *int64          `json:"stateSerial"`
	StateLineage      string          `json:"stateLineage"`
	ApprovalsRequired int             `json:"approvalsRequired"`
	PlanExpiresAt     *time.Time      `json:"planExpiresAt"`
	ExitCode          *int            `json:"exitCode"`
	Error             string          `json:"error"`
	CancelRequested   bool            `json:"cancelRequested"`
	TriggeredBy       string          `json:"triggeredBy"`
	TaskID            *string         `json:"taskId"`
	CreatedBy         *string         `json:"createdBy"`
	CreatedByName     string          `json:"createdByName"`
	CreatedAt         time.Time       `json:"createdAt"`
	StartedAt         *time.Time      `json:"startedAt"`
	FinishedAt        *time.Time      `json:"finishedAt"`
}

// RunCols : colonnes lues pour un Run (jointures projet/environnement/utilisateur).
const RunCols = `r.id, r.project_id, p.name, r.environment_id, e.name, r.operation, r.destroy, r.status, r.options, r.snapshot_hash, r.project_version,
	r.plan_run_id, r.summary, r.diagnostics, r.policy_report, r.state_serial, r.state_lineage, r.approvals_required, r.plan_expires_at, r.exit_code,
	r.error, r.cancel_requested, r.triggered_by, r.task_id, r.created_by, COALESCE(u.username,''), r.created_at, r.started_at, r.finished_at`

// RunFrom : clause FROM associée à RunCols.
const RunFrom = ` FROM runs r JOIN projects p ON p.id=r.project_id JOIN environments e ON e.id=r.environment_id LEFT JOIN users u ON u.id=r.created_by`

func ScanRun(row pgx.Row) (*Run, error) {
	var r Run
	var opts []byte
	if err := row.Scan(&r.ID, &r.ProjectID, &r.ProjectName, &r.EnvironmentID, &r.EnvironmentName, &r.Operation, &r.Destroy, &r.Status, &opts, &r.SnapshotHash, &r.ProjectVersion,
		&r.PlanRunID, &r.Summary, &r.Diagnostics, &r.PolicyReport, &r.StateSerial, &r.StateLineage, &r.ApprovalsRequired, &r.PlanExpiresAt, &r.ExitCode,
		&r.Error, &r.CancelRequested, &r.TriggeredBy, &r.TaskID, &r.CreatedBy, &r.CreatedByName, &r.CreatedAt, &r.StartedAt, &r.FinishedAt); err != nil {
		return nil, db.NotFound(err)
	}
	_ = json.Unmarshal(opts, &r.Options)
	return &r, nil
}

func (c *Core) GetRun(ctx context.Context, id string) (*Run, error) {
	return ScanRun(c.DB.QueryRow(ctx, `SELECT `+RunCols+RunFrom+` WHERE r.id=$1`, id))
}

// RunSnapshot lit les fichiers figés d'un run.
func (c *Core) RunSnapshot(ctx context.Context, id string) (*Snapshot, error) {
	var raw []byte
	if err := c.DB.QueryRow(ctx, `SELECT snapshot FROM runs WHERE id=$1`, id).Scan(&raw); err != nil {
		return nil, db.NotFound(err)
	}
	var s Snapshot
	return &s, json.Unmarshal(raw, &s)
}

// RunRequest décrit une demande d'exécution.
type RunRequest struct {
	ProjectID     string
	EnvironmentID string
	Operation     string
	Destroy       bool
	Options       RunOptions
	PlanRunID     string // pour apply
	UserID        string
	TriggeredBy   string // user | schedule | api
	TaskID        string
	// BypassWindow : l'appelant a le droit runs.bypass_window.
	BypassWindow bool
}

// ErrRefused regroupe les refus métier (renvoyés en 409/422 par l'API).
type ErrRefused struct{ Msg string }

func (e ErrRefused) Error() string { return e.Msg }

func refused(format string, a ...any) error { return ErrRefused{fmt.Sprintf(format, a...)} }

// IsRefused indique si err est un refus métier.
func IsRefused(err error) bool {
	var r ErrRefused
	return errors.As(err, &r)
}

// Approvals renvoie le nombre d'approbations et de refus d'un plan.
func (c *Core) Approvals(ctx context.Context, runID string) (approve, reject int, err error) {
	err = c.DB.QueryRow(ctx, `SELECT count(*) FILTER (WHERE decision='approve'), count(*) FILTER (WHERE decision='reject') FROM approvals WHERE run_id=$1`, runID).Scan(&approve, &reject)
	return
}

// CheckApplicable vérifie qu'un plan peut être appliqué maintenant.
func (c *Core) CheckApplicable(ctx context.Context, plan *Run, env *Environment, bypassWindow bool) error {
	if plan.Operation != OpPlan || plan.Status != StatusPlanned {
		return refused("seul un plan au statut « planned » peut être appliqué (statut actuel : %s)", plan.Status)
	}
	if plan.Options.Drift {
		return refused("un plan de détection de drift n'est pas applicable")
	}
	if plan.PlanExpiresAt != nil && time.Now().After(*plan.PlanExpiresAt) {
		return refused("le plan a expiré le %s : relancez un plan", plan.PlanExpiresAt.Format("02/01 15:04"))
	}
	ok, ko, err := c.Approvals(ctx, plan.ID)
	if err != nil {
		return err
	}
	if ko > 0 {
		return refused("le plan a été refusé par un approbateur")
	}
	if ok < plan.ApprovalsRequired {
		return refused("approbations insuffisantes : %d/%d", ok, plan.ApprovalsRequired)
	}
	var rep struct {
		Blocking bool `json:"blocking"`
	}
	_ = json.Unmarshal(plan.PolicyReport, &rep)
	if rep.Blocking {
		return refused("le plan viole une règle de conformité bloquante")
	}
	if plan.Destroy && !env.AllowDestroy {
		return refused("le destroy est désactivé sur l'environnement %s", env.Name)
	}
	if !bypassWindow && !env.ChangeWindow.Allows(time.Now()) {
		return refused("hors de la fenêtre de changement autorisée pour %s", env.Name)
	}
	return nil
}

// CreateRun valide et met en file une exécution. Les contrôles de permission sont faits par l'appelant.
func (c *Core) CreateRun(ctx context.Context, req RunRequest) (*Run, error) {
	proj, err := c.GetProject(ctx, req.ProjectID)
	if err != nil {
		return nil, err
	}
	env, err := c.GetEnvironment(ctx, req.EnvironmentID)
	if err != nil {
		return nil, err
	}
	if env.ProjectID != proj.ID {
		return nil, refused("l'environnement n'appartient pas au projet")
	}
	if req.TriggeredBy == "" {
		req.TriggeredBy = "user"
	}
	var snap *Snapshot
	var planRunID any
	approvals := 0
	projectVersion := proj.Version
	switch req.Operation {
	case OpApply:
		plan, err := c.GetRun(ctx, req.PlanRunID)
		if err != nil {
			return nil, refused("plan introuvable")
		}
		if plan.EnvironmentID != env.ID {
			return nil, refused("le plan ne concerne pas cet environnement")
		}
		if err := c.CheckApplicable(ctx, plan, env, req.BypassWindow); err != nil {
			return nil, err
		}
		if snap, err = c.RunSnapshot(ctx, plan.ID); err != nil {
			return nil, err
		}
		planRunID = plan.ID
		req.Destroy = plan.Destroy
		projectVersion = plan.ProjectVersion
	case OpInit, OpValidate, OpPlan, OpState:
		if req.Operation == OpPlan && req.Destroy && !env.AllowDestroy {
			return nil, refused("le destroy est désactivé sur l'environnement %s", env.Name)
		}
		if req.Operation == OpState {
			if err := validateStateCmd(req.Options); err != nil {
				return nil, err
			}
		}
		res, err := c.Generate(ctx, &proj.Model, GenerateOptions{Env: req.Options.Backend.ApplyTo(env), ForRunner: true})
		if err != nil {
			return nil, err
		}
		if len(res.Diags) > 0 {
			return nil, refused("le code ne peut pas être généré : %s", res.Diags[0].Summary)
		}
		if diags := proj.Model.Validate(); hasErrors(diags) {
			return nil, refused("modèle invalide : %s", firstError(diags))
		}
		if err := c.CheckForbidden(ctx, res.Files); err != nil {
			return nil, ErrRefused{err.Error()}
		}
		snap = &Snapshot{Files: res.Files, Ranges: res.Ranges}
		if req.Operation == OpPlan && !req.Options.Drift {
			approvals = env.RequireApprovals
		}
	default:
		return nil, refused("opération inconnue %q", req.Operation)
	}
	if req.Options.Backend == nil {
		req.Options.Backend = &BackendSnapshot{Type: env.BackendType, Config: env.BackendConfig, SecretID: env.BackendSecretID}
	}
	snapRaw, _ := json.Marshal(snap)
	optsRaw, _ := json.Marshal(req.Options)
	var id string
	err = c.DB.QueryRow(ctx, `INSERT INTO runs(project_id, environment_id, operation, destroy, options, snapshot, snapshot_hash, project_version, plan_run_id,
		approvals_required, triggered_by, task_id, created_by) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13) RETURNING id`,
		proj.ID, env.ID, req.Operation, req.Destroy, optsRaw, snapRaw, snap.Hash(), projectVersion, planRunID, approvals, req.TriggeredBy,
		nullable(req.TaskID), nullable(req.UserID)).Scan(&id)
	if err != nil {
		return nil, err
	}
	return c.GetRun(ctx, id)
}

func hasErrors(d []model.Diagnostic) bool {
	for _, x := range d {
		if x.Severity == "error" {
			return true
		}
	}
	return false
}

func firstError(d []model.Diagnostic) string {
	for _, x := range d {
		if x.Severity == "error" {
			return x.Summary
		}
	}
	return ""
}

// validateStateCmd n'autorise que les sous-commandes de state prévues, avec des arguments simples.
func validateStateCmd(o RunOptions) error {
	allowed := map[string]int{"list": -1, "show": 1, "mv": 2, "rm": -1, "import": 2, "unlock": 1, "pull": 0, "push": 0}
	n, ok := allowed[o.StateCmd]
	if !ok {
		return refused("commande de state non autorisée : %q", o.StateCmd)
	}
	if n >= 0 && len(o.StateArgs) != n {
		return refused("la commande state %s attend %d argument(s)", o.StateCmd, n)
	}
	if o.StateCmd == "rm" && len(o.StateArgs) == 0 {
		return refused("state rm attend au moins une adresse")
	}
	for _, a := range o.StateArgs {
		if strings.HasPrefix(a, "-") {
			return refused("les options ne sont pas autorisées dans les arguments (%q)", a)
		}
	}
	return nil
}
