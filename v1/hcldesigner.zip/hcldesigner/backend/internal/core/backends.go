package core

import (
	"context"
	"encoding/json"
	"fmt"
	"strings"

	"github.com/AZIZI-Sajjad/hcldesigner/internal/hclgen"
)

// Field décrit un champ de formulaire (backend ou credential). Le frontend construit
// ses formulaires à partir de ces définitions : une seule source de vérité.
type Field struct {
	Name     string   `json:"name"`
	Label    string   `json:"label"`
	Type     string   `json:"type"` // string | bool | number | text | select
	Required bool     `json:"required,omitempty"`
	Secret   bool     `json:"secret,omitempty"` // stocké dans le coffre, jamais dans backend_config
	Default  any      `json:"default,omitempty"`
	Options  []string `json:"options,omitempty"`
	Help     string   `json:"help,omitempty"`
}

type BackendType struct {
	Type        string  `json:"type"`
	Label       string  `json:"label"`
	Fields      []Field `json:"fields"`
	TFType      string  `json:"tfType"` // type réel du bloc backend (gitlab -> http)
	Description string  `json:"description"`
}

// BackendTypes : backends supportés et leurs champs.
var BackendTypes = []BackendType{
	{Type: "internal", TFType: "", Label: "Interne HCLDesigner (chiffré, versionné)", Description: "State stocké chiffré sur le volume HCLDesigner, avec historique des versions et verrou PostgreSQL."},
	{Type: "s3", TFType: "s3", Label: "Amazon S3 (ou compatible)", Fields: []Field{
		{Name: "bucket", Label: "Bucket", Type: "string", Required: true},
		{Name: "key", Label: "Clé de l'objet", Type: "string", Required: true, Default: "terraform.tfstate"},
		{Name: "region", Label: "Région", Type: "string", Required: true},
		{Name: "use_lockfile", Label: "Verrou natif S3 (Terraform ≥ 1.10)", Type: "bool", Default: true},
		{Name: "dynamodb_table", Label: "Table DynamoDB (verrou historique)", Type: "string"},
		{Name: "encrypt", Label: "Chiffrement côté serveur", Type: "bool", Default: true},
		{Name: "endpoints", Label: "Endpoints personnalisés (objet HCL, ex. MinIO)", Type: "text", Help: `{ s3 = "https://minio.local:9000" }`},
		{Name: "use_path_style", Label: "Path style (MinIO)", Type: "bool"},
		{Name: "skip_credentials_validation", Label: "Ne pas valider les credentials (S3 compatible)", Type: "bool"},
		{Name: "access_key", Label: "Access key", Type: "string", Secret: true},
		{Name: "secret_key", Label: "Secret key", Type: "string", Secret: true},
		{Name: "role_arn", Label: "Rôle à assumer (ARN)", Type: "string"},
	}},
	{Type: "azurerm", TFType: "azurerm", Label: "Azure Blob Storage", Fields: []Field{
		{Name: "resource_group_name", Label: "Resource group", Type: "string", Required: true},
		{Name: "storage_account_name", Label: "Compte de stockage", Type: "string", Required: true},
		{Name: "container_name", Label: "Conteneur", Type: "string", Required: true},
		{Name: "key", Label: "Clé du blob", Type: "string", Required: true, Default: "terraform.tfstate"},
		{Name: "subscription_id", Label: "Subscription ID", Type: "string"},
		{Name: "tenant_id", Label: "Tenant ID", Type: "string"},
		{Name: "client_id", Label: "Client ID", Type: "string"},
		{Name: "use_azuread_auth", Label: "Authentification Entra ID", Type: "bool"},
		{Name: "client_secret", Label: "Client secret", Type: "string", Secret: true},
		{Name: "access_key", Label: "Clé d'accès du compte", Type: "string", Secret: true},
		{Name: "sas_token", Label: "Jeton SAS", Type: "string", Secret: true},
	}},
	{Type: "gcs", TFType: "gcs", Label: "Google Cloud Storage", Fields: []Field{
		{Name: "bucket", Label: "Bucket", Type: "string", Required: true},
		{Name: "prefix", Label: "Préfixe", Type: "string"},
		{Name: "credentials", Label: "Clé JSON du compte de service", Type: "text", Secret: true},
	}},
	{Type: "http", TFType: "http", Label: "HTTP", Fields: []Field{
		{Name: "address", Label: "URL du state", Type: "string", Required: true},
		{Name: "lock_address", Label: "URL de verrouillage", Type: "string"},
		{Name: "unlock_address", Label: "URL de déverrouillage", Type: "string"},
		{Name: "lock_method", Label: "Méthode de verrouillage", Type: "string", Default: "LOCK"},
		{Name: "unlock_method", Label: "Méthode de déverrouillage", Type: "string", Default: "UNLOCK"},
		{Name: "skip_cert_verification", Label: "Ignorer le certificat", Type: "bool"},
		{Name: "username", Label: "Utilisateur", Type: "string"},
		{Name: "password", Label: "Mot de passe / jeton", Type: "string", Secret: true},
	}},
	{Type: "gitlab", TFType: "http", Label: "GitLab (Terraform state géré)", Description: "Backend HTTP de GitLab : les URLs sont calculées.", Fields: []Field{
		{Name: "gitlab_url", Label: "URL GitLab", Type: "string", Required: true, Default: "https://gitlab.example.com"},
		{Name: "project_id", Label: "ID du projet GitLab", Type: "string", Required: true},
		{Name: "state_name", Label: "Nom du state", Type: "string", Required: true, Default: "default"},
		{Name: "username", Label: "Utilisateur", Type: "string", Required: true},
		{Name: "password", Label: "Jeton d'accès (scope api)", Type: "string", Secret: true, Required: true},
	}},
	{Type: "pg", TFType: "pg", Label: "PostgreSQL", Fields: []Field{
		{Name: "conn_str", Label: "Chaîne de connexion", Type: "string", Secret: true, Required: true, Help: "postgres://user:pass@host/db?sslmode=require"},
		{Name: "schema_name", Label: "Schéma", Type: "string", Default: "terraform_remote_state"},
	}},
	{Type: "consul", TFType: "consul", Label: "Consul", Fields: []Field{
		{Name: "address", Label: "Adresse", Type: "string", Required: true},
		{Name: "path", Label: "Chemin", Type: "string", Required: true},
		{Name: "scheme", Label: "Schéma", Type: "select", Options: []string{"https", "http"}, Default: "https"},
		{Name: "access_token", Label: "Jeton", Type: "string", Secret: true},
	}},
	{Type: "kubernetes", TFType: "kubernetes", Label: "Kubernetes (secret)", Fields: []Field{
		{Name: "secret_suffix", Label: "Suffixe du secret", Type: "string", Required: true},
		{Name: "namespace", Label: "Namespace", Type: "string", Default: "default"},
		{Name: "config_path", Label: "Chemin kubeconfig (dans le runner)", Type: "string"},
		{Name: "in_cluster_config", Label: "Configuration in-cluster", Type: "bool"},
	}},
	{Type: "oss", TFType: "oss", Label: "Alibaba OSS", Fields: []Field{
		{Name: "bucket", Label: "Bucket", Type: "string", Required: true},
		{Name: "prefix", Label: "Préfixe", Type: "string"},
		{Name: "key", Label: "Clé", Type: "string", Default: "terraform.tfstate"},
		{Name: "region", Label: "Région", Type: "string", Required: true},
		{Name: "access_key", Label: "Access key", Type: "string", Secret: true},
		{Name: "secret_key", Label: "Secret key", Type: "string", Secret: true},
	}},
	{Type: "cos", TFType: "cos", Label: "Tencent COS", Fields: []Field{
		{Name: "bucket", Label: "Bucket", Type: "string", Required: true},
		{Name: "prefix", Label: "Préfixe", Type: "string"},
		{Name: "region", Label: "Région", Type: "string", Required: true},
		{Name: "secret_id", Label: "Secret ID", Type: "string", Secret: true},
		{Name: "secret_key", Label: "Secret key", Type: "string", Secret: true},
	}},
	{Type: "remote", TFType: "remote", Label: "HCP Terraform / Terraform Enterprise", Fields: []Field{
		{Name: "hostname", Label: "Hôte", Type: "string", Default: "app.terraform.io"},
		{Name: "organization", Label: "Organisation", Type: "string", Required: true},
		{Name: "workspaces", Label: "Workspaces (objet HCL)", Type: "text", Required: true, Help: `{ name = "mon-workspace" }`},
		{Name: "token", Label: "Jeton", Type: "string", Secret: true},
	}},
}

func backendType(t string) (*BackendType, error) {
	for i := range BackendTypes {
		if BackendTypes[i].Type == t {
			return &BackendTypes[i], nil
		}
	}
	return nil, fmt.Errorf("backend inconnu %q", t)
}

// BackendFor construit le backend à générer pour un environnement. withSecrets ajoute
// les champs secrets (fichier backend.hcl du runner uniquement, jamais dans l'export).
func (c *Core) BackendFor(ctx context.Context, env *Environment, withSecrets bool) (*hclgen.Backend, error) {
	bt, err := backendType(env.BackendType)
	if err != nil {
		return nil, err
	}
	if bt.TFType == "" {
		return nil, nil // backend interne : state local géré par le runner
	}
	cfg := map[string]json.RawMessage{}
	for k, v := range env.BackendConfig {
		cfg[k] = v
	}
	if withSecrets && env.BackendSecretID != nil {
		secrets, err := c.CredentialData(ctx, *env.BackendSecretID)
		if err != nil {
			return nil, fmt.Errorf("secrets du backend : %w", err)
		}
		for k, v := range secrets {
			b, _ := json.Marshal(v)
			cfg[k] = b
		}
	}
	if env.BackendType == "gitlab" {
		cfg = gitlabHTTPConfig(cfg)
	}
	// Les champs de type "text" non secrets (endpoints, workspaces) sont des objets HCL saisis
	// comme expression : ils sont écrits tels quels et non comme chaîne.
	exprs := map[string]string{}
	for _, f := range bt.Fields {
		if f.Type != "text" || f.Secret {
			continue
		}
		var s string
		if raw, ok := cfg[f.Name]; ok && json.Unmarshal(raw, &s) == nil {
			delete(cfg, f.Name)
			if strings.TrimSpace(s) != "" {
				exprs[f.Name] = s
			}
		}
	}
	return &hclgen.Backend{Type: bt.TFType, Config: cfg, Exprs: exprs}, nil
}

// gitlabHTTPConfig convertit les champs GitLab en configuration du backend http.
func gitlabHTTPConfig(cfg map[string]json.RawMessage) map[string]json.RawMessage {
	str := func(k string) string {
		var s string
		_ = json.Unmarshal(cfg[k], &s)
		return s
	}
	base := strings.TrimRight(str("gitlab_url"), "/") + "/api/v4/projects/" + str("project_id") + "/terraform/state/" + str("state_name")
	out := map[string]json.RawMessage{}
	set := func(k string, v any) {
		b, _ := json.Marshal(v)
		out[k] = b
	}
	set("address", base)
	set("lock_address", base+"/lock")
	set("unlock_address", base+"/lock")
	set("lock_method", "POST")
	set("unlock_method", "DELETE")
	set("retry_wait_min", 5)
	if u := str("username"); u != "" {
		set("username", u)
	}
	if p, ok := cfg["password"]; ok {
		out["password"] = p
	}
	return out
}

// SplitBackendConfig sépare valeurs publiques et secrètes selon la définition du backend.
func SplitBackendConfig(t string, in map[string]json.RawMessage) (public map[string]json.RawMessage, secret map[string]string, err error) {
	bt, err := backendType(t)
	if err != nil {
		return nil, nil, err
	}
	public, secret = map[string]json.RawMessage{}, map[string]string{}
	fields := map[string]Field{}
	for _, f := range bt.Fields {
		fields[f.Name] = f
	}
	for k, v := range in {
		f, ok := fields[k]
		if !ok {
			continue // champ inconnu ignoré : on n'écrit que ce qui est déclaré
		}
		if f.Secret {
			var s string
			if json.Unmarshal(v, &s) == nil && s != "" {
				secret[k] = s
			}
			continue
		}
		public[k] = v
	}
	for _, f := range bt.Fields {
		if f.Required && !f.Secret {
			if v, ok := public[f.Name]; !ok || string(v) == `""` || string(v) == "null" {
				return nil, nil, fmt.Errorf("champ obligatoire manquant : %s", f.Label)
			}
		}
	}
	return public, secret, nil
}
