// Package core regroupe les services métier partagés par l'API, le worker et le scheduler :
// accès aux projets et environnements, génération, création d'exécutions, schémas.
package core

import (
	"github.com/jackc/pgx/v5/pgxpool"

	"github.com/AZIZI-Sajjad/hcldesigner/internal/audit"
	"github.com/AZIZI-Sajjad/hcldesigner/internal/config"
	"github.com/AZIZI-Sajjad/hcldesigner/internal/notify"
	"github.com/AZIZI-Sajjad/hcldesigner/internal/settings"
	"github.com/AZIZI-Sajjad/hcldesigner/internal/tfbin"
	"github.com/AZIZI-Sajjad/hcldesigner/internal/vault"
	"github.com/AZIZI-Sajjad/hcldesigner/rules"
)

// Core porte les dépendances communes.
type Core struct {
	DB       *pgxpool.Pool
	Cfg      *config.Config
	Vault    *vault.Vault
	Settings *settings.Store
	Audit    *audit.Logger
	Notifier *notify.Notifier
	Rules    *rules.Set
	TF       *tfbin.Manager
	schemas  *schemaCache
}

func New(pool *pgxpool.Pool, cfg *config.Config, v *vault.Vault) *Core {
	st := settings.New(pool)
	return &Core{
		DB:       pool,
		Cfg:      cfg,
		Vault:    v,
		Settings: st,
		Audit:    audit.New(pool),
		Notifier: notify.New(pool, st, v, cfg.BaseURL),
		Rules:    rules.MustLoad(),
		TF:       tfbin.New(cfg.DataDir),
		schemas:  newSchemaCache(2000),
	}
}
