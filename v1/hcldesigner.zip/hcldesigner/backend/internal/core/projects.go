package core

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"time"

	"github.com/jackc/pgx/v5"

	"github.com/AZIZI-Sajjad/hcldesigner/internal/db"
	"github.com/AZIZI-Sajjad/hcldesigner/internal/model"
)

// Project est une ligne de la table projects avec son modèle décodé.
type Project struct {
	ID          string        `json:"id"`
	Name        string        `json:"name"`
	Description string        `json:"description"`
	TeamID      *string       `json:"teamId"`
	Model       model.Project `json:"model"`
	Version     int           `json:"version"`
	LockFile    string        `json:"lockFile"`
	CreatedBy   *string       `json:"createdBy"`
	CreatedAt   time.Time     `json:"createdAt"`
	UpdatedAt   time.Time     `json:"updatedAt"`
}

// ErrConflict signale une sauvegarde concurrente (verrouillage optimiste).
var ErrConflict = errors.New("le projet a été modifié entre-temps : rechargez-le")

const projectCols = `id, name, description, team_id, model, version, lock_file, created_by, created_at, updated_at`

func scanProject(row pgx.Row) (*Project, error) {
	var p Project
	var raw []byte
	if err := row.Scan(&p.ID, &p.Name, &p.Description, &p.TeamID, &raw, &p.Version, &p.LockFile, &p.CreatedBy, &p.CreatedAt, &p.UpdatedAt); err != nil {
		return nil, db.NotFound(err)
	}
	if err := json.Unmarshal(raw, &p.Model); err != nil {
		return nil, fmt.Errorf("modèle du projet illisible : %w", err)
	}
	normalize(&p.Model)
	return &p, nil
}

// normalize garantit des collections non nulles (JSON stable côté frontend).
func normalize(m *model.Project) {
	if m.Providers == nil {
		m.Providers = []model.ProviderConfig{}
	}
	if m.Nodes == nil {
		m.Nodes = []model.Node{}
	}
	if m.FileLayout.Mode == "" {
		m.FileLayout.Mode = model.LayoutStandard
	}
	if m.FileLayout.Rules == nil {
		m.FileLayout.Rules = []model.LayoutRule{}
	}
	if m.FileLayout.CustomFiles == nil {
		m.FileLayout.CustomFiles = []string{}
	}
	for i := range m.Nodes {
		if m.Nodes[i].Attrs == nil {
			m.Nodes[i].Attrs = map[string]model.Value{}
		}
	}
}

func (c *Core) GetProject(ctx context.Context, id string) (*Project, error) {
	return scanProject(c.DB.QueryRow(ctx, `SELECT `+projectCols+` FROM projects WHERE id=$1`, id))
}

// ListProjects renvoie les projets (filtrés par ids si visible != nil).
func (c *Core) ListProjects(ctx context.Context, visible []string) ([]*Project, error) {
	q := `SELECT ` + projectCols + ` FROM projects`
	args := []any{}
	if visible != nil {
		q += ` WHERE id::text = ANY($1)`
		args = append(args, visible)
	}
	rows, err := c.DB.Query(ctx, q+` ORDER BY name`, args...)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var out []*Project
	for rows.Next() {
		p, err := scanProject(rows)
		if err != nil {
			return nil, err
		}
		out = append(out, p)
	}
	return out, rows.Err()
}

func (c *Core) CreateProject(ctx context.Context, name, description, userID string, teamID *string, m model.Project) (*Project, error) {
	normalize(&m)
	raw, _ := json.Marshal(m)
	var id string
	err := pgx.BeginFunc(ctx, c.DB, func(tx pgx.Tx) error {
		if err := tx.QueryRow(ctx, `INSERT INTO projects(name, description, team_id, model, created_by) VALUES ($1,$2,$3,$4,$5) RETURNING id`,
			name, description, teamID, raw, nullable(userID)).Scan(&id); err != nil {
			return err
		}
		if _, err := tx.Exec(ctx, `INSERT INTO project_versions(project_id, version, model, message, author_id) VALUES ($1,1,$2,'création',$3)`, id, raw, nullable(userID)); err != nil {
			return err
		}
		// Un environnement "dev" est créé par défaut, backend interne.
		_, err := tx.Exec(ctx, `INSERT INTO environments(project_id, name) VALUES ($1,'dev')`, id)
		return err
	})
	if err != nil {
		return nil, err
	}
	return c.GetProject(ctx, id)
}

// SaveModel enregistre le modèle si la version attendue correspond (verrouillage optimiste)
// et historise la nouvelle version.
func (c *Core) SaveModel(ctx context.Context, id string, expectedVersion int, m model.Project, userID, message string) (*Project, error) {
	normalize(&m)
	m.SchemaVersion = model.SchemaVersion
	raw, _ := json.Marshal(m)
	err := pgx.BeginFunc(ctx, c.DB, func(tx pgx.Tx) error {
		var newVersion int
		err := tx.QueryRow(ctx, `UPDATE projects SET model=$3, version=version+1, updated_at=now() WHERE id=$1 AND version=$2 RETURNING version`,
			id, expectedVersion, raw).Scan(&newVersion)
		if errors.Is(err, pgx.ErrNoRows) {
			return ErrConflict
		}
		if err != nil {
			return err
		}
		_, err = tx.Exec(ctx, `INSERT INTO project_versions(project_id, version, model, message, author_id) VALUES ($1,$2,$3,$4,$5)`,
			id, newVersion, raw, message, nullable(userID))
		return err
	})
	if err != nil {
		return nil, err
	}
	return c.GetProject(ctx, id)
}

func nullable(s string) any {
	if s == "" {
		return nil
	}
	return s
}

// ---- Environnements ----------------------------------------------------------

// ChangeWindow : jours (1 = lundi … 7 = dimanche) et plage horaire autorisés pour apply/destroy.
type ChangeWindow struct {
	Enabled  bool   `json:"enabled"`
	Days     []int  `json:"days"`
	Start    string `json:"start"` // HH:MM
	End      string `json:"end"`
	Timezone string `json:"timezone"`
}

// Allows indique si t est dans la fenêtre.
func (w ChangeWindow) Allows(t time.Time) bool {
	if !w.Enabled {
		return true
	}
	loc, err := time.LoadLocation(w.Timezone)
	if err != nil {
		loc = time.Local
	}
	lt := t.In(loc)
	wd := int(lt.Weekday())
	if wd == 0 {
		wd = 7
	}
	dayOK := len(w.Days) == 0
	for _, d := range w.Days {
		if d == wd {
			dayOK = true
		}
	}
	if !dayOK {
		return false
	}
	hm := lt.Format("15:04")
	if w.Start != "" && hm < w.Start {
		return false
	}
	if w.End != "" && hm >= w.End {
		return false
	}
	return true
}

type Environment struct {
	ID               string                     `json:"id"`
	ProjectID        string                     `json:"projectId"`
	Name             string                     `json:"name"`
	BackendType      string                     `json:"backendType"`
	BackendConfig    map[string]json.RawMessage `json:"backendConfig"`
	BackendSecretID  *string                    `json:"backendSecretId"`
	TFVars           string                     `json:"tfvars,omitempty"`
	Workspace        string                     `json:"workspace"`
	CredentialIDs    []string                   `json:"credentialIds"`
	Protected        bool                       `json:"protected"`
	RequireApprovals int                        `json:"requireApprovals"`
	AllowDestroy     bool                       `json:"allowDestroy"`
	ChangeWindow     ChangeWindow               `json:"changeWindow"`
	CreatedAt        time.Time                  `json:"createdAt"`
}

const envCols = `id, project_id, name, backend_type, backend_config, backend_secret_id, tfvars, workspace, credential_ids::text[], protected, require_approvals, allow_destroy, change_window, created_at`

func scanEnv(row pgx.Row) (*Environment, error) {
	var e Environment
	var cfg, win []byte
	if err := row.Scan(&e.ID, &e.ProjectID, &e.Name, &e.BackendType, &cfg, &e.BackendSecretID, &e.TFVars, &e.Workspace, &e.CredentialIDs, &e.Protected, &e.RequireApprovals, &e.AllowDestroy, &win, &e.CreatedAt); err != nil {
		return nil, db.NotFound(err)
	}
	_ = json.Unmarshal(cfg, &e.BackendConfig)
	_ = json.Unmarshal(win, &e.ChangeWindow)
	if e.BackendConfig == nil {
		e.BackendConfig = map[string]json.RawMessage{}
	}
	if e.CredentialIDs == nil {
		e.CredentialIDs = []string{}
	}
	return &e, nil
}

func (c *Core) GetEnvironment(ctx context.Context, id string) (*Environment, error) {
	return scanEnv(c.DB.QueryRow(ctx, `SELECT `+envCols+` FROM environments WHERE id=$1`, id))
}

func (c *Core) ListEnvironments(ctx context.Context, projectID string) ([]*Environment, error) {
	rows, err := c.DB.Query(ctx, `SELECT `+envCols+` FROM environments WHERE project_id=$1 ORDER BY name`, projectID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var out []*Environment
	for rows.Next() {
		e, err := scanEnv(rows)
		if err != nil {
			return nil, err
		}
		out = append(out, e)
	}
	return out, rows.Err()
}

func (c *Core) SaveEnvironment(ctx context.Context, e *Environment) error {
	cfg, _ := json.Marshal(e.BackendConfig)
	win, _ := json.Marshal(e.ChangeWindow)
	if e.ID == "" {
		return c.DB.QueryRow(ctx, `INSERT INTO environments(project_id, name, backend_type, backend_config, backend_secret_id, tfvars, workspace, credential_ids, protected, require_approvals, allow_destroy, change_window)
			VALUES ($1,$2,$3,$4,$5,$6,$7,$8::uuid[],$9,$10,$11,$12) RETURNING id`,
			e.ProjectID, e.Name, e.BackendType, cfg, e.BackendSecretID, e.TFVars, e.Workspace, e.CredentialIDs, e.Protected, e.RequireApprovals, e.AllowDestroy, win).Scan(&e.ID)
	}
	_, err := c.DB.Exec(ctx, `UPDATE environments SET name=$2, backend_type=$3, backend_config=$4, backend_secret_id=$5, tfvars=$6, workspace=$7, credential_ids=$8::uuid[],
		protected=$9, require_approvals=$10, allow_destroy=$11, change_window=$12 WHERE id=$1`,
		e.ID, e.Name, e.BackendType, cfg, e.BackendSecretID, e.TFVars, e.Workspace, e.CredentialIDs, e.Protected, e.RequireApprovals, e.AllowDestroy, win)
	return err
}
