package core

import (
	"container/list"
	"context"
	"encoding/json"
	"fmt"
	"strings"
	"sync"

	"github.com/AZIZI-Sajjad/hcldesigner/internal/hclgen"
	"github.com/AZIZI-Sajjad/hcldesigner/internal/schema"
)

// schemaCache est un cache LRU des blocs de schéma (source, version, kind, type).
// Les gros schémas (AWS ~ 1 500 ressources) ne sont jamais chargés en entier.
type schemaCache struct {
	mu    sync.Mutex
	max   int
	ll    *list.List
	items map[string]*list.Element
}

type cacheEntry struct {
	key   string
	block *schema.Block
}

func newSchemaCache(max int) *schemaCache {
	return &schemaCache{max: max, ll: list.New(), items: map[string]*list.Element{}}
}

func (c *schemaCache) get(key string) (*schema.Block, bool) {
	c.mu.Lock()
	defer c.mu.Unlock()
	if el, ok := c.items[key]; ok {
		c.ll.MoveToFront(el)
		return el.Value.(*cacheEntry).block, true
	}
	return nil, false
}

func (c *schemaCache) put(key string, b *schema.Block) {
	c.mu.Lock()
	defer c.mu.Unlock()
	if el, ok := c.items[key]; ok {
		el.Value.(*cacheEntry).block = b
		c.ll.MoveToFront(el)
		return
	}
	c.items[key] = c.ll.PushFront(&cacheEntry{key, b})
	if c.ll.Len() > c.max {
		last := c.ll.Back()
		c.ll.Remove(last)
		delete(c.items, last.Value.(*cacheEntry).key)
	}
}

func (c *schemaCache) purge(source, version string) {
	c.mu.Lock()
	defer c.mu.Unlock()
	prefix := source + "|" + version + "|"
	for k, el := range c.items {
		if strings.HasPrefix(k, prefix) {
			c.ll.Remove(el)
			delete(c.items, k)
		}
	}
}

// SchemaBlock lit un bloc de schéma depuis la base (avec cache). kind = resource | data | ephemeral | provider.
func (c *Core) SchemaBlock(ctx context.Context, source, version, kind, tfType string) (*schema.Block, error) {
	source = strings.ToLower(source)
	if version == "" {
		v, err := c.LatestSchemaVersion(ctx, source)
		if err != nil {
			return nil, err
		}
		version = v
	}
	key := source + "|" + version + "|" + kind + "|" + tfType
	if b, ok := c.schemas.get(key); ok {
		return b, nil
	}
	var path []string
	switch kind {
	case "resource":
		path = []string{"resource_schemas", tfType, "block"}
	case "data":
		path = []string{"data_source_schemas", tfType, "block"}
	case "ephemeral":
		path = []string{"ephemeral_resource_schemas", tfType, "block"}
	case "provider":
		path = []string{"provider", "block"}
	default:
		return nil, fmt.Errorf("kind de schéma inconnu %q", kind)
	}
	var raw []byte
	err := c.DB.QueryRow(ctx, `SELECT schema #> $3 FROM provider_schemas WHERE source=$1 AND version=$2`, source, version, path).Scan(&raw)
	if err != nil {
		return nil, fmt.Errorf("schéma %s %s introuvable : %w", source, version, err)
	}
	var b *schema.Block
	if len(raw) > 0 && string(raw) != "null" {
		b = &schema.Block{}
		if err := json.Unmarshal(raw, b); err != nil {
			return nil, err
		}
	}
	c.schemas.put(key, b)
	return b, nil
}

// LatestSchemaVersion renvoie la version la plus récemment résolue d'un provider.
func (c *Core) LatestSchemaVersion(ctx context.Context, source string) (string, error) {
	var v string
	err := c.DB.QueryRow(ctx, `SELECT version FROM provider_schemas WHERE source=$1 ORDER BY fetched_at DESC LIMIT 1`, strings.ToLower(source)).Scan(&v)
	if err != nil {
		return "", fmt.Errorf("aucun schéma en cache pour %s (résoudre le provider d'abord)", source)
	}
	return v, nil
}

// Lookup adapte SchemaBlock à hclgen.LookupFunc (les erreurs donnent un schéma inconnu : génération sans typage).
func (c *Core) Lookup(ctx context.Context) hclgen.LookupFunc {
	return func(source, version, kind, tfType string) *schema.Block {
		b, err := c.SchemaBlock(ctx, source, version, kind, tfType)
		if err != nil {
			return nil
		}
		return b
	}
}

// StoreSchema enregistre un schéma résolu et son catalogue.
func (c *Core) StoreSchema(ctx context.Context, res *schema.FetchResult) error {
	raw, err := json.Marshal(res.Schema)
	if err != nil {
		return err
	}
	tx, err := c.DB.Begin(ctx)
	if err != nil {
		return err
	}
	defer tx.Rollback(ctx)
	if _, err := tx.Exec(ctx, `INSERT INTO provider_schemas(source, version, address, schema) VALUES ($1,$2,$3,$4)
		ON CONFLICT (source, version) DO UPDATE SET schema=EXCLUDED.schema, address=EXCLUDED.address, fetched_at=now()`,
		res.Source, res.Version, res.Address, raw); err != nil {
		return err
	}
	if _, err := tx.Exec(ctx, `DELETE FROM catalog_entries WHERE source=$1 AND version=$2`, res.Source, res.Version); err != nil {
		return err
	}
	for _, e := range res.Schema.Catalog(res.Source, res.Version) {
		if _, err := tx.Exec(ctx, `INSERT INTO catalog_entries(source, version, kind, type, category, description, deprecated) VALUES ($1,$2,$3,$4,$5,$6,$7)`,
			e.Source, e.Version, e.Kind, e.Type, e.Category, e.Description, e.Deprecated); err != nil {
			return err
		}
	}
	if err := tx.Commit(ctx); err != nil {
		return err
	}
	c.schemas.purge(res.Source, res.Version)
	return nil
}
