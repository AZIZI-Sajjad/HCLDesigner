// Package hclimport convertit du code Terraform existant (.tf) en modèle HCLDesigner.
//
// Principe : les fichiers sont analysés avec hclsyntax (aucun schéma provider n'est
// nécessaire : la syntaxe distingue déjà attributs et blocs). Une première passe crée
// un nœud par bloc (resource, data, module, variable, local, output) ; une seconde
// convertit les valeurs :
//   - constante (chaîne, nombre, objet sans interpolation)  -> valeur littérale ;
//   - référence simple vers un nœud importé (aws_vpc.main.id) -> référence (lien sur le canvas) ;
//   - liste de références / littéraux                         -> liste ;
//   - tout le reste (interpolations, fonctions, conditions)   -> expression conservée telle quelle.
//
// Ce qui n'a pas d'équivalent dans le modèle (blocs dynamic, check, removed, backend…)
// est signalé dans les diagnostics au lieu d'être perdu silencieusement.
package hclimport

import (
	"encoding/json"
	"fmt"
	"path"
	"sort"
	"strings"

	"github.com/google/uuid"
	"github.com/hashicorp/hcl/v2"
	"github.com/hashicorp/hcl/v2/hclsyntax"
	"github.com/zclconf/go-cty/cty"
	ctyjson "github.com/zclconf/go-cty/cty/json"

	"github.com/AZIZI-Sajjad/hcldesigner/internal/model"
)

// Result est le produit d'un import.
type Result struct {
	Model       model.Project      `json:"model"`
	Diagnostics []model.Diagnostic `json:"diagnostics"`
	Files       []string           `json:"files"` // fichiers .tf effectivement importés
}

// pending garde le corps HCL d'un nœud jusqu'à la conversion de ses valeurs (passe 2).
type pending struct {
	node     *model.Node // nil pour un bloc provider
	provider string      // clé du provider (aws, aws.eu) quand node est nil
	body     *hclsyntax.Body
	file     string
	src      []byte
}

type importer struct {
	files    map[string][]byte
	project  model.Project
	diags    []model.Diagnostic
	pend     []pending
	byAddr   map[string]string // adresse Terraform -> id de nœud
	provSeen map[string]bool   // clés provider déjà déclarées (aws, aws.eu)
	reqProv  map[string]model.ProviderConfig
	imports  []pendingAddr // blocs import { to, id }
	moves    []pendingAddr // blocs moved { from, to }
}

type pendingAddr struct{ to, value, file string }

// Import analyse les fichiers .tf (nom -> contenu) et construit le modèle.
func Import(files map[string][]byte) *Result {
	im := &importer{
		files:    files,
		project:  model.New(),
		byAddr:   map[string]string{},
		provSeen: map[string]bool{},
		reqProv:  map[string]model.ProviderConfig{},
	}
	names := make([]string, 0, len(files))
	for n := range files {
		names = append(names, n)
	}
	sort.Strings(names)

	// Passe 1 : blocs de premier niveau -> nœuds, providers, terraform {}.
	for _, name := range names {
		f, diags := hclsyntax.ParseConfig(files[name], name, hcl.InitialPos)
		if diags.HasErrors() {
			for _, d := range diags {
				im.diag("error", name, rangeLine(d.Subject), "syntaxe HCL : "+d.Summary, d.Detail)
			}
			continue
		}
		body := f.Body.(*hclsyntax.Body)
		for _, blk := range body.Blocks {
			im.topBlock(blk, name, files[name])
		}
	}

	// Passe 2 : valeurs (les références ont besoin de tous les nœuds).
	for _, p := range im.pend {
		im.fillNode(p)
	}
	im.applyImportsAndMoves()
	im.finishProviders()
	im.project.FileLayout = model.FileLayout{Mode: model.LayoutCustom, Rules: []model.LayoutRule{}, CustomFiles: customFiles(names)}
	layoutPositions(&im.project)

	if im.diags == nil {
		im.diags = []model.Diagnostic{}
	}
	return &Result{Model: im.project, Diagnostics: im.diags, Files: names}
}

// ---- Passe 1 ---------------------------------------------------------------------

func (im *importer) topBlock(blk *hclsyntax.Block, file string, src []byte) {
	line := blk.TypeRange.Start.Line
	switch blk.Type {
	case "resource", "data":
		if len(blk.Labels) != 2 {
			im.diag("error", file, line, fmt.Sprintf("bloc %s : deux labels attendus", blk.Type), "")
			return
		}
		kind := model.KindResource
		if blk.Type == "data" {
			kind = model.KindData
		}
		im.addNode(&model.Node{Kind: kind, Type: blk.Labels[0], Label: blk.Labels[1], File: file}, blk.Body, file, src)
	case "module":
		if len(blk.Labels) != 1 {
			im.diag("error", file, line, "bloc module : un label attendu", "")
			return
		}
		im.addNode(&model.Node{Kind: model.KindModule, Label: blk.Labels[0], File: file}, blk.Body, file, src)
	case "variable", "output":
		if len(blk.Labels) != 1 {
			im.diag("error", file, line, fmt.Sprintf("bloc %s : un label attendu", blk.Type), "")
			return
		}
		im.addNode(&model.Node{Kind: blk.Type, Label: blk.Labels[0], File: file}, blk.Body, file, src)
	case "locals":
		for _, name := range sortedAttrNames(blk.Body) {
			a := blk.Body.Attributes[name]
			body := &hclsyntax.Body{Attributes: hclsyntax.Attributes{"value": a}, SrcRange: a.SrcRange}
			im.addNode(&model.Node{Kind: model.KindLocal, Label: name, File: file}, body, file, src)
		}
	case "provider":
		if len(blk.Labels) != 1 {
			im.diag("error", file, line, "bloc provider : un label attendu", "")
			return
		}
		im.provider(blk, file, src)
	case "terraform":
		im.terraformBlock(blk, file)
	case "import":
		im.imports = append(im.imports, pendingAddr{to: exprText(attrExpr(blk.Body, "to"), src), value: literalString(attrExpr(blk.Body, "id")), file: file})
	case "moved":
		im.moves = append(im.moves, pendingAddr{to: exprText(attrExpr(blk.Body, "to"), src), value: exprText(attrExpr(blk.Body, "from"), src), file: file})
	default:
		im.diag("warning", file, line, fmt.Sprintf("bloc %q non pris en charge : ignoré", blk.Type), "Blocs gérés : terraform, provider, resource, data, module, variable, locals, output, import, moved.")
	}
}

func (im *importer) addNode(n *model.Node, body *hclsyntax.Body, file string, src []byte) {
	n.ID = uuid.NewString()
	n.Attrs = map[string]model.Value{}
	if !model.LabelRegexp.MatchString(n.Label) {
		im.diag("error", file, body.SrcRange.Start.Line, fmt.Sprintf("label %q invalide : bloc ignoré", n.Label), "")
		return
	}
	addr := n.Address()
	if _, dup := im.byAddr[addr]; dup {
		im.diag("error", file, body.SrcRange.Start.Line, fmt.Sprintf("%s déclaré plusieurs fois : doublon ignoré", addr), "")
		return
	}
	im.project.Nodes = append(im.project.Nodes, *n)
	im.byAddr[addr] = n.ID
	im.pend = append(im.pend, pending{node: n, body: body, file: file, src: src})
}

func (im *importer) provider(blk *hclsyntax.Block, file string, src []byte) {
	pc := model.ProviderConfig{LocalName: blk.Labels[0], Config: map[string]model.Value{}}
	if a := blk.Body.Attributes["alias"]; a != nil {
		pc.Alias = literalString(a.Expr)
	}
	if im.provSeen[pc.Key()] {
		im.diag("error", file, blk.TypeRange.Start.Line, fmt.Sprintf("provider %s déclaré plusieurs fois", pc.Key()), "")
		return
	}
	im.provSeen[pc.Key()] = true
	im.project.Providers = append(im.project.Providers, pc)
	// Les valeurs du provider peuvent référencer des variables : converties en passe 2.
	im.pend = append(im.pend, pending{provider: pc.Key(), body: blk.Body, file: file, src: src})
}

func (im *importer) terraformBlock(blk *hclsyntax.Block, file string) {
	if a := blk.Body.Attributes["required_version"]; a != nil {
		im.project.RequiredVer = literalString(a.Expr)
	}
	for _, sub := range blk.Body.Blocks {
		switch sub.Type {
		case "required_providers":
			for _, name := range sortedAttrNames(sub.Body) {
				pc := model.ProviderConfig{LocalName: name, Source: "hashicorp/" + name}
				val, diags := sub.Body.Attributes[name].Expr.Value(nil)
				switch {
				case diags.HasErrors():
					im.diag("warning", file, sub.Body.Attributes[name].SrcRange.Start.Line, "required_providers."+name+" non constant : ignoré", "")
					continue
				case val.Type() == cty.String: // ancienne syntaxe : aws = "~> 4.0"
					pc.Version = val.AsString()
				case val.Type().IsObjectType():
					if val.Type().HasAttribute("source") {
						pc.Source = strings.ToLower(val.GetAttr("source").AsString())
					}
					if val.Type().HasAttribute("version") {
						pc.Version = val.GetAttr("version").AsString()
					}
				}
				pc.Source = shortSource(pc.Source)
				im.reqProv[name] = pc
			}
		case "backend", "cloud":
			kind := sub.Type
			if len(sub.Labels) == 1 {
				kind += " " + quote(sub.Labels[0])
			}
			im.diag("warning", file, sub.TypeRange.Start.Line, kind+" ignoré", "Le backend se configure par environnement (onglet Environnements), avec les secrets dans le coffre.")
		}
	}
}

// ---- Passe 2 ---------------------------------------------------------------------

func (im *importer) fillNode(p pending) {
	if p.node == nil {
		im.fillProvider(p.provider, p)
		return
	}
	n := im.nodePtr(p.node.ID)
	if n == nil {
		return
	}
	ctx := convCtx{im: im, file: p.file, src: p.src, nodeID: n.ID}
	switch n.Kind {
	case model.KindResource, model.KindData:
		im.fillMeta(n, p.body, ctx)
		n.Attrs = ctx.attrs(p.body, metaArgs)
		n.Blocks = ctx.blocks(p.body, map[string]bool{"lifecycle": true})
	case model.KindModule:
		im.fillMeta(n, p.body, ctx)
		n.Module = moduleRef(p.body)
		if n.Module.SourceKind == "local" {
			ctx.warn(p.body.SrcRange.Start.Line, fmt.Sprintf("module %s : source locale %q non importée", n.Label, n.Module.Source), "Le dossier du module n'est pas copié : le créer comme module interne ou le publier sur un registry / dépôt Git.")
		}
		n.Type = n.Module.Source
		n.Attrs = ctx.attrs(p.body, map[string]bool{"source": true, "version": true, "count": true, "for_each": true, "depends_on": true, "providers": true})
		if len(p.body.Blocks) > 0 {
			ctx.warn(p.body.SrcRange.Start.Line, "module "+n.Label+" : blocs imbriqués ignorés", "")
		}
	case model.KindVariable:
		for _, k := range []string{"default", "description", "sensitive", "nullable", "ephemeral"} {
			if a := p.body.Attributes[k]; a != nil {
				n.Attrs[k] = ctx.value(a.Expr, k)
			}
		}
		if a := p.body.Attributes["type"]; a != nil {
			// Le type est une expression de type (string, list(object({...}))) : conservé en texte.
			n.Attrs["type"] = literal(exprText(a.Expr, p.src))
		}
		for _, vb := range p.body.Blocks {
			if vb.Type != "validation" {
				continue
			}
			b := model.Block{Attrs: map[string]model.Value{}}
			if a := vb.Body.Attributes["condition"]; a != nil {
				b.Attrs["condition"] = model.Value{Mode: model.ModeExpr, Expr: exprText(a.Expr, p.src)}
			}
			if a := vb.Body.Attributes["error_message"]; a != nil {
				b.Attrs["error_message"] = ctx.value(a.Expr, "error_message")
			}
			if n.Blocks == nil {
				n.Blocks = map[string][]model.Block{}
			}
			n.Blocks["validation"] = append(n.Blocks["validation"], b)
		}
	case model.KindLocal:
		n.Attrs["value"] = ctx.value(p.body.Attributes["value"].Expr, "value")
	case model.KindOutput:
		for _, k := range []string{"value", "description", "sensitive", "ephemeral"} {
			if a := p.body.Attributes[k]; a != nil {
				n.Attrs[k] = ctx.value(a.Expr, k)
			}
		}
		n.Meta.DependsOn = ctx.dependsOn(p.body)
		if len(p.body.Blocks) > 0 {
			ctx.warn(p.body.SrcRange.Start.Line, "output "+n.Label+" : precondition ignorée", "")
		}
	}
}

// metaArgs ne sont pas des arguments du provider : traités par fillMeta.
var metaArgs = map[string]bool{"count": true, "for_each": true, "provider": true, "depends_on": true}

func (im *importer) fillMeta(n *model.Node, body *hclsyntax.Body, ctx convCtx) {
	if a := body.Attributes["count"]; a != nil {
		v := ctx.value(a.Expr, "count")
		n.Meta.Count = &v
	}
	if a := body.Attributes["for_each"]; a != nil {
		v := ctx.value(a.Expr, "for_each")
		n.Meta.ForEach = &v
	}
	if a := body.Attributes["provider"]; a != nil {
		n.Provider = exprText(a.Expr, ctx.src)
	}
	if a := body.Attributes["providers"]; a != nil && n.Kind == model.KindModule {
		// providers = { aws = aws.eu } : seule la forme à un alias est représentée dans le modèle.
		if obj, ok := a.Expr.(*hclsyntax.ObjectConsExpr); ok && len(obj.Items) == 1 {
			n.Provider = exprText(obj.Items[0].ValueExpr, ctx.src)
		} else {
			ctx.warn(a.SrcRange.Start.Line, "module "+n.Label+" : providers à plusieurs entrées non repris", "")
		}
	}
	n.Meta.DependsOn = ctx.dependsOn(body)
	for _, b := range body.Blocks {
		if b.Type == "lifecycle" {
			n.Meta.Lifecycle, n.Meta.Conditions = ctx.lifecycle(b.Body)
		}
	}
}

func (im *importer) fillProvider(key string, p pending) {
	ctx := convCtx{im: im, file: p.file, src: p.src}
	for i := range im.project.Providers {
		pc := &im.project.Providers[i]
		if pc.Key() != key {
			continue
		}
		pc.Config = ctx.attrs(p.body, map[string]bool{"alias": true})
		if blks := ctx.blocks(p.body, nil); len(blks) > 0 {
			pc.ConfigBlks = blks
		}
	}
}

// applyImportsAndMoves rattache les blocs import / moved aux nœuds visés.
func (im *importer) applyImportsAndMoves() {
	for _, i := range im.imports {
		n := im.nodePtr(im.byAddr[i.to])
		if n == nil || n.Kind != model.KindResource || i.value == "" {
			im.diag("warning", i.file, 0, fmt.Sprintf("import vers %q non repris (cible absente ou id non littéral)", i.to), "")
			continue
		}
		n.ImportID = i.value
	}
	for _, m := range im.moves {
		n := im.nodePtr(im.byAddr[m.to])
		if n == nil {
			im.diag("warning", m.file, 0, fmt.Sprintf("moved vers %q non repris (cible absente)", m.to), "")
			continue
		}
		n.MovedFrom = m.value
	}
}

// finishProviders complète source/version depuis required_providers et ajoute
// les providers seulement implicites (utilisés par des ressources sans bloc provider).
func (im *importer) finishProviders() {
	used := map[string]bool{}
	for i := range im.project.Providers {
		used[im.project.Providers[i].LocalName] = true
	}
	for name := range im.reqProv {
		used[name] = true
	}
	for _, n := range im.project.Nodes {
		if n.Kind == model.KindResource || n.Kind == model.KindData {
			used[strings.SplitN(n.Type, "_", 2)[0]] = true
		}
	}
	names := make([]string, 0, len(used))
	for name := range used {
		names = append(names, name)
	}
	sort.Strings(names)
	for _, name := range names {
		if !im.provSeen[name] {
			im.project.Providers = append(im.project.Providers, model.ProviderConfig{LocalName: name, Config: map[string]model.Value{}})
			im.provSeen[name] = true
		}
	}
	for i := range im.project.Providers {
		pc := &im.project.Providers[i]
		req, ok := im.reqProv[pc.LocalName]
		if ok {
			pc.Source, pc.Version = req.Source, req.Version
		} else {
			pc.Source = "hashicorp/" + pc.LocalName
		}
		if pc.Config == nil {
			pc.Config = map[string]model.Value{}
		}
	}
	sort.SliceStable(im.project.Providers, func(a, b int) bool {
		return im.project.Providers[a].Key() < im.project.Providers[b].Key()
	})
}

// ---- Conversion des valeurs -------------------------------------------------------------

type convCtx struct {
	im     *importer
	file   string
	src    []byte
	nodeID string
}

func (c convCtx) warn(line int, summary, detail string) {
	c.im.diags = append(c.im.diags, model.Diagnostic{Severity: "warning", NodeID: c.nodeID, File: c.file, Line: line, Summary: summary, Detail: detail})
}

// attrs convertit les attributs d'un corps, sauf ceux de skip.
func (c convCtx) attrs(body *hclsyntax.Body, skip map[string]bool) map[string]model.Value {
	out := map[string]model.Value{}
	for _, name := range sortedAttrNames(body) {
		if skip[name] {
			continue
		}
		out[name] = c.value(body.Attributes[name].Expr, name)
	}
	return out
}

// blocks convertit les blocs imbriqués (récursivement), sauf ceux de skip.
func (c convCtx) blocks(body *hclsyntax.Body, skip map[string]bool) map[string][]model.Block {
	var out map[string][]model.Block
	for _, b := range body.Blocks {
		if skip[b.Type] {
			continue
		}
		if b.Type == "dynamic" {
			c.warn(b.TypeRange.Start.Line, "bloc dynamic "+strings.Join(b.Labels, " ")+" ignoré", "Les blocs dynamic n'ont pas d'équivalent sur le canvas : à recréer en blocs statiques ou en module.")
			continue
		}
		if len(b.Labels) > 0 { // provisioner "remote-exec", etc.
			c.warn(b.TypeRange.Start.Line, "bloc "+b.Type+" "+strings.Join(b.Labels, " ")+" ignoré", "Les provisioners et blocs à label ne sont pas représentés sur le canvas.")
			continue
		}
		if out == nil {
			out = map[string][]model.Block{}
		}
		out[b.Type] = append(out[b.Type], model.Block{Attrs: c.attrs(b.Body, nil), Blocks: c.blocks(b.Body, nil)})
	}
	return out
}

func (c convCtx) dependsOn(body *hclsyntax.Body) []string {
	a := body.Attributes["depends_on"]
	if a == nil {
		return nil
	}
	tup, ok := a.Expr.(*hclsyntax.TupleConsExpr)
	if !ok {
		c.warn(a.SrcRange.Start.Line, "depends_on non littéral ignoré", "")
		return nil
	}
	var ids []string
	for _, e := range tup.Exprs {
		addr := exprText(e, c.src)
		if id, ok := c.im.byAddr[addr]; ok {
			ids = append(ids, id)
		} else {
			c.warn(a.SrcRange.Start.Line, "depends_on : "+addr+" introuvable", "")
		}
	}
	return ids
}

func (c convCtx) lifecycle(body *hclsyntax.Body) (*model.Lifecycle, []model.Condition) {
	lc := &model.Lifecycle{IgnoreChanges: []string{}, ReplaceTriggeredBy: []string{}}
	if a := body.Attributes["create_before_destroy"]; a != nil {
		lc.CreateBeforeDestroy = literalBool(a.Expr)
	}
	if a := body.Attributes["prevent_destroy"]; a != nil {
		lc.PreventDestroy = literalBool(a.Expr)
	}
	if a := body.Attributes["ignore_changes"]; a != nil {
		if tup, ok := a.Expr.(*hclsyntax.TupleConsExpr); ok {
			for _, e := range tup.Exprs {
				lc.IgnoreChanges = append(lc.IgnoreChanges, exprText(e, c.src))
			}
		} else if exprText(a.Expr, c.src) == "all" {
			lc.IgnoreAll = true
		}
	}
	if a := body.Attributes["replace_triggered_by"]; a != nil {
		if tup, ok := a.Expr.(*hclsyntax.TupleConsExpr); ok {
			for _, e := range tup.Exprs {
				lc.ReplaceTriggeredBy = append(lc.ReplaceTriggeredBy, exprText(e, c.src))
			}
		}
	}
	var conds []model.Condition
	for _, b := range body.Blocks {
		if b.Type != "precondition" && b.Type != "postcondition" {
			continue
		}
		cond := model.Condition{Kind: b.Type}
		if a := b.Body.Attributes["condition"]; a != nil {
			cond.Condition = exprText(a.Expr, c.src)
		}
		if a := b.Body.Attributes["error_message"]; a != nil {
			cond.ErrorMessage = literalString(a.Expr)
		}
		conds = append(conds, cond)
	}
	return lc, conds
}

// value convertit une expression : littéral, référence, liste ou expression brute.
func (c convCtx) value(e hclsyntax.Expression, _ string) model.Value {
	if v, ok := constValue(e); ok {
		return v
	}
	if ref := c.ref(e); ref != nil {
		return model.Value{Mode: model.ModeRef, Ref: ref}
	}
	if tup, ok := e.(*hclsyntax.TupleConsExpr); ok {
		items := make([]model.Value, 0, len(tup.Exprs))
		simple := true
		for _, it := range tup.Exprs {
			v := c.value(it, "")
			if v.Mode == model.ModeExpr {
				simple = false
				break
			}
			items = append(items, v)
		}
		if simple {
			return model.Value{Mode: model.ModeList, Items: items}
		}
	}
	return model.Value{Mode: model.ModeExpr, Expr: exprText(e, c.src)}
}

// ref reconnaît x.y.attr, x.y[0].attr, x.y["k"].attr, x.y[*].attr, var.x, local.x, module.m.out.
func (c convCtx) ref(e hclsyntax.Expression) *model.Ref {
	indexMode := ""
	var trav hcl.Traversal
	switch ex := e.(type) {
	case *hclsyntax.ScopeTraversalExpr:
		trav = ex.Traversal
	case *hclsyntax.SplatExpr: // aws_subnet.a[*].id
		src, ok := ex.Source.(*hclsyntax.ScopeTraversalExpr)
		if !ok {
			return nil
		}
		trav = src.Traversal
		indexMode = "splat"
		if each, ok := ex.Each.(*hclsyntax.RelativeTraversalExpr); ok {
			if _, isAnon := each.Source.(*hclsyntax.AnonSymbolExpr); !isAnon {
				return nil
			}
			trav = append(append(hcl.Traversal{}, trav...), each.Traversal...)
		} else if _, isAnon := ex.Each.(*hclsyntax.AnonSymbolExpr); !isAnon {
			return nil
		}
	default:
		return nil
	}
	steps := traversalSteps(trav)
	if steps == nil {
		return nil
	}
	// Longueur de l'adresse de base selon le préfixe.
	baseLen := 2
	switch steps[0].name {
	case "data":
		baseLen = 3
	case "count", "each", "path", "self", "terraform":
		return nil
	}
	if len(steps) < baseLen {
		return nil
	}
	parts := make([]string, baseLen)
	for i := 0; i < baseLen; i++ {
		if steps[i].name == "" {
			return nil
		}
		parts[i] = steps[i].name
	}
	id, ok := c.im.byAddr[strings.Join(parts, ".")]
	if !ok {
		return nil
	}
	rest := steps[baseLen:]
	ref := &model.Ref{NodeID: id, IndexMode: indexMode}
	if indexMode == "" && len(rest) > 0 && rest[0].name == "" { // index juste après l'adresse
		if rest[0].isNum {
			ref.IndexMode, ref.Index = "index", rest[0].key
		} else {
			ref.IndexMode, ref.Index = "key", rest[0].key
		}
		rest = rest[1:]
	}
	ref.Attr = joinSteps(rest)
	if parts[0] == "var" || parts[0] == "local" {
		if ref.Attr != "" || ref.IndexMode != "" {
			return nil // var.x.y : expression, la référence simple ne porte pas de chemin
		}
	}
	return ref
}

type step struct {
	name  string // nom d'attribut ; vide pour un index
	key   string // clé d'index
	isNum bool
}

func traversalSteps(t hcl.Traversal) []step {
	var out []step
	for _, s := range t {
		switch tt := s.(type) {
		case hcl.TraverseRoot:
			out = append(out, step{name: tt.Name})
		case hcl.TraverseAttr:
			out = append(out, step{name: tt.Name})
		case hcl.TraverseIndex:
			switch {
			case tt.Key.Type() == cty.Number:
				out = append(out, step{key: tt.Key.AsBigFloat().Text('f', -1), isNum: true})
			case tt.Key.Type() == cty.String:
				out = append(out, step{key: tt.Key.AsString()})
			default:
				return nil
			}
		default:
			return nil
		}
	}
	return out
}

// joinSteps reconstruit un chemin d'attribut : a.b[0].c
func joinSteps(steps []step) string {
	var b strings.Builder
	for _, s := range steps {
		switch {
		case s.name != "":
			if b.Len() > 0 {
				b.WriteByte('.')
			}
			b.WriteString(s.name)
		case s.isNum:
			b.WriteString("[" + s.key + "]")
		default:
			b.WriteString("[" + quote(s.key) + "]")
		}
	}
	return b.String()
}

// ---- Utilitaires ---------------------------------------------------------------------------

// constValue renvoie la valeur littérale d'une expression sans variable ni fonction.
func constValue(e hclsyntax.Expression) (model.Value, bool) {
	if len(e.Variables()) > 0 {
		return model.Value{}, false
	}
	if _, isFunc := e.(*hclsyntax.FunctionCallExpr); isFunc {
		return model.Value{}, false
	}
	v, diags := e.Value(nil)
	if diags.HasErrors() || !v.IsWhollyKnown() {
		return model.Value{}, false
	}
	if v.IsNull() {
		return model.Value{Mode: model.ModeNull}, true
	}
	raw, err := ctyjson.SimpleJSONValue{Value: v}.MarshalJSON()
	if err != nil {
		return model.Value{}, false
	}
	return model.Value{Mode: model.ModeLiteral, Value: raw}, true
}

func literal(v any) model.Value {
	raw, _ := json.Marshal(v)
	return model.Value{Mode: model.ModeLiteral, Value: raw}
}

func literalString(e hclsyntax.Expression) string {
	if e == nil {
		return ""
	}
	v, diags := e.Value(nil)
	if diags.HasErrors() || v.IsNull() || !v.IsKnown() || v.Type() != cty.String {
		return ""
	}
	return v.AsString()
}

func literalBool(e hclsyntax.Expression) bool {
	v, diags := e.Value(nil)
	return !diags.HasErrors() && v.Type() == cty.Bool && v.IsKnown() && v.True()
}

func attrExpr(body *hclsyntax.Body, name string) hclsyntax.Expression {
	if a := body.Attributes[name]; a != nil {
		return a.Expr
	}
	return nil
}

// exprText renvoie le texte source exact d'une expression.
func exprText(e hclsyntax.Expression, src []byte) string {
	if e == nil {
		return ""
	}
	r := e.Range()
	if r.Start.Byte < 0 || r.End.Byte > len(src) || r.Start.Byte > r.End.Byte {
		return ""
	}
	return strings.TrimSpace(string(src[r.Start.Byte:r.End.Byte]))
}

func sortedAttrNames(body *hclsyntax.Body) []string {
	names := make([]string, 0, len(body.Attributes))
	for n := range body.Attributes {
		names = append(names, n)
	}
	sort.Strings(names)
	return names
}

func (im *importer) nodePtr(id string) *model.Node {
	for i := range im.project.Nodes {
		if im.project.Nodes[i].ID == id {
			return &im.project.Nodes[i]
		}
	}
	return nil
}

func (im *importer) diag(sev, file string, line int, summary, detail string) {
	im.diags = append(im.diags, model.Diagnostic{Severity: sev, File: file, Line: line, Summary: summary, Detail: detail})
}

func rangeLine(r *hcl.Range) int {
	if r == nil {
		return 0
	}
	return r.Start.Line
}

// moduleRef déduit le type de source d'un module.
func moduleRef(body *hclsyntax.Body) *model.ModuleRef {
	m := &model.ModuleRef{Source: literalString(attrExpr(body, "source")), Version: literalString(attrExpr(body, "version"))}
	s := m.Source
	switch {
	case strings.HasPrefix(s, "./") || strings.HasPrefix(s, "../") || strings.HasPrefix(s, "/"):
		m.SourceKind = "local"
	case strings.HasPrefix(s, "git::") || strings.HasPrefix(s, "github.com/") || strings.HasPrefix(s, "gitlab.com/") ||
		strings.HasPrefix(s, "bitbucket.org/") || strings.HasPrefix(s, "git@") || strings.Contains(s, ".git") || strings.Contains(s, "?ref="):
		m.SourceKind = "git"
	default:
		m.SourceKind = "registry"
	}
	return m
}

// shortSource retire le préfixe registry.terraform.io/ (forme normalisée du catalogue).
func shortSource(s string) string {
	s = strings.TrimPrefix(strings.ToLower(s), "registry.terraform.io/")
	return strings.TrimPrefix(s, "registry.opentofu.org/")
}

func customFiles(names []string) []string {
	out := []string{}
	for _, n := range names {
		out = append(out, path.Base(n))
	}
	return out
}

func quote(s string) string {
	b, _ := json.Marshal(s)
	return string(b)
}
