package hclimport

import (
	"archive/zip"
	"bytes"
	"fmt"
	"io"
	"path"
	"sort"
	"strings"

	"github.com/AZIZI-Sajjad/hcldesigner/internal/model"
)

// Limites de l'import (protection contre les archives piégées).
const (
	MaxFiles      = 500
	MaxTotalBytes = 50 << 20 // contenu décompressé
)

// Upload est un fichier reçu (fichier .tf isolé ou archive .zip).
type Upload struct {
	Name string
	Data []byte
}

// Collect sélectionne les fichiers .tf à importer.
//
// Dans une archive, seul le dossier racine du projet est retenu : le dossier le moins
// profond qui contient des .tf (les sous-dossiers sont en général des modules locaux,
// signalés dans les diagnostics). Les .tf.json, .tfvars et autres fichiers sont ignorés.
func Collect(uploads []Upload) (map[string][]byte, []model.Diagnostic, error) {
	type entry struct {
		dir, name string
		data      []byte
	}
	var entries []entry
	var diags []model.Diagnostic
	total := 0

	add := func(full string, data []byte) error {
		total += len(data)
		if total > MaxTotalBytes {
			return fmt.Errorf("contenu trop volumineux (%d Mo maximum)", MaxTotalBytes>>20)
		}
		if len(entries) >= MaxFiles {
			return fmt.Errorf("trop de fichiers (%d maximum)", MaxFiles)
		}
		full = strings.TrimPrefix(path.Clean("/"+strings.ReplaceAll(full, "\\", "/")), "/")
		entries = append(entries, entry{dir: path.Dir(full), name: path.Base(full), data: data})
		return nil
	}
	skipped := map[string]int{}

	for _, u := range uploads {
		switch {
		case strings.HasSuffix(strings.ToLower(u.Name), ".zip"):
			zr, err := zip.NewReader(bytes.NewReader(u.Data), int64(len(u.Data)))
			if err != nil {
				return nil, nil, fmt.Errorf("%s : archive zip illisible : %w", u.Name, err)
			}
			for _, f := range zr.File {
				name := f.Name
				if f.FileInfo().IsDir() || isHidden(name) {
					continue
				}
				if !strings.HasSuffix(name, ".tf") {
					skipped[path.Ext(name)]++
					continue
				}
				rc, err := f.Open()
				if err != nil {
					return nil, nil, fmt.Errorf("%s : %w", name, err)
				}
				// Lecture bornée : la taille annoncée dans l'en-tête zip n'est pas fiable.
				data, err := io.ReadAll(io.LimitReader(rc, MaxTotalBytes-int64(total)+1))
				rc.Close()
				if err != nil {
					return nil, nil, fmt.Errorf("%s : %w", name, err)
				}
				if err := add(name, data); err != nil {
					return nil, nil, err
				}
			}
		case strings.HasSuffix(u.Name, ".tf"):
			if err := add(path.Base(u.Name), u.Data); err != nil {
				return nil, nil, err
			}
		default:
			skipped[path.Ext(u.Name)]++
		}
	}
	if len(entries) == 0 {
		return nil, nil, fmt.Errorf("aucun fichier .tf trouvé")
	}

	// Dossier racine = le moins profond contenant des .tf (à profondeur égale : ordre alphabétique).
	root := entries[0].dir
	for _, e := range entries[1:] {
		if depthOf(e.dir) < depthOf(root) || (depthOf(e.dir) == depthOf(root) && e.dir < root) {
			root = e.dir
		}
	}
	files := map[string][]byte{}
	other := map[string]bool{}
	for _, e := range entries {
		if e.dir != root {
			other[e.dir] = true
			continue
		}
		if _, dup := files[e.name]; dup {
			return nil, nil, fmt.Errorf("fichier %s fourni plusieurs fois", e.name)
		}
		files[e.name] = e.data
	}
	dirs := make([]string, 0, len(other))
	for d := range other {
		dirs = append(dirs, d)
	}
	sort.Strings(dirs)
	for _, d := range dirs {
		diags = append(diags, model.Diagnostic{Severity: "warning", Summary: "dossier " + d + " non importé",
			Detail: "Seul le dossier racine (" + root + ") est converti. Un sous-dossier est souvent un module local : l'importer séparément puis l'extraire en module interne."})
	}
	for ext, n := range skipped {
		if ext == "" {
			ext = "(sans extension)"
		}
		diags = append(diags, model.Diagnostic{Severity: "info", Summary: fmt.Sprintf("%d fichier(s) %s ignoré(s)", n, ext)})
	}
	sort.SliceStable(diags, func(i, j int) bool { return diags[i].Summary < diags[j].Summary })
	return files, diags, nil
}

func depthOf(dir string) int {
	if dir == "." {
		return 0
	}
	return strings.Count(dir, "/") + 1
}

// isHidden écarte .terraform/, .git/, __MACOSX/ et fichiers cachés.
func isHidden(name string) bool {
	for _, part := range strings.Split(name, "/") {
		if strings.HasPrefix(part, ".") || part == "__MACOSX" {
			return true
		}
	}
	return false
}
