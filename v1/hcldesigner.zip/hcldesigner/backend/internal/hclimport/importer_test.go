package hclimport

import (
	"archive/zip"
	"bytes"
	"strings"
	"testing"

	"github.com/hashicorp/hcl/v2"
	"github.com/hashicorp/hcl/v2/hclsyntax"

	"github.com/AZIZI-Sajjad/hcldesigner/internal/hclgen"
	"github.com/AZIZI-Sajjad/hcldesigner/internal/model"
)

const versionsTF = `
terraform {
  required_version = ">= 1.6"
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.0"
    }
  }
  backend "s3" {
    bucket = "tfstate"
  }
}

provider "aws" {
  region = var.region
}

provider "aws" {
  alias  = "eu"
  region = "eu-west-3"
}
`

const mainTF = `
variable "region" {
  type    = string
  default = "eu-west-1"
}

variable "cidr" {
  type = string
  default = "10.0.0.0/16"
  validation {
    condition     = can(cidrhost(var.cidr, 0))
    error_message = "CIDR invalide."
  }
}

locals {
  name = "demo-${var.region}"
}

resource "aws_vpc" "main" {
  cidr_block = var.cidr
  tags = {
    Name = local.name
  }
}

resource "aws_subnet" "a" {
  count             = 2
  vpc_id            = aws_vpc.main.id
  cidr_block        = cidrsubnet(var.cidr, 8, count.index)
  availability_zone = "eu-west-1a"
}

resource "aws_security_group" "web" {
  name   = "web"
  vpc_id = aws_vpc.main.id

  ingress {
    from_port   = 443
    to_port     = 443
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }

  dynamic "egress" {
    for_each = [1]
    content {}
  }
}

data "aws_ami" "debian" {
  most_recent = true
  owners      = ["136693071363"]
}

resource "aws_instance" "web" {
  provider               = aws.eu
  ami                    = data.aws_ami.debian.id
  instance_type          = "t3.micro"
  subnet_id              = aws_subnet.a[0].id
  vpc_security_group_ids = [aws_security_group.web.id]

  lifecycle {
    create_before_destroy = true
    ignore_changes        = [tags]
  }

  depends_on = [aws_vpc.main]
}

module "s3" {
  source  = "terraform-aws-modules/s3-bucket/aws"
  version = "4.1.0"
  bucket  = "${local.name}-logs"
}

output "subnet_ids" {
  value = aws_subnet.a[*].id
}

import {
  to = aws_vpc.main
  id = "vpc-123"
}

check "health" {
  assert {
    condition     = true
    error_message = "x"
  }
}
`

func nodeByAddr(t *testing.T, p *model.Project, addr string) *model.Node {
	t.Helper()
	for i := range p.Nodes {
		if p.Nodes[i].Address() == addr {
			return &p.Nodes[i]
		}
	}
	t.Fatalf("nœud %s absent", addr)
	return nil
}

func TestImport(t *testing.T) {
	res := Import(map[string][]byte{"versions.tf": []byte(versionsTF), "main.tf": []byte(mainTF)})
	p := &res.Model

	// Nœuds : 2 variables, 1 local, 5 ressources/data, 1 module, 1 output.
	if got := len(p.Nodes); got != 10 {
		t.Fatalf("10 nœuds attendus, %d obtenus", got)
	}
	if p.RequiredVer != ">= 1.6" {
		t.Errorf("required_version : %q", p.RequiredVer)
	}
	if len(p.Providers) != 2 || p.Providers[0].Key() != "aws" || p.Providers[1].Key() != "aws.eu" {
		t.Fatalf("providers : %+v", p.Providers)
	}
	if p.Providers[0].Source != "hashicorp/aws" || p.Providers[0].Version != "~> 5.0" {
		t.Errorf("source/version : %+v", p.Providers[0])
	}
	if r := p.Providers[0].Config["region"]; r.Mode != model.ModeRef {
		t.Errorf("provider.region doit référencer var.region : %+v", r)
	}

	vpc := nodeByAddr(t, p, "aws_vpc.main")
	if vpc.File != "main.tf" || vpc.ImportID != "vpc-123" {
		t.Errorf("vpc : file=%q importId=%q", vpc.File, vpc.ImportID)
	}
	if v := vpc.Attrs["cidr_block"]; v.Mode != model.ModeRef || v.Ref.Attr != "" {
		t.Errorf("cidr_block : %+v", v)
	}
	if v := vpc.Attrs["tags"]; v.Mode != model.ModeExpr {
		t.Errorf("tags (contient local.name) doit rester une expression : %+v", v)
	}

	subnet := nodeByAddr(t, p, "aws_subnet.a")
	if subnet.Meta.Count == nil || string(subnet.Meta.Count.Value) != "2" {
		t.Errorf("count : %+v", subnet.Meta.Count)
	}
	if v := subnet.Attrs["vpc_id"]; v.Mode != model.ModeRef || v.Ref.NodeID != vpc.ID || v.Ref.Attr != "id" {
		t.Errorf("vpc_id : %+v", v)
	}

	web := nodeByAddr(t, p, "aws_instance.web")
	if web.Provider != "aws.eu" {
		t.Errorf("provider : %q", web.Provider)
	}
	if v := web.Attrs["subnet_id"]; v.Ref == nil || v.Ref.IndexMode != "index" || v.Ref.Index != "0" || v.Ref.Attr != "id" {
		t.Errorf("subnet_id : %+v", v)
	}
	if v := web.Attrs["vpc_security_group_ids"]; v.Mode != model.ModeList || len(v.Items) != 1 || v.Items[0].Mode != model.ModeRef {
		t.Errorf("vpc_security_group_ids : %+v", v)
	}
	if web.Meta.Lifecycle == nil || !web.Meta.Lifecycle.CreateBeforeDestroy || len(web.Meta.Lifecycle.IgnoreChanges) != 1 {
		t.Errorf("lifecycle : %+v", web.Meta.Lifecycle)
	}
	if len(web.Meta.DependsOn) != 1 || web.Meta.DependsOn[0] != vpc.ID {
		t.Errorf("depends_on : %v", web.Meta.DependsOn)
	}

	sg := nodeByAddr(t, p, "aws_security_group.web")
	if len(sg.Blocks["ingress"]) != 1 || len(sg.Blocks["egress"]) != 0 {
		t.Errorf("blocs : %+v", sg.Blocks)
	}

	mod := nodeByAddr(t, p, "module.s3")
	if mod.Module == nil || mod.Module.SourceKind != "registry" || mod.Module.Version != "4.1.0" {
		t.Errorf("module : %+v", mod.Module)
	}

	out := nodeByAddr(t, p, "output.subnet_ids")
	if v := out.Attrs["value"]; v.Ref == nil || v.Ref.IndexMode != "splat" || v.Ref.Attr != "id" {
		t.Errorf("output splat : %+v", v)
	}

	// Liens : références + adresses citées dans les expressions (cidrsubnet(var.cidr…), "${local.name}").
	kinds := map[string]int{}
	for _, e := range p.Edges() {
		kinds[e.Kind]++
	}
	if kinds["ref"] == 0 || kinds["expr"] == 0 || kinds["depends_on"] != 1 {
		t.Errorf("liens : %v", kinds)
	}

	// Diagnostics attendus : backend ignoré, dynamic ignoré, check non pris en charge.
	wants := []string{"backend", "dynamic", "check"}
	for _, w := range wants {
		found := false
		for _, d := range res.Diagnostics {
			if strings.Contains(d.Summary, w) {
				found = true
			}
		}
		if !found {
			t.Errorf("diagnostic %q absent : %+v", w, res.Diagnostics)
		}
	}
	if diags := p.Validate(); len(diags) > 0 {
		t.Errorf("modèle importé invalide : %+v", diags)
	}

	// Aller-retour : le code régénéré est du HCL valide et garde les fichiers d'origine.
	gen := hclgen.Generate(p, nil, hclgen.Options{})
	for _, d := range gen.Diags {
		if d.Severity == "error" {
			t.Errorf("génération : %+v", d)
		}
	}
	mainOut, ok := gen.Files["main.tf"]
	if !ok {
		t.Fatalf("main.tf absent : %v", keys(gen.Files))
	}
	for name, content := range gen.Files {
		if _, diags := hclsyntax.ParseConfig([]byte(content), name, hcl.InitialPos); diags.HasErrors() {
			t.Errorf("%s régénéré invalide : %v\n%s", name, diags, content)
		}
	}
	for _, want := range []string{
		"subnet_id              = aws_subnet.a[0].id",
		"cidr_block        = cidrsubnet(var.cidr, 8, count.index)",
		"provider = aws.eu",
		"vpc_security_group_ids = [aws_security_group.web.id]",
	} {
		if !strings.Contains(mainOut, want) {
			t.Errorf("main.tf régénéré ne contient pas %q :\n%s", want, mainOut)
		}
	}
}

func TestCollectZip(t *testing.T) {
	var buf bytes.Buffer
	zw := zip.NewWriter(&buf)
	for name, body := range map[string]string{
		"infra/main.tf":              `resource "null_resource" "a" {}`,
		"infra/variables.tf":         `variable "x" {}`,
		"infra/modules/net/main.tf":  `resource "null_resource" "b" {}`,
		"infra/.terraform/x/main.tf": `bad`,
		"infra/terraform.tfvars":     `x = 1`,
		"__MACOSX/infra/._main.tf":   `bad`,
	} {
		w, _ := zw.Create(name)
		_, _ = w.Write([]byte(body))
	}
	_ = zw.Close()

	files, diags, err := Collect([]Upload{{Name: "repo.zip", Data: buf.Bytes()}})
	if err != nil {
		t.Fatal(err)
	}
	if len(files) != 2 || files["main.tf"] == nil || files["variables.tf"] == nil {
		t.Fatalf("fichiers retenus : %v", keys(files))
	}
	joined := ""
	for _, d := range diags {
		joined += d.Summary + "\n"
	}
	if !strings.Contains(joined, "infra/modules/net") || !strings.Contains(joined, ".tfvars") {
		t.Errorf("diagnostics : %s", joined)
	}
}

func keys[V any](m map[string]V) []string {
	out := make([]string, 0, len(m))
	for k := range m {
		out = append(out, k)
	}
	return out
}
