package hclimport

import (
	"sort"

	"github.com/AZIZI-Sajjad/hcldesigner/internal/model"
)

// Espacement de la grille initiale (la carte d'un nœud fait environ 224 x 80 px).
const (
	colWidth  = 320
	rowHeight = 130
)

// layoutPositions place les nœuds en colonnes selon leur profondeur de dépendance :
// colonne 0 = nœuds sans dépendance (variables, VPC…), puis chaque consommateur à droite
// de ce qu'il référence. L'utilisateur peut ensuite lancer la disposition automatique (ELK).
func layoutPositions(p *model.Project) {
	preds := map[string][]string{}
	for _, e := range p.Edges() {
		if e.Source != e.Target {
			preds[e.Target] = append(preds[e.Target], e.Source)
		}
	}
	depth := map[string]int{}
	visiting := map[string]bool{}
	var visit func(id string) int
	visit = func(id string) int {
		if d, ok := depth[id]; ok {
			return d
		}
		if visiting[id] { // cycle : signalé par la validation du modèle, on coupe ici
			return 0
		}
		visiting[id] = true
		d := 0
		for _, src := range preds[id] {
			if v := visit(src) + 1; v > d {
				d = v
			}
		}
		visiting[id] = false
		depth[id] = d
		return d
	}

	cols := map[int][]*model.Node{}
	for i := range p.Nodes {
		n := &p.Nodes[i]
		d := visit(n.ID)
		if n.Kind == model.KindOutput { // les outputs à droite de tout ce qu'ils exposent
			d++
		}
		cols[d] = append(cols[d], n)
	}
	for d, nodes := range cols {
		sort.SliceStable(nodes, func(i, j int) bool {
			if nodes[i].Kind != nodes[j].Kind {
				return nodes[i].Kind < nodes[j].Kind
			}
			return nodes[i].Address() < nodes[j].Address()
		})
		for row, n := range nodes {
			n.Position = model.Position{X: float64(d * colWidth), Y: float64(row * rowHeight)}
		}
	}
}
