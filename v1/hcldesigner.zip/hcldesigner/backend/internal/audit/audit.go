// Package audit écrit le journal d'audit (table append-only) et le relaie en syslog si configuré.
package audit

import (
	"context"
	"encoding/json"
	"fmt"
	"log/slog"
	"net"
	"sync"
	"time"

	"github.com/jackc/pgx/v5/pgxpool"
)

type Event struct {
	UserID     string
	Username   string
	IP         string
	Action     string // ex: project.update, run.apply, role.create
	ObjectType string
	ObjectID   string
	Details    any // diff avant/après, paramètres...
}

type Logger struct {
	pool   *pgxpool.Pool
	mu     sync.Mutex
	syslog string // hôte:port UDP, vide = désactivé
}

func New(pool *pgxpool.Pool) *Logger { return &Logger{pool: pool} }

// SetSyslog active l'export syslog UDP (Wazuh, Graylog...).
func (l *Logger) SetSyslog(addr string) {
	l.mu.Lock()
	l.syslog = addr
	l.mu.Unlock()
}

// Log enregistre un événement ; une erreur d'audit est journalisée mais ne bloque pas l'action.
func (l *Logger) Log(ctx context.Context, e Event) {
	details, err := json.Marshal(e.Details)
	if err != nil || e.Details == nil {
		details = []byte("{}")
	}
	var uid any
	if e.UserID != "" {
		uid = e.UserID
	}
	if _, err := l.pool.Exec(ctx, `INSERT INTO audit_events(user_id, username, ip, action, object_type, object_id, details) VALUES ($1,$2,$3,$4,$5,$6,$7)`,
		uid, e.Username, e.IP, e.Action, e.ObjectType, e.ObjectID, details); err != nil {
		slog.Error("audit : écriture impossible", "err", err, "action", e.Action)
	}
	l.mu.Lock()
	addr := l.syslog
	l.mu.Unlock()
	if addr != "" {
		go sendSyslog(addr, e, details)
	}
}

func sendSyslog(addr string, e Event, details []byte) {
	conn, err := net.DialTimeout("udp", addr, 3*time.Second)
	if err != nil {
		return
	}
	defer conn.Close()
	// RFC 5424, facility local0 (16), severity notice (5) => PRI 133
	msg := fmt.Sprintf("<133>1 %s hcldesigner hcldesigner - audit - user=%q ip=%q action=%q object=%s/%s details=%s",
		time.Now().UTC().Format(time.RFC3339), e.Username, e.IP, e.Action, e.ObjectType, e.ObjectID, details)
	_, _ = conn.Write([]byte(msg))
}
