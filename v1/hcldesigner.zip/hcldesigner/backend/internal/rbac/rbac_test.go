package rbac

import "testing"

// Matrice permissions × portées : un "Opérateur dev" ne peut pas appliquer en prod.
func TestScopes(t *testing.T) {
	op := &Subject{Bindings: []Binding{
		{Perms: []Permission{"projects.view", "runs.plan", "runs.apply"}, Scope: ScopeEnvironment, ProjectID: "p1", Environment: "dev"},
		{Perms: []Permission{"runs.plan"}, Scope: ScopeEnvironment, ProjectID: "p1", Environment: "prod"},
	}}
	cases := []struct {
		perm    Permission
		project string
		env     string
		want    bool
	}{
		{"runs.apply", "p1", "dev", true},
		{"runs.apply", "p1", "prod", false},
		{"runs.plan", "p1", "prod", true},
		{"runs.destroy", "p1", "dev", false},
		{"projects.view", "p1", "", true}, // attribution environnement => lecture du projet
		{"runs.apply", "p1", "", false},
		{"projects.view", "p2", "", false},
		{"admin.users", "", "", false},
	}
	for _, c := range cases {
		if got := op.Can(c.perm, c.project, c.env); got != c.want {
			t.Errorf("Can(%s,%s,%s) = %v, attendu %v", c.perm, c.project, c.env, got, c.want)
		}
	}
	admin := &Subject{Bindings: []Binding{{Perms: []Permission{All}, Scope: ScopeGlobal}}}
	if !admin.Can("runs.destroy", "p9", "prod") {
		t.Error("* global doit tout autoriser")
	}
	if vis := op.VisibleProjects(); len(vis) != 1 || vis[0] != "p1" {
		t.Errorf("projets visibles : %v", vis)
	}
}

func TestBuiltinPermsAreKnown(t *testing.T) {
	for _, r := range Builtins {
		for _, p := range r.Perms {
			if !Known(p) {
				t.Errorf("rôle %s : permission inconnue %s", r.Name, p)
			}
		}
	}
}
