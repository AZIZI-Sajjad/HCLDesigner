package schema

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"time"

	"github.com/hashicorp/hcl/v2"
	"github.com/hashicorp/hcl/v2/hclsyntax"
)

// FetchResult est le résultat d'une résolution de provider.
type FetchResult struct {
	Source   string          `json:"source"`
	Address  string          `json:"address"`
	Version  string          `json:"version"`
	Schema   *ProviderSchema `json:"-"`
	LockFile string          `json:"-"`
}

// Fetch résout un provider (source + contrainte) dans un workspace temporaire,
// puis extrait son schéma. bin = binaire terraform/tofu, env = environnement d'exécution.
func Fetch(ctx context.Context, bin string, env []string, workRoot, localName, source, constraint string) (*FetchResult, error) {
	dir, err := os.MkdirTemp(workRoot, "schema-*")
	if err != nil {
		return nil, err
	}
	defer os.RemoveAll(dir)
	if localName == "" {
		localName = source[strings.LastIndex(source, "/")+1:]
	}
	var b strings.Builder
	b.WriteString("terraform {\n  required_providers {\n")
	fmt.Fprintf(&b, "    %s = {\n      source = %q\n", localName, source)
	if constraint != "" {
		fmt.Fprintf(&b, "      version = %q\n", constraint)
	}
	b.WriteString("    }\n  }\n}\n")
	if err := os.WriteFile(filepath.Join(dir, "versions.tf"), []byte(b.String()), 0o644); err != nil {
		return nil, err
	}
	run := func(timeout time.Duration, args ...string) ([]byte, error) {
		c, cancel := context.WithTimeout(ctx, timeout)
		defer cancel()
		cmd := exec.CommandContext(c, bin, args...)
		cmd.Dir = dir
		cmd.Env = env
		var stdout, stderr bytes.Buffer
		cmd.Stdout, cmd.Stderr = &stdout, &stderr
		if err := cmd.Run(); err != nil {
			return nil, fmt.Errorf("%s %s : %v\n%s%s", filepath.Base(bin), strings.Join(args, " "), err, stderr.String(), tail(stdout.String(), 2000))
		}
		return stdout.Bytes(), nil
	}
	if _, err := run(15*time.Minute, "init", "-input=false", "-no-color", "-backend=false"); err != nil {
		return nil, err
	}
	out, err := run(5*time.Minute, "providers", "schema", "-json")
	if err != nil {
		return nil, err
	}
	var full ProvidersSchemaJSON
	if err := json.Unmarshal(out, &full); err != nil {
		return nil, fmt.Errorf("décodage du schéma : %w", err)
	}
	ps, addr, err := full.FindProvider(source)
	if err != nil {
		return nil, err
	}
	lock, _ := os.ReadFile(filepath.Join(dir, ".terraform.lock.hcl"))
	versions, _ := ParseLockFile(lock)
	return &FetchResult{Source: strings.ToLower(source), Address: addr, Version: versions[strings.ToLower(addr)], Schema: ps, LockFile: string(lock)}, nil
}

// ParseLockFile renvoie adresse provider -> version depuis un .terraform.lock.hcl.
func ParseLockFile(src []byte) (map[string]string, error) {
	out := map[string]string{}
	if len(src) == 0 {
		return out, nil
	}
	f, diags := hclsyntax.ParseConfig(src, ".terraform.lock.hcl", hcl.InitialPos)
	if diags.HasErrors() {
		return out, diags
	}
	body := f.Body.(*hclsyntax.Body)
	for _, blk := range body.Blocks {
		if blk.Type != "provider" || len(blk.Labels) != 1 {
			continue
		}
		if a, ok := blk.Body.Attributes["version"]; ok {
			v, d := a.Expr.Value(nil)
			if !d.HasErrors() && v.Type().FriendlyName() == "string" {
				out[strings.ToLower(blk.Labels[0])] = v.AsString()
			}
		}
	}
	return out, nil
}

func tail(s string, n int) string {
	if len(s) <= n {
		return s
	}
	return s[len(s)-n:]
}
