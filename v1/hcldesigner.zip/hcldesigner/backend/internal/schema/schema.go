// Package schema récupère, normalise et interroge les schémas de providers
// obtenus via `terraform providers schema -json`.
package schema

import (
	"encoding/json"
	"fmt"
	"sort"
	"strings"
)

// ProvidersSchemaJSON est la sortie de `terraform providers schema -json`.
type ProvidersSchemaJSON struct {
	FormatVersion   string                     `json:"format_version"`
	ProviderSchemas map[string]*ProviderSchema `json:"provider_schemas"`
}

type ProviderSchema struct {
	Provider          *Schema                    `json:"provider,omitempty"`
	ResourceSchemas   map[string]*Schema         `json:"resource_schemas,omitempty"`
	DataSourceSchemas map[string]*Schema         `json:"data_source_schemas,omitempty"`
	EphemeralSchemas  map[string]*Schema         `json:"ephemeral_resource_schemas,omitempty"`
	Functions         map[string]json.RawMessage `json:"functions,omitempty"`
}

type Schema struct {
	Version int    `json:"version"`
	Block   *Block `json:"block"`
}

type Block struct {
	Attributes      map[string]*Attribute `json:"attributes,omitempty"`
	BlockTypes      map[string]*BlockType `json:"block_types,omitempty"`
	Description     string                `json:"description,omitempty"`
	DescriptionKind string                `json:"description_kind,omitempty"`
	Deprecated      bool                  `json:"deprecated,omitempty"`
}

type Attribute struct {
	Type            json.RawMessage `json:"type,omitempty"`
	NestedType      *NestedType     `json:"nested_type,omitempty"`
	Description     string          `json:"description,omitempty"`
	DescriptionKind string          `json:"description_kind,omitempty"`
	Required        bool            `json:"required,omitempty"`
	Optional        bool            `json:"optional,omitempty"`
	Computed        bool            `json:"computed,omitempty"`
	Sensitive       bool            `json:"sensitive,omitempty"`
	Deprecated      bool            `json:"deprecated,omitempty"`
	WriteOnly       bool            `json:"write_only,omitempty"`
}

type NestedType struct {
	Attributes  map[string]*Attribute `json:"attributes"`
	NestingMode string                `json:"nesting_mode"`
	MinItems    int                   `json:"min_items,omitempty"`
	MaxItems    int                   `json:"max_items,omitempty"`
}

type BlockType struct {
	NestingMode string `json:"nesting_mode"`
	Block       *Block `json:"block"`
	MinItems    int    `json:"min_items,omitempty"`
	MaxItems    int    `json:"max_items,omitempty"`
}

// TypeString renvoie une représentation lisible du type cty (string, list(string), ...).
func TypeString(raw json.RawMessage) string {
	if len(raw) == 0 {
		return "dynamic"
	}
	var s string
	if json.Unmarshal(raw, &s) == nil {
		return s
	}
	var arr []json.RawMessage
	if json.Unmarshal(raw, &arr) != nil || len(arr) == 0 {
		return "dynamic"
	}
	var kind string
	_ = json.Unmarshal(arr[0], &kind)
	switch kind {
	case "list", "set", "map":
		if len(arr) > 1 {
			return kind + "(" + TypeString(arr[1]) + ")"
		}
	case "object":
		var attrs map[string]json.RawMessage
		if len(arr) > 1 && json.Unmarshal(arr[1], &attrs) == nil {
			keys := make([]string, 0, len(attrs))
			for k := range attrs {
				keys = append(keys, k)
			}
			sort.Strings(keys)
			parts := make([]string, 0, len(keys))
			for _, k := range keys {
				parts = append(parts, k+"="+TypeString(attrs[k]))
			}
			return "object({" + strings.Join(parts, ", ") + "})"
		}
	case "tuple":
		var elems []json.RawMessage
		if len(arr) > 1 && json.Unmarshal(arr[1], &elems) == nil {
			parts := make([]string, 0, len(elems))
			for _, e := range elems {
				parts = append(parts, TypeString(e))
			}
			return "tuple([" + strings.Join(parts, ", ") + "])"
		}
	}
	return kind
}

// IsStringish : string, list(string) ou set(string) — types typiquement référençables.
func IsStringish(t string) bool {
	return t == "string" || t == "list(string)" || t == "set(string)"
}

// IsCollection : list(...) ou set(...).
func IsCollection(t string) bool {
	return strings.HasPrefix(t, "list(") || strings.HasPrefix(t, "set(")
}

// ElemType renvoie le type élément d'une collection.
func ElemType(t string) string {
	if i := strings.Index(t, "("); i > 0 && strings.HasSuffix(t, ")") {
		return t[i+1 : len(t)-1]
	}
	return t
}

// Compatible indique si un attribut source de type src peut alimenter un argument de type dst.
func Compatible(src, dst string) bool {
	if src == "dynamic" || dst == "dynamic" || src == dst {
		return true
	}
	if IsCollection(dst) && ElemType(dst) == src {
		return true // ajout d'un élément dans la liste
	}
	if IsCollection(dst) && IsCollection(src) && ElemType(dst) == ElemType(src) {
		return true
	}
	// number/bool -> string : conversion implicite Terraform
	if dst == "string" && (src == "number" || src == "bool") {
		return true
	}
	return false
}

// AttrInfo est une vue aplatie d'un attribut (utilisée par le moteur de connexion et le panneau de liaison).
type AttrInfo struct {
	Name        string `json:"name"`
	Type        string `json:"type"`
	Required    bool   `json:"required"`
	Optional    bool   `json:"optional"`
	Computed    bool   `json:"computed"`
	Sensitive   bool   `json:"sensitive"`
	Deprecated  bool   `json:"deprecated"`
	Description string `json:"description,omitempty"`
}

// Attrs renvoie les attributs de premier niveau triés par nom.
func (b *Block) Attrs() []AttrInfo {
	if b == nil {
		return nil
	}
	out := make([]AttrInfo, 0, len(b.Attributes))
	for name, a := range b.Attributes {
		t := TypeString(a.Type)
		if a.NestedType != nil {
			t = "nested(" + a.NestedType.NestingMode + ")"
		}
		out = append(out, AttrInfo{
			Name: name, Type: t, Required: a.Required, Optional: a.Optional, Computed: a.Computed,
			Sensitive: a.Sensitive, Deprecated: a.Deprecated, Description: a.Description,
		})
	}
	sort.Slice(out, func(i, j int) bool { return out[i].Name < out[j].Name })
	return out
}

// RequiredBlocks renvoie les blocs imbriqués avec min_items > 0.
func (b *Block) RequiredBlocks() []string {
	var out []string
	if b == nil {
		return out
	}
	for name, bt := range b.BlockTypes {
		if bt.MinItems > 0 {
			out = append(out, name)
		}
	}
	sort.Strings(out)
	return out
}

// Category devine une catégorie fonctionnelle à partir du type de ressource.
func Category(tfType string) string {
	t := tfType
	if i := strings.Index(t, "_"); i > 0 {
		t = t[i+1:]
	}
	checks := []struct {
		cat  string
		keys []string
	}{
		{"security", []string{"security_group", "firewall", "waf", "network_security", "nsg", "kms", "key_vault", "secret", "certificate", "acm", "shield", "guardduty", "policy_attachment"}},
		{"iam", []string{"iam", "role", "policy", "user", "group", "service_account", "identity", "access"}},
		{"network", []string{"vpc", "subnet", "route", "gateway", "network", "vnet", "peering", "eip", "nat", "vpn", "lb", "load_balancer", "elb", "alb", "nic", "interface", "public_ip", "endpoint", "transit", "dvs", "port_group", "nsxt", "edge"}},
		{"dns", []string{"route53", "dns", "record", "zone", "domain"}},
		{"compute", []string{"instance", "virtual_machine", "vm", "compute", "launch", "autoscaling", "scale_set", "lambda", "function", "container", "ecs", "batch", "lxc", "vapp", "host"}},
		{"kubernetes", []string{"eks", "aks", "gke", "kubernetes", "cluster", "deployment", "namespace", "pod", "ingress", "config_map", "helm"}},
		{"database", []string{"db_", "rds", "database", "sql", "dynamodb", "redis", "elasticache", "cosmos", "postgres", "mysql", "mongo", "bigtable", "spanner"}},
		{"storage", []string{"s3", "bucket", "storage", "disk", "volume", "ebs", "efs", "blob", "file_share", "datastore", "backup", "snapshot"}},
		{"monitoring", []string{"cloudwatch", "monitor", "log", "alarm", "metric", "insights", "sns", "alert"}},
		{"messaging", []string{"sqs", "queue", "topic", "pubsub", "eventhub", "servicebus", "kinesis", "event"}},
	}
	for _, c := range checks {
		for _, k := range c.keys {
			if strings.Contains(t, k) {
				return c.cat
			}
		}
	}
	return "other"
}

// ProviderPrefix renvoie le préfixe provider d'un type (aws_instance -> aws).
func ProviderPrefix(tfType string) string {
	if i := strings.Index(tfType, "_"); i > 0 {
		return tfType[:i]
	}
	return tfType
}

// ShortSource normalise une adresse de provider : registry.terraform.io/hashicorp/aws -> hashicorp/aws.
func ShortSource(addr string) string {
	parts := strings.Split(addr, "/")
	if len(parts) == 3 {
		return parts[1] + "/" + parts[2]
	}
	return addr
}

// FindProvider cherche dans la sortie JSON l'entrée correspondant à source (hashicorp/aws).
func (p *ProvidersSchemaJSON) FindProvider(source string) (*ProviderSchema, string, error) {
	src := strings.ToLower(source)
	for addr, ps := range p.ProviderSchemas {
		a := strings.ToLower(addr)
		if a == src || ShortSource(a) == src || strings.HasSuffix(a, "/"+src) {
			return ps, addr, nil
		}
	}
	return nil, "", fmt.Errorf("provider %s absent de la sortie du schéma", source)
}

// CatalogEntry est une ligne du catalogue (index plein texte).
type CatalogEntry struct {
	Source      string `json:"source"`
	Version     string `json:"version"`
	Kind        string `json:"kind"` // resource | data | ephemeral
	Type        string `json:"type"`
	Category    string `json:"category"`
	Description string `json:"description"`
	Deprecated  bool   `json:"deprecated"`
}

// Catalog construit les entrées du catalogue pour un provider.
func (ps *ProviderSchema) Catalog(source, version string) []CatalogEntry {
	var out []CatalogEntry
	add := func(kind string, m map[string]*Schema) {
		for t, s := range m {
			desc, dep := "", false
			if s != nil && s.Block != nil {
				desc, dep = s.Block.Description, s.Block.Deprecated
			}
			if len(desc) > 400 {
				desc = desc[:400] + "…"
			}
			out = append(out, CatalogEntry{Source: source, Version: version, Kind: kind, Type: t, Category: Category(t), Description: desc, Deprecated: dep})
		}
	}
	add("resource", ps.ResourceSchemas)
	add("data", ps.DataSourceSchemas)
	add("ephemeral", ps.EphemeralSchemas)
	sort.Slice(out, func(i, j int) bool {
		if out[i].Kind != out[j].Kind {
			return out[i].Kind < out[j].Kind
		}
		return out[i].Type < out[j].Type
	})
	return out
}
