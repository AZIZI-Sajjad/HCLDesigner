// Package tfbin installe et localise les binaires Terraform / OpenTofu,
// et produit la configuration CLI (cache de plugins, mirrors de providers).
package tfbin

import (
	"archive/zip"
	"bufio"
	"context"
	"crypto/sha256"
	"encoding/hex"
	"errors"
	"fmt"
	"io"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"regexp"
	"runtime"
	"strings"
	"sync"
	"time"
)

type MirrorConfig struct {
	Mode string `json:"mode"` // none | filesystem | network
	Path string `json:"path"`
	URL  string `json:"url"`
}

type Manager struct {
	DataDir          string
	TerraformURL     string // modèle d'URL, {v} = version, {os}, {arch}
	TofuURL          string
	PreinstalledTF   string // binaire présent dans l'image (TERRAFORM_BIN)
	PreinstalledTofu string
	HTTPClient       *http.Client
	mu               sync.Mutex
}

func New(dataDir string) *Manager {
	return &Manager{
		DataDir:          dataDir,
		TerraformURL:     envOr("HCLD_TERRAFORM_URL", "https://releases.hashicorp.com/terraform/{v}/terraform_{v}_{os}_{arch}.zip"),
		TofuURL:          envOr("HCLD_TOFU_URL", "https://github.com/opentofu/opentofu/releases/download/v{v}/tofu_{v}_{os}_{arch}.zip"),
		PreinstalledTF:   os.Getenv("TERRAFORM_BIN"),
		PreinstalledTofu: os.Getenv("TOFU_BIN"),
		HTTPClient:       &http.Client{Timeout: 10 * time.Minute},
	}
}

func envOr(k, d string) string {
	if v := os.Getenv(k); v != "" {
		return v
	}
	return d
}

var versionRe = regexp.MustCompile(`v?(\d+\.\d+\.\d+(?:-[0-9A-Za-z.]+)?)`)

// BinaryVersion exécute `<bin> version` et renvoie la version.
func BinaryVersion(ctx context.Context, bin string) (string, error) {
	ctx, cancel := context.WithTimeout(ctx, 20*time.Second)
	defer cancel()
	out, err := exec.CommandContext(ctx, bin, "version").Output()
	if err != nil {
		return "", err
	}
	line := strings.SplitN(string(out), "\n", 2)[0]
	m := versionRe.FindStringSubmatch(line)
	if m == nil {
		return "", fmt.Errorf("version illisible : %q", line)
	}
	return m[1], nil
}

// Resolve renvoie le chemin du binaire pour engine (terraform|opentofu) et version ("" = binaire préinstallé).
func (m *Manager) Resolve(ctx context.Context, engine, version string) (string, error) {
	if engine == "" {
		engine = "terraform"
	}
	pre := m.PreinstalledTF
	name := "terraform"
	tmpl := m.TerraformURL
	if engine == "opentofu" {
		pre, name, tmpl = m.PreinstalledTofu, "tofu", m.TofuURL
	}
	if pre != "" {
		if version == "" {
			return pre, nil
		}
		if v, err := BinaryVersion(ctx, pre); err == nil && v == version {
			return pre, nil
		}
	}
	if version == "" {
		if p, err := exec.LookPath(name); err == nil {
			return p, nil
		}
		return "", fmt.Errorf("aucun binaire %s préinstallé et aucune version demandée", name)
	}
	m.mu.Lock()
	defer m.mu.Unlock()
	dir := filepath.Join(m.DataDir, "bin", engine+"_"+version)
	bin := filepath.Join(dir, name)
	if st, err := os.Stat(bin); err == nil && st.Mode()&0o111 != 0 {
		return bin, nil
	}
	url := strings.NewReplacer("{v}", version, "{os}", runtime.GOOS, "{arch}", runtime.GOARCH).Replace(tmpl)
	if err := m.download(ctx, url, dir, name); err != nil {
		return "", fmt.Errorf("installation %s %s : %w", engine, version, err)
	}
	return bin, nil
}

func (m *Manager) download(ctx context.Context, url, dir, name string) error {
	if err := os.MkdirAll(dir, 0o755); err != nil {
		return err
	}
	tmp, err := os.CreateTemp(dir, "dl-*.zip")
	if err != nil {
		return err
	}
	defer os.Remove(tmp.Name())
	req, _ := http.NewRequestWithContext(ctx, http.MethodGet, url, nil)
	resp, err := m.HTTPClient.Do(req)
	if err != nil {
		return err
	}
	defer resp.Body.Close()
	if resp.StatusCode != 200 {
		return fmt.Errorf("téléchargement %s : HTTP %d", url, resp.StatusCode)
	}
	h := sha256.New()
	if _, err := io.Copy(io.MultiWriter(tmp, h), resp.Body); err != nil {
		return err
	}
	tmp.Close()
	sum := hex.EncodeToString(h.Sum(nil))
	if err := m.verifyChecksum(ctx, url, sum); err != nil {
		return err
	}
	zr, err := zip.OpenReader(tmp.Name())
	if err != nil {
		return err
	}
	defer zr.Close()
	for _, f := range zr.File {
		if filepath.Base(f.Name) != name {
			continue
		}
		rc, err := f.Open()
		if err != nil {
			return err
		}
		out, err := os.OpenFile(filepath.Join(dir, name), os.O_CREATE|os.O_WRONLY|os.O_TRUNC, 0o755)
		if err != nil {
			rc.Close()
			return err
		}
		_, err = io.Copy(out, rc)
		rc.Close()
		out.Close()
		return err
	}
	return errors.New("binaire absent de l'archive")
}

// verifyChecksum télécharge le fichier SHA256SUMS publié à côté de l'archive s'il existe.
func (m *Manager) verifyChecksum(ctx context.Context, url, sum string) error {
	base := url[:strings.LastIndex(url, "/")+1]
	file := url[strings.LastIndex(url, "/")+1:]
	parts := strings.Split(file, "_")
	if len(parts) < 2 {
		return nil
	}
	candidates := []string{
		base + parts[0] + "_" + parts[1] + "_SHA256SUMS",
	}
	for _, c := range candidates {
		req, _ := http.NewRequestWithContext(ctx, http.MethodGet, c, nil)
		resp, err := m.HTTPClient.Do(req)
		if err != nil {
			continue
		}
		if resp.StatusCode != 200 {
			resp.Body.Close()
			continue
		}
		sc := bufio.NewScanner(resp.Body)
		for sc.Scan() {
			f := strings.Fields(sc.Text())
			if len(f) == 2 && f[1] == file {
				resp.Body.Close()
				if f[0] != sum {
					return fmt.Errorf("somme SHA256 invalide pour %s", file)
				}
				return nil
			}
		}
		resp.Body.Close()
	}
	return nil // pas de fichier de sommes publié : on accepte (mirror interne)
}

// CLIConfig écrit un fichier de configuration CLI et renvoie son chemin.
func (m *Manager) CLIConfig(dir string, mirror MirrorConfig) (string, error) {
	cache := filepath.Join(m.DataDir, "plugin-cache")
	if err := os.MkdirAll(cache, 0o755); err != nil {
		return "", err
	}
	var b strings.Builder
	fmt.Fprintf(&b, "plugin_cache_dir = %q\n", cache)
	b.WriteString("plugin_cache_may_break_dependency_lock_file = true\n")
	switch mirror.Mode {
	case "filesystem":
		fmt.Fprintf(&b, "provider_installation {\n  filesystem_mirror {\n    path = %q\n  }\n}\n", mirror.Path)
	case "network":
		fmt.Fprintf(&b, "provider_installation {\n  network_mirror {\n    url = %q\n  }\n}\n", mirror.URL)
	}
	path := filepath.Join(dir, ".terraformrc")
	return path, os.WriteFile(path, []byte(b.String()), 0o600)
}

// BaseEnv renvoie l'environnement minimal pour exécuter terraform (sans hériter des secrets du process).
func BaseEnv(cliConfig string) []string {
	env := []string{
		"PATH=" + os.Getenv("PATH"),
		"HOME=" + filepath.Dir(cliConfig),
		"TF_IN_AUTOMATION=1",
		"TF_INPUT=0",
		"CHECKPOINT_DISABLE=1",
		"TF_CLI_CONFIG_FILE=" + cliConfig,
	}
	for _, k := range []string{"HTTPS_PROXY", "HTTP_PROXY", "NO_PROXY", "https_proxy", "http_proxy", "no_proxy", "SSL_CERT_FILE", "SSL_CERT_DIR"} {
		if v := os.Getenv(k); v != "" {
			env = append(env, k+"="+v)
		}
	}
	return env
}
