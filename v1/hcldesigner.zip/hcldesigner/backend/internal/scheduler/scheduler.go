// Package scheduler exécute les tâches planifiées (cron), l'envoi des notifications,
// l'expiration des plans et la rétention des données.
package scheduler

import (
	"bytes"
	"context"
	"encoding/csv"
	"encoding/json"
	"fmt"
	"log/slog"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"time"

	"github.com/robfig/cron/v3"

	"github.com/AZIZI-Sajjad/hcldesigner/internal/core"
	"github.com/AZIZI-Sajjad/hcldesigner/internal/notify"
	"github.com/AZIZI-Sajjad/hcldesigner/internal/policy"
	"github.com/AZIZI-Sajjad/hcldesigner/internal/runner"
)

// Types de tâches.
const (
	TaskDrift        = "drift"
	TaskPlan         = "plan"
	TaskApplyPlan    = "apply_plan"
	TaskDestroy      = "destroy_ephemeral"
	TaskUpgrade      = "upgrade"
	TaskStateBackup  = "state_backup"
	TaskCompliance   = "compliance_scan"
	TaskReportExport = "report_export"
)

// TaskKinds : catalogue exposé au frontend.
var TaskKinds = []struct {
	Kind        string `json:"kind"`
	Label       string `json:"label"`
	NeedsEnv    bool   `json:"needsEnv"`
	Description string `json:"description"`
}{
	{TaskDrift, "Détection de drift", true, "plan périodique ; alerte si l'infrastructure a été modifiée hors Terraform"},
	{TaskPlan, "Plan périodique", true, "plan simple, apply automatique optionnel (paramètre autoApply) si aucune approbation n'est requise"},
	{TaskApplyPlan, "Apply planifié d'un plan approuvé", true, "fenêtre de maintenance : applique le plan indiqué (paramètre planRunId) puis se désactive"},
	{TaskDestroy, "Destroy d'environnement éphémère", true, "plan -destroy ; appliqué automatiquement si l'environnement n'exige aucune approbation"},
	{TaskUpgrade, "Mise à jour providers et modules", true, "init -upgrade + plan, avec rapport"},
	{TaskStateBackup, "Sauvegarde du state", true, "state pull chiffré et versionné"},
	{TaskCompliance, "Scan de conformité", false, "évalue les règles sur les modèles et envoie le rapport (paramètre recipients)"},
	{TaskReportExport, "Rapport des exécutions (CSV)", false, "export CSV des exécutions des N derniers jours (paramètres days, recipients)"},
}

type taskParams struct {
	PlanRunID  string   `json:"planRunId"`
	AutoApply  bool     `json:"autoApply"`
	Recipients []string `json:"recipients"`
	Days       int      `json:"days"`
}

var cronParser = cron.NewParser(cron.Minute | cron.Hour | cron.Dom | cron.Month | cron.Dow | cron.Descriptor)

// NextRun calcule la prochaine exécution d'une expression cron dans un fuseau donné.
func NextRun(expr, tz string, from time.Time) (time.Time, error) {
	loc, err := time.LoadLocation(tz)
	if err != nil {
		return time.Time{}, fmt.Errorf("fuseau horaire inconnu %q", tz)
	}
	sched, err := cronParser.Parse(expr)
	if err != nil {
		return time.Time{}, fmt.Errorf("expression cron invalide : %w", err)
	}
	return sched.Next(from.In(loc)), nil
}

type Scheduler struct {
	core       *core.Core
	lockAlerts sync.Map // run id -> déjà signalé
}

func New(c *core.Core) *Scheduler { return &Scheduler{core: c} }

// Run exécute les boucles périodiques jusqu'à l'annulation du contexte.
func (s *Scheduler) Run(ctx context.Context) {
	slog.Info("scheduler démarré")
	fast := time.NewTicker(15 * time.Second)
	slow := time.NewTicker(time.Hour)
	defer fast.Stop()
	defer slow.Stop()
	s.housekeeping(ctx)
	for {
		select {
		case <-ctx.Done():
			return
		case <-fast.C:
			s.runDueTasks(ctx)
			s.core.Notifier.ProcessOutbox(ctx)
			s.expirePlans(ctx)
			s.detectStuckLocks(ctx)
			s.digests(ctx)
		case <-slow.C:
			s.housekeeping(ctx)
		}
	}
}

func (s *Scheduler) runDueTasks(ctx context.Context) {
	rows, err := s.core.DB.Query(ctx, `SELECT id FROM scheduled_tasks WHERE enabled AND next_run_at IS NOT NULL AND next_run_at <= now() ORDER BY next_run_at LIMIT 20`)
	if err != nil {
		slog.Error("tâches planifiées", "err", err)
		return
	}
	var ids []string
	for rows.Next() {
		var id string
		if rows.Scan(&id) == nil {
			ids = append(ids, id)
		}
	}
	rows.Close()
	for _, id := range ids {
		// Réservation atomique : un seul scheduler traite une échéance donnée.
		var cronExpr, tz string
		err := s.core.DB.QueryRow(ctx, `UPDATE scheduled_tasks SET next_run_at=NULL WHERE id=$1 AND next_run_at <= now() RETURNING cron, timezone`, id).Scan(&cronExpr, &tz)
		if err != nil {
			continue
		}
		if err := s.RunTask(ctx, id, false); err != nil {
			slog.Error("tâche", "id", id, "err", err)
		}
		next, err := NextRun(cronExpr, tz, time.Now())
		if err == nil {
			_, _ = s.core.DB.Exec(ctx, `UPDATE scheduled_tasks SET next_run_at=$2 WHERE id=$1 AND enabled AND kind<>'apply_plan'`, id, next)
		}
	}
}

// RunTask exécute une tâche (échéance ou "exécuter maintenant").
func (s *Scheduler) RunTask(ctx context.Context, taskID string, manual bool) error {
	c := s.core
	var kind, name string
	var projectID, envID *string
	var raw []byte
	var maxRetries int
	if err := c.DB.QueryRow(ctx, `SELECT kind, name, project_id::text, environment_id::text, params, max_retries FROM scheduled_tasks WHERE id=$1`, taskID).
		Scan(&kind, &name, &projectID, &envID, &raw, &maxRetries); err != nil {
		return err
	}
	var p taskParams
	_ = json.Unmarshal(raw, &p)
	// Pas d'exécution concurrente : une exécution précédente de la tâche est-elle encore active ?
	var busy bool
	_ = c.DB.QueryRow(ctx, `SELECT EXISTS(SELECT 1 FROM task_executions te JOIN runs r ON r.id=te.run_id WHERE te.task_id=$1 AND r.status IN ('queued','running'))`, taskID).Scan(&busy)
	if busy {
		_, err := c.DB.Exec(ctx, `INSERT INTO task_executions(task_id, status, message, manual, finished_at) VALUES ($1,'skipped','exécution précédente encore en cours',$2,now())`, taskID, manual)
		return err
	}
	var execID string
	if err := c.DB.QueryRow(ctx, `INSERT INTO task_executions(task_id, manual) VALUES ($1,$2) RETURNING id`, taskID, manual).Scan(&execID); err != nil {
		return err
	}
	_, _ = c.DB.Exec(ctx, `UPDATE scheduled_tasks SET last_run_at=now(), last_status='running' WHERE id=$1`, taskID)

	finish := func(status, msg string) {
		_, _ = c.DB.Exec(ctx, `UPDATE task_executions SET status=$2, message=$3, finished_at=now() WHERE id=$1`, execID, status, msg)
		_, _ = c.DB.Exec(ctx, `UPDATE scheduled_tasks SET last_status=$2 WHERE id=$1`, taskID, status)
		if status == "failed" {
			c.Notifier.Emit(ctx, notify.Event{Type: notify.EvTaskFailed, ProjectID: deref(projectID), Summary: fmt.Sprintf("Tâche « %s » en échec : %s", name, msg), Link: "/admin/schedules"})
			s.retryLater(ctx, taskID, maxRetries)
		}
	}
	req := core.RunRequest{ProjectID: deref(projectID), EnvironmentID: deref(envID), TriggeredBy: "schedule", TaskID: taskID, BypassWindow: false}
	switch kind {
	case TaskDrift:
		req.Operation, req.Options = core.OpPlan, core.RunOptions{Drift: true}
	case TaskPlan:
		req.Operation, req.Options = core.OpPlan, core.RunOptions{AutoApply: p.AutoApply}
	case TaskUpgrade:
		req.Operation, req.Options = core.OpPlan, core.RunOptions{Upgrade: true}
	case TaskDestroy:
		req.Operation, req.Destroy, req.Options = core.OpPlan, true, core.RunOptions{AutoApply: true}
	case TaskApplyPlan:
		req.Operation, req.PlanRunID = core.OpApply, p.PlanRunID
		_, _ = c.DB.Exec(ctx, `UPDATE scheduled_tasks SET enabled=false WHERE id=$1`, taskID) // tâche à usage unique
	case TaskStateBackup:
		req.Operation, req.Options = core.OpState, core.RunOptions{StateCmd: "pull"}
	case TaskCompliance:
		msg, err := s.complianceScan(ctx, deref(projectID), p.Recipients)
		if err != nil {
			finish("failed", err.Error())
			return err
		}
		finish("succeeded", msg)
		return nil
	case TaskReportExport:
		msg, err := s.reportExport(ctx, deref(projectID), p)
		if err != nil {
			finish("failed", err.Error())
			return err
		}
		finish("succeeded", msg)
		return nil
	default:
		finish("failed", "type de tâche inconnu")
		return fmt.Errorf("type de tâche inconnu %q", kind)
	}
	run, err := c.CreateRun(ctx, req)
	if err != nil {
		finish("failed", err.Error())
		return err
	}
	_, err = c.DB.Exec(ctx, `UPDATE task_executions SET run_id=$2, message='run en file' WHERE id=$1`, execID, run.ID)
	return err
}

// retryLater reprogramme une tâche en échec dans 5 minutes tant que le nombre d'échecs consécutifs < max.
func (s *Scheduler) retryLater(ctx context.Context, taskID string, maxRetries int) {
	if maxRetries <= 0 {
		return
	}
	var failures int
	_ = s.core.DB.QueryRow(ctx, `SELECT count(*) FROM (SELECT status FROM task_executions WHERE task_id=$1 ORDER BY started_at DESC LIMIT $2) t WHERE status='failed'`, taskID, maxRetries+1).Scan(&failures)
	if failures <= maxRetries {
		_, _ = s.core.DB.Exec(ctx, `UPDATE scheduled_tasks SET next_run_at=now()+interval '5 minutes' WHERE id=$1 AND enabled`, taskID)
	}
}

func deref(s *string) string {
	if s == nil {
		return ""
	}
	return *s
}

// complianceScan évalue les règles sur les modèles (statique) et envoie le rapport.
func (s *Scheduler) complianceScan(ctx context.Context, projectID string, recipients []string) (string, error) {
	var visible []string
	if projectID != "" {
		visible = []string{projectID}
	}
	projects, err := s.core.ListProjects(ctx, visible)
	if err != nil {
		return "", err
	}
	var b strings.Builder
	total := 0
	for _, p := range projects {
		pols, err := runner.LoadPolicies(ctx, s.core, p.ID)
		if err != nil {
			return "", err
		}
		rep := policy.Evaluate(pols, policy.FromModel(&p.Model), p.Model.Providers)
		if len(rep.Violations) == 0 {
			continue
		}
		total += len(rep.Violations)
		fmt.Fprintf(&b, "<h3>%s — %d violation(s)</h3><ul>", p.Name, len(rep.Violations))
		for _, v := range rep.Violations {
			fmt.Fprintf(&b, "<li>[%s] %s : %s</li>", v.Severity, v.Address, v.Message)
		}
		b.WriteString("</ul>")
		s.core.Notifier.Emit(ctx, notify.Event{Type: notify.EvCompliance, ProjectID: p.ID, Project: p.Name,
			Summary: fmt.Sprintf("%d violation(s) de conformité dans le modèle.", len(rep.Violations)), Link: "/projects/" + p.ID})
	}
	msg := fmt.Sprintf("%d projet(s) analysé(s), %d violation(s)", len(projects), total)
	if len(recipients) > 0 {
		body := "<h2>Rapport de conformité</h2><p>" + msg + "</p>" + b.String()
		if err := s.core.Notifier.SendMail(ctx, recipients, "[HCLDesigner] Rapport de conformité", body, nil, ""); err != nil {
			return msg, fmt.Errorf("envoi du rapport : %w", err)
		}
	}
	return msg, nil
}

// reportExport envoie un CSV des exécutions récentes.
func (s *Scheduler) reportExport(ctx context.Context, projectID string, p taskParams) (string, error) {
	days := p.Days
	if days <= 0 {
		days = 7
	}
	q := `SELECT r.created_at, p.name, e.name, r.operation, r.destroy, r.status, COALESCE(u.username,''), r.triggered_by, COALESCE(r.finished_at - r.started_at, interval '0')
		FROM runs r JOIN projects p ON p.id=r.project_id JOIN environments e ON e.id=r.environment_id LEFT JOIN users u ON u.id=r.created_by
		WHERE r.created_at > now() - make_interval(days => $1)`
	args := []any{days}
	if projectID != "" {
		q += ` AND r.project_id=$2`
		args = append(args, projectID)
	}
	rows, err := s.core.DB.Query(ctx, q+` ORDER BY r.created_at DESC`, args...)
	if err != nil {
		return "", err
	}
	defer rows.Close()
	var buf bytes.Buffer
	w := csv.NewWriter(&buf)
	w.Comma = ';'
	_ = w.Write([]string{"date", "projet", "environnement", "opération", "destroy", "statut", "utilisateur", "déclencheur", "durée"})
	n := 0
	for rows.Next() {
		var at time.Time
		var proj, env, op, status, user, trig string
		var destroy bool
		var dur time.Duration
		if err := rows.Scan(&at, &proj, &env, &op, &destroy, &status, &user, &trig, &dur); err != nil {
			return "", err
		}
		_ = w.Write([]string{at.Format("2006-01-02 15:04:05"), proj, env, op, fmt.Sprint(destroy), status, user, trig, dur.Round(time.Second).String()})
		n++
	}
	w.Flush()
	msg := fmt.Sprintf("%d exécution(s) sur %d jour(s)", n, days)
	if len(p.Recipients) == 0 {
		return msg + " (aucun destinataire)", nil
	}
	err = s.core.Notifier.SendMail(ctx, p.Recipients, "[HCLDesigner] Rapport des exécutions", "<p>"+msg+" : voir le fichier joint.</p>", buf.Bytes(), "executions.csv")
	return msg, err
}

// expirePlans écarte les plans dont la durée de validité est dépassée.
func (s *Scheduler) expirePlans(ctx context.Context) {
	_, _ = s.core.DB.Exec(ctx, `UPDATE runs SET status='discarded' WHERE status='planned' AND plan_expires_at < now()`)
}

// detectStuckLocks signale les runs bloqués en attente du verrou de state depuis plus de 10 minutes.
func (s *Scheduler) detectStuckLocks(ctx context.Context) {
	rows, err := s.core.DB.Query(ctx, `SELECT `+core.RunCols+core.RunFrom+` WHERE r.status='running' AND r.started_at < now() - interval '10 minutes'`)
	if err != nil {
		return
	}
	var runs []*core.Run
	for rows.Next() {
		if r, err := core.ScanRun(rows); err == nil {
			runs = append(runs, r)
		}
	}
	rows.Close()
	for _, r := range runs {
		if _, seen := s.lockAlerts.Load(r.ID); seen {
			continue
		}
		path := filepath.Join(s.core.Cfg.DataDir, "logs", r.ID+".log")
		st, err := os.Stat(path)
		if err != nil || time.Since(st.ModTime()) < 10*time.Minute {
			continue
		}
		tail := readTail(path, 2048)
		if strings.Contains(tail, "Acquiring state lock") || strings.Contains(tail, "Error acquiring the state lock") {
			s.lockAlerts.Store(r.ID, true)
			s.core.Notifier.Emit(ctx, notify.Event{Type: notify.EvStateLockStuck, ProjectID: r.ProjectID, Project: r.ProjectName, Environment: r.EnvironmentName,
				Summary: "Le run attend le verrou de state depuis plus de 10 minutes. Vérifiez qu'aucune autre exécution ne tient le verrou (force-unlock possible depuis l'explorateur de state).", Link: "/runs/" + r.ID})
		}
	}
}

func readTail(path string, n int64) string {
	f, err := os.Open(path)
	if err != nil {
		return ""
	}
	defer f.Close()
	st, _ := f.Stat()
	off := st.Size() - n
	if off < 0 {
		off = 0
	}
	buf := make([]byte, st.Size()-off)
	_, _ = f.ReadAt(buf, off)
	return string(buf)
}

// digests envoie les résumés quotidiens (8h) et hebdomadaires (lundi 8h).
func (s *Scheduler) digests(ctx context.Context) {
	now := time.Now()
	if now.Hour() != 8 {
		return
	}
	var state map[string]string
	_ = s.core.Settings.Get(ctx, "digest_state", &state)
	if state == nil {
		state = map[string]string{}
	}
	today := now.Format("2006-01-02")
	if state["daily"] != today {
		s.core.Notifier.SendDigests(ctx, "daily")
		state["daily"] = today
	}
	if now.Weekday() == time.Monday && state["weekly"] != today {
		s.core.Notifier.SendDigests(ctx, "weekly")
		state["weekly"] = today
	}
	_ = s.core.Settings.Set(ctx, "digest_state", state)
}

// housekeeping applique la rétention (logs, artefacts, versions de state, audit).
func (s *Scheduler) housekeeping(ctx context.Context) {
	rs := s.core.Settings.Runs(ctx)
	purgeOlder(filepath.Join(s.core.Cfg.DataDir, "logs"), time.Duration(rs.LogRetentionDays)*24*time.Hour)
	purgeOlder(filepath.Join(s.core.Cfg.DataDir, "artifacts"), time.Duration(rs.PlanRetentionDays)*24*time.Hour)
	if err := s.core.PruneStateVersions(ctx, rs.StateVersionsKept); err != nil {
		slog.Error("rétention des states", "err", err)
	}
	if rs.AuditRetentionDays > 0 {
		tx, err := s.core.DB.Begin(ctx)
		if err == nil {
			_, _ = tx.Exec(ctx, `SET LOCAL hcldesigner.retention = 'on'`)
			_, _ = tx.Exec(ctx, `DELETE FROM audit_events WHERE ts < now() - make_interval(days => $1)`, rs.AuditRetentionDays)
			_ = tx.Commit(ctx)
		}
	}
	_, _ = s.core.DB.Exec(ctx, `DELETE FROM sessions WHERE expires_at < now()`)
	_, _ = s.core.DB.Exec(ctx, `DELETE FROM notification_outbox WHERE status IN ('sent','digested') AND created_at < now() - interval '30 days'`)
}

func purgeOlder(dir string, maxAge time.Duration) {
	if maxAge <= 0 {
		return
	}
	entries, err := os.ReadDir(dir)
	if err != nil {
		return
	}
	for _, e := range entries {
		info, err := e.Info()
		if err == nil && time.Since(info.ModTime()) > maxAge {
			_ = os.RemoveAll(filepath.Join(dir, e.Name()))
		}
	}
}
