// Package vault chiffre les secrets au repos (AES-256-GCM) avec la clé maître HCLD_MASTER_KEY.
package vault

import (
	"crypto/aes"
	"crypto/cipher"
	"crypto/rand"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"os"
)

type Vault struct {
	aead cipher.AEAD
}

func New(key []byte) (*Vault, error) {
	if len(key) != 32 {
		return nil, errors.New("la clé maître doit faire 32 octets")
	}
	block, err := aes.NewCipher(key)
	if err != nil {
		return nil, err
	}
	aead, err := cipher.NewGCM(block)
	if err != nil {
		return nil, err
	}
	return &Vault{aead: aead}, nil
}

// Encrypt renvoie nonce || ciphertext.
func (v *Vault) Encrypt(plain []byte) ([]byte, error) {
	nonce := make([]byte, v.aead.NonceSize())
	if _, err := io.ReadFull(rand.Reader, nonce); err != nil {
		return nil, err
	}
	return v.aead.Seal(nonce, nonce, plain, nil), nil
}

func (v *Vault) Decrypt(data []byte) ([]byte, error) {
	ns := v.aead.NonceSize()
	if len(data) < ns {
		return nil, errors.New("données chiffrées tronquées")
	}
	plain, err := v.aead.Open(nil, data[:ns], data[ns:], nil)
	if err != nil {
		return nil, fmt.Errorf("déchiffrement impossible (clé maître différente ?) : %w", err)
	}
	return plain, nil
}

// EncryptJSON sérialise puis chiffre.
func (v *Vault) EncryptJSON(x any) ([]byte, error) {
	b, err := json.Marshal(x)
	if err != nil {
		return nil, err
	}
	return v.Encrypt(b)
}

func (v *Vault) DecryptJSON(data []byte, x any) error {
	b, err := v.Decrypt(data)
	if err != nil {
		return err
	}
	return json.Unmarshal(b, x)
}

// WriteFile écrit un fichier chiffré (plans, states, logs sensibles).
func (v *Vault) WriteFile(path string, plain []byte) error {
	enc, err := v.Encrypt(plain)
	if err != nil {
		return err
	}
	return os.WriteFile(path, enc, 0o600)
}

func (v *Vault) ReadFile(path string) ([]byte, error) {
	enc, err := os.ReadFile(path)
	if err != nil {
		return nil, err
	}
	return v.Decrypt(enc)
}
