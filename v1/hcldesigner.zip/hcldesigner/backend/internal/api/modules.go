package api

import (
	"encoding/json"
	"fmt"
	"net/http"
	"regexp"
	"strconv"
	"strings"
	"time"

	"github.com/go-chi/chi/v5"

	"github.com/AZIZI-Sajjad/hcldesigner/internal/db"
	"github.com/AZIZI-Sajjad/hcldesigner/internal/hclgen"
	"github.com/AZIZI-Sajjad/hcldesigner/internal/model"
)

func (s *Server) moduleRoutes(r chi.Router) {
	r.Get("/modules", s.listModules)
	r.Post("/modules", s.requireGlobal("modules.create", s.createModule))
	r.Route("/modules/{mid}", func(r chi.Router) {
		r.Get("/", s.getModule)
		r.Put("/", s.requireGlobal("modules.create", s.updateModule))
		r.Delete("/", s.requireGlobal("modules.create", s.deleteModule))
		r.Put("/draft", s.requireGlobal("modules.create", s.saveModuleDraft))
		r.Post("/generate", s.generateModule)
		r.Post("/versions", s.requireGlobal("modules.publish", s.publishModule))
		r.Get("/versions/{v}", s.getModuleVersion)
		r.Get("/diff", s.moduleDiff)
	})
}

type moduleDTO struct {
	ID          string               `json:"id"`
	Name        string               `json:"name"`
	Description string               `json:"description"`
	Scope       string               `json:"scope"`
	ProjectID   *string              `json:"projectId"`
	TeamID      *string              `json:"teamId"`
	Tags        []string             `json:"tags"`
	Versions    []string             `json:"versions"`
	Latest      string               `json:"latest"`
	Inputs      []model.ModuleVar    `json:"inputs"`
	Outputs     []model.ModuleOutput `json:"outputs"`
	UpdatedAt   time.Time            `json:"updatedAt"`
	Draft       *model.Project       `json:"draft,omitempty"`
}

// moduleVisible applique la portée du module (projet, équipe, global).
func (s *Server) moduleVisible(r *http.Request, scope string, projectID, teamID *string) bool {
	sub := subjectOf(r)
	if sub.IsSuper || sub.Can("modules.create", "", "") {
		return true
	}
	switch scope {
	case "project":
		return projectID != nil && sub.Can("projects.view", *projectID, "")
	case "team":
		if teamID == nil {
			return false
		}
		var member bool
		_ = s.core.DB.QueryRow(r.Context(), `SELECT EXISTS(SELECT 1 FROM team_members WHERE team_id=$1 AND user_id=$2)`, *teamID, sessionOf(r).UserID).Scan(&member)
		return member
	}
	return sub.CanAnyProject("modules.use")
}

func (s *Server) listModules(w http.ResponseWriter, r *http.Request) {
	rows, err := s.core.DB.Query(r.Context(), `SELECT m.id, m.name, m.description, m.scope, m.project_id::text, m.team_id::text, m.tags, m.updated_at,
		COALESCE(array_agg(v.version ORDER BY v.created_at DESC) FILTER (WHERE v.version IS NOT NULL), '{}'),
		(SELECT model FROM module_versions x WHERE x.module_id=m.id ORDER BY x.created_at DESC LIMIT 1)
		FROM modules m LEFT JOIN module_versions v ON v.module_id=m.id GROUP BY m.id ORDER BY m.name`)
	if err != nil {
		fail(w, err)
		return
	}
	defer rows.Close()
	out := []moduleDTO{}
	for rows.Next() {
		var m moduleDTO
		var latest []byte
		if err := rows.Scan(&m.ID, &m.Name, &m.Description, &m.Scope, &m.ProjectID, &m.TeamID, &m.Tags, &m.UpdatedAt, &m.Versions, &latest); err != nil {
			fail(w, err)
			return
		}
		if !s.moduleVisible(r, m.Scope, m.ProjectID, m.TeamID) {
			continue
		}
		if len(m.Versions) > 0 {
			m.Latest = m.Versions[0]
		}
		var mm model.Project
		if json.Unmarshal(latest, &mm) == nil {
			m.Inputs, m.Outputs = hclgen.ModuleInterface(&mm)
		}
		out = append(out, m)
	}
	writeJSON(w, http.StatusOK, out)
}

func (s *Server) createModule(w http.ResponseWriter, r *http.Request) {
	var in struct {
		Name        string   `json:"name"`
		Description string   `json:"description"`
		Scope       string   `json:"scope"`
		ProjectID   *string  `json:"projectId"`
		TeamID      *string  `json:"teamId"`
		Tags        []string `json:"tags"`
	}
	if !readJSON(w, r, &in) {
		return
	}
	if !model.LabelRegexp.MatchString(in.Name) {
		writeError(w, http.StatusBadRequest, "nom de module invalide (lettres, chiffres, _ et -)")
		return
	}
	if in.Scope == "" {
		in.Scope = "global"
	}
	if in.Tags == nil {
		in.Tags = []string{}
	}
	draft, _ := json.Marshal(model.New())
	var id string
	if err := s.core.DB.QueryRow(r.Context(), `INSERT INTO modules(name, description, scope, project_id, team_id, tags, draft, created_by) VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING id`,
		in.Name, in.Description, in.Scope, in.ProjectID, in.TeamID, in.Tags, draft, sessionOf(r).UserID).Scan(&id); err != nil {
		fail(w, err)
		return
	}
	s.audit(r, "module.create", "module", id, in)
	writeJSON(w, http.StatusCreated, map[string]string{"id": id})
}

func (s *Server) loadModule(r *http.Request) (*moduleDTO, error) {
	var m moduleDTO
	var draft []byte
	err := s.core.DB.QueryRow(r.Context(), `SELECT m.id, m.name, m.description, m.scope, m.project_id::text, m.team_id::text, m.tags, m.updated_at, m.draft,
		COALESCE((SELECT array_agg(version ORDER BY created_at DESC) FROM module_versions WHERE module_id=m.id), '{}')
		FROM modules m WHERE m.id=$1`, chi.URLParam(r, "mid")).Scan(&m.ID, &m.Name, &m.Description, &m.Scope, &m.ProjectID, &m.TeamID, &m.Tags, &m.UpdatedAt, &draft, &m.Versions)
	if err != nil {
		return nil, err
	}
	var d model.Project
	if err := json.Unmarshal(draft, &d); err != nil {
		return nil, err
	}
	m.Draft = &d
	if len(m.Versions) > 0 {
		m.Latest = m.Versions[0]
	}
	m.Inputs, m.Outputs = hclgen.ModuleInterface(&d)
	return &m, nil
}

func (s *Server) getModule(w http.ResponseWriter, r *http.Request) {
	m, err := s.loadModule(r)
	if err != nil {
		fail(w, db.NotFound(err))
		return
	}
	if !s.moduleVisible(r, m.Scope, m.ProjectID, m.TeamID) {
		writeError(w, http.StatusForbidden, "module non visible")
		return
	}
	writeJSON(w, http.StatusOK, m)
}

func (s *Server) updateModule(w http.ResponseWriter, r *http.Request) {
	var in struct {
		Description string   `json:"description"`
		Scope       string   `json:"scope"`
		ProjectID   *string  `json:"projectId"`
		TeamID      *string  `json:"teamId"`
		Tags        []string `json:"tags"`
	}
	if !readJSON(w, r, &in) {
		return
	}
	id := chi.URLParam(r, "mid")
	if _, err := s.core.DB.Exec(r.Context(), `UPDATE modules SET description=$2, scope=$3, project_id=$4, team_id=$5, tags=$6, updated_at=now() WHERE id=$1`,
		id, in.Description, in.Scope, in.ProjectID, in.TeamID, in.Tags); err != nil {
		fail(w, err)
		return
	}
	s.audit(r, "module.update", "module", id, in)
	w.WriteHeader(http.StatusNoContent)
}

func (s *Server) deleteModule(w http.ResponseWriter, r *http.Request) {
	id := chi.URLParam(r, "mid")
	// Refus si un projet l'utilise encore.
	var users []string
	rows, err := s.core.DB.Query(r.Context(), `SELECT name FROM projects WHERE model::text LIKE '%' || $1 || '%'`, id)
	if err == nil {
		for rows.Next() {
			var n string
			if rows.Scan(&n) == nil {
				users = append(users, n)
			}
		}
		rows.Close()
	}
	if len(users) > 0 {
		writeError(w, http.StatusConflict, "module utilisé par : "+strings.Join(users, ", "))
		return
	}
	if _, err := s.core.DB.Exec(r.Context(), `DELETE FROM modules WHERE id=$1`, id); err != nil {
		fail(w, err)
		return
	}
	s.audit(r, "module.delete", "module", id, nil)
	w.WriteHeader(http.StatusNoContent)
}

func (s *Server) saveModuleDraft(w http.ResponseWriter, r *http.Request) {
	var in struct {
		Draft model.Project `json:"draft"`
	}
	if !readJSON(w, r, &in) {
		return
	}
	raw, _ := json.Marshal(in.Draft)
	id := chi.URLParam(r, "mid")
	if _, err := s.core.DB.Exec(r.Context(), `UPDATE modules SET draft=$2, updated_at=now() WHERE id=$1`, id, raw); err != nil {
		fail(w, err)
		return
	}
	s.audit(r, "module.draft_update", "module", id, map[string]int{"nodes": len(in.Draft.Nodes)})
	vars, outs := hclgen.ModuleInterface(&in.Draft)
	writeJSON(w, http.StatusOK, map[string]any{"inputs": vars, "outputs": outs, "diagnostics": in.Draft.Validate()})
}

// generateModule : aperçu du code du module (brouillon fourni ou enregistré).
func (s *Server) generateModule(w http.ResponseWriter, r *http.Request) {
	m, err := s.loadModule(r)
	if err != nil {
		fail(w, db.NotFound(err))
		return
	}
	var in struct {
		Draft *model.Project `json:"draft"`
	}
	if !readJSON(w, r, &in) {
		return
	}
	draft := m.Draft
	if in.Draft != nil {
		draft = in.Draft
	}
	mods, err := s.core.ModuleDefs(r.Context(), draft)
	if err != nil {
		fail(w, err)
		return
	}
	sub := *draft
	sub.FileLayout = model.FileLayout{Mode: model.LayoutStandard}
	sub.RequiredVer = ""
	res := hclgen.Generate(&sub, hclgen.ProjectResolver{Project: &sub, Lookup: s.core.Lookup(r.Context())}, hclgen.Options{IsModule: true, Modules: mods, Defaults: s.core.Rules, ModulesPrefix: ".."})
	res.Files["README.md"] = hclgen.ModuleReadme(&hclgen.ModuleDef{ID: m.ID, Name: m.Name, Version: "brouillon", Model: draft})
	writeJSON(w, http.StatusOK, map[string]any{"files": res.Files, "ranges": res.Ranges, "diagnostics": append(draft.Validate(), res.Diags...)})
}

var semverRe = regexp.MustCompile(`^(\d+)\.(\d+)\.(\d+)$`)

func semverLess(a, b string) bool {
	pa, pb := semverRe.FindStringSubmatch(a), semverRe.FindStringSubmatch(b)
	if pa == nil || pb == nil {
		return a < b
	}
	for i := 1; i <= 3; i++ {
		x, _ := strconv.Atoi(pa[i])
		y, _ := strconv.Atoi(pb[i])
		if x != y {
			return x < y
		}
	}
	return false
}

// publishModule fige le brouillon dans une nouvelle version sémantique.
func (s *Server) publishModule(w http.ResponseWriter, r *http.Request) {
	var in struct {
		Version   string `json:"version"`
		Changelog string `json:"changelog"`
	}
	if !readJSON(w, r, &in) {
		return
	}
	if !semverRe.MatchString(in.Version) {
		writeError(w, http.StatusBadRequest, "version au format x.y.z attendue")
		return
	}
	m, err := s.loadModule(r)
	if err != nil {
		fail(w, db.NotFound(err))
		return
	}
	if m.Latest != "" && !semverLess(m.Latest, in.Version) {
		writeError(w, http.StatusBadRequest, fmt.Sprintf("la version doit être supérieure à %s", m.Latest))
		return
	}
	if d := m.Draft.Validate(); len(d) > 0 {
		writeError(w, http.StatusUnprocessableEntity, "brouillon invalide : "+d[0].Summary)
		return
	}
	raw, _ := json.Marshal(m.Draft)
	if _, err := s.core.DB.Exec(r.Context(), `INSERT INTO module_versions(module_id, version, model, changelog, created_by) VALUES ($1,$2,$3,$4,$5)`,
		m.ID, in.Version, raw, in.Changelog, sessionOf(r).UserID); err != nil {
		fail(w, err)
		return
	}
	s.audit(r, "module.publish", "module", m.ID, in)
	writeJSON(w, http.StatusCreated, map[string]string{"version": in.Version})
}

func (s *Server) getModuleVersion(w http.ResponseWriter, r *http.Request) {
	def, err := s.core.LoadModuleVersion(r.Context(), chi.URLParam(r, "mid"), chi.URLParam(r, "v"))
	if err != nil {
		fail(w, db.NotFound(err))
		return
	}
	vars, outs := hclgen.ModuleInterface(def.Model)
	var changelog string
	_ = s.core.DB.QueryRow(r.Context(), `SELECT changelog FROM module_versions WHERE module_id=$1 AND version=$2`, def.ID, def.Version).Scan(&changelog)
	writeJSON(w, http.StatusOK, map[string]any{"version": def.Version, "model": def.Model, "inputs": vars, "outputs": outs, "changelog": changelog})
}

// moduleDiff compare l'interface de deux versions et signale les ruptures.
func (s *Server) moduleDiff(w http.ResponseWriter, r *http.Request) {
	id := chi.URLParam(r, "mid")
	from, err := s.core.LoadModuleVersion(r.Context(), id, r.URL.Query().Get("from"))
	if err != nil {
		fail(w, db.NotFound(err))
		return
	}
	to, err := s.core.LoadModuleVersion(r.Context(), id, r.URL.Query().Get("to"))
	if err != nil {
		fail(w, db.NotFound(err))
		return
	}
	writeJSON(w, http.StatusOK, InterfaceDiff(from.Model, to.Model))
}

// InterfaceDiff liste les changements d'inputs/outputs ; breaking = l'appelant doit être modifié.
func InterfaceDiff(a, b *model.Project) map[string]any {
	va, oa := hclgen.ModuleInterface(a)
	vb, ob := hclgen.ModuleInterface(b)
	inA := map[string]model.ModuleVar{}
	for _, v := range va {
		inA[v.Name] = v
	}
	var changes []map[string]any
	breaking := false
	inB := map[string]bool{}
	for _, v := range vb {
		inB[v.Name] = true
		old, ok := inA[v.Name]
		switch {
		case !ok && v.Required:
			changes = append(changes, map[string]any{"kind": "input_added_required", "name": v.Name, "breaking": true})
			breaking = true
		case !ok:
			changes = append(changes, map[string]any{"kind": "input_added", "name": v.Name})
		case old.Type != v.Type:
			changes = append(changes, map[string]any{"kind": "input_type_changed", "name": v.Name, "from": old.Type, "to": v.Type, "breaking": true})
			breaking = true
		case !old.Required && v.Required:
			changes = append(changes, map[string]any{"kind": "input_now_required", "name": v.Name, "breaking": true})
			breaking = true
		}
	}
	for _, v := range va {
		if !inB[v.Name] {
			changes = append(changes, map[string]any{"kind": "input_removed", "name": v.Name, "breaking": true})
			breaking = true
		}
	}
	outB := map[string]bool{}
	for _, o := range ob {
		outB[o.Name] = true
	}
	outA := map[string]bool{}
	for _, o := range oa {
		outA[o.Name] = true
		if !outB[o.Name] {
			changes = append(changes, map[string]any{"kind": "output_removed", "name": o.Name, "breaking": true})
			breaking = true
		}
	}
	for _, o := range ob {
		if !outA[o.Name] {
			changes = append(changes, map[string]any{"kind": "output_added", "name": o.Name})
		}
	}
	if changes == nil {
		changes = []map[string]any{}
	}
	return map[string]any{"changes": changes, "breaking": breaking}
}
