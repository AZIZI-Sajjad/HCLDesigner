package api

import (
	"context"
	"encoding/base64"
	"net/http"
	"strings"
	"time"

	"github.com/go-chi/chi/v5"

	"github.com/AZIZI-Sajjad/hcldesigner/internal/auth"
	"github.com/AZIZI-Sajjad/hcldesigner/internal/notify"
	"github.com/AZIZI-Sajjad/hcldesigner/internal/rbac"
	"github.com/AZIZI-Sajjad/hcldesigner/internal/settings"
)

const cookieName = "hcld_session"

func (s *Server) authRoutes(r chi.Router) {
	r.Post("/auth/login", s.login)
	r.Group(func(r chi.Router) {
		r.Use(s.authenticateAllowMFA)
		r.Post("/auth/logout", s.logout)
		r.Get("/auth/me", s.me)
		r.Post("/auth/mfa/verify", s.mfaVerify)
	})
	r.Group(func(r chi.Router) {
		r.Use(s.authenticate, csrfGuard)
		r.Post("/auth/password", s.changePassword)
		r.Post("/auth/mfa/setup", s.mfaSetup)
		r.Post("/auth/mfa/enable", s.mfaEnable)
		r.Post("/auth/mfa/disable", s.mfaDisable)
		r.Get("/auth/tokens", s.listTokens)
		r.Post("/auth/tokens", s.createToken)
		r.Delete("/auth/tokens/{id}", s.deleteToken)
	})
}

// authenticate exige une session complète (MFA validée si activée).
func (s *Server) authenticate(next http.Handler) http.Handler {
	return s.authMiddleware(next, false)
}

// authenticateAllowMFA accepte une session dont la MFA reste à valider.
func (s *Server) authenticateAllowMFA(next http.Handler) http.Handler {
	return s.authMiddleware(next, true)
}

func (s *Server) authMiddleware(next http.Handler, allowPendingMFA bool) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		sess, isSuper, err := s.resolveSession(r)
		if err != nil || sess == nil {
			writeError(w, http.StatusUnauthorized, "authentification requise")
			return
		}
		if !sess.MFAOk && !allowPendingMFA {
			writeError(w, http.StatusUnauthorized, "mfa_required")
			return
		}
		sub, err := rbac.Load(r.Context(), s.core.DB, sess.UserID, sess.Username, isSuper)
		if err != nil {
			fail(w, err)
			return
		}
		next.ServeHTTP(w, r.WithContext(withAuth(r.Context(), sub, sess)))
	})
}

// resolveSession lit le jeton (cookie de session ou Bearer d'API) et charge l'utilisateur.
func (s *Server) resolveSession(r *http.Request) (*session, bool, error) {
	ctx := r.Context()
	if h := r.Header.Get("Authorization"); strings.HasPrefix(h, "Bearer ") {
		hash := auth.HashToken(strings.TrimPrefix(h, "Bearer "))
		sess := &session{TokenHash: hash, ViaToken: true, MFAOk: true}
		var isSuper bool
		err := s.core.DB.QueryRow(ctx, `UPDATE api_tokens t SET last_used=now() FROM users u
			WHERE t.token_hash=$1 AND u.id=t.user_id AND u.active AND (t.expires_at IS NULL OR t.expires_at > now()) AND (u.expires_at IS NULL OR u.expires_at > now())
			RETURNING u.id, u.username, u.email, u.display_name, u.is_super`, hash).Scan(&sess.UserID, &sess.Username, &sess.Email, &sess.DisplayName, &isSuper)
		return sess, isSuper, err
	}
	c, err := r.Cookie(cookieName)
	if err != nil {
		return nil, false, err
	}
	hash := auth.HashToken(c.Value)
	sess := &session{TokenHash: hash}
	var isSuper bool
	err = s.core.DB.QueryRow(ctx, `UPDATE sessions s SET last_seen=now() FROM users u
		WHERE s.token_hash=$1 AND u.id=s.user_id AND u.active AND s.expires_at > now() AND (u.expires_at IS NULL OR u.expires_at > now())
		RETURNING u.id, u.username, u.email, u.display_name, u.is_super, s.mfa_ok`, hash).Scan(&sess.UserID, &sess.Username, &sess.Email, &sess.DisplayName, &isSuper, &sess.MFAOk)
	return sess, isSuper, err
}

func (s *Server) login(w http.ResponseWriter, r *http.Request) {
	ip := clientIP(r)
	if !s.loginLim.allow(ip) {
		writeError(w, http.StatusTooManyRequests, "trop de tentatives, réessayez plus tard")
		return
	}
	var in struct {
		Username string `json:"username"`
		Password string `json:"password"`
	}
	if !readJSON(w, r, &in) {
		return
	}
	ctx := r.Context()
	var id, hash string
	var totpOn bool
	var knownIPs []string
	err := s.core.DB.QueryRow(ctx, `SELECT id, password_hash, totp_enabled, known_ips FROM users
		WHERE lower(username)=lower($1) AND active AND (expires_at IS NULL OR expires_at > now())`, in.Username).Scan(&id, &hash, &totpOn, &knownIPs)
	if err != nil || !auth.CheckPassword(hash, in.Password) {
		auth.CheckPassword("$argon2id$v=19$m=65536,t=3,p=2$c2FsdHNhbHRzYWx0$aGFzaGhhc2hoYXNoaGFzaGhhc2hoYXNoaGFzaA", in.Password) // temps constant
		s.core.Audit.Log(ctx, auditEvent(ip, in.Username, "auth.login_failed"))
		writeError(w, http.StatusUnauthorized, auth.ErrInvalidCredentials.Error())
		return
	}
	token, tokenHash, err := auth.RandomToken("")
	if err != nil {
		fail(w, err)
		return
	}
	ttl := s.core.Cfg.SessionTTL
	if _, err := s.core.DB.Exec(ctx, `INSERT INTO sessions(token_hash, user_id, ip, user_agent, mfa_ok, expires_at) VALUES ($1,$2,$3,$4,$5,$6)`,
		tokenHash, id, ip, r.UserAgent(), !totpOn, time.Now().Add(ttl)); err != nil {
		fail(w, err)
		return
	}
	// Alerte "nouvelle IP" : notifiée à l'utilisateur concerné.
	if !contains(knownIPs, ip) {
		_, _ = s.core.DB.Exec(ctx, `UPDATE users SET known_ips = (array_append(known_ips, $2))[greatest(1, cardinality(known_ips)-18):] WHERE id=$1`, id, ip)
		if len(knownIPs) > 0 {
			s.core.Notifier.Emit(ctx, notify.Event{Type: notify.EvNewIP, Summary: "Connexion de " + in.Username + " depuis l'adresse " + ip, Recipients: []string{id}, Actor: in.Username})
		}
	}
	_, _ = s.core.DB.Exec(ctx, `UPDATE users SET last_login_at=now(), last_login_ip=$2 WHERE id=$1`, id, ip)
	http.SetCookie(w, &http.Cookie{Name: cookieName, Value: token, Path: "/", HttpOnly: true, Secure: s.core.Cfg.SecureCookies, SameSite: http.SameSiteStrictMode, Expires: time.Now().Add(ttl)})
	ev := auditEvent(ip, in.Username, "auth.login")
	ev.UserID = id
	s.core.Audit.Log(ctx, ev)
	writeJSON(w, http.StatusOK, map[string]any{"mfaRequired": totpOn})
}

func contains(list []string, v string) bool {
	for _, x := range list {
		if x == v {
			return true
		}
	}
	return false
}

func (s *Server) logout(w http.ResponseWriter, r *http.Request) {
	sess := sessionOf(r)
	if !sess.ViaToken {
		_, _ = s.core.DB.Exec(r.Context(), `DELETE FROM sessions WHERE token_hash=$1`, sess.TokenHash)
	}
	http.SetCookie(w, &http.Cookie{Name: cookieName, Value: "", Path: "/", HttpOnly: true, MaxAge: -1, SameSite: http.SameSiteStrictMode})
	s.audit(r, "auth.logout", "user", sess.UserID, nil)
	w.WriteHeader(http.StatusNoContent)
}

// me renvoie l'utilisateur courant, ses permissions et l'état MFA.
func (s *Server) me(w http.ResponseWriter, r *http.Request) {
	sess, sub := sessionOf(r), subjectOf(r)
	var totpOn bool
	_ = s.core.DB.QueryRow(r.Context(), `SELECT totp_enabled FROM users WHERE id=$1`, sess.UserID).Scan(&totpOn)
	var sec settings.Security
	_ = s.core.Settings.Get(r.Context(), settings.KeySecurity, &sec)
	var brand settings.Branding
	_ = s.core.Settings.Get(r.Context(), settings.KeyBranding, &brand)
	writeJSON(w, http.StatusOK, map[string]any{
		"id": sess.UserID, "username": sess.Username, "email": sess.Email, "displayName": sess.DisplayName,
		"isSuper": sub.IsSuper, "bindings": sub.Bindings, "mfaOk": sess.MFAOk, "totpEnabled": totpOn,
		"mfaSetupRequired": sec.RequireMFA && !totpOn, "branding": brand,
	})
}

func (s *Server) mfaVerify(w http.ResponseWriter, r *http.Request) {
	var in struct {
		Code string `json:"code"`
	}
	if !readJSON(w, r, &in) {
		return
	}
	sess := sessionOf(r)
	secret, err := s.totpSecret(r.Context(), sess.UserID)
	if err != nil || secret == nil || !auth.CheckTOTP(secret, in.Code, time.Now()) {
		s.audit(r, "auth.mfa_failed", "user", sess.UserID, nil)
		writeError(w, http.StatusUnauthorized, "code invalide")
		return
	}
	_, _ = s.core.DB.Exec(r.Context(), `UPDATE sessions SET mfa_ok=true WHERE token_hash=$1`, sess.TokenHash)
	w.WriteHeader(http.StatusNoContent)
}

func (s *Server) totpSecret(ctx context.Context, userID string) ([]byte, error) {
	var enc []byte
	if err := s.core.DB.QueryRow(ctx, `SELECT totp_secret FROM users WHERE id=$1`, userID).Scan(&enc); err != nil || enc == nil {
		return nil, err
	}
	return s.core.Vault.Decrypt(enc)
}

// mfaSetup génère un secret (non activé tant que mfaEnable n'a pas reçu un code valide).
func (s *Server) mfaSetup(w http.ResponseWriter, r *http.Request) {
	sess := sessionOf(r)
	secret, err := auth.NewTOTPSecret()
	if err != nil {
		fail(w, err)
		return
	}
	enc, err := s.core.Vault.Encrypt(secret)
	if err != nil {
		fail(w, err)
		return
	}
	if _, err := s.core.DB.Exec(r.Context(), `UPDATE users SET totp_secret=$2, totp_enabled=false WHERE id=$1`, sess.UserID, enc); err != nil {
		fail(w, err)
		return
	}
	writeJSON(w, http.StatusOK, map[string]string{"uri": auth.TOTPURI(secret, "HCLDesigner", sess.Username), "secret": base64.StdEncoding.EncodeToString(secret)})
}

func (s *Server) mfaEnable(w http.ResponseWriter, r *http.Request) {
	var in struct {
		Code string `json:"code"`
	}
	if !readJSON(w, r, &in) {
		return
	}
	sess := sessionOf(r)
	secret, err := s.totpSecret(r.Context(), sess.UserID)
	if err != nil || secret == nil || !auth.CheckTOTP(secret, in.Code, time.Now()) {
		writeError(w, http.StatusBadRequest, "code invalide")
		return
	}
	_, _ = s.core.DB.Exec(r.Context(), `UPDATE users SET totp_enabled=true WHERE id=$1`, sess.UserID)
	s.audit(r, "auth.mfa_enabled", "user", sess.UserID, nil)
	w.WriteHeader(http.StatusNoContent)
}

func (s *Server) mfaDisable(w http.ResponseWriter, r *http.Request) {
	var in struct {
		Password string `json:"password"`
	}
	if !readJSON(w, r, &in) {
		return
	}
	sess := sessionOf(r)
	if !s.checkUserPassword(r.Context(), sess.UserID, in.Password) {
		writeError(w, http.StatusUnauthorized, "mot de passe incorrect")
		return
	}
	_, _ = s.core.DB.Exec(r.Context(), `UPDATE users SET totp_enabled=false, totp_secret=NULL WHERE id=$1`, sess.UserID)
	s.audit(r, "auth.mfa_disabled", "user", sess.UserID, nil)
	w.WriteHeader(http.StatusNoContent)
}

func (s *Server) checkUserPassword(ctx context.Context, userID, pw string) bool {
	var hash string
	if err := s.core.DB.QueryRow(ctx, `SELECT password_hash FROM users WHERE id=$1`, userID).Scan(&hash); err != nil {
		return false
	}
	return auth.CheckPassword(hash, pw)
}

func (s *Server) passwordPolicy(ctx context.Context) auth.PasswordPolicy {
	var sec settings.Security
	_ = s.core.Settings.Get(ctx, settings.KeySecurity, &sec)
	if sec.PasswordPolicy.MinLength == 0 {
		return auth.DefaultPolicy
	}
	return sec.PasswordPolicy
}

func (s *Server) changePassword(w http.ResponseWriter, r *http.Request) {
	var in struct {
		Current string `json:"current"`
		New     string `json:"new"`
	}
	if !readJSON(w, r, &in) {
		return
	}
	sess := sessionOf(r)
	if !s.checkUserPassword(r.Context(), sess.UserID, in.Current) {
		writeError(w, http.StatusUnauthorized, "mot de passe actuel incorrect")
		return
	}
	if err := s.passwordPolicy(r.Context()).Check(in.New); err != nil {
		writeError(w, http.StatusBadRequest, err.Error())
		return
	}
	hash, err := auth.HashPassword(in.New)
	if err != nil {
		fail(w, err)
		return
	}
	_, _ = s.core.DB.Exec(r.Context(), `UPDATE users SET password_hash=$2, updated_at=now() WHERE id=$1`, sess.UserID, hash)
	// Les autres sessions sont révoquées.
	_, _ = s.core.DB.Exec(r.Context(), `DELETE FROM sessions WHERE user_id=$1 AND token_hash<>$2`, sess.UserID, sess.TokenHash)
	s.audit(r, "auth.password_changed", "user", sess.UserID, nil)
	w.WriteHeader(http.StatusNoContent)
}

// ---- Jetons d'API personnels ----------------------------------------------------

func (s *Server) listTokens(w http.ResponseWriter, r *http.Request) {
	rows, err := s.core.DB.Query(r.Context(), `SELECT id, name, prefix, expires_at, last_used, created_at FROM api_tokens WHERE user_id=$1 ORDER BY created_at DESC`, sessionOf(r).UserID)
	if err != nil {
		fail(w, err)
		return
	}
	defer rows.Close()
	type tok struct {
		ID        string     `json:"id"`
		Name      string     `json:"name"`
		Prefix    string     `json:"prefix"`
		ExpiresAt *time.Time `json:"expiresAt"`
		LastUsed  *time.Time `json:"lastUsed"`
		CreatedAt time.Time  `json:"createdAt"`
	}
	out := []tok{}
	for rows.Next() {
		var t tok
		if err := rows.Scan(&t.ID, &t.Name, &t.Prefix, &t.ExpiresAt, &t.LastUsed, &t.CreatedAt); err != nil {
			fail(w, err)
			return
		}
		out = append(out, t)
	}
	writeJSON(w, http.StatusOK, out)
}

func (s *Server) createToken(w http.ResponseWriter, r *http.Request) {
	var in struct {
		Name      string     `json:"name"`
		ExpiresAt *time.Time `json:"expiresAt"`
	}
	if !readJSON(w, r, &in) {
		return
	}
	if strings.TrimSpace(in.Name) == "" {
		writeError(w, http.StatusBadRequest, "nom obligatoire")
		return
	}
	token, hash, err := auth.RandomToken("hcld_")
	if err != nil {
		fail(w, err)
		return
	}
	var id string
	if err := s.core.DB.QueryRow(r.Context(), `INSERT INTO api_tokens(user_id, name, token_hash, prefix, expires_at) VALUES ($1,$2,$3,$4,$5) RETURNING id`,
		sessionOf(r).UserID, in.Name, hash, token[:10], in.ExpiresAt).Scan(&id); err != nil {
		fail(w, err)
		return
	}
	s.audit(r, "token.create", "api_token", id, map[string]any{"name": in.Name})
	writeJSON(w, http.StatusCreated, map[string]string{"id": id, "token": token})
}

func (s *Server) deleteToken(w http.ResponseWriter, r *http.Request) {
	id := chi.URLParam(r, "id")
	if _, err := s.core.DB.Exec(r.Context(), `DELETE FROM api_tokens WHERE id=$1 AND user_id=$2`, id, sessionOf(r).UserID); err != nil {
		fail(w, err)
		return
	}
	s.audit(r, "token.delete", "api_token", id, nil)
	w.WriteHeader(http.StatusNoContent)
}
