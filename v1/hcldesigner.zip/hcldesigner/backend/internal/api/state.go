package api

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"net/http"
	"regexp"
	"sort"

	"github.com/go-chi/chi/v5"

	"github.com/AZIZI-Sajjad/hcldesigner/internal/core"
	"github.com/AZIZI-Sajjad/hcldesigner/internal/rbac"
)

func (s *Server) stateRoutes(r chi.Router) {
	r.Route("/environments/{eid}/state", func(r chi.Router) {
		r.Get("/versions", s.stateVersions)
		r.Get("/resources", s.stateResources)
		r.Get("/resource", s.stateResource)
		r.Get("/diff", s.stateDiff)
		r.Get("/versions/{vid}/download", s.stateDownload)
	})
}

// envFor charge l'environnement de l'URL et vérifie la permission sur celui-ci.
func (s *Server) envFor(w http.ResponseWriter, r *http.Request, perm rbac.Permission) *core.Environment {
	env, err := s.core.GetEnvironment(r.Context(), chi.URLParam(r, "eid"))
	if err != nil {
		fail(w, err)
		return nil
	}
	if !can(w, r, perm, env.ProjectID, env.Name) {
		return nil
	}
	return env
}

func (s *Server) stateVersions(w http.ResponseWriter, r *http.Request) {
	env := s.envFor(w, r, "state.view")
	if env == nil {
		return
	}
	rows, err := s.core.DB.Query(r.Context(), `SELECT id, environment_id, serial, lineage, resources, run_id::text, reason, created_at FROM state_versions WHERE environment_id=$1 ORDER BY created_at DESC LIMIT 500`, env.ID)
	if err != nil {
		fail(w, err)
		return
	}
	defer rows.Close()
	out := []core.StateVersion{}
	for rows.Next() {
		var v core.StateVersion
		if err := rows.Scan(&v.ID, &v.EnvironmentID, &v.Serial, &v.Lineage, &v.Resources, &v.RunID, &v.Reason, &v.CreatedAt); err != nil {
			fail(w, err)
			return
		}
		out = append(out, v)
	}
	writeJSON(w, http.StatusOK, out)
}

// fullState est la structure d'un tfstate (v4) utile à l'explorateur.
type fullState struct {
	Serial    int64  `json:"serial"`
	Lineage   string `json:"lineage"`
	Resources []struct {
		Module    string `json:"module"`
		Mode      string `json:"mode"`
		Type      string `json:"type"`
		Name      string `json:"name"`
		Provider  string `json:"provider"`
		Instances []struct {
			IndexKey            any               `json:"index_key"`
			Attributes          map[string]any    `json:"attributes"`
			SensitiveAttributes []json.RawMessage `json:"sensitive_attributes"`
			Dependencies        []string          `json:"dependencies"`
		} `json:"instances"`
	} `json:"resources"`
}

func (s *Server) loadState(r *http.Request, env *core.Environment) (*fullState, error) {
	var raw []byte
	var err error
	if vid := r.URL.Query().Get("version"); vid != "" {
		raw, err = s.core.StateVersionContent(r.Context(), env.ID, vid)
	} else {
		raw, err = s.core.LatestState(r.Context(), env.ID)
	}
	if err != nil {
		return nil, err
	}
	st := &fullState{}
	if raw == nil {
		return st, nil
	}
	return st, json.Unmarshal(raw, st)
}

type stateInstance struct {
	Address string         `json:"address"`
	Mode    string         `json:"mode"`
	Type    string         `json:"type"`
	Module  string         `json:"module,omitempty"`
	Attrs   map[string]any `json:"attributes,omitempty"`
	Deps    []string       `json:"dependencies,omitempty"`
	hash    string
}

// instances aplatit le state (une entrée par instance count/for_each).
func (st *fullState) instances(withAttrs bool) []stateInstance {
	out := []stateInstance{}
	for _, res := range st.Resources {
		base := res.Type + "." + res.Name
		if res.Mode == "data" {
			base = "data." + base
		}
		if res.Module != "" {
			base = res.Module + "." + base
		}
		for _, inst := range res.Instances {
			addr := base
			switch k := inst.IndexKey.(type) {
			case float64:
				addr += fmt.Sprintf("[%d]", int(k))
			case string:
				addr += fmt.Sprintf("[%q]", k)
			}
			b, _ := json.Marshal(inst.Attributes)
			sum := sha256.Sum256(b)
			si := stateInstance{Address: addr, Mode: res.Mode, Type: res.Type, Module: res.Module, Deps: inst.Dependencies, hash: hex.EncodeToString(sum[:])}
			if withAttrs {
				si.Attrs = maskState(inst.Attributes, inst.SensitiveAttributes)
			}
			out = append(out, si)
		}
	}
	sort.Slice(out, func(i, j int) bool { return out[i].Address < out[j].Address })
	return out
}

var secretKey = regexp.MustCompile(`(?i)(password|secret|token|private_key|access_key|client_key|certificate_pem|kubeconfig)`)

// maskState masque les attributs déclarés sensibles par le provider et ceux au nom évocateur.
func maskState(attrs map[string]any, sensitive []json.RawMessage) map[string]any {
	sens := map[string]bool{}
	for _, raw := range sensitive {
		// Formats possibles : [{"type":"get_attr","value":"password"}, ...] ou {"value": "..."} selon la version.
		var path []struct {
			Type  string `json:"type"`
			Value any    `json:"value"`
		}
		if json.Unmarshal(raw, &path) == nil && len(path) > 0 {
			if v, ok := path[0].Value.(string); ok {
				sens[v] = true
			}
		}
	}
	out := make(map[string]any, len(attrs))
	for k, v := range attrs {
		if sens[k] || (secretKey.MatchString(k) && v != nil && v != "") {
			out[k] = "(sensible)"
			continue
		}
		out[k] = v
	}
	return out
}

func (s *Server) stateResources(w http.ResponseWriter, r *http.Request) {
	env := s.envFor(w, r, "state.view")
	if env == nil {
		return
	}
	st, err := s.loadState(r, env)
	if err != nil {
		fail(w, err)
		return
	}
	writeJSON(w, http.StatusOK, map[string]any{"serial": st.Serial, "lineage": st.Lineage, "resources": st.instances(false), "internal": env.BackendType == "internal"})
}

func (s *Server) stateResource(w http.ResponseWriter, r *http.Request) {
	env := s.envFor(w, r, "state.view")
	if env == nil {
		return
	}
	st, err := s.loadState(r, env)
	if err != nil {
		fail(w, err)
		return
	}
	addr := r.URL.Query().Get("address")
	for _, inst := range st.instances(true) {
		if inst.Address == addr {
			writeJSON(w, http.StatusOK, inst)
			return
		}
	}
	writeError(w, http.StatusNotFound, "ressource absente du state")
}

// stateDiff compare deux versions : ressources ajoutées, supprimées, modifiées.
func (s *Server) stateDiff(w http.ResponseWriter, r *http.Request) {
	env := s.envFor(w, r, "state.view")
	if env == nil {
		return
	}
	load := func(vid string) (map[string]stateInstance, error) {
		raw, err := s.core.StateVersionContent(r.Context(), env.ID, vid)
		if err != nil {
			return nil, err
		}
		st := &fullState{}
		if err := json.Unmarshal(raw, st); err != nil {
			return nil, err
		}
		m := map[string]stateInstance{}
		for _, i := range st.instances(false) {
			m[i.Address] = i
		}
		return m, nil
	}
	a, err := load(r.URL.Query().Get("from"))
	if err != nil {
		fail(w, err)
		return
	}
	b, err := load(r.URL.Query().Get("to"))
	if err != nil {
		fail(w, err)
		return
	}
	added, removed, changed := []string{}, []string{}, []string{}
	for addr, ib := range b {
		ia, ok := a[addr]
		switch {
		case !ok:
			added = append(added, addr)
		case ia.hash != ib.hash:
			changed = append(changed, addr)
		}
	}
	for addr := range a {
		if _, ok := b[addr]; !ok {
			removed = append(removed, addr)
		}
	}
	sort.Strings(added)
	sort.Strings(removed)
	sort.Strings(changed)
	writeJSON(w, http.StatusOK, map[string]any{"added": added, "removed": removed, "changed": changed})
}

func (s *Server) stateDownload(w http.ResponseWriter, r *http.Request) {
	env := s.envFor(w, r, "state.download")
	if env == nil {
		return
	}
	vid := chi.URLParam(r, "vid")
	raw, err := s.core.StateVersionContent(r.Context(), env.ID, vid)
	if err != nil {
		fail(w, err)
		return
	}
	s.audit(r, "state.download", "state_version", vid, map[string]string{"environment": env.Name})
	w.Header().Set("Content-Type", "application/json")
	w.Header().Set("Content-Disposition", fmt.Sprintf(`attachment; filename="%s-%s.tfstate"`, env.Name, vid[:8]))
	_, _ = w.Write(raw)
}
