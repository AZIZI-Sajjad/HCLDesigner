package api

import (
	"encoding/json"
	"net/http"
	"time"

	"github.com/go-chi/chi/v5"

	"github.com/AZIZI-Sajjad/hcldesigner/internal/policy"
)

// policyKinds décrit les règles disponibles et leurs paramètres (formulaires du frontend).
var policyKinds = []map[string]any{
	{"kind": policy.KindRequiredTags, "label": "Tags obligatoires", "params": []string{"types", "tags"}},
	{"kind": policy.KindAllowedValues, "label": "Valeurs autorisées (ex. types d'instance)", "params": []string{"types", "attribute", "values"}},
	{"kind": policy.KindAttributeEq, "label": "Attribut imposé (ex. chiffrement)", "params": []string{"types", "attribute", "value"}},
	{"kind": policy.KindNamingRegex, "label": "Nommage imposé (regex)", "params": []string{"types", "regex"}},
	{"kind": policy.KindOpenIngress, "label": "Interdire l'ouverture 0.0.0.0/0", "params": []string{"types", "ports"}},
	{"kind": policy.KindAllowedRegions, "label": "Régions autorisées", "params": []string{"regions"}},
	{"kind": policy.KindProviderMinVer, "label": "Version minimale de provider", "params": []string{"source", "min"}},
}

func (s *Server) policyRoutes(r chi.Router) {
	r.Get("/policies/kinds", func(w http.ResponseWriter, r *http.Request) { writeJSON(w, http.StatusOK, policyKinds) })
	r.Get("/policies", s.listPolicies)
	r.Post("/policies", s.requireGlobal("policies.manage", s.savePolicy))
	r.Put("/policies/{id}", s.requireGlobal("policies.manage", s.savePolicy))
	r.Delete("/policies/{id}", s.requireGlobal("policies.manage", s.deletePolicy))
}

type policyDTO struct {
	policy.Policy
	ProjectID *string   `json:"projectId"`
	CreatedAt time.Time `json:"createdAt"`
}

func (s *Server) listPolicies(w http.ResponseWriter, r *http.Request) {
	rows, err := s.core.DB.Query(r.Context(), `SELECT id, name, kind, severity, enabled, params, project_id::text, created_at FROM policies ORDER BY name`)
	if err != nil {
		fail(w, err)
		return
	}
	defer rows.Close()
	out := []policyDTO{}
	for rows.Next() {
		var p policyDTO
		if err := rows.Scan(&p.ID, &p.Name, &p.Kind, &p.Severity, &p.Enabled, &p.Params, &p.ProjectID, &p.CreatedAt); err != nil {
			fail(w, err)
			return
		}
		out = append(out, p)
	}
	writeJSON(w, http.StatusOK, out)
}

func (s *Server) savePolicy(w http.ResponseWriter, r *http.Request) {
	var in struct {
		Name      string          `json:"name"`
		Kind      string          `json:"kind"`
		Severity  string          `json:"severity"`
		Enabled   bool            `json:"enabled"`
		Params    json.RawMessage `json:"params"`
		ProjectID *string         `json:"projectId"`
	}
	if !readJSON(w, r, &in) {
		return
	}
	known := false
	for _, k := range policyKinds {
		if k["kind"] == in.Kind {
			known = true
		}
	}
	if !known {
		writeError(w, http.StatusBadRequest, "type de règle inconnu")
		return
	}
	if len(in.Params) == 0 {
		in.Params = json.RawMessage(`{}`)
	}
	if in.ProjectID != nil && *in.ProjectID == "" {
		in.ProjectID = nil
	}
	id := chi.URLParam(r, "id")
	var err error
	if id == "" {
		err = s.core.DB.QueryRow(r.Context(), `INSERT INTO policies(name, kind, severity, enabled, params, project_id) VALUES ($1,$2,$3,$4,$5,$6) RETURNING id`,
			in.Name, in.Kind, in.Severity, in.Enabled, in.Params, in.ProjectID).Scan(&id)
	} else {
		_, err = s.core.DB.Exec(r.Context(), `UPDATE policies SET name=$2, kind=$3, severity=$4, enabled=$5, params=$6, project_id=$7 WHERE id=$1`,
			id, in.Name, in.Kind, in.Severity, in.Enabled, in.Params, in.ProjectID)
	}
	if err != nil {
		fail(w, err)
		return
	}
	s.audit(r, "policy.save", "policy", id, in)
	writeJSON(w, http.StatusOK, map[string]string{"id": id})
}

func (s *Server) deletePolicy(w http.ResponseWriter, r *http.Request) {
	id := chi.URLParam(r, "id")
	if _, err := s.core.DB.Exec(r.Context(), `DELETE FROM policies WHERE id=$1`, id); err != nil {
		fail(w, err)
		return
	}
	s.audit(r, "policy.delete", "policy", id, nil)
	w.WriteHeader(http.StatusNoContent)
}
