package api

import (
	"encoding/json"
	"net/http"
	"time"

	"github.com/go-chi/chi/v5"

	"github.com/AZIZI-Sajjad/hcldesigner/internal/scheduler"
)

func (s *Server) scheduleRoutes(r chi.Router) {
	r.Get("/schedules/kinds", func(w http.ResponseWriter, r *http.Request) { writeJSON(w, http.StatusOK, scheduler.TaskKinds) })
	r.Post("/schedules/preview", s.previewCron)
	r.Get("/schedules", s.listSchedules)
	r.Post("/schedules", s.saveSchedule)
	r.Put("/schedules/{id}", s.saveSchedule)
	r.Delete("/schedules/{id}", s.deleteSchedule)
	r.Post("/schedules/{id}/run", s.runScheduleNow)
	r.Get("/schedules/{id}/executions", s.scheduleExecutions)
}

type scheduleDTO struct {
	ID            string          `json:"id"`
	Name          string          `json:"name"`
	Kind          string          `json:"kind"`
	Cron          string          `json:"cron"`
	Timezone      string          `json:"timezone"`
	ProjectID     *string         `json:"projectId"`
	ProjectName   string          `json:"projectName"`
	EnvironmentID *string         `json:"environmentId"`
	EnvName       string          `json:"environmentName"`
	Params        json.RawMessage `json:"params"`
	Enabled       bool            `json:"enabled"`
	TimeoutS      int             `json:"timeoutS"`
	MaxRetries    int             `json:"maxRetries"`
	NextRunAt     *time.Time      `json:"nextRunAt"`
	LastRunAt     *time.Time      `json:"lastRunAt"`
	LastStatus    string          `json:"lastStatus"`
}

// canManageSchedule : schedules.manage sur le projet, ou admin.settings pour les tâches globales.
func canManageSchedule(r *http.Request, projectID *string) bool {
	sub := subjectOf(r)
	if projectID == nil || *projectID == "" {
		return sub.Can("admin.settings", "", "")
	}
	return sub.Can("schedules.manage", *projectID, "")
}

func (s *Server) loadSchedule(r *http.Request, id string) (*scheduleDTO, error) {
	var d scheduleDTO
	err := s.core.DB.QueryRow(r.Context(), `SELECT t.id, t.name, t.kind, t.cron, t.timezone, t.project_id::text, COALESCE(p.name,''), t.environment_id::text, COALESCE(e.name,''),
		t.params, t.enabled, t.timeout_s, t.max_retries, t.next_run_at, t.last_run_at, t.last_status
		FROM scheduled_tasks t LEFT JOIN projects p ON p.id=t.project_id LEFT JOIN environments e ON e.id=t.environment_id WHERE t.id=$1`, id).
		Scan(&d.ID, &d.Name, &d.Kind, &d.Cron, &d.Timezone, &d.ProjectID, &d.ProjectName, &d.EnvironmentID, &d.EnvName, &d.Params, &d.Enabled, &d.TimeoutS, &d.MaxRetries, &d.NextRunAt, &d.LastRunAt, &d.LastStatus)
	return &d, err
}

func (s *Server) listSchedules(w http.ResponseWriter, r *http.Request) {
	rows, err := s.core.DB.Query(r.Context(), `SELECT id FROM scheduled_tasks ORDER BY name`)
	if err != nil {
		fail(w, err)
		return
	}
	var ids []string
	for rows.Next() {
		var id string
		if rows.Scan(&id) == nil {
			ids = append(ids, id)
		}
	}
	rows.Close()
	sub := subjectOf(r)
	filter := r.URL.Query().Get("project")
	out := []*scheduleDTO{}
	for _, id := range ids {
		d, err := s.loadSchedule(r, id)
		if err != nil {
			continue
		}
		if filter != "" && (d.ProjectID == nil || *d.ProjectID != filter) {
			continue
		}
		visible := (d.ProjectID == nil && sub.Can("admin.settings", "", "")) || (d.ProjectID != nil && sub.Can("projects.view", *d.ProjectID, ""))
		if visible {
			out = append(out, d)
		}
	}
	writeJSON(w, http.StatusOK, out)
}

func (s *Server) saveSchedule(w http.ResponseWriter, r *http.Request) {
	var in struct {
		Name          string          `json:"name"`
		Kind          string          `json:"kind"`
		Cron          string          `json:"cron"`
		Timezone      string          `json:"timezone"`
		ProjectID     *string         `json:"projectId"`
		EnvironmentID *string         `json:"environmentId"`
		Params        json.RawMessage `json:"params"`
		Enabled       bool            `json:"enabled"`
		TimeoutS      int             `json:"timeoutS"`
		MaxRetries    int             `json:"maxRetries"`
	}
	if !readJSON(w, r, &in) {
		return
	}
	if in.ProjectID != nil && *in.ProjectID == "" {
		in.ProjectID = nil
	}
	if in.EnvironmentID != nil && *in.EnvironmentID == "" {
		in.EnvironmentID = nil
	}
	if !canManageSchedule(r, in.ProjectID) {
		writeError(w, http.StatusForbidden, "permission requise : schedules.manage")
		return
	}
	needsEnv := false
	known := false
	for _, k := range scheduler.TaskKinds {
		if k.Kind == in.Kind {
			known, needsEnv = true, k.NeedsEnv
		}
	}
	if !known {
		writeError(w, http.StatusBadRequest, "type de tâche inconnu")
		return
	}
	if needsEnv && (in.ProjectID == nil || in.EnvironmentID == nil) {
		writeError(w, http.StatusBadRequest, "projet et environnement obligatoires pour ce type de tâche")
		return
	}
	if in.Timezone == "" {
		in.Timezone = "Europe/Paris"
	}
	next, err := scheduler.NextRun(in.Cron, in.Timezone, time.Now())
	if err != nil {
		writeError(w, http.StatusBadRequest, err.Error())
		return
	}
	if len(in.Params) == 0 {
		in.Params = json.RawMessage(`{}`)
	}
	if in.TimeoutS <= 0 {
		in.TimeoutS = 3600
	}
	var nextAt *time.Time
	if in.Enabled {
		nextAt = &next
	}
	ctx := r.Context()
	id := chi.URLParam(r, "id")
	if id == "" {
		err = s.core.DB.QueryRow(ctx, `INSERT INTO scheduled_tasks(name, kind, cron, timezone, project_id, environment_id, params, enabled, timeout_s, max_retries, next_run_at, created_by)
			VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12) RETURNING id`,
			in.Name, in.Kind, in.Cron, in.Timezone, in.ProjectID, in.EnvironmentID, in.Params, in.Enabled, in.TimeoutS, in.MaxRetries, nextAt, sessionOf(r).UserID).Scan(&id)
	} else {
		old, lerr := s.loadSchedule(r, id)
		if lerr != nil {
			fail(w, lerr)
			return
		}
		if !canManageSchedule(r, old.ProjectID) {
			writeError(w, http.StatusForbidden, "permission requise : schedules.manage")
			return
		}
		_, err = s.core.DB.Exec(ctx, `UPDATE scheduled_tasks SET name=$2, kind=$3, cron=$4, timezone=$5, project_id=$6, environment_id=$7, params=$8, enabled=$9,
			timeout_s=$10, max_retries=$11, next_run_at=$12 WHERE id=$1`,
			id, in.Name, in.Kind, in.Cron, in.Timezone, in.ProjectID, in.EnvironmentID, in.Params, in.Enabled, in.TimeoutS, in.MaxRetries, nextAt)
	}
	if err != nil {
		fail(w, err)
		return
	}
	s.audit(r, "schedule.save", "scheduled_task", id, in)
	d, _ := s.loadSchedule(r, id)
	writeJSON(w, http.StatusOK, d)
}

func (s *Server) scheduleFor(w http.ResponseWriter, r *http.Request) *scheduleDTO {
	d, err := s.loadSchedule(r, chi.URLParam(r, "id"))
	if err != nil {
		fail(w, err)
		return nil
	}
	if !canManageSchedule(r, d.ProjectID) {
		writeError(w, http.StatusForbidden, "permission requise : schedules.manage")
		return nil
	}
	return d
}

func (s *Server) deleteSchedule(w http.ResponseWriter, r *http.Request) {
	d := s.scheduleFor(w, r)
	if d == nil {
		return
	}
	if _, err := s.core.DB.Exec(r.Context(), `DELETE FROM scheduled_tasks WHERE id=$1`, d.ID); err != nil {
		fail(w, err)
		return
	}
	s.audit(r, "schedule.delete", "scheduled_task", d.ID, map[string]string{"name": d.Name})
	w.WriteHeader(http.StatusNoContent)
}

func (s *Server) runScheduleNow(w http.ResponseWriter, r *http.Request) {
	d := s.scheduleFor(w, r)
	if d == nil {
		return
	}
	if err := s.scheduler.RunTask(r.Context(), d.ID, true); err != nil {
		fail(w, err)
		return
	}
	s.audit(r, "schedule.run_now", "scheduled_task", d.ID, nil)
	w.WriteHeader(http.StatusAccepted)
}

func (s *Server) scheduleExecutions(w http.ResponseWriter, r *http.Request) {
	d, err := s.loadSchedule(r, chi.URLParam(r, "id"))
	if err != nil {
		fail(w, err)
		return
	}
	if d.ProjectID != nil && !can(w, r, "projects.view", *d.ProjectID, "") {
		return
	}
	rows, err := s.core.DB.Query(r.Context(), `SELECT id, status, attempt, run_id::text, message, manual, started_at, finished_at FROM task_executions WHERE task_id=$1 ORDER BY started_at DESC LIMIT 200`, d.ID)
	if err != nil {
		fail(w, err)
		return
	}
	defer rows.Close()
	out := []map[string]any{}
	for rows.Next() {
		var id, status, msg string
		var attempt int
		var runID *string
		var manual bool
		var started time.Time
		var finished *time.Time
		if rows.Scan(&id, &status, &attempt, &runID, &msg, &manual, &started, &finished) == nil {
			var dur float64
			if finished != nil {
				dur = finished.Sub(started).Seconds()
			}
			out = append(out, map[string]any{"id": id, "status": status, "attempt": attempt, "runId": runID, "message": msg, "manual": manual, "startedAt": started, "finishedAt": finished, "durationS": dur})
		}
	}
	writeJSON(w, http.StatusOK, out)
}

func (s *Server) previewCron(w http.ResponseWriter, r *http.Request) {
	var in struct {
		Cron     string `json:"cron"`
		Timezone string `json:"timezone"`
	}
	if !readJSON(w, r, &in) {
		return
	}
	if in.Timezone == "" {
		in.Timezone = "Europe/Paris"
	}
	var out []time.Time
	t := time.Now()
	for i := 0; i < 5; i++ {
		next, err := scheduler.NextRun(in.Cron, in.Timezone, t)
		if err != nil {
			writeError(w, http.StatusBadRequest, err.Error())
			return
		}
		out = append(out, next)
		t = next
	}
	writeJSON(w, http.StatusOK, out)
}
