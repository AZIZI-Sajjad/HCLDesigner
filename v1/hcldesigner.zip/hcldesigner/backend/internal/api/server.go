// Package api expose l'API REST/WebSocket consommée par le frontend et les intégrations.
// Chaque fichier regroupe les routes d'un domaine ; les helpers communs sont ici.
package api

import (
	"context"
	"encoding/json"
	"errors"
	"log/slog"
	"net"
	"net/http"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"time"

	"github.com/go-chi/chi/v5"
	"github.com/go-chi/chi/v5/middleware"

	"github.com/AZIZI-Sajjad/hcldesigner/internal/audit"
	"github.com/AZIZI-Sajjad/hcldesigner/internal/core"
	"github.com/AZIZI-Sajjad/hcldesigner/internal/db"
	"github.com/AZIZI-Sajjad/hcldesigner/internal/rbac"
	"github.com/AZIZI-Sajjad/hcldesigner/internal/scheduler"
)

type Server struct {
	core      *core.Core
	scheduler *scheduler.Scheduler
	limiter   *ipLimiter
	loginLim  *ipLimiter
}

func New(c *core.Core) *Server {
	return &Server{
		core:      c,
		scheduler: scheduler.New(c),
		limiter:   newIPLimiter(50, 200),
		loginLim:  newIPLimiter(0.2, 10), // 10 tentatives puis 1 toutes les 5 s
	}
}

// Router construit l'ensemble des routes.
func (s *Server) Router() http.Handler {
	r := chi.NewRouter()
	r.Use(middleware.RequestID, middleware.Recoverer, securityHeaders, s.rateLimit)
	if s.core.Cfg.TrustedProxies {
		r.Use(middleware.RealIP)
	}
	r.Get("/healthz", func(w http.ResponseWriter, r *http.Request) {
		if err := s.core.DB.Ping(r.Context()); err != nil {
			http.Error(w, "db", http.StatusServiceUnavailable)
			return
		}
		_, _ = w.Write([]byte("ok"))
	})
	r.Route("/api", func(r chi.Router) {
		r.Use(middleware.Timeout(5 * time.Minute))
		s.authRoutes(r)
		r.Group(func(r chi.Router) {
			r.Use(s.authenticate, csrfGuard)
			s.adminRoutes(r)
			s.projectRoutes(r)
			s.providerRoutes(r)
			s.moduleRoutes(r)
			s.environmentRoutes(r)
			s.credentialRoutes(r)
			s.runRoutes(r)
			s.stateRoutes(r)
			s.scheduleRoutes(r)
			s.policyRoutes(r)
			s.notificationRoutes(r)
			s.settingsRoutes(r)
			s.prefsRoutes(r)
			s.dashboardRoutes(r)
		})
	})
	if dir := s.core.Cfg.StaticDir; dir != "" {
		r.Handle("/*", spaHandler(dir))
	}
	return r
}

// spaHandler sert le frontend compilé avec repli sur index.html (routage côté client).
func spaHandler(dir string) http.Handler {
	fs := http.FileServer(http.Dir(dir))
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		p := filepath.Join(dir, filepath.Clean("/"+r.URL.Path))
		if st, err := os.Stat(p); err != nil || st.IsDir() {
			http.ServeFile(w, r, filepath.Join(dir, "index.html"))
			return
		}
		fs.ServeHTTP(w, r)
	})
}

func securityHeaders(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		h := w.Header()
		h.Set("X-Content-Type-Options", "nosniff")
		h.Set("X-Frame-Options", "DENY")
		h.Set("Referrer-Policy", "same-origin")
		h.Set("Content-Security-Policy", "default-src 'self'; script-src 'self' 'unsafe-eval' blob:; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; font-src 'self' data:; connect-src 'self' ws: wss:; worker-src 'self' blob:; frame-ancestors 'none'")
		next.ServeHTTP(w, r)
	})
}

// csrfGuard : les requêtes modifiantes authentifiées par cookie doivent porter l'en-tête
// X-Requested-With (impossible à poser depuis un formulaire d'un autre site).
func csrfGuard(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodGet && r.Method != http.MethodHead && r.Method != http.MethodOptions {
			if !strings.HasPrefix(r.Header.Get("Authorization"), "Bearer ") && r.Header.Get("X-Requested-With") != "hcldesigner" {
				writeError(w, http.StatusForbidden, "en-tête X-Requested-With manquant (protection CSRF)")
				return
			}
		}
		next.ServeHTTP(w, r)
	})
}

// ---- Limitation de débit (seau à jetons par IP) --------------------------------

type ipLimiter struct {
	mu      sync.Mutex
	rate    float64
	burst   float64
	buckets map[string]*bucket
}

type bucket struct {
	tokens float64
	last   time.Time
}

func newIPLimiter(rate, burst float64) *ipLimiter {
	return &ipLimiter{rate: rate, burst: burst, buckets: map[string]*bucket{}}
}

func (l *ipLimiter) allow(key string) bool {
	l.mu.Lock()
	defer l.mu.Unlock()
	now := time.Now()
	b, ok := l.buckets[key]
	if !ok {
		if len(l.buckets) > 10000 {
			l.buckets = map[string]*bucket{} // purge simple pour borner la mémoire
		}
		b = &bucket{tokens: l.burst, last: now}
		l.buckets[key] = b
	}
	b.tokens = min(l.burst, b.tokens+now.Sub(b.last).Seconds()*l.rate)
	b.last = now
	if b.tokens < 1 {
		return false
	}
	b.tokens--
	return true
}

func (s *Server) rateLimit(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if strings.HasPrefix(r.URL.Path, "/api/") && !s.limiter.allow(clientIP(r)) {
			writeError(w, http.StatusTooManyRequests, "trop de requêtes")
			return
		}
		next.ServeHTTP(w, r)
	})
}

func clientIP(r *http.Request) string {
	host, _, err := net.SplitHostPort(r.RemoteAddr)
	if err != nil {
		return r.RemoteAddr
	}
	return host
}

// ---- Helpers JSON / erreurs ----------------------------------------------------

func writeJSON(w http.ResponseWriter, status int, v any) {
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	w.WriteHeader(status)
	if err := json.NewEncoder(w).Encode(v); err != nil {
		slog.Error("encodage JSON", "err", err)
	}
}

func writeError(w http.ResponseWriter, status int, msg string) {
	writeJSON(w, status, map[string]string{"error": msg})
}

// fail convertit une erreur métier en réponse HTTP adaptée.
func fail(w http.ResponseWriter, err error) {
	switch {
	case errors.Is(err, db.ErrNotFound):
		writeError(w, http.StatusNotFound, "introuvable")
	case errors.Is(err, core.ErrConflict):
		writeError(w, http.StatusConflict, err.Error())
	case core.IsRefused(err):
		writeError(w, http.StatusUnprocessableEntity, err.Error())
	default:
		var bad badRequest
		if errors.As(err, &bad) {
			writeError(w, http.StatusBadRequest, bad.msg)
			return
		}
		if strings.Contains(err.Error(), "duplicate key") {
			writeError(w, http.StatusConflict, "cet élément existe déjà")
			return
		}
		slog.Error("erreur interne", "err", err)
		writeError(w, http.StatusInternalServerError, "erreur interne")
	}
}

type badRequest struct{ msg string }

func (b badRequest) Error() string { return b.msg }

func bad(msg string) error { return badRequest{msg} }

// readJSON décode le corps (limité à 20 Mo) en refusant les champs inconnus de premier niveau.
func readJSON(w http.ResponseWriter, r *http.Request, v any) bool {
	r.Body = http.MaxBytesReader(w, r.Body, 20<<20)
	if err := json.NewDecoder(r.Body).Decode(v); err != nil {
		writeError(w, http.StatusBadRequest, "JSON invalide : "+err.Error())
		return false
	}
	return true
}

// ---- Contexte d'authentification ----------------------------------------------

type ctxKey int

const (
	keySubject ctxKey = iota
	keySession
)

type session struct {
	UserID      string
	Username    string
	Email       string
	DisplayName string
	TokenHash   string
	ViaToken    bool
	MFAOk       bool
}

func subjectOf(r *http.Request) *rbac.Subject {
	s, _ := r.Context().Value(keySubject).(*rbac.Subject)
	return s
}

func sessionOf(r *http.Request) *session {
	s, _ := r.Context().Value(keySession).(*session)
	return s
}

func withAuth(ctx context.Context, sub *rbac.Subject, sess *session) context.Context {
	return context.WithValue(context.WithValue(ctx, keySubject, sub), keySession, sess)
}

// can vérifie une permission ; écrit 403 sinon.
func can(w http.ResponseWriter, r *http.Request, p rbac.Permission, projectID, env string) bool {
	if subjectOf(r).Can(p, projectID, env) {
		return true
	}
	writeError(w, http.StatusForbidden, "permission requise : "+string(p))
	return false
}

// audit enregistre une action de l'utilisateur courant.
func (s *Server) audit(r *http.Request, action, objType, objID string, details any) {
	sess := sessionOf(r)
	e := audit.Event{IP: clientIP(r), Action: action, ObjectType: objType, ObjectID: objID, Details: details}
	if sess != nil {
		e.UserID, e.Username = sess.UserID, sess.Username
	}
	s.core.Audit.Log(r.Context(), e)
}

// auditEvent construit un événement d'audit hors session (connexion).
func auditEvent(ip, username, action string) audit.Event {
	return audit.Event{IP: ip, Username: username, Action: action, ObjectType: "user"}
}
