package api

import (
	"net/http"
	"strings"
	"time"

	"github.com/go-chi/chi/v5"

	"github.com/AZIZI-Sajjad/hcldesigner/internal/auth"
	"github.com/AZIZI-Sajjad/hcldesigner/internal/notify"
	"github.com/AZIZI-Sajjad/hcldesigner/internal/rbac"
)

func (s *Server) adminRoutes(r chi.Router) {
	// Annuaire léger accessible à tout utilisateur connecté (sélecteurs d'utilisateurs).
	r.Get("/directory/users", s.directory)

	r.Route("/admin", func(r chi.Router) {
		r.Get("/users", s.requireGlobal("admin.users", s.listUsers))
		r.Post("/users", s.requireGlobal("admin.users", s.createUser))
		r.Put("/users/{id}", s.requireGlobal("admin.users", s.updateUser))
		r.Delete("/users/{id}", s.requireGlobal("admin.users", s.deleteUser))
		r.Get("/users/{id}/sessions", s.requireGlobal("admin.users", s.userSessions))
		r.Delete("/users/{id}/sessions", s.requireGlobal("admin.users", s.revokeSessions))
		r.Get("/users/{id}/effective", s.requireGlobal("admin.roles", s.effectivePerms))

		r.Get("/teams", s.requireGlobal("admin.users", s.listTeams))
		r.Post("/teams", s.requireGlobal("admin.users", s.saveTeam))
		r.Put("/teams/{id}", s.requireGlobal("admin.users", s.saveTeam))
		r.Delete("/teams/{id}", s.requireGlobal("admin.users", s.deleteTeam))

		r.Get("/permissions", s.permissionsCatalog)
		r.Get("/roles", s.listRoles)
		r.Post("/roles", s.requireGlobal("admin.roles", s.saveRole))
		r.Put("/roles/{id}", s.requireGlobal("admin.roles", s.saveRole))
		r.Delete("/roles/{id}", s.requireGlobal("admin.roles", s.deleteRole))
		r.Get("/bindings", s.listBindings)
		r.Post("/bindings", s.createBinding)
		r.Delete("/bindings/{id}", s.deleteBinding)
	})
}

// requireGlobal enveloppe un handler avec une vérification de permission globale.
func (s *Server) requireGlobal(p rbac.Permission, h http.HandlerFunc) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		if can(w, r, p, "", "") {
			h(w, r)
		}
	}
}

type userDTO struct {
	ID          string     `json:"id"`
	Username    string     `json:"username"`
	Email       string     `json:"email"`
	DisplayName string     `json:"displayName"`
	Active      bool       `json:"active"`
	IsSuper     bool       `json:"isSuper"`
	TOTP        bool       `json:"totpEnabled"`
	ExpiresAt   *time.Time `json:"expiresAt"`
	LastLoginAt *time.Time `json:"lastLoginAt"`
	LastLoginIP string     `json:"lastLoginIp"`
	Teams       []string   `json:"teams"`
	CreatedAt   time.Time  `json:"createdAt"`
}

func (s *Server) directory(w http.ResponseWriter, r *http.Request) {
	rows, err := s.core.DB.Query(r.Context(), `SELECT id, username, display_name FROM users WHERE active ORDER BY username`)
	if err != nil {
		fail(w, err)
		return
	}
	defer rows.Close()
	out := []map[string]string{}
	for rows.Next() {
		var id, u, d string
		if rows.Scan(&id, &u, &d) == nil {
			out = append(out, map[string]string{"id": id, "username": u, "displayName": d})
		}
	}
	writeJSON(w, http.StatusOK, out)
}

func (s *Server) listUsers(w http.ResponseWriter, r *http.Request) {
	rows, err := s.core.DB.Query(r.Context(), `SELECT u.id, u.username, u.email, u.display_name, u.active, u.is_super, u.totp_enabled, u.expires_at, u.last_login_at, u.last_login_ip,
		COALESCE(array_agg(t.name ORDER BY t.name) FILTER (WHERE t.name IS NOT NULL), '{}'), u.created_at
		FROM users u LEFT JOIN team_members tm ON tm.user_id=u.id LEFT JOIN teams t ON t.id=tm.team_id GROUP BY u.id ORDER BY u.username`)
	if err != nil {
		fail(w, err)
		return
	}
	defer rows.Close()
	out := []userDTO{}
	for rows.Next() {
		var u userDTO
		if err := rows.Scan(&u.ID, &u.Username, &u.Email, &u.DisplayName, &u.Active, &u.IsSuper, &u.TOTP, &u.ExpiresAt, &u.LastLoginAt, &u.LastLoginIP, &u.Teams, &u.CreatedAt); err != nil {
			fail(w, err)
			return
		}
		out = append(out, u)
	}
	writeJSON(w, http.StatusOK, out)
}

type userInput struct {
	Username    string     `json:"username"`
	Email       string     `json:"email"`
	DisplayName string     `json:"displayName"`
	Password    string     `json:"password"`
	Active      *bool      `json:"active"`
	ExpiresAt   *time.Time `json:"expiresAt"`
	ResetMFA    bool       `json:"resetMfa"`
}

func (s *Server) createUser(w http.ResponseWriter, r *http.Request) {
	var in userInput
	if !readJSON(w, r, &in) {
		return
	}
	in.Username = strings.TrimSpace(in.Username)
	if in.Username == "" {
		writeError(w, http.StatusBadRequest, "identifiant obligatoire")
		return
	}
	if err := s.passwordPolicy(r.Context()).Check(in.Password); err != nil {
		writeError(w, http.StatusBadRequest, err.Error())
		return
	}
	hash, err := auth.HashPassword(in.Password)
	if err != nil {
		fail(w, err)
		return
	}
	active := in.Active == nil || *in.Active
	var id string
	if err := s.core.DB.QueryRow(r.Context(), `INSERT INTO users(username, email, display_name, password_hash, active, expires_at) VALUES ($1,$2,$3,$4,$5,$6) RETURNING id`,
		in.Username, in.Email, in.DisplayName, hash, active, in.ExpiresAt).Scan(&id); err != nil {
		fail(w, err)
		return
	}
	s.audit(r, "user.create", "user", id, map[string]any{"username": in.Username, "email": in.Email})
	writeJSON(w, http.StatusCreated, map[string]string{"id": id})
}

func (s *Server) updateUser(w http.ResponseWriter, r *http.Request) {
	id := chi.URLParam(r, "id")
	var in userInput
	if !readJSON(w, r, &in) {
		return
	}
	ctx := r.Context()
	active := in.Active == nil || *in.Active
	if _, err := s.core.DB.Exec(ctx, `UPDATE users SET email=$2, display_name=$3, active=$4, expires_at=$5, updated_at=now() WHERE id=$1`,
		id, in.Email, in.DisplayName, active, in.ExpiresAt); err != nil {
		fail(w, err)
		return
	}
	if in.Password != "" {
		if err := s.passwordPolicy(ctx).Check(in.Password); err != nil {
			writeError(w, http.StatusBadRequest, err.Error())
			return
		}
		hash, err := auth.HashPassword(in.Password)
		if err != nil {
			fail(w, err)
			return
		}
		_, _ = s.core.DB.Exec(ctx, `UPDATE users SET password_hash=$2 WHERE id=$1`, id, hash)
		_, _ = s.core.DB.Exec(ctx, `DELETE FROM sessions WHERE user_id=$1`, id)
	}
	if in.ResetMFA {
		_, _ = s.core.DB.Exec(ctx, `UPDATE users SET totp_enabled=false, totp_secret=NULL WHERE id=$1`, id)
	}
	if !active {
		_, _ = s.core.DB.Exec(ctx, `DELETE FROM sessions WHERE user_id=$1`, id)
	}
	s.audit(r, "user.update", "user", id, map[string]any{"email": in.Email, "active": active, "passwordReset": in.Password != "", "mfaReset": in.ResetMFA})
	w.WriteHeader(http.StatusNoContent)
}

func (s *Server) deleteUser(w http.ResponseWriter, r *http.Request) {
	id := chi.URLParam(r, "id")
	if id == sessionOf(r).UserID {
		writeError(w, http.StatusBadRequest, "impossible de supprimer son propre compte")
		return
	}
	if _, err := s.core.DB.Exec(r.Context(), `DELETE FROM users WHERE id=$1`, id); err != nil {
		fail(w, err)
		return
	}
	s.audit(r, "user.delete", "user", id, nil)
	w.WriteHeader(http.StatusNoContent)
}

func (s *Server) userSessions(w http.ResponseWriter, r *http.Request) {
	rows, err := s.core.DB.Query(r.Context(), `SELECT substr(token_hash,1,12), ip, user_agent, created_at, last_seen, expires_at FROM sessions WHERE user_id=$1 AND expires_at > now() ORDER BY last_seen DESC`, chi.URLParam(r, "id"))
	if err != nil {
		fail(w, err)
		return
	}
	defer rows.Close()
	out := []map[string]any{}
	for rows.Next() {
		var id, ip, ua string
		var created, seen, exp time.Time
		if rows.Scan(&id, &ip, &ua, &created, &seen, &exp) == nil {
			out = append(out, map[string]any{"id": id, "ip": ip, "userAgent": ua, "createdAt": created, "lastSeen": seen, "expiresAt": exp})
		}
	}
	writeJSON(w, http.StatusOK, out)
}

func (s *Server) revokeSessions(w http.ResponseWriter, r *http.Request) {
	id := chi.URLParam(r, "id")
	if _, err := s.core.DB.Exec(r.Context(), `DELETE FROM sessions WHERE user_id=$1`, id); err != nil {
		fail(w, err)
		return
	}
	s.audit(r, "user.sessions_revoked", "user", id, nil)
	w.WriteHeader(http.StatusNoContent)
}

// effectivePerms montre les permissions effectives d'un utilisateur et leur origine.
func (s *Server) effectivePerms(w http.ResponseWriter, r *http.Request) {
	id := chi.URLParam(r, "id")
	var username string
	var isSuper bool
	if err := s.core.DB.QueryRow(r.Context(), `SELECT username, is_super FROM users WHERE id=$1`, id).Scan(&username, &isSuper); err != nil {
		fail(w, err)
		return
	}
	sub, err := rbac.Load(r.Context(), s.core.DB, id, username, isSuper)
	if err != nil {
		fail(w, err)
		return
	}
	writeJSON(w, http.StatusOK, map[string]any{"isSuper": sub.IsSuper, "bindings": sub.Bindings})
}

// ---- Équipes ------------------------------------------------------------------

func (s *Server) listTeams(w http.ResponseWriter, r *http.Request) {
	rows, err := s.core.DB.Query(r.Context(), `SELECT t.id, t.name, t.description, COALESCE(array_agg(tm.user_id::text) FILTER (WHERE tm.user_id IS NOT NULL), '{}')
		FROM teams t LEFT JOIN team_members tm ON tm.team_id=t.id GROUP BY t.id ORDER BY t.name`)
	if err != nil {
		fail(w, err)
		return
	}
	defer rows.Close()
	out := []map[string]any{}
	for rows.Next() {
		var id, name, desc string
		var members []string
		if rows.Scan(&id, &name, &desc, &members) == nil {
			out = append(out, map[string]any{"id": id, "name": name, "description": desc, "members": members})
		}
	}
	writeJSON(w, http.StatusOK, out)
}

func (s *Server) saveTeam(w http.ResponseWriter, r *http.Request) {
	var in struct {
		Name        string   `json:"name"`
		Description string   `json:"description"`
		Members     []string `json:"members"`
	}
	if !readJSON(w, r, &in) {
		return
	}
	ctx := r.Context()
	tx, err := s.core.DB.Begin(ctx)
	if err != nil {
		fail(w, err)
		return
	}
	defer tx.Rollback(ctx)
	id := chi.URLParam(r, "id")
	if id == "" {
		err = tx.QueryRow(ctx, `INSERT INTO teams(name, description) VALUES ($1,$2) RETURNING id`, in.Name, in.Description).Scan(&id)
	} else {
		_, err = tx.Exec(ctx, `UPDATE teams SET name=$2, description=$3 WHERE id=$1`, id, in.Name, in.Description)
	}
	if err == nil {
		_, err = tx.Exec(ctx, `DELETE FROM team_members WHERE team_id=$1`, id)
	}
	for _, m := range in.Members {
		if err != nil {
			break
		}
		_, err = tx.Exec(ctx, `INSERT INTO team_members(team_id, user_id) VALUES ($1,$2)`, id, m)
	}
	if err == nil {
		err = tx.Commit(ctx)
	}
	if err != nil {
		fail(w, err)
		return
	}
	s.audit(r, "team.save", "team", id, in)
	writeJSON(w, http.StatusOK, map[string]string{"id": id})
}

func (s *Server) deleteTeam(w http.ResponseWriter, r *http.Request) {
	id := chi.URLParam(r, "id")
	if _, err := s.core.DB.Exec(r.Context(), `DELETE FROM teams WHERE id=$1`, id); err != nil {
		fail(w, err)
		return
	}
	s.audit(r, "team.delete", "team", id, nil)
	w.WriteHeader(http.StatusNoContent)
}

// ---- Rôles et attributions --------------------------------------------------------

func (s *Server) permissionsCatalog(w http.ResponseWriter, r *http.Request) {
	writeJSON(w, http.StatusOK, rbac.Groups)
}

func (s *Server) listRoles(w http.ResponseWriter, r *http.Request) {
	rows, err := s.core.DB.Query(r.Context(), `SELECT r.id, r.name, r.description, r.builtin, r.permissions, (SELECT count(*) FROM role_bindings b WHERE b.role_id=r.id)
		FROM roles r ORDER BY r.builtin DESC, r.name`)
	if err != nil {
		fail(w, err)
		return
	}
	defer rows.Close()
	out := []map[string]any{}
	for rows.Next() {
		var id, name, desc string
		var builtin bool
		var perms []string
		var n int
		if rows.Scan(&id, &name, &desc, &builtin, &perms, &n) == nil {
			out = append(out, map[string]any{"id": id, "name": name, "description": desc, "builtin": builtin, "permissions": perms, "bindings": n})
		}
	}
	writeJSON(w, http.StatusOK, out)
}

func (s *Server) saveRole(w http.ResponseWriter, r *http.Request) {
	var in struct {
		Name        string   `json:"name"`
		Description string   `json:"description"`
		Permissions []string `json:"permissions"`
	}
	if !readJSON(w, r, &in) {
		return
	}
	for _, p := range in.Permissions {
		if !rbac.Known(rbac.Permission(p)) || p == string(rbac.All) {
			writeError(w, http.StatusBadRequest, "permission inconnue ou interdite : "+p)
			return
		}
	}
	ctx := r.Context()
	id := chi.URLParam(r, "id")
	var err error
	if id == "" {
		err = s.core.DB.QueryRow(ctx, `INSERT INTO roles(name, description, permissions) VALUES ($1,$2,$3) RETURNING id`, in.Name, in.Description, in.Permissions).Scan(&id)
	} else {
		var tag interface{ RowsAffected() int64 }
		tag, err = s.core.DB.Exec(ctx, `UPDATE roles SET name=$2, description=$3, permissions=$4 WHERE id=$1 AND NOT builtin`, id, in.Name, in.Description, in.Permissions)
		if err == nil && tag.RowsAffected() == 0 {
			writeError(w, http.StatusBadRequest, "les rôles prédéfinis ne sont pas modifiables")
			return
		}
	}
	if err != nil {
		fail(w, err)
		return
	}
	s.audit(r, "role.save", "role", id, in)
	s.core.Notifier.Emit(ctx, notify.Event{Type: notify.EvRoleChanged, Actor: sessionOf(r).Username, Summary: "Rôle « " + in.Name + " » modifié : " + strings.Join(in.Permissions, ", ")})
	writeJSON(w, http.StatusOK, map[string]string{"id": id})
}

func (s *Server) deleteRole(w http.ResponseWriter, r *http.Request) {
	id := chi.URLParam(r, "id")
	tag, err := s.core.DB.Exec(r.Context(), `DELETE FROM roles WHERE id=$1 AND NOT builtin`, id)
	if err != nil {
		fail(w, err)
		return
	}
	if tag.RowsAffected() == 0 {
		writeError(w, http.StatusBadRequest, "les rôles prédéfinis ne sont pas supprimables")
		return
	}
	s.audit(r, "role.delete", "role", id, nil)
	w.WriteHeader(http.StatusNoContent)
}

type bindingDTO struct {
	ID          string    `json:"id"`
	RoleID      string    `json:"roleId"`
	RoleName    string    `json:"roleName"`
	UserID      *string   `json:"userId"`
	Username    string    `json:"username"`
	TeamID      *string   `json:"teamId"`
	TeamName    string    `json:"teamName"`
	Scope       string    `json:"scope"`
	ProjectID   *string   `json:"projectId"`
	ProjectName string    `json:"projectName"`
	Environment string    `json:"environment"`
	CreatedAt   time.Time `json:"createdAt"`
}

// listBindings : admin.roles voit tout ; projects.share voit les attributions de ses projets.
func (s *Server) listBindings(w http.ResponseWriter, r *http.Request) {
	projectID := r.URL.Query().Get("project")
	sub := subjectOf(r)
	if !sub.Can("admin.roles", "", "") && (projectID == "" || !sub.Can("projects.share", projectID, "")) {
		writeError(w, http.StatusForbidden, "permission requise : admin.roles")
		return
	}
	q := `SELECT b.id, r.id, r.name, b.user_id::text, COALESCE(u.username,''), b.team_id::text, COALESCE(t.name,''), b.scope, b.project_id::text, COALESCE(p.name,''), b.environment, b.created_at
		FROM role_bindings b JOIN roles r ON r.id=b.role_id LEFT JOIN users u ON u.id=b.user_id LEFT JOIN teams t ON t.id=b.team_id LEFT JOIN projects p ON p.id=b.project_id`
	args := []any{}
	if projectID != "" {
		q += ` WHERE b.project_id=$1`
		args = append(args, projectID)
	}
	rows, err := s.core.DB.Query(r.Context(), q+` ORDER BY b.created_at`, args...)
	if err != nil {
		fail(w, err)
		return
	}
	defer rows.Close()
	out := []bindingDTO{}
	for rows.Next() {
		var b bindingDTO
		if err := rows.Scan(&b.ID, &b.RoleID, &b.RoleName, &b.UserID, &b.Username, &b.TeamID, &b.TeamName, &b.Scope, &b.ProjectID, &b.ProjectName, &b.Environment, &b.CreatedAt); err != nil {
			fail(w, err)
			return
		}
		out = append(out, b)
	}
	writeJSON(w, http.StatusOK, out)
}

func (s *Server) createBinding(w http.ResponseWriter, r *http.Request) {
	var in struct {
		RoleID      string  `json:"roleId"`
		UserID      *string `json:"userId"`
		TeamID      *string `json:"teamId"`
		Scope       string  `json:"scope"`
		ProjectID   *string `json:"projectId"`
		Environment string  `json:"environment"`
	}
	if !readJSON(w, r, &in) {
		return
	}
	sub := subjectOf(r)
	// Partage d'un projet : un détenteur de projects.share attribue des rôles limités à son projet.
	allowed := sub.Can("admin.roles", "", "") || (in.Scope != rbac.ScopeGlobal && in.ProjectID != nil && sub.Can("projects.share", *in.ProjectID, ""))
	if !allowed {
		writeError(w, http.StatusForbidden, "permission requise : admin.roles ou projects.share")
		return
	}
	if (in.UserID == nil) == (in.TeamID == nil) {
		writeError(w, http.StatusBadRequest, "indiquer un utilisateur ou une équipe")
		return
	}
	if in.Scope != rbac.ScopeGlobal && (in.ProjectID == nil || *in.ProjectID == "") {
		writeError(w, http.StatusBadRequest, "projet obligatoire pour cette portée")
		return
	}
	if in.Scope == rbac.ScopeEnvironment && in.Environment == "" {
		writeError(w, http.StatusBadRequest, "environnement obligatoire pour cette portée")
		return
	}
	// Seul un super admin peut attribuer un rôle contenant "*".
	var perms []string
	if err := s.core.DB.QueryRow(r.Context(), `SELECT permissions FROM roles WHERE id=$1`, in.RoleID).Scan(&perms); err != nil {
		fail(w, err)
		return
	}
	for _, p := range perms {
		if p == string(rbac.All) && !sub.IsSuper {
			writeError(w, http.StatusForbidden, "seul un super admin peut attribuer ce rôle")
			return
		}
	}
	if in.Scope == rbac.ScopeGlobal {
		in.ProjectID, in.Environment = nil, ""
	}
	var id string
	if err := s.core.DB.QueryRow(r.Context(), `INSERT INTO role_bindings(role_id, user_id, team_id, scope, project_id, environment) VALUES ($1,$2,$3,$4,$5,$6) RETURNING id`,
		in.RoleID, in.UserID, in.TeamID, in.Scope, in.ProjectID, in.Environment).Scan(&id); err != nil {
		fail(w, err)
		return
	}
	s.audit(r, "binding.create", "role_binding", id, in)
	s.core.Notifier.Emit(r.Context(), notify.Event{Type: notify.EvRoleChanged, Actor: sessionOf(r).Username, Summary: "Nouvelle attribution de rôle (portée " + in.Scope + ")"})
	writeJSON(w, http.StatusCreated, map[string]string{"id": id})
}

func (s *Server) deleteBinding(w http.ResponseWriter, r *http.Request) {
	id := chi.URLParam(r, "id")
	var projectID *string
	if err := s.core.DB.QueryRow(r.Context(), `SELECT project_id::text FROM role_bindings WHERE id=$1`, id).Scan(&projectID); err != nil {
		fail(w, err)
		return
	}
	sub := subjectOf(r)
	if !sub.Can("admin.roles", "", "") && (projectID == nil || !sub.Can("projects.share", *projectID, "")) {
		writeError(w, http.StatusForbidden, "permission requise")
		return
	}
	if _, err := s.core.DB.Exec(r.Context(), `DELETE FROM role_bindings WHERE id=$1`, id); err != nil {
		fail(w, err)
		return
	}
	s.audit(r, "binding.delete", "role_binding", id, nil)
	w.WriteHeader(http.StatusNoContent)
}
