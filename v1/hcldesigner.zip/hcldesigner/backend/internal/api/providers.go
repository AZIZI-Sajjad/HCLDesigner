package api

import (
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"os"
	"strings"
	"time"

	"github.com/go-chi/chi/v5"

	"github.com/AZIZI-Sajjad/hcldesigner/internal/connection"
	"github.com/AZIZI-Sajjad/hcldesigner/internal/hclgen"
	"github.com/AZIZI-Sajjad/hcldesigner/internal/model"
)

func (s *Server) providerRoutes(r chi.Router) {
	r.Get("/providers", s.listProviderSchemas)
	r.Post("/providers/resolve", s.resolveProvider)
	r.Get("/providers/jobs/{id}", s.providerJob)
	r.Get("/catalog", s.catalog)
	r.Get("/schemas/block", s.schemaBlock)
	r.Get("/rules", s.rulesAndDefaults)
	r.Post("/connections/suggest", s.suggest)
	r.Post("/connections/compatible", s.compatible)
	r.Get("/registry/modules/search", s.registrySearch)
	r.Get("/registry/modules/{ns}/{name}/{provider}", s.registryModule)
	r.Get("/registry/providers/{ns}/{name}/versions", s.registryProviderVersions)
}

func (s *Server) listProviderSchemas(w http.ResponseWriter, r *http.Request) {
	rows, err := s.core.DB.Query(r.Context(), `SELECT s.source, s.version, s.address, s.fetched_at,
		(SELECT count(*) FROM catalog_entries c WHERE c.source=s.source AND c.version=s.version AND c.kind='resource'),
		(SELECT count(*) FROM catalog_entries c WHERE c.source=s.source AND c.version=s.version AND c.kind='data')
		FROM provider_schemas s ORDER BY s.source, s.fetched_at DESC`)
	if err != nil {
		fail(w, err)
		return
	}
	defer rows.Close()
	out := []map[string]any{}
	for rows.Next() {
		var src, ver, addr string
		var at time.Time
		var res, data int
		if rows.Scan(&src, &ver, &addr, &at, &res, &data) == nil {
			out = append(out, map[string]any{"source": src, "version": ver, "address": addr, "fetchedAt": at, "resources": res, "dataSources": data})
		}
	}
	writeJSON(w, http.StatusOK, out)
}

func (s *Server) resolveProvider(w http.ResponseWriter, r *http.Request) {
	if !can(w, r, "providers.add", "", "") {
		return
	}
	var in struct {
		Source        string `json:"source"`
		Version       string `json:"version"`
		LocalName     string `json:"localName"`
		Engine        string `json:"engine"`
		EngineVersion string `json:"engineVersion"`
	}
	if !readJSON(w, r, &in) {
		return
	}
	in.Source = strings.ToLower(strings.TrimSpace(in.Source))
	if strings.Count(in.Source, "/") < 1 || strings.ContainsAny(in.Source, " \"'\n") {
		writeError(w, http.StatusBadRequest, "source invalide (attendu : namespace/nom, ex. hashicorp/aws)")
		return
	}
	if in.Engine == "" {
		in.Engine = "terraform"
	}
	var id string
	if err := s.core.DB.QueryRow(r.Context(), `INSERT INTO schema_jobs(engine, engine_version, local_name, source, constraint_, created_by) VALUES ($1,$2,$3,$4,$5,$6) RETURNING id`,
		in.Engine, in.EngineVersion, in.LocalName, in.Source, in.Version, sessionOf(r).UserID).Scan(&id); err != nil {
		fail(w, err)
		return
	}
	s.audit(r, "provider.resolve", "provider", in.Source, in)
	writeJSON(w, http.StatusAccepted, map[string]string{"jobId": id})
}

func (s *Server) providerJob(w http.ResponseWriter, r *http.Request) {
	var status, source, version, errMsg string
	if err := s.core.DB.QueryRow(r.Context(), `SELECT status, source, version, error FROM schema_jobs WHERE id=$1`, chi.URLParam(r, "id")).Scan(&status, &source, &version, &errMsg); err != nil {
		fail(w, err)
		return
	}
	writeJSON(w, http.StatusOK, map[string]string{"status": status, "source": source, "version": version, "error": errMsg})
}

// catalog : recherche plein texte dans les ressources d'un ou plusieurs providers.
func (s *Server) catalog(w http.ResponseWriter, r *http.Request) {
	q := r.URL.Query()
	sql := `SELECT source, version, kind, type, category, description, deprecated FROM catalog_entries WHERE true`
	args := []any{}
	add := func(cond string, v any) {
		args = append(args, v)
		sql += fmt.Sprintf(" AND "+cond, len(args))
	}
	// sources=hashicorp/aws@5.80.0,hashicorp/random@3.6.0
	if src := q.Get("sources"); src != "" {
		var conds []string
		for _, sv := range strings.Split(src, ",") {
			parts := strings.SplitN(sv, "@", 2)
			args = append(args, strings.ToLower(parts[0]))
			c := fmt.Sprintf("(source=$%d", len(args))
			if len(parts) == 2 && parts[1] != "" {
				args = append(args, parts[1])
				c += fmt.Sprintf(" AND version=$%d", len(args))
			} else {
				c += fmt.Sprintf(" AND version=(SELECT version FROM provider_schemas WHERE source=$%d ORDER BY fetched_at DESC LIMIT 1)", len(args))
			}
			conds = append(conds, c+")")
		}
		sql += " AND (" + strings.Join(conds, " OR ") + ")"
	}
	if v := q.Get("q"); v != "" {
		args = append(args, "%"+strings.ToLower(v)+"%")
		sql += fmt.Sprintf(" AND (type ILIKE $%d OR lower(description) LIKE $%d)", len(args), len(args))
	}
	if v := q.Get("category"); v != "" {
		add("category=$%d", v)
	}
	if v := q.Get("kind"); v != "" {
		add("kind=$%d", v)
	}
	sql += " ORDER BY length(type), type LIMIT 300" // les noms courts (aws_vpc) avant les dérivés
	rows, err := s.core.DB.Query(r.Context(), sql, args...)
	if err != nil {
		fail(w, err)
		return
	}
	defer rows.Close()
	out := []map[string]any{}
	for rows.Next() {
		var src, ver, kind, typ, cat, desc string
		var dep bool
		if rows.Scan(&src, &ver, &kind, &typ, &cat, &desc, &dep) == nil {
			out = append(out, map[string]any{"source": src, "version": ver, "kind": kind, "type": typ, "category": cat, "description": desc, "deprecated": dep})
		}
	}
	writeJSON(w, http.StatusOK, out)
}

// schemaBlock renvoie le schéma d'un type (chargement paresseux par le frontend).
func (s *Server) schemaBlock(w http.ResponseWriter, r *http.Request) {
	q := r.URL.Query()
	b, err := s.core.SchemaBlock(r.Context(), q.Get("source"), q.Get("version"), q.Get("kind"), q.Get("type"))
	if err != nil {
		writeError(w, http.StatusNotFound, err.Error())
		return
	}
	writeJSON(w, http.StatusOK, map[string]any{"block": b, "defaults": s.core.Rules.Defaults(q.Get("type"))})
}

func (s *Server) rulesAndDefaults(w http.ResponseWriter, r *http.Request) {
	writeJSON(w, http.StatusOK, map[string]any{"connections": s.core.Rules.Connections, "defaults": s.core.Rules.AllDefaults()})
}

// endpointSpec décrit une extrémité de liaison envoyée par le frontend.
type endpointSpec struct {
	ID       string           `json:"id"`
	Kind     string           `json:"kind"`
	Type     string           `json:"type"`
	Label    string           `json:"label"`
	Provider string           `json:"provider"`
	Module   *model.ModuleRef `json:"module"`
	Multi    string           `json:"multi"`
}

// endpoint résout le schéma (ou l'interface de module) d'une extrémité.
func (s *Server) endpoint(ctx context.Context, providers []model.ProviderConfig, spec endpointSpec) connection.Endpoint {
	ep := connection.Endpoint{Kind: spec.Kind, Type: spec.Type, Label: spec.Label, Multi: spec.Multi}
	switch spec.Kind {
	case model.KindResource, model.KindData:
		proj := &model.Project{Providers: providers}
		node := &model.Node{Kind: spec.Kind, Type: spec.Type, Provider: spec.Provider}
		if pc := hclgen.ProviderFor(proj, node); pc != nil {
			ep.Block, _ = s.core.SchemaBlock(ctx, pc.Source, pc.Resolved, spec.Kind, spec.Type)
		}
	case model.KindModule:
		if spec.Module == nil {
			break
		}
		if spec.Module.SourceKind == "internal" {
			if def, err := s.core.LoadModuleVersion(ctx, spec.Module.ModuleID, spec.Module.Version); err == nil {
				ep.ModuleVars, ep.ModuleOutputs = hclgen.ModuleInterface(def.Model)
			}
		} else {
			ep.ModuleVars, ep.ModuleOutputs = spec.Module.Inputs, spec.Module.Outputs
		}
	}
	return ep
}

func (s *Server) suggest(w http.ResponseWriter, r *http.Request) {
	var in struct {
		Providers []model.ProviderConfig `json:"providers"`
		Source    endpointSpec           `json:"source"`
		Target    endpointSpec           `json:"target"`
	}
	if !readJSON(w, r, &in) {
		return
	}
	eng := connection.Engine{Rules: s.core.Rules}
	writeJSON(w, http.StatusOK, eng.Suggest(s.endpoint(r.Context(), in.Providers, in.Source), s.endpoint(r.Context(), in.Providers, in.Target)))
}

// compatible renvoie les ids des cibles pouvant recevoir une liaison depuis la source (surlignage pendant le drag).
func (s *Server) compatible(w http.ResponseWriter, r *http.Request) {
	var in struct {
		Providers []model.ProviderConfig `json:"providers"`
		Source    endpointSpec           `json:"source"`
		Targets   []endpointSpec         `json:"targets"`
	}
	if !readJSON(w, r, &in) {
		return
	}
	eng := connection.Engine{Rules: s.core.Rules}
	src := s.endpoint(r.Context(), in.Providers, in.Source)
	ids := []string{}
	for _, t := range in.Targets {
		if t.ID == in.Source.ID {
			continue
		}
		if eng.Compatible(src, s.endpoint(r.Context(), in.Providers, t)) {
			ids = append(ids, t.ID)
		}
	}
	writeJSON(w, http.StatusOK, map[string]any{"compatible": ids})
}

// ---- Proxy Terraform Registry ---------------------------------------------------

func registryURL() string {
	if v := os.Getenv("HCLD_REGISTRY_URL"); v != "" {
		return strings.TrimRight(v, "/")
	}
	return "https://registry.terraform.io"
}

var registryClient = &http.Client{Timeout: 20 * time.Second}

func registryGet(ctx context.Context, path string, out any) error {
	req, _ := http.NewRequestWithContext(ctx, http.MethodGet, registryURL()+path, nil)
	resp, err := registryClient.Do(req)
	if err != nil {
		return fmt.Errorf("registry injoignable : %w", err)
	}
	defer resp.Body.Close()
	if resp.StatusCode != 200 {
		return fmt.Errorf("registry : HTTP %d", resp.StatusCode)
	}
	return json.NewDecoder(io.LimitReader(resp.Body, 20<<20)).Decode(out)
}

func (s *Server) registrySearch(w http.ResponseWriter, r *http.Request) {
	var out any
	if err := registryGet(r.Context(), "/v1/modules/search?limit=20&q="+url.QueryEscape(r.URL.Query().Get("q")), &out); err != nil {
		writeError(w, http.StatusBadGateway, err.Error())
		return
	}
	writeJSON(w, http.StatusOK, out)
}

// registryModule renvoie l'interface (inputs/outputs) d'un module du Registry.
func (s *Server) registryModule(w http.ResponseWriter, r *http.Request) {
	path := "/v1/modules/" + url.PathEscape(chi.URLParam(r, "ns")) + "/" + url.PathEscape(chi.URLParam(r, "name")) + "/" + url.PathEscape(chi.URLParam(r, "provider"))
	if v := r.URL.Query().Get("version"); v != "" {
		path += "/" + url.PathEscape(v)
	}
	var mod struct {
		ID       string   `json:"id"`
		Version  string   `json:"version"`
		Versions []string `json:"versions"`
		Root     struct {
			Inputs []struct {
				Name        string `json:"name"`
				Type        string `json:"type"`
				Description string `json:"description"`
				Default     string `json:"default"`
				Required    bool   `json:"required"`
			} `json:"inputs"`
			Outputs []struct {
				Name        string `json:"name"`
				Description string `json:"description"`
			} `json:"outputs"`
		} `json:"root"`
	}
	if err := registryGet(r.Context(), path, &mod); err != nil {
		writeError(w, http.StatusBadGateway, err.Error())
		return
	}
	inputs := []model.ModuleVar{}
	for _, in := range mod.Root.Inputs {
		inputs = append(inputs, model.ModuleVar{Name: in.Name, Type: in.Type, Description: in.Description, Default: in.Default, Required: in.Required})
	}
	outputs := []model.ModuleOutput{}
	for _, o := range mod.Root.Outputs {
		outputs = append(outputs, model.ModuleOutput{Name: o.Name, Description: o.Description})
	}
	writeJSON(w, http.StatusOK, map[string]any{"id": mod.ID, "version": mod.Version, "inputs": inputs, "outputs": outputs})
}

func (s *Server) registryProviderVersions(w http.ResponseWriter, r *http.Request) {
	var out struct {
		Versions []struct {
			Version string `json:"version"`
		} `json:"versions"`
	}
	path := "/v1/providers/" + url.PathEscape(chi.URLParam(r, "ns")) + "/" + url.PathEscape(chi.URLParam(r, "name")) + "/versions"
	if err := registryGet(r.Context(), path, &out); err != nil {
		writeError(w, http.StatusBadGateway, err.Error())
		return
	}
	vs := make([]string, 0, len(out.Versions))
	for i := len(out.Versions) - 1; i >= 0 && len(vs) < 50; i-- {
		vs = append(vs, out.Versions[i].Version)
	}
	writeJSON(w, http.StatusOK, vs)
}
