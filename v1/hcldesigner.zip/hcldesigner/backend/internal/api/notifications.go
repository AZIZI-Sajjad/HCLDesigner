package api

import (
	"net/http"
	"time"

	"github.com/go-chi/chi/v5"

	"github.com/AZIZI-Sajjad/hcldesigner/internal/notify"
	"github.com/AZIZI-Sajjad/hcldesigner/internal/settings"
)

func (s *Server) notificationRoutes(r chi.Router) {
	r.Get("/notifications/events", func(w http.ResponseWriter, r *http.Request) { writeJSON(w, http.StatusOK, notify.Catalog) })
	// Abonnements personnels
	r.Get("/notifications/rules", s.myRules)
	r.Post("/notifications/rules", s.saveRule)
	r.Put("/notifications/rules/{id}", s.saveRule)
	r.Delete("/notifications/rules/{id}", s.deleteRule)
	// Administration
	r.Get("/admin/smtp", s.requireGlobal("admin.smtp", s.getSMTP))
	r.Put("/admin/smtp", s.requireGlobal("admin.smtp", s.putSMTP))
	r.Post("/admin/smtp/test", s.requireGlobal("admin.smtp", s.testSMTP))
	r.Get("/admin/templates", s.requireGlobal("admin.smtp", s.getTemplates))
	r.Put("/admin/templates", s.requireGlobal("admin.smtp", s.putTemplates))
	r.Post("/admin/templates/preview", s.requireGlobal("admin.smtp", s.previewTemplate))
	r.Get("/admin/webhooks", s.requireGlobal("admin.smtp", s.listWebhooks))
	r.Post("/admin/webhooks", s.requireGlobal("admin.smtp", s.saveWebhook))
	r.Put("/admin/webhooks/{id}", s.requireGlobal("admin.smtp", s.saveWebhook))
	r.Delete("/admin/webhooks/{id}", s.requireGlobal("admin.smtp", s.deleteWebhook))
	r.Get("/admin/outbox", s.requireGlobal("admin.smtp", s.outbox))
}

func (s *Server) myRules(w http.ResponseWriter, r *http.Request) {
	rows, err := s.core.DB.Query(r.Context(), `SELECT nr.id, nr.project_id::text, COALESCE(p.name,''), nr.events, nr.digest FROM notification_rules nr
		LEFT JOIN projects p ON p.id=nr.project_id WHERE nr.user_id=$1 ORDER BY nr.created_at`, sessionOf(r).UserID)
	if err != nil {
		fail(w, err)
		return
	}
	defer rows.Close()
	out := []map[string]any{}
	for rows.Next() {
		var id, pname, digest string
		var pid *string
		var events []string
		if rows.Scan(&id, &pid, &pname, &events, &digest) == nil {
			out = append(out, map[string]any{"id": id, "projectId": pid, "projectName": pname, "events": events, "digest": digest})
		}
	}
	writeJSON(w, http.StatusOK, out)
}

func (s *Server) saveRule(w http.ResponseWriter, r *http.Request) {
	var in struct {
		ProjectID *string  `json:"projectId"`
		Events    []string `json:"events"`
		Digest    string   `json:"digest"`
	}
	if !readJSON(w, r, &in) {
		return
	}
	if in.ProjectID != nil && *in.ProjectID == "" {
		in.ProjectID = nil
	}
	if in.ProjectID != nil && !can(w, r, "projects.view", *in.ProjectID, "") {
		return
	}
	if in.Digest == "" {
		in.Digest = "none"
	}
	uid := sessionOf(r).UserID
	id := chi.URLParam(r, "id")
	var err error
	if id == "" {
		err = s.core.DB.QueryRow(r.Context(), `INSERT INTO notification_rules(user_id, project_id, events, digest) VALUES ($1,$2,$3,$4) RETURNING id`, uid, in.ProjectID, in.Events, in.Digest).Scan(&id)
	} else {
		_, err = s.core.DB.Exec(r.Context(), `UPDATE notification_rules SET project_id=$3, events=$4, digest=$5 WHERE id=$1 AND user_id=$2`, id, uid, in.ProjectID, in.Events, in.Digest)
	}
	if err != nil {
		fail(w, err)
		return
	}
	writeJSON(w, http.StatusOK, map[string]string{"id": id})
}

func (s *Server) deleteRule(w http.ResponseWriter, r *http.Request) {
	if _, err := s.core.DB.Exec(r.Context(), `DELETE FROM notification_rules WHERE id=$1 AND user_id=$2`, chi.URLParam(r, "id"), sessionOf(r).UserID); err != nil {
		fail(w, err)
		return
	}
	w.WriteHeader(http.StatusNoContent)
}

// smtpDTO : le mot de passe n'est jamais renvoyé, seulement sa présence.
type smtpDTO struct {
	Host        string `json:"host"`
	Port        int    `json:"port"`
	Security    string `json:"security"`
	Username    string `json:"username"`
	Password    string `json:"password,omitempty"`
	HasPassword bool   `json:"hasPassword"`
	From        string `json:"from"`
	SkipVerify  bool   `json:"skipVerify"`
}

func (s *Server) getSMTP(w http.ResponseWriter, r *http.Request) {
	var cfg settings.SMTP
	if err := s.core.Settings.Get(r.Context(), settings.KeySMTP, &cfg); err != nil {
		fail(w, err)
		return
	}
	writeJSON(w, http.StatusOK, smtpDTO{Host: cfg.Host, Port: cfg.Port, Security: cfg.Security, Username: cfg.Username, HasPassword: len(cfg.PasswordEnc) > 0, From: cfg.From, SkipVerify: cfg.SkipVerify})
}

func (s *Server) putSMTP(w http.ResponseWriter, r *http.Request) {
	var in smtpDTO
	if !readJSON(w, r, &in) {
		return
	}
	var cfg settings.SMTP
	_ = s.core.Settings.Get(r.Context(), settings.KeySMTP, &cfg)
	cfg.Host, cfg.Port, cfg.Security, cfg.Username, cfg.From, cfg.SkipVerify = in.Host, in.Port, in.Security, in.Username, in.From, in.SkipVerify
	if in.Password != "" {
		enc, err := s.core.Vault.Encrypt([]byte(in.Password))
		if err != nil {
			fail(w, err)
			return
		}
		cfg.PasswordEnc = enc
	}
	if err := s.core.Settings.Set(r.Context(), settings.KeySMTP, cfg); err != nil {
		fail(w, err)
		return
	}
	s.audit(r, "settings.smtp", "settings", settings.KeySMTP, map[string]any{"host": in.Host, "port": in.Port, "passwordUpdated": in.Password != ""})
	w.WriteHeader(http.StatusNoContent)
}

func (s *Server) testSMTP(w http.ResponseWriter, r *http.Request) {
	var in struct {
		To string `json:"to"`
	}
	if !readJSON(w, r, &in) {
		return
	}
	if in.To == "" {
		in.To = sessionOf(r).Email
	}
	if err := s.core.Notifier.SendMail(r.Context(), []string{in.To}, "[HCLDesigner] Mail de test", "<p>La configuration SMTP de HCLDesigner fonctionne.</p>", nil, ""); err != nil {
		writeError(w, http.StatusBadGateway, "échec de l'envoi : "+err.Error())
		return
	}
	writeJSON(w, http.StatusOK, map[string]string{"sentTo": in.To})
}

func (s *Server) getTemplates(w http.ResponseWriter, r *http.Request) {
	custom := map[string]notify.Template{}
	_ = s.core.Settings.Get(r.Context(), settings.KeyTemplates, &custom)
	writeJSON(w, http.StatusOK, map[string]any{"custom": custom, "default": notify.DefaultTemplates["default"]})
}

func (s *Server) putTemplates(w http.ResponseWriter, r *http.Request) {
	var in map[string]notify.Template
	if !readJSON(w, r, &in) {
		return
	}
	for ev, tpl := range in {
		if _, _, err := notify.RenderTemplate(tpl, sampleData()); err != nil {
			writeError(w, http.StatusBadRequest, "modèle "+ev+" invalide : "+err.Error())
			return
		}
	}
	if err := s.core.Settings.Set(r.Context(), settings.KeyTemplates, in); err != nil {
		fail(w, err)
		return
	}
	s.audit(r, "settings.templates", "settings", settings.KeyTemplates, map[string]int{"templates": len(in)})
	w.WriteHeader(http.StatusNoContent)
}

func sampleData() map[string]any {
	return map[string]any{"Brand": "HCLDesigner", "Event": notify.EvPlanFinished, "Label": "Plan terminé", "Project": "demo", "Environment": "prod",
		"Actor": "saz", "Summary": "à créer : 3, à modifier : 1, à remplacer : 0, à détruire : 0", "Link": "https://hcldesigner.local/runs/x",
		"Data": map[string]any{}, "Time": time.Now().Format("02/01/2006 15:04:05")}
}

func (s *Server) previewTemplate(w http.ResponseWriter, r *http.Request) {
	var in notify.Template
	if !readJSON(w, r, &in) {
		return
	}
	subject, body, err := notify.RenderTemplate(in, sampleData())
	if err != nil {
		writeError(w, http.StatusBadRequest, err.Error())
		return
	}
	writeJSON(w, http.StatusOK, map[string]string{"subject": subject, "body": body})
}

func (s *Server) listWebhooks(w http.ResponseWriter, r *http.Request) {
	rows, err := s.core.DB.Query(r.Context(), `SELECT id, name, kind, events, enabled, created_at FROM webhooks ORDER BY name`)
	if err != nil {
		fail(w, err)
		return
	}
	defer rows.Close()
	out := []map[string]any{}
	for rows.Next() {
		var id, name, kind string
		var events []string
		var enabled bool
		var at time.Time
		if rows.Scan(&id, &name, &kind, &events, &enabled, &at) == nil {
			out = append(out, map[string]any{"id": id, "name": name, "kind": kind, "events": events, "enabled": enabled, "createdAt": at})
		}
	}
	writeJSON(w, http.StatusOK, out)
}

// saveWebhook : l'URL (souvent porteuse d'un secret) est chiffrée ; vide en modification = inchangée.
func (s *Server) saveWebhook(w http.ResponseWriter, r *http.Request) {
	var in struct {
		Name    string   `json:"name"`
		Kind    string   `json:"kind"`
		URL     string   `json:"url"`
		Events  []string `json:"events"`
		Enabled bool     `json:"enabled"`
	}
	if !readJSON(w, r, &in) {
		return
	}
	id := chi.URLParam(r, "id")
	ctx := r.Context()
	var err error
	if id == "" {
		if in.URL == "" {
			writeError(w, http.StatusBadRequest, "URL obligatoire")
			return
		}
		enc, eerr := s.core.Vault.Encrypt([]byte(in.URL))
		if eerr != nil {
			fail(w, eerr)
			return
		}
		err = s.core.DB.QueryRow(ctx, `INSERT INTO webhooks(name, kind, url_enc, events, enabled) VALUES ($1,$2,$3,$4,$5) RETURNING id`, in.Name, in.Kind, enc, in.Events, in.Enabled).Scan(&id)
	} else {
		_, err = s.core.DB.Exec(ctx, `UPDATE webhooks SET name=$2, kind=$3, events=$4, enabled=$5 WHERE id=$1`, id, in.Name, in.Kind, in.Events, in.Enabled)
		if err == nil && in.URL != "" {
			enc, eerr := s.core.Vault.Encrypt([]byte(in.URL))
			if eerr != nil {
				fail(w, eerr)
				return
			}
			_, err = s.core.DB.Exec(ctx, `UPDATE webhooks SET url_enc=$2 WHERE id=$1`, id, enc)
		}
	}
	if err != nil {
		fail(w, err)
		return
	}
	s.audit(r, "webhook.save", "webhook", id, map[string]any{"name": in.Name, "kind": in.Kind, "events": in.Events})
	writeJSON(w, http.StatusOK, map[string]string{"id": id})
}

func (s *Server) deleteWebhook(w http.ResponseWriter, r *http.Request) {
	id := chi.URLParam(r, "id")
	if _, err := s.core.DB.Exec(r.Context(), `DELETE FROM webhooks WHERE id=$1`, id); err != nil {
		fail(w, err)
		return
	}
	s.audit(r, "webhook.delete", "webhook", id, nil)
	w.WriteHeader(http.StatusNoContent)
}

// outbox : historique des notifications envoyées.
func (s *Server) outbox(w http.ResponseWriter, r *http.Request) {
	rows, err := s.core.DB.Query(r.Context(), `SELECT id, channel, recipient, subject, event, status, attempts, error, created_at, sent_at FROM notification_outbox ORDER BY id DESC LIMIT 1000`)
	if err != nil {
		fail(w, err)
		return
	}
	defer rows.Close()
	out := []map[string]any{}
	for rows.Next() {
		var id int64
		var channel, recipient, subject, event, status, errMsg string
		var attempts int
		var created time.Time
		var sent *time.Time
		if rows.Scan(&id, &channel, &recipient, &subject, &event, &status, &attempts, &errMsg, &created, &sent) == nil {
			out = append(out, map[string]any{"id": id, "channel": channel, "recipient": recipient, "subject": subject, "event": event, "status": status,
				"attempts": attempts, "error": errMsg, "createdAt": created, "sentAt": sent})
		}
	}
	writeJSON(w, http.StatusOK, out)
}
