package api

import (
	"encoding/json"
	"net/http"
	"sort"
	"strconv"
	"strings"
	"time"

	"github.com/go-chi/chi/v5"

	"github.com/AZIZI-Sajjad/hcldesigner/internal/core"
)

func (s *Server) dashboardRoutes(r chi.Router) {
	r.Get("/dashboard", s.dashboard)
	r.Get("/dashboard/metric", s.metric)
}

// visibleFilter renvoie un filtre SQL sur project_id selon les droits ("" = tout).
func visibleFilter(r *http.Request, col string, args *[]any) string {
	vis := subjectOf(r).VisibleProjects()
	if vis == nil {
		return ""
	}
	*args = append(*args, vis)
	return " AND " + col + "::text = ANY($" + strconv.Itoa(len(*args)) + ")"
}

func (s *Server) dashboard(w http.ResponseWriter, r *http.Request) {
	ctx := r.Context()
	out := map[string]any{}
	count := func(key, sql string) {
		args := []any{}
		sql = strings.Replace(sql, "{vis}", visibleFilter(r, "project_id", &args), 1)
		var n int
		_ = s.core.DB.QueryRow(ctx, sql, args...).Scan(&n)
		out[key] = n
	}
	count("projects", `SELECT count(*) FROM (SELECT id AS project_id FROM projects) p WHERE true{vis}`)
	count("environments", `SELECT count(*) FROM environments WHERE true{vis}`)
	count("running", `SELECT count(*) FROM runs WHERE status IN ('queued','running'){vis}`)
	count("failed24h", `SELECT count(*) FROM runs WHERE status='failed' AND created_at > now()-interval '24 hours'{vis}`)

	// Listes : exécutions récentes, en cours, approbations en attente, drifts, non-conformités.
	list := func(key, where string, limit int) []*core.Run {
		args := []any{}
		sql := `SELECT ` + core.RunCols + core.RunFrom + ` WHERE ` + where + visibleFilter(r, "r.project_id", &args) + ` ORDER BY r.created_at DESC LIMIT ` + strconv.Itoa(limit)
		rows, err := s.core.DB.Query(ctx, sql, args...)
		res := []*core.Run{}
		if err == nil {
			for rows.Next() {
				if run, err := core.ScanRun(rows); err == nil {
					res = append(res, run)
				}
			}
			rows.Close()
		}
		out[key] = res
		return res
	}
	list("recentRuns", "true", 10)
	list("activeRuns", "r.status IN ('queued','running')", 20)
	pending := list("pendingApprovals", "r.status='planned' AND r.approvals_required > 0", 50)
	sub := subjectOf(r)
	mine := []*core.Run{}
	for _, p := range pending {
		if sub.Can("runs.approve", p.ProjectID, p.EnvironmentName) {
			mine = append(mine, p)
		}
	}
	out["pendingApprovals"] = mine
	// Dernier contrôle de drift par environnement, gardé s'il a détecté des écarts.
	drifts := list("drifts", `r.id IN (SELECT DISTINCT ON (environment_id) id FROM runs WHERE operation='plan' AND options->>'drift'='true' AND status='checked' ORDER BY environment_id, created_at DESC)`, 100)
	withDrift := []*core.Run{}
	for _, d := range drifts {
		var sm struct {
			Drift []json.RawMessage `json:"drift"`
		}
		if json.Unmarshal(d.Summary, &sm) == nil && len(sm.Drift) > 0 {
			withDrift = append(withDrift, d)
		}
	}
	out["drifts"] = withDrift
	list("nonCompliant", `r.status IN ('planned','applied') AND jsonb_array_length(COALESCE(r.policy_report->'violations','[]'::jsonb)) > 0 AND r.created_at > now()-interval '30 days'`, 20)

	// Prochaines tâches planifiées
	args := []any{}
	rows, err := s.core.DB.Query(ctx, `SELECT t.id, t.name, t.kind, t.next_run_at, COALESCE(p.name,'') FROM scheduled_tasks t LEFT JOIN projects p ON p.id=t.project_id
		WHERE t.enabled AND t.next_run_at IS NOT NULL`+visibleFilterNullable(r, "t.project_id", &args)+` ORDER BY t.next_run_at LIMIT 10`, args...)
	next := []map[string]any{}
	if err == nil {
		for rows.Next() {
			var id, name, kind, project string
			var at time.Time
			if rows.Scan(&id, &name, &kind, &at, &project) == nil {
				next = append(next, map[string]any{"id": id, "name": name, "kind": kind, "nextRunAt": at, "project": project})
			}
		}
		rows.Close()
	}
	out["nextTasks"] = next
	out["runsPerDay"] = s.metricData(r, "runs", "day_status", 30)
	out["resourcesByProvider"] = s.metricData(r, "resources", "provider", 0)
	out["durations"] = s.metricData(r, "duration", "operation", 30)
	out["topChanged"] = s.metricData(r, "changes", "address", 30)
	writeJSON(w, http.StatusOK, out)
}

// visibleFilterNullable : comme visibleFilter, mais les lignes sans projet (tâches globales) restent visibles des admins.
func visibleFilterNullable(r *http.Request, col string, args *[]any) string {
	f := visibleFilter(r, col, args)
	if f == "" {
		return ""
	}
	return " AND (" + strings.TrimPrefix(f, " AND ") + ")"
}

// metric : données d'un widget personnalisé (métrique × dimension × période).
func (s *Server) metric(w http.ResponseWriter, r *http.Request) {
	q := r.URL.Query()
	days, _ := strconv.Atoi(q.Get("period"))
	writeJSON(w, http.StatusOK, s.metricData(r, q.Get("metric"), q.Get("dimension"), days))
}

type point struct {
	Key   string  `json:"key"`
	Group string  `json:"group,omitempty"`
	Value float64 `json:"value"`
}

// metricData calcule une série. Métriques : runs, duration, resources, changes.
func (s *Server) metricData(r *http.Request, metric, dimension string, days int) []point {
	ctx := r.Context()
	if days <= 0 {
		days = 30
	}
	args := []any{days}
	period := ` AND r.created_at > now() - make_interval(days => $1)`
	dims := map[string]string{
		"project": "p.name", "environment": "p.name || '/' || e.name", "status": "r.status", "operation": "r.operation",
		"day": "to_char(r.created_at, 'YYYY-MM-DD')", "user": "COALESCE(u.username, r.triggered_by)", "trigger": "r.triggered_by",
	}
	out := []point{}
	scan := func(sql string, args []any, grouped bool) {
		rows, err := s.core.DB.Query(ctx, sql, args...)
		if err != nil {
			return
		}
		defer rows.Close()
		for rows.Next() {
			var p point
			if grouped {
				if rows.Scan(&p.Key, &p.Group, &p.Value) == nil {
					out = append(out, p)
				}
			} else if rows.Scan(&p.Key, &p.Value) == nil {
				out = append(out, p)
			}
		}
	}
	from := ` FROM runs r JOIN projects p ON p.id=r.project_id JOIN environments e ON e.id=r.environment_id LEFT JOIN users u ON u.id=r.created_by WHERE true`
	switch metric {
	case "runs":
		if dimension == "day_status" {
			scan(`SELECT to_char(r.created_at,'YYYY-MM-DD'), CASE WHEN r.status='failed' THEN 'échec' ELSE 'succès' END, count(*)`+from+period+visibleFilter(r, "r.project_id", &args)+` GROUP BY 1,2 ORDER BY 1`, args, true)
			return out
		}
		d, ok := dims[dimension]
		if !ok {
			d = dims["status"]
		}
		scan(`SELECT `+d+`, count(*)`+from+period+visibleFilter(r, "r.project_id", &args)+` GROUP BY 1 ORDER BY 2 DESC LIMIT 50`, args, false)
	case "duration":
		d, ok := dims[dimension]
		if !ok {
			d = dims["operation"]
		}
		scan(`SELECT `+d+`, round(avg(extract(epoch FROM r.finished_at - r.started_at))::numeric, 1)`+from+period+` AND r.finished_at IS NOT NULL AND r.started_at IS NOT NULL`+
			visibleFilter(r, "r.project_id", &args)+` GROUP BY 1 ORDER BY 2 DESC LIMIT 50`, args, false)
	case "changes":
		out = s.topChanged(r, days)
	case "resources":
		out = s.resourceCounts(r, dimension)
	}
	return out
}

// topChanged : ressources les plus modifiées par les applies récents.
func (s *Server) topChanged(r *http.Request, days int) []point {
	args := []any{days}
	sql := `SELECT c->>'address', count(*) FROM runs r CROSS JOIN LATERAL jsonb_array_elements(COALESCE(r.summary->'changes','[]'::jsonb)) c
		WHERE r.operation='apply' AND r.status='applied' AND r.created_at > now() - make_interval(days => $1)` + visibleFilter(r, "r.project_id", &args) + ` GROUP BY 1 ORDER BY 2 DESC LIMIT 15`
	out := []point{}
	rows, err := s.core.DB.Query(r.Context(), sql, args...)
	if err != nil {
		return out
	}
	defer rows.Close()
	for rows.Next() {
		var p point
		if rows.Scan(&p.Key, &p.Value) == nil {
			out = append(out, p)
		}
	}
	return out
}

// resourceCounts compte les ressources gérées d'après la dernière version de state de chaque environnement.
func (s *Server) resourceCounts(r *http.Request, dimension string) []point {
	ctx := r.Context()
	args := []any{}
	rows, err := s.core.DB.Query(ctx, `SELECT DISTINCT ON (sv.environment_id) sv.environment_id, p.name, e.name FROM state_versions sv
		JOIN environments e ON e.id=sv.environment_id JOIN projects p ON p.id=e.project_id WHERE true`+visibleFilter(r, "p.id", &args)+
		` ORDER BY sv.environment_id, sv.created_at DESC`, args...)
	if err != nil {
		return []point{}
	}
	type envRef struct{ id, project, env string }
	var envs []envRef
	for rows.Next() {
		var e envRef
		if rows.Scan(&e.id, &e.project, &e.env) == nil {
			envs = append(envs, e)
		}
	}
	rows.Close()
	counts := map[string]float64{}
	for _, e := range envs {
		raw, err := s.core.LatestState(ctx, e.id)
		if err != nil || raw == nil {
			continue
		}
		meta, err := core.ParseStateMeta(raw)
		if err != nil {
			continue
		}
		for _, res := range meta.Resources {
			if res.Mode != "managed" {
				continue
			}
			key := res.Type
			switch dimension {
			case "provider":
				key = strings.SplitN(res.Type, "_", 2)[0]
			case "project":
				key = e.project
			case "environment":
				key = e.project + "/" + e.env
			}
			counts[key] += float64(max(1, len(res.Instances)))
		}
	}
	out := make([]point, 0, len(counts))
	for k, v := range counts {
		out = append(out, point{Key: k, Value: v})
	}
	sort.Slice(out, func(i, j int) bool { return out[i].Value > out[j].Value })
	if len(out) > 50 {
		out = out[:50]
	}
	return out
}
