package api

import (
	"encoding/json"
	"fmt"
	"net/http"
	"strconv"
	"strings"
	"time"

	"github.com/go-chi/chi/v5"

	"github.com/AZIZI-Sajjad/hcldesigner/internal/core"
	"github.com/AZIZI-Sajjad/hcldesigner/internal/db"
	"github.com/AZIZI-Sajjad/hcldesigner/internal/model"
	"github.com/AZIZI-Sajjad/hcldesigner/internal/modules"
	"github.com/AZIZI-Sajjad/hcldesigner/internal/policy"
	"github.com/AZIZI-Sajjad/hcldesigner/internal/rbac"
	"github.com/AZIZI-Sajjad/hcldesigner/internal/runner"
)

func (s *Server) projectRoutes(r chi.Router) {
	r.Get("/projects", s.listProjects)
	r.Post("/projects", s.createProject)
	r.Post("/projects/import-hcl", s.importHCL)
	r.Route("/projects/{pid}", func(r chi.Router) {
		r.Get("/", s.getProject)
		r.Put("/", s.updateProject)
		r.Delete("/", s.deleteProject)
		r.Put("/model", s.saveModel)
		r.Get("/versions", s.listVersions)
		r.Get("/versions/{v}", s.getVersion)
		r.Post("/versions/{v}/restore", s.restoreVersion)
		r.Post("/generate", s.generate)
		r.Get("/export", s.export)
		r.Post("/policies/check", s.checkPolicies)
		r.Post("/extract-module", s.extractModule)
	})
}

type projectListItem struct {
	ID            string     `json:"id"`
	Name          string     `json:"name"`
	Description   string     `json:"description"`
	Nodes         int        `json:"nodes"`
	Providers     []string   `json:"providers"`
	Environments  int        `json:"environments"`
	LastRunStatus string     `json:"lastRunStatus"`
	LastRunAt     *time.Time `json:"lastRunAt"`
	Version       int        `json:"version"`
	UpdatedAt     time.Time  `json:"updatedAt"`
}

func (s *Server) listProjects(w http.ResponseWriter, r *http.Request) {
	projects, err := s.core.ListProjects(r.Context(), subjectOf(r).VisibleProjects())
	if err != nil {
		fail(w, err)
		return
	}
	out := make([]projectListItem, 0, len(projects))
	for _, p := range projects {
		it := projectListItem{ID: p.ID, Name: p.Name, Description: p.Description, Nodes: len(p.Model.Nodes), Version: p.Version, UpdatedAt: p.UpdatedAt, Providers: []string{}}
		for _, pc := range p.Model.Providers {
			it.Providers = append(it.Providers, pc.Source)
		}
		_ = s.core.DB.QueryRow(r.Context(), `SELECT count(*) FROM environments WHERE project_id=$1`, p.ID).Scan(&it.Environments)
		_ = s.core.DB.QueryRow(r.Context(), `SELECT status, created_at FROM runs WHERE project_id=$1 ORDER BY created_at DESC LIMIT 1`, p.ID).Scan(&it.LastRunStatus, &it.LastRunAt)
		out = append(out, it)
	}
	writeJSON(w, http.StatusOK, out)
}

func (s *Server) createProject(w http.ResponseWriter, r *http.Request) {
	if !can(w, r, "projects.create", "", "") {
		return
	}
	var in struct {
		Name        string         `json:"name"`
		Description string         `json:"description"`
		TeamID      *string        `json:"teamId"`
		Model       *model.Project `json:"model"` // import d'un modèle JSON exporté
	}
	if !readJSON(w, r, &in) {
		return
	}
	if strings.TrimSpace(in.Name) == "" {
		writeError(w, http.StatusBadRequest, "nom obligatoire")
		return
	}
	m := model.New()
	if in.Model != nil {
		if in.Model.SchemaVersion > model.SchemaVersion {
			writeError(w, http.StatusBadRequest, "modèle produit par une version plus récente de HCLDesigner")
			return
		}
		m = *in.Model
	}
	sess := sessionOf(r)
	p, err := s.core.CreateProject(r.Context(), strings.TrimSpace(in.Name), in.Description, sess.UserID, in.TeamID, m)
	if err != nil {
		fail(w, err)
		return
	}
	// Le créateur reçoit le rôle Admin sur son projet s'il n'a pas déjà un accès global.
	if !subjectOf(r).Can("projects.edit", p.ID, "") {
		_, _ = s.core.DB.Exec(r.Context(), `INSERT INTO role_bindings(role_id, user_id, scope, project_id) SELECT id, $1, 'project', $2 FROM roles WHERE name='Admin'`, sess.UserID, p.ID)
	}
	s.audit(r, "project.create", "project", p.ID, map[string]any{"name": p.Name, "imported": in.Model != nil})
	writeJSON(w, http.StatusCreated, p)
}

// projectFor charge le projet de l'URL après vérification de la permission.
func (s *Server) projectFor(w http.ResponseWriter, r *http.Request, perm rbac.Permission) *core.Project {
	pid := chi.URLParam(r, "pid")
	if !can(w, r, perm, pid, "") {
		return nil
	}
	p, err := s.core.GetProject(r.Context(), pid)
	if err != nil {
		fail(w, err)
		return nil
	}
	return p
}

func (s *Server) getProject(w http.ResponseWriter, r *http.Request) {
	p := s.projectFor(w, r, "projects.view")
	if p == nil {
		return
	}
	sub := subjectOf(r)
	writeJSON(w, http.StatusOK, map[string]any{
		"project":     p,
		"diagnostics": p.Model.Validate(),
		"permissions": map[string]bool{
			"edit": sub.Can("projects.edit", p.ID, ""), "delete": sub.Can("projects.delete", p.ID, ""),
			"share": sub.Can("projects.share", p.ID, ""), "export": sub.Can("code.export", p.ID, ""),
			"environments": sub.Can("environments.manage", p.ID, ""), "schedules": sub.Can("schedules.manage", p.ID, ""),
			"modulesCreate": sub.Can("modules.create", "", ""), "providersAdd": sub.Can("providers.add", "", ""),
		},
	})
}

func (s *Server) updateProject(w http.ResponseWriter, r *http.Request) {
	p := s.projectFor(w, r, "projects.edit")
	if p == nil {
		return
	}
	var in struct {
		Name        string  `json:"name"`
		Description string  `json:"description"`
		TeamID      *string `json:"teamId"`
	}
	if !readJSON(w, r, &in) {
		return
	}
	if _, err := s.core.DB.Exec(r.Context(), `UPDATE projects SET name=$2, description=$3, team_id=$4, updated_at=now() WHERE id=$1`, p.ID, in.Name, in.Description, in.TeamID); err != nil {
		fail(w, err)
		return
	}
	s.audit(r, "project.update", "project", p.ID, map[string]any{"before": map[string]string{"name": p.Name, "description": p.Description}, "after": in})
	w.WriteHeader(http.StatusNoContent)
}

func (s *Server) deleteProject(w http.ResponseWriter, r *http.Request) {
	p := s.projectFor(w, r, "projects.delete")
	if p == nil {
		return
	}
	var active bool
	_ = s.core.DB.QueryRow(r.Context(), `SELECT EXISTS(SELECT 1 FROM runs WHERE project_id=$1 AND status IN ('queued','running'))`, p.ID).Scan(&active)
	if active {
		writeError(w, http.StatusConflict, "des exécutions sont en cours sur ce projet")
		return
	}
	if _, err := s.core.DB.Exec(r.Context(), `DELETE FROM projects WHERE id=$1`, p.ID); err != nil {
		fail(w, err)
		return
	}
	_, _ = s.core.DB.Exec(r.Context(), `DELETE FROM role_bindings WHERE project_id=$1`, p.ID)
	s.audit(r, "project.delete", "project", p.ID, map[string]any{"name": p.Name})
	w.WriteHeader(http.StatusNoContent)
}

func (s *Server) saveModel(w http.ResponseWriter, r *http.Request) {
	p := s.projectFor(w, r, "projects.edit")
	if p == nil {
		return
	}
	var in struct {
		Version int           `json:"version"`
		Model   model.Project `json:"model"`
		Message string        `json:"message"`
	}
	if !readJSON(w, r, &in) {
		return
	}
	// Seuls les utilisateurs autorisés à configurer les providers peuvent en ajouter.
	if len(in.Model.Providers) > len(p.Model.Providers) && !subjectOf(r).Can("providers.add", "", "") {
		writeError(w, http.StatusForbidden, "permission requise : providers.add")
		return
	}
	saved, err := s.core.SaveModel(r.Context(), p.ID, in.Version, in.Model, sessionOf(r).UserID, in.Message)
	if err != nil {
		fail(w, err)
		return
	}
	s.audit(r, "project.model_update", "project", p.ID, modelDiff(&p.Model, &saved.Model, in.Message))
	writeJSON(w, http.StatusOK, map[string]any{"version": saved.Version, "updatedAt": saved.UpdatedAt, "diagnostics": saved.Model.Validate()})
}

// modelDiff résume les changements d'un modèle pour l'audit.
func modelDiff(before, after *model.Project, msg string) map[string]any {
	b, a := map[string]string{}, map[string]string{}
	for _, n := range before.Nodes {
		b[n.ID] = n.Address()
	}
	for _, n := range after.Nodes {
		a[n.ID] = n.Address()
	}
	var added, removed, renamed []string
	for id, addr := range a {
		if old, ok := b[id]; !ok {
			added = append(added, addr)
		} else if old != addr {
			renamed = append(renamed, old+" → "+addr)
		}
	}
	for id, addr := range b {
		if _, ok := a[id]; !ok {
			removed = append(removed, addr)
		}
	}
	return map[string]any{"message": msg, "added": added, "removed": removed, "renamed": renamed, "nodes": len(after.Nodes)}
}

type versionItem struct {
	Version   int       `json:"version"`
	Message   string    `json:"message"`
	Author    string    `json:"author"`
	CreatedAt time.Time `json:"createdAt"`
	Nodes     int       `json:"nodes"`
}

func (s *Server) listVersions(w http.ResponseWriter, r *http.Request) {
	p := s.projectFor(w, r, "projects.view")
	if p == nil {
		return
	}
	rows, err := s.core.DB.Query(r.Context(), `SELECT v.version, v.message, COALESCE(u.username,''), v.created_at, jsonb_array_length(COALESCE(v.model->'nodes','[]'::jsonb))
		FROM project_versions v LEFT JOIN users u ON u.id=v.author_id WHERE v.project_id=$1 ORDER BY v.version DESC LIMIT 500`, p.ID)
	if err != nil {
		fail(w, err)
		return
	}
	defer rows.Close()
	out := []versionItem{}
	for rows.Next() {
		var v versionItem
		if err := rows.Scan(&v.Version, &v.Message, &v.Author, &v.CreatedAt, &v.Nodes); err != nil {
			fail(w, err)
			return
		}
		out = append(out, v)
	}
	writeJSON(w, http.StatusOK, out)
}

func (s *Server) loadVersion(r *http.Request, projectID string) (*model.Project, int, error) {
	v, err := strconv.Atoi(chi.URLParam(r, "v"))
	if err != nil {
		return nil, 0, bad("numéro de version invalide")
	}
	var raw []byte
	if err := s.core.DB.QueryRow(r.Context(), `SELECT model FROM project_versions WHERE project_id=$1 AND version=$2`, projectID, v).Scan(&raw); err != nil {
		return nil, 0, db.NotFound(err)
	}
	var m model.Project
	return &m, v, json.Unmarshal(raw, &m)
}

func (s *Server) getVersion(w http.ResponseWriter, r *http.Request) {
	p := s.projectFor(w, r, "projects.view")
	if p == nil {
		return
	}
	m, _, err := s.loadVersion(r, p.ID)
	if err != nil {
		fail(w, err)
		return
	}
	writeJSON(w, http.StatusOK, m)
}

func (s *Server) restoreVersion(w http.ResponseWriter, r *http.Request) {
	p := s.projectFor(w, r, "projects.edit")
	if p == nil {
		return
	}
	m, v, err := s.loadVersion(r, p.ID)
	if err != nil {
		fail(w, err)
		return
	}
	saved, err := s.core.SaveModel(r.Context(), p.ID, p.Version, *m, sessionOf(r).UserID, fmt.Sprintf("restauration de la version %d", v))
	if err != nil {
		fail(w, err)
		return
	}
	s.audit(r, "project.restore", "project", p.ID, map[string]int{"version": v})
	writeJSON(w, http.StatusOK, map[string]int{"version": saved.Version})
}

// generate produit le code du modèle fourni (aperçu temps réel, non sauvegardé) ou enregistré.
func (s *Server) generate(w http.ResponseWriter, r *http.Request) {
	p := s.projectFor(w, r, "code.view")
	if p == nil {
		return
	}
	var in struct {
		Model         *model.Project `json:"model"`
		EnvironmentID string         `json:"environmentId"`
	}
	if !readJSON(w, r, &in) {
		return
	}
	m := &p.Model
	if in.Model != nil {
		m = in.Model
	}
	opts := core.GenerateOptions{}
	if in.EnvironmentID != "" {
		env, err := s.core.GetEnvironment(r.Context(), in.EnvironmentID)
		if err != nil || env.ProjectID != p.ID {
			writeError(w, http.StatusBadRequest, "environnement invalide")
			return
		}
		opts.Env = env
	}
	res, err := s.core.Generate(r.Context(), m, opts)
	if err != nil {
		fail(w, err)
		return
	}
	diags := append(m.Validate(), res.Diags...)
	if p.LockFile != "" {
		res.Files[".terraform.lock.hcl"] = p.LockFile
	}
	writeJSON(w, http.StatusOK, map[string]any{"files": res.Files, "ranges": res.Ranges, "diagnostics": diags})
}

// checkPolicies évalue les règles de conformité sur le modèle (coloration du canvas).
func (s *Server) checkPolicies(w http.ResponseWriter, r *http.Request) {
	p := s.projectFor(w, r, "projects.view")
	if p == nil {
		return
	}
	var in struct {
		Model *model.Project `json:"model"`
	}
	if !readJSON(w, r, &in) {
		return
	}
	m := &p.Model
	if in.Model != nil {
		m = in.Model
	}
	pols, err := runner.LoadPolicies(r.Context(), s.core, p.ID)
	if err != nil {
		fail(w, err)
		return
	}
	writeJSON(w, http.StatusOK, policy.Evaluate(pols, policy.FromModel(m), m.Providers))
}

// extractModule crée un module (version 1.0.0) depuis une sélection et remplace celle-ci dans le projet.
func (s *Server) extractModule(w http.ResponseWriter, r *http.Request) {
	p := s.projectFor(w, r, "projects.edit")
	if p == nil || !can(w, r, "modules.create", "", "") {
		return
	}
	var in struct {
		Model       model.Project `json:"model"`
		Version     int           `json:"version"`
		NodeIDs     []string      `json:"nodeIds"`
		Name        string        `json:"name"`
		Label       string        `json:"label"`
		Description string        `json:"description"`
	}
	if !readJSON(w, r, &in) {
		return
	}
	if !model.LabelRegexp.MatchString(in.Name) {
		writeError(w, http.StatusBadRequest, "nom de module invalide (lettres, chiffres, _ et -)")
		return
	}
	if in.Label == "" {
		in.Label = strings.ReplaceAll(in.Name, "-", "_")
	}
	ctx := r.Context()
	var moduleID string
	if err := s.core.DB.QueryRow(ctx, `INSERT INTO modules(name, description, scope, project_id, draft, created_by) VALUES ($1,$2,'project',$3,'{}',$4) RETURNING id`,
		in.Name, in.Description, p.ID, sessionOf(r).UserID).Scan(&moduleID); err != nil {
		fail(w, err)
		return
	}
	res, err := modules.Extract(&in.Model, in.NodeIDs, moduleID, in.Name, in.Label)
	if err != nil {
		_, _ = s.core.DB.Exec(ctx, `DELETE FROM modules WHERE id=$1`, moduleID)
		writeError(w, http.StatusBadRequest, err.Error())
		return
	}
	res.Project.Nodes[len(res.Project.Nodes)-1].Module.Version = "1.0.0"
	modRaw, _ := json.Marshal(res.Module)
	if _, err := s.core.DB.Exec(ctx, `UPDATE modules SET draft=$2 WHERE id=$1`, moduleID, modRaw); err != nil {
		fail(w, err)
		return
	}
	if _, err := s.core.DB.Exec(ctx, `INSERT INTO module_versions(module_id, version, model, changelog, created_by) VALUES ($1,'1.0.0',$2,'Extraction depuis le projet '||$3,$4)`,
		moduleID, modRaw, p.Name, sessionOf(r).UserID); err != nil {
		fail(w, err)
		return
	}
	saved, err := s.core.SaveModel(ctx, p.ID, in.Version, res.Project, sessionOf(r).UserID, "extraction du module "+in.Name)
	if err != nil {
		fail(w, err)
		return
	}
	s.audit(r, "module.extract", "module", moduleID, map[string]any{"project": p.ID, "nodes": in.NodeIDs})
	writeJSON(w, http.StatusOK, map[string]any{"moduleId": moduleID, "model": saved.Model, "version": saved.Version, "warnings": res.Warnings})
}
