package api

import (
	"encoding/csv"
	"encoding/json"
	"net/http"
	"strconv"
	"time"

	"github.com/go-chi/chi/v5"

	"github.com/AZIZI-Sajjad/hcldesigner/internal/settings"
	"github.com/AZIZI-Sajjad/hcldesigner/internal/tfbin"
)

func (s *Server) settingsRoutes(r chi.Router) {
	r.Get("/admin/settings", s.requireGlobal("admin.settings", s.getSettings))
	r.Put("/admin/settings", s.requireGlobal("admin.settings", s.putSettings))
	r.Get("/engines", s.engines)
	r.Get("/admin/audit", s.requireGlobal("audit.view", s.listAudit))
	r.Get("/admin/audit/export", s.requireGlobal("audit.export", s.exportAudit))
}

// generalSettings regroupe les paramètres éditables dans l'écran "Paramètres".
type generalSettings struct {
	Runs     settings.Runs      `json:"runs"`
	Mirror   tfbin.MirrorConfig `json:"mirror"`
	Branding settings.Branding  `json:"branding"`
	Security settings.Security  `json:"security"`
	Syslog   settings.Syslog    `json:"syslog"`
	Engines  settings.Engines   `json:"engines"`
}

func (s *Server) loadGeneral(r *http.Request) generalSettings {
	ctx := r.Context()
	var g generalSettings
	_ = s.core.Settings.Get(ctx, settings.KeyRuns, &g.Runs)
	_ = s.core.Settings.Get(ctx, settings.KeyMirror, &g.Mirror)
	_ = s.core.Settings.Get(ctx, settings.KeyBranding, &g.Branding)
	_ = s.core.Settings.Get(ctx, settings.KeySecurity, &g.Security)
	_ = s.core.Settings.Get(ctx, settings.KeySyslog, &g.Syslog)
	_ = s.core.Settings.Get(ctx, settings.KeyEngines, &g.Engines)
	return g
}

func (s *Server) getSettings(w http.ResponseWriter, r *http.Request) {
	writeJSON(w, http.StatusOK, s.loadGeneral(r))
}

func (s *Server) putSettings(w http.ResponseWriter, r *http.Request) {
	var in generalSettings
	if !readJSON(w, r, &in) {
		return
	}
	if in.Security.PasswordPolicy.MinLength < 8 {
		writeError(w, http.StatusBadRequest, "longueur minimale des mots de passe : 8 au moins")
		return
	}
	before := s.loadGeneral(r)
	ctx := r.Context()
	for key, v := range map[string]any{settings.KeyRuns: in.Runs, settings.KeyMirror: in.Mirror, settings.KeyBranding: in.Branding,
		settings.KeySecurity: in.Security, settings.KeySyslog: in.Syslog, settings.KeyEngines: in.Engines} {
		if err := s.core.Settings.Set(ctx, key, v); err != nil {
			fail(w, err)
			return
		}
	}
	s.core.Audit.SetSyslog(in.Syslog.Addr)
	s.audit(r, "settings.update", "settings", "general", map[string]any{"before": before, "after": in})
	w.WriteHeader(http.StatusNoContent)
}

// engines liste les versions Terraform/OpenTofu proposées dans les projets.
func (s *Server) engines(w http.ResponseWriter, r *http.Request) {
	var e settings.Engines
	_ = s.core.Settings.Get(r.Context(), settings.KeyEngines, &e)
	pre := map[string]string{}
	for engine, bin := range map[string]string{"terraform": s.core.TF.PreinstalledTF, "opentofu": s.core.TF.PreinstalledTofu} {
		if bin == "" {
			continue
		}
		if v, err := tfbin.BinaryVersion(r.Context(), bin); err == nil {
			pre[engine] = v
		}
	}
	writeJSON(w, http.StatusOK, map[string]any{"versions": e.Versions, "preinstalled": pre})
}

type auditRow struct {
	ID         int64           `json:"id"`
	TS         time.Time       `json:"ts"`
	Username   string          `json:"username"`
	IP         string          `json:"ip"`
	Action     string          `json:"action"`
	ObjectType string          `json:"objectType"`
	ObjectID   string          `json:"objectId"`
	Details    json.RawMessage `json:"details"`
}

func (s *Server) queryAudit(r *http.Request, limit int) ([]auditRow, error) {
	q := r.URL.Query()
	sql := `SELECT id, ts, username, ip, action, object_type, object_id, details FROM audit_events WHERE true`
	args := []any{}
	add := func(cond string, v any) {
		args = append(args, v)
		sql += " AND " + cond + "$" + strconv.Itoa(len(args))
	}
	if v := q.Get("user"); v != "" {
		add("username ILIKE ", "%"+v+"%")
	}
	if v := q.Get("action"); v != "" {
		add("action ILIKE ", v+"%")
	}
	if v := q.Get("object"); v != "" {
		add("object_id=", v)
	}
	if v := q.Get("from"); v != "" {
		add("ts >= ", v)
	}
	if v := q.Get("to"); v != "" {
		add("ts <= ", v)
	}
	sql += " ORDER BY id DESC LIMIT " + strconv.Itoa(limit)
	rows, err := s.core.DB.Query(r.Context(), sql, args...)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	out := []auditRow{}
	for rows.Next() {
		var a auditRow
		if err := rows.Scan(&a.ID, &a.TS, &a.Username, &a.IP, &a.Action, &a.ObjectType, &a.ObjectID, &a.Details); err != nil {
			return nil, err
		}
		out = append(out, a)
	}
	return out, rows.Err()
}

func (s *Server) listAudit(w http.ResponseWriter, r *http.Request) {
	rows, err := s.queryAudit(r, 2000)
	if err != nil {
		fail(w, err)
		return
	}
	writeJSON(w, http.StatusOK, rows)
}

func (s *Server) exportAudit(w http.ResponseWriter, r *http.Request) {
	rows, err := s.queryAudit(r, 100000)
	if err != nil {
		fail(w, err)
		return
	}
	s.audit(r, "audit.export", "audit", "", map[string]int{"rows": len(rows)})
	w.Header().Set("Content-Type", "text/csv; charset=utf-8")
	w.Header().Set("Content-Disposition", `attachment; filename="audit.csv"`)
	cw := csv.NewWriter(w)
	cw.Comma = ';'
	_ = cw.Write([]string{"id", "date", "utilisateur", "ip", "action", "type", "objet", "détails"})
	for _, a := range rows {
		_ = cw.Write([]string{strconv.FormatInt(a.ID, 10), a.TS.Format(time.RFC3339), a.Username, a.IP, a.Action, a.ObjectType, a.ObjectID, string(a.Details)})
	}
	cw.Flush()
}
