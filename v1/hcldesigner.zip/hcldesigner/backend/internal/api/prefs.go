package api

import (
	"encoding/json"
	"net/http"
	"regexp"
	"time"

	"github.com/go-chi/chi/v5"
)

var tableIDRe = regexp.MustCompile(`^[a-z0-9_.-]{1,64}$`)

// prefsRoutes : préférences de tableaux (ordre, largeurs, colonnes visibles, tris, filtres),
// vues enregistrées et réglages personnels (tableau de bord).
func (s *Server) prefsRoutes(r chi.Router) {
	r.Get("/prefs/tables/{table}", s.getTablePrefs)
	r.Put("/prefs/tables/{table}", s.putTablePrefs)
	r.Delete("/prefs/tables/{table}", s.resetTablePrefs)
	r.Get("/prefs/views/{table}", s.listViews)
	r.Post("/prefs/views/{table}", s.saveView)
	r.Delete("/prefs/views/{table}/{id}", s.deleteView)
	r.Get("/prefs/user/{key}", s.getUserSetting)
	r.Put("/prefs/user/{key}", s.putUserSetting)
}

func tableParam(w http.ResponseWriter, r *http.Request) (string, bool) {
	t := chi.URLParam(r, "table")
	if !tableIDRe.MatchString(t) {
		writeError(w, http.StatusBadRequest, "identifiant de tableau invalide")
		return "", false
	}
	return t, true
}

func (s *Server) getTablePrefs(w http.ResponseWriter, r *http.Request) {
	t, ok := tableParam(w, r)
	if !ok {
		return
	}
	var raw []byte
	if err := s.core.DB.QueryRow(r.Context(), `SELECT prefs FROM table_prefs WHERE user_id=$1 AND table_id=$2`, sessionOf(r).UserID, t).Scan(&raw); err != nil {
		writeJSON(w, http.StatusOK, nil)
		return
	}
	w.Header().Set("Content-Type", "application/json")
	_, _ = w.Write(raw)
}

func (s *Server) putTablePrefs(w http.ResponseWriter, r *http.Request) {
	t, ok := tableParam(w, r)
	if !ok {
		return
	}
	var prefs json.RawMessage
	if !readJSON(w, r, &prefs) {
		return
	}
	if _, err := s.core.DB.Exec(r.Context(), `INSERT INTO table_prefs(user_id, table_id, prefs) VALUES ($1,$2,$3) ON CONFLICT (user_id, table_id) DO UPDATE SET prefs=EXCLUDED.prefs`,
		sessionOf(r).UserID, t, []byte(prefs)); err != nil {
		fail(w, err)
		return
	}
	w.WriteHeader(http.StatusNoContent)
}

func (s *Server) resetTablePrefs(w http.ResponseWriter, r *http.Request) {
	t, ok := tableParam(w, r)
	if !ok {
		return
	}
	_, _ = s.core.DB.Exec(r.Context(), `DELETE FROM table_prefs WHERE user_id=$1 AND table_id=$2`, sessionOf(r).UserID, t)
	w.WriteHeader(http.StatusNoContent)
}

func (s *Server) listViews(w http.ResponseWriter, r *http.Request) {
	t, ok := tableParam(w, r)
	if !ok {
		return
	}
	uid := sessionOf(r).UserID
	rows, err := s.core.DB.Query(r.Context(), `SELECT v.id, v.name, v.prefs, v.shared, v.user_id=$1, u.username, v.created_at FROM saved_views v JOIN users u ON u.id=v.user_id
		WHERE v.table_id=$2 AND (v.user_id=$1 OR v.shared) ORDER BY v.name`, uid, t)
	if err != nil {
		fail(w, err)
		return
	}
	defer rows.Close()
	out := []map[string]any{}
	for rows.Next() {
		var id, name, owner string
		var prefs json.RawMessage
		var shared, mine bool
		var at time.Time
		if rows.Scan(&id, &name, &prefs, &shared, &mine, &owner, &at) == nil {
			out = append(out, map[string]any{"id": id, "name": name, "prefs": prefs, "shared": shared, "mine": mine, "owner": owner, "createdAt": at})
		}
	}
	writeJSON(w, http.StatusOK, out)
}

func (s *Server) saveView(w http.ResponseWriter, r *http.Request) {
	t, ok := tableParam(w, r)
	if !ok {
		return
	}
	var in struct {
		Name   string          `json:"name"`
		Prefs  json.RawMessage `json:"prefs"`
		Shared bool            `json:"shared"`
	}
	if !readJSON(w, r, &in) {
		return
	}
	var id string
	if err := s.core.DB.QueryRow(r.Context(), `INSERT INTO saved_views(user_id, table_id, name, prefs, shared) VALUES ($1,$2,$3,$4,$5) RETURNING id`,
		sessionOf(r).UserID, t, in.Name, []byte(in.Prefs), in.Shared).Scan(&id); err != nil {
		fail(w, err)
		return
	}
	writeJSON(w, http.StatusCreated, map[string]string{"id": id})
}

func (s *Server) deleteView(w http.ResponseWriter, r *http.Request) {
	_, _ = s.core.DB.Exec(r.Context(), `DELETE FROM saved_views WHERE id=$1 AND user_id=$2`, chi.URLParam(r, "id"), sessionOf(r).UserID)
	w.WriteHeader(http.StatusNoContent)
}

func (s *Server) getUserSetting(w http.ResponseWriter, r *http.Request) {
	var raw []byte
	if err := s.core.DB.QueryRow(r.Context(), `SELECT value FROM user_settings WHERE user_id=$1 AND key=$2`, sessionOf(r).UserID, chi.URLParam(r, "key")).Scan(&raw); err != nil {
		writeJSON(w, http.StatusOK, nil)
		return
	}
	w.Header().Set("Content-Type", "application/json")
	_, _ = w.Write(raw)
}

func (s *Server) putUserSetting(w http.ResponseWriter, r *http.Request) {
	var v json.RawMessage
	if !readJSON(w, r, &v) {
		return
	}
	key := chi.URLParam(r, "key")
	if !tableIDRe.MatchString(key) {
		writeError(w, http.StatusBadRequest, "clé invalide")
		return
	}
	if _, err := s.core.DB.Exec(r.Context(), `INSERT INTO user_settings(user_id, key, value) VALUES ($1,$2,$3) ON CONFLICT (user_id, key) DO UPDATE SET value=EXCLUDED.value`,
		sessionOf(r).UserID, key, []byte(v)); err != nil {
		fail(w, err)
		return
	}
	w.WriteHeader(http.StatusNoContent)
}
