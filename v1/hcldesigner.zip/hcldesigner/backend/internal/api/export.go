package api

import (
	"archive/zip"
	"encoding/json"
	"fmt"
	"net/http"
	"regexp"
	"sort"
	"strings"
	"time"

	"github.com/AZIZI-Sajjad/hcldesigner/internal/core"
	"github.com/AZIZI-Sajjad/hcldesigner/internal/hclgen"
	"github.com/AZIZI-Sajjad/hcldesigner/internal/model"
)

var unsafeChars = regexp.MustCompile(`[^a-zA-Z0-9_-]+`)

const gitignore = `# Terraform
.terraform/
*.tfstate
*.tfstate.*
crash.log
crash.*.log
*.tfplan
override.tf
override.tf.json
*_override.tf
*_override.tf.json
.terraformrc
terraform.rc
# Les valeurs réelles ne sont pas versionnées : copier terraform.tfvars.example
terraform.tfvars
*.auto.tfvars
`

// export : zip (arborescence complète), json (modèle) ou mermaid (diagramme).
func (s *Server) export(w http.ResponseWriter, r *http.Request) {
	p := s.projectFor(w, r, "code.export")
	if p == nil {
		return
	}
	format := r.URL.Query().Get("format")
	safe := unsafeChars.ReplaceAllString(p.Name, "-")
	switch format {
	case "json":
		w.Header().Set("Content-Disposition", fmt.Sprintf(`attachment; filename="%s.hcldesigner.json"`, safe))
		writeJSON(w, http.StatusOK, p.Model)
		s.audit(r, "project.export", "project", p.ID, map[string]string{"format": "json"})
		return
	case "mermaid":
		w.Header().Set("Content-Type", "text/plain; charset=utf-8")
		_, _ = w.Write([]byte(Mermaid(&p.Model)))
		return
	}
	opts := core.GenerateOptions{}
	if envID := r.URL.Query().Get("environmentId"); envID != "" {
		env, err := s.core.GetEnvironment(r.Context(), envID)
		if err != nil || env.ProjectID != p.ID {
			writeError(w, http.StatusBadRequest, "environnement invalide")
			return
		}
		opts.Env = env
	}
	res, err := s.core.Generate(r.Context(), &p.Model, opts)
	if err != nil {
		fail(w, err)
		return
	}
	if len(res.Diags) > 0 {
		writeError(w, http.StatusUnprocessableEntity, "génération impossible : "+res.Diags[0].Summary)
		return
	}
	files := map[string]string{}
	for k, v := range res.Files {
		files[k] = v
	}
	files[".gitignore"] = gitignore
	files["README.md"] = projectReadme(p, res)
	files["diagram.mmd"] = Mermaid(&p.Model)
	files["terraform.tfvars.example"] = tfvarsExample(&p.Model)
	if p.LockFile != "" {
		files[".terraform.lock.hcl"] = p.LockFile
	}
	raw, _ := json.MarshalIndent(p.Model, "", "  ")
	files["hcldesigner.json"] = string(raw)

	w.Header().Set("Content-Type", "application/zip")
	w.Header().Set("Content-Disposition", fmt.Sprintf(`attachment; filename="%s.zip"`, safe))
	zw := zip.NewWriter(w)
	names := make([]string, 0, len(files))
	for n := range files {
		names = append(names, n)
	}
	sort.Strings(names)
	now := time.Now()
	for _, n := range names {
		f, err := zw.CreateHeader(&zip.FileHeader{Name: safe + "/" + n, Method: zip.Deflate, Modified: now})
		if err != nil {
			return
		}
		_, _ = f.Write([]byte(files[n]))
	}
	_ = zw.Close()
	s.audit(r, "project.export", "project", p.ID, map[string]any{"format": "zip", "environment": r.URL.Query().Get("environmentId")})
}

// Mermaid produit un diagramme flowchart du projet.
func Mermaid(m *model.Project) string {
	var b strings.Builder
	b.WriteString("flowchart LR\n")
	id := map[string]string{}
	for i, n := range m.Nodes {
		id[n.ID] = fmt.Sprintf("n%d", i)
		label := n.Address()
		shape := `["%s"]`
		switch n.Kind {
		case model.KindVariable:
			shape = `[/"%s"/]`
		case model.KindOutput:
			shape = `[\"%s"\]`
		case model.KindModule:
			shape = `[["%s"]]`
		case model.KindData:
			shape = `[("%s")]`
		}
		fmt.Fprintf(&b, "  %s"+shape+"\n", id[n.ID], strings.ReplaceAll(label, `"`, "'"))
	}
	seen := map[string]bool{}
	for _, e := range m.Edges() {
		src, dst := id[e.Source], id[e.Target]
		if src == "" || dst == "" {
			continue
		}
		key := src + dst + e.Kind
		if seen[key] {
			continue
		}
		seen[key] = true
		if e.Kind == "depends_on" {
			fmt.Fprintf(&b, "  %s -.->|depends_on| %s\n", src, dst)
		} else {
			fmt.Fprintf(&b, "  %s -->|%s| %s\n", src, strings.Split(e.TargetPath, "[")[0], dst)
		}
	}
	return b.String()
}

func tfvarsExample(m *model.Project) string {
	var b strings.Builder
	b.WriteString("# Exemple de valeurs — copier en terraform.tfvars et adapter\n\n")
	vars := []model.Node{}
	for _, n := range m.Nodes {
		if n.Kind == model.KindVariable {
			vars = append(vars, n)
		}
	}
	sort.Slice(vars, func(i, j int) bool { return vars[i].Label < vars[j].Label })
	for _, n := range vars {
		if d, ok := n.Attrs["description"]; ok && d.Mode == model.ModeLiteral {
			var s string
			_ = json.Unmarshal(d.Value, &s)
			fmt.Fprintf(&b, "# %s\n", s)
		}
		val := "\"\""
		if d, ok := n.Attrs["default"]; ok && d.Mode == model.ModeLiteral && len(d.Value) > 0 {
			// un littéral JSON est une expression HCL valide
			if toks, err := hclgen.ParseExpr(string(d.Value)); err == nil {
				val = strings.TrimSpace(string(toks.Bytes()))
			}
		}
		if s, ok := n.Attrs["sensitive"]; ok && string(s.Value) == "true" {
			val = "\"<secret>\""
		}
		fmt.Fprintf(&b, "%s = %s\n\n", n.Label, val)
	}
	return b.String()
}

func projectReadme(p *core.Project, res *hclgen.Result) string {
	var b strings.Builder
	fmt.Fprintf(&b, "# %s\n\n%s\n\nCode généré par HCLDesigner (version %d du projet).\n\n", p.Name, p.Description, p.Version)
	b.WriteString("## Providers\n\n| Nom | Source | Version |\n|---|---|---|\n")
	for _, pc := range p.Model.Providers {
		fmt.Fprintf(&b, "| %s | %s | %s |\n", pc.Key(), pc.Source, pc.Version)
	}
	b.WriteString("\n## Fichiers\n\n")
	names := make([]string, 0, len(res.Files))
	for n := range res.Files {
		names = append(names, n)
	}
	sort.Strings(names)
	for _, n := range names {
		fmt.Fprintf(&b, "- `%s`\n", n)
	}
	b.WriteString("\n## Variables\n\n| Nom | Type | Défaut | Description |\n|---|---|---|---|\n")
	for _, v := range variablesOf(&p.Model) {
		fmt.Fprintf(&b, "| %s | `%s` | %s | %s |\n", v.Name, v.Type, v.Default, v.Description)
	}
	b.WriteString("\n## Outputs\n\n")
	for _, n := range p.Model.Nodes {
		if n.Kind == model.KindOutput {
			fmt.Fprintf(&b, "- `%s`\n", n.Label)
		}
	}
	b.WriteString("\n## Utilisation\n\n```bash\ncp terraform.tfvars.example terraform.tfvars\nterraform init\nterraform plan\n```\n\n## Diagramme\n\n```mermaid\n")
	b.WriteString(Mermaid(&p.Model))
	b.WriteString("```\n")
	return b.String()
}

func variablesOf(m *model.Project) []model.ModuleVar {
	vars, _ := hclgen.ModuleInterface(m)
	return vars
}
