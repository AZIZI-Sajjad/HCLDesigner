package api

import (
	"net/http"
	"time"

	"github.com/go-chi/chi/v5"

	"github.com/AZIZI-Sajjad/hcldesigner/internal/core"
)

func (s *Server) credentialRoutes(r chi.Router) {
	r.Get("/credential-kinds", func(w http.ResponseWriter, r *http.Request) { writeJSON(w, http.StatusOK, core.CredentialKinds) })
	// La liste (sans secrets) sert aussi au sélecteur des environnements.
	r.Get("/credentials", s.listCredentials)
	r.Post("/credentials", s.requireGlobal("credentials.manage", s.saveCredential))
	r.Put("/credentials/{id}", s.requireGlobal("credentials.manage", s.saveCredential))
	r.Delete("/credentials/{id}", s.requireGlobal("credentials.manage", s.deleteCredential))
}

type credentialDTO struct {
	ID          string    `json:"id"`
	Name        string    `json:"name"`
	Kind        string    `json:"kind"`
	Description string    `json:"description"`
	Fields      []string  `json:"fields"` // noms des champs renseignés, jamais les valeurs
	CreatedBy   string    `json:"createdBy"`
	UpdatedAt   time.Time `json:"updatedAt"`
	UsedBy      int       `json:"usedBy"`
}

func (s *Server) listCredentials(w http.ResponseWriter, r *http.Request) {
	sub := subjectOf(r)
	if !sub.Can("credentials.manage", "", "") && !sub.Can("credentials.use", "", "") && !sub.CanAnyProject("environments.manage") {
		writeError(w, http.StatusForbidden, "permission requise : credentials.use")
		return
	}
	rows, err := s.core.DB.Query(r.Context(), `SELECT c.id, c.name, c.kind, c.description, c.data_enc, COALESCE(u.username,''), c.updated_at,
		(SELECT count(*) FROM environments e WHERE c.id = ANY(e.credential_ids))
		FROM credentials c LEFT JOIN users u ON u.id=c.created_by WHERE c.kind<>'backend' ORDER BY c.name`)
	if err != nil {
		fail(w, err)
		return
	}
	defer rows.Close()
	out := []credentialDTO{}
	for rows.Next() {
		var c credentialDTO
		var enc []byte
		if err := rows.Scan(&c.ID, &c.Name, &c.Kind, &c.Description, &enc, &c.CreatedBy, &c.UpdatedAt, &c.UsedBy); err != nil {
			fail(w, err)
			return
		}
		data := map[string]string{}
		if s.core.Vault.DecryptJSON(enc, &data) == nil {
			for k, v := range data {
				if v != "" {
					c.Fields = append(c.Fields, k)
				}
			}
		}
		out = append(out, c)
	}
	writeJSON(w, http.StatusOK, out)
}

// saveCredential : un champ laissé vide en modification conserve la valeur existante.
func (s *Server) saveCredential(w http.ResponseWriter, r *http.Request) {
	var in struct {
		Name        string            `json:"name"`
		Kind        string            `json:"kind"`
		Description string            `json:"description"`
		Data        map[string]string `json:"data"`
	}
	if !readJSON(w, r, &in) {
		return
	}
	if in.Kind == "backend" {
		writeError(w, http.StatusBadRequest, "type réservé aux secrets de backend")
		return
	}
	id := chi.URLParam(r, "id")
	data := map[string]string{}
	if id != "" {
		old, err := s.core.CredentialData(r.Context(), id)
		if err != nil {
			fail(w, err)
			return
		}
		data = old
	}
	for k, v := range in.Data {
		if v != "" {
			data[k] = v
		}
	}
	newID, err := s.core.SaveCredentialData(r.Context(), id, in.Name, in.Kind, in.Description, sessionOf(r).UserID, data)
	if err != nil {
		fail(w, err)
		return
	}
	fields := make([]string, 0, len(in.Data))
	for k, v := range in.Data {
		if v != "" {
			fields = append(fields, k)
		}
	}
	s.audit(r, "credential.save", "credential", newID, map[string]any{"name": in.Name, "kind": in.Kind, "fieldsUpdated": fields})
	writeJSON(w, http.StatusOK, map[string]string{"id": newID})
}

func (s *Server) deleteCredential(w http.ResponseWriter, r *http.Request) {
	id := chi.URLParam(r, "id")
	var used int
	_ = s.core.DB.QueryRow(r.Context(), `SELECT count(*) FROM environments WHERE $1 = ANY(credential_ids)`, id).Scan(&used)
	if used > 0 {
		writeError(w, http.StatusConflict, "credential utilisé par des environnements")
		return
	}
	if _, err := s.core.DB.Exec(r.Context(), `DELETE FROM credentials WHERE id=$1 AND kind<>'backend'`, id); err != nil {
		fail(w, err)
		return
	}
	s.audit(r, "credential.delete", "credential", id, nil)
	w.WriteHeader(http.StatusNoContent)
}
