package api

import (
	"errors"
	"io"
	"net/http"

	"github.com/AZIZI-Sajjad/hcldesigner/internal/hclimport"
	"github.com/AZIZI-Sajjad/hcldesigner/internal/model"
)

// maxImportUpload borne la requête multipart (fichiers .tf ou archive .zip).
const maxImportUpload = 25 << 20

// importHCL convertit du code Terraform existant en modèle, sans rien enregistrer :
// le frontend affiche le résultat et les diagnostics, puis crée le projet via POST /projects.
//
//	POST /api/projects/import-hcl   (multipart, champ "files" répété : .tf et/ou .zip)
func (s *Server) importHCL(w http.ResponseWriter, r *http.Request) {
	if !can(w, r, "projects.create", "", "") {
		return
	}
	r.Body = http.MaxBytesReader(w, r.Body, maxImportUpload)
	if err := r.ParseMultipartForm(8 << 20); err != nil {
		var tooBig *http.MaxBytesError
		if errors.As(err, &tooBig) {
			writeError(w, http.StatusRequestEntityTooLarge, "envoi trop volumineux (25 Mo maximum)")
			return
		}
		writeError(w, http.StatusBadRequest, "formulaire multipart invalide : "+err.Error())
		return
	}
	defer func() { _ = r.MultipartForm.RemoveAll() }()

	var uploads []hclimport.Upload
	for _, fh := range r.MultipartForm.File["files"] {
		f, err := fh.Open()
		if err != nil {
			fail(w, err)
			return
		}
		data, err := io.ReadAll(f)
		f.Close()
		if err != nil {
			fail(w, err)
			return
		}
		uploads = append(uploads, hclimport.Upload{Name: fh.Filename, Data: data})
	}
	if len(uploads) == 0 {
		writeError(w, http.StatusBadRequest, "aucun fichier reçu (champ files)")
		return
	}

	files, collectDiags, err := hclimport.Collect(uploads)
	if err != nil {
		writeError(w, http.StatusBadRequest, err.Error())
		return
	}
	res := hclimport.Import(files)
	// Tableau jamais null en JSON : le frontend itère dessus sans test.
	res.Diagnostics = append(append([]model.Diagnostic{}, collectDiags...), res.Diagnostics...)

	// Version déjà résolue sur cette instance : le catalogue et les formulaires sont disponibles
	// tout de suite. Sinon, l'utilisateur résout le provider dans Paramètres du projet.
	for i := range res.Model.Providers {
		pc := &res.Model.Providers[i]
		if v, err := s.core.LatestSchemaVersion(r.Context(), pc.Source); err == nil {
			pc.Resolved = v
		} else {
			res.Diagnostics = append(res.Diagnostics, model.Diagnostic{Severity: "info",
				Summary: "provider " + pc.Source + " à résoudre", Detail: "Paramètres du projet → Providers → Résoudre, pour le catalogue et les formulaires."})
		}
	}
	s.audit(r, "project.import_hcl", "project", "", map[string]any{"files": res.Files, "nodes": len(res.Model.Nodes)})
	writeJSON(w, http.StatusOK, res)
}
