package api

import (
	"context"
	"encoding/json"
	"errors"
	"io"
	"net/http"
	"os"
	"path/filepath"
	"strconv"
	"time"

	"github.com/coder/websocket"
	"github.com/go-chi/chi/v5"

	"github.com/AZIZI-Sajjad/hcldesigner/internal/core"
	"github.com/AZIZI-Sajjad/hcldesigner/internal/notify"
	"github.com/AZIZI-Sajjad/hcldesigner/internal/rbac"
)

func (s *Server) runRoutes(r chi.Router) {
	r.Get("/runs", s.listRuns)
	r.Post("/projects/{pid}/runs", s.createRun)
	r.Route("/runs/{rid}", func(r chi.Router) {
		r.Get("/", s.getRun)
		r.Post("/cancel", s.cancelRun)
		r.Post("/approve", s.approveRun)
		r.Get("/logs", s.runLogs)
		r.Get("/ws", s.runLogsWS)
		r.Get("/plan", s.runPlan)
		r.Get("/files", s.runFiles)
	})
}

// runPermission renvoie la permission nécessaire pour une demande d'exécution.
func runPermission(op string, destroy bool, o core.RunOptions) rbac.Permission {
	switch op {
	case core.OpInit, core.OpValidate:
		if o.MigrateState {
			return "state.edit"
		}
		return "runs.init"
	case core.OpPlan:
		if destroy {
			return "runs.destroy"
		}
		return "runs.plan"
	case core.OpApply:
		if destroy {
			return "runs.destroy"
		}
		return "runs.apply"
	case core.OpState:
		switch o.StateCmd {
		case "list", "show":
			return "state.view"
		case "pull":
			return "state.download"
		case "unlock":
			return "state.unlock"
		}
		return "state.edit"
	}
	return "runs.apply"
}

func (s *Server) listRuns(w http.ResponseWriter, r *http.Request) {
	q := r.URL.Query()
	sql := `SELECT ` + core.RunCols + core.RunFrom + ` WHERE true`
	args := []any{}
	add := func(cond string, v any) {
		args = append(args, v)
		sql += " AND " + cond + "$" + strconv.Itoa(len(args))
	}
	if vis := subjectOf(r).VisibleProjects(); vis != nil {
		add("r.project_id::text = ANY(", vis)
		sql += ")"
	}
	if v := q.Get("project"); v != "" {
		add("r.project_id=", v)
	}
	if v := q.Get("environment"); v != "" {
		add("r.environment_id=", v)
	}
	if v := q.Get("status"); v != "" {
		add("r.status=", v)
	}
	limit, _ := strconv.Atoi(q.Get("limit"))
	if limit <= 0 || limit > 2000 {
		limit = 500
	}
	sql += " ORDER BY r.created_at DESC LIMIT " + strconv.Itoa(limit)
	rows, err := s.core.DB.Query(r.Context(), sql, args...)
	if err != nil {
		fail(w, err)
		return
	}
	defer rows.Close()
	out := []*core.Run{}
	for rows.Next() {
		run, err := core.ScanRun(rows)
		if err != nil {
			fail(w, err)
			return
		}
		out = append(out, run)
	}
	writeJSON(w, http.StatusOK, out)
}

func (s *Server) createRun(w http.ResponseWriter, r *http.Request) {
	pid := chi.URLParam(r, "pid")
	var in struct {
		EnvironmentID string          `json:"environmentId"`
		Operation     string          `json:"operation"`
		Destroy       bool            `json:"destroy"`
		Options       core.RunOptions `json:"options"`
		PlanRunID     string          `json:"planRunId"`
	}
	if !readJSON(w, r, &in) {
		return
	}
	ctx := r.Context()
	env, err := s.core.GetEnvironment(ctx, in.EnvironmentID)
	if err != nil || env.ProjectID != pid {
		writeError(w, http.StatusBadRequest, "environnement invalide")
		return
	}
	destroy := in.Destroy
	if in.Operation == core.OpApply {
		if plan, err := s.core.GetRun(ctx, in.PlanRunID); err == nil {
			destroy = plan.Destroy // appliquer un plan -destroy exige runs.destroy
		}
	}
	in.Options.Backend = nil // jamais fourni par le client
	if !can(w, r, runPermission(in.Operation, destroy, in.Options), pid, env.Name) {
		return
	}
	run, err := s.core.CreateRun(ctx, core.RunRequest{ProjectID: pid, EnvironmentID: env.ID, Operation: in.Operation, Destroy: in.Destroy,
		Options: in.Options, PlanRunID: in.PlanRunID, UserID: sessionOf(r).UserID, TriggeredBy: triggerOf(r),
		BypassWindow: subjectOf(r).Can("runs.bypass_window", pid, env.Name)})
	if err != nil {
		fail(w, err)
		return
	}
	s.audit(r, "run."+in.Operation, "run", run.ID, map[string]any{"environment": env.Name, "destroy": run.Destroy, "options": in.Options, "planRunId": in.PlanRunID})
	writeJSON(w, http.StatusCreated, run)
}

func triggerOf(r *http.Request) string {
	if sessionOf(r).ViaToken {
		return "api"
	}
	return "user"
}

// runFor charge un run et vérifie la visibilité du projet.
func (s *Server) runFor(w http.ResponseWriter, r *http.Request) *core.Run {
	run, err := s.core.GetRun(r.Context(), chi.URLParam(r, "rid"))
	if err != nil {
		fail(w, err)
		return nil
	}
	if !can(w, r, "projects.view", run.ProjectID, "") {
		return nil
	}
	return run
}

type approvalDTO struct {
	UserID    string    `json:"userId"`
	Username  string    `json:"username"`
	Decision  string    `json:"decision"`
	Comment   string    `json:"comment"`
	CreatedAt time.Time `json:"createdAt"`
}

func (s *Server) getRun(w http.ResponseWriter, r *http.Request) {
	run := s.runFor(w, r)
	if run == nil {
		return
	}
	rows, err := s.core.DB.Query(r.Context(), `SELECT a.user_id, u.username, a.decision, a.comment, a.created_at FROM approvals a JOIN users u ON u.id=a.user_id WHERE a.run_id=$1 ORDER BY a.created_at`, run.ID)
	if err != nil {
		fail(w, err)
		return
	}
	approvals := []approvalDTO{}
	for rows.Next() {
		var a approvalDTO
		if rows.Scan(&a.UserID, &a.Username, &a.Decision, &a.Comment, &a.CreatedAt) == nil {
			approvals = append(approvals, a)
		}
	}
	rows.Close()
	sub := subjectOf(r)
	applyPerm := rbac.Permission("runs.apply")
	if run.Destroy {
		applyPerm = "runs.destroy"
	}
	var applicableErr string
	if run.Status == core.StatusPlanned {
		if env, err := s.core.GetEnvironment(r.Context(), run.EnvironmentID); err == nil {
			if err := s.core.CheckApplicable(r.Context(), run, env, sub.Can("runs.bypass_window", run.ProjectID, run.EnvironmentName)); err != nil {
				applicableErr = err.Error()
			}
		}
	}
	isAuthor := run.CreatedBy != nil && *run.CreatedBy == sessionOf(r).UserID
	writeJSON(w, http.StatusOK, map[string]any{
		"run": run, "approvals": approvals, "applicableError": applicableErr,
		"permissions": map[string]bool{
			"apply":   sub.Can(applyPerm, run.ProjectID, run.EnvironmentName),
			"approve": sub.Can("runs.approve", run.ProjectID, run.EnvironmentName) && !isAuthor,
			"cancel":  sub.Can("runs.cancel", run.ProjectID, run.EnvironmentName),
			"code":    sub.Can("code.view", run.ProjectID, ""),
		},
	})
}

func (s *Server) cancelRun(w http.ResponseWriter, r *http.Request) {
	run := s.runFor(w, r)
	if run == nil || !can(w, r, "runs.cancel", run.ProjectID, run.EnvironmentName) {
		return
	}
	ctx := r.Context()
	switch run.Status {
	case core.StatusQueued:
		_, _ = s.core.DB.Exec(ctx, `UPDATE runs SET status='canceled', finished_at=now(), error='annulé avant exécution' WHERE id=$1 AND status='queued'`, run.ID)
	case core.StatusRunning:
		_, _ = s.core.DB.Exec(ctx, `UPDATE runs SET cancel_requested=true WHERE id=$1`, run.ID)
	case core.StatusPlanned:
		_, _ = s.core.DB.Exec(ctx, `UPDATE runs SET status='discarded' WHERE id=$1`, run.ID)
	default:
		writeError(w, http.StatusConflict, "exécution terminée")
		return
	}
	s.audit(r, "run.cancel", "run", run.ID, map[string]string{"status": run.Status})
	w.WriteHeader(http.StatusNoContent)
}

func (s *Server) approveRun(w http.ResponseWriter, r *http.Request) {
	run := s.runFor(w, r)
	if run == nil || !can(w, r, "runs.approve", run.ProjectID, run.EnvironmentName) {
		return
	}
	var in struct {
		Decision string `json:"decision"`
		Comment  string `json:"comment"`
	}
	if !readJSON(w, r, &in) {
		return
	}
	if in.Decision != "approve" && in.Decision != "reject" {
		writeError(w, http.StatusBadRequest, "décision : approve ou reject")
		return
	}
	sess := sessionOf(r)
	if run.CreatedBy != nil && *run.CreatedBy == sess.UserID {
		writeError(w, http.StatusForbidden, "l'auteur du plan ne peut pas l'approuver lui-même")
		return
	}
	if run.Status != core.StatusPlanned {
		writeError(w, http.StatusConflict, "seul un plan en attente peut être approuvé")
		return
	}
	ctx := r.Context()
	if _, err := s.core.DB.Exec(ctx, `INSERT INTO approvals(run_id, user_id, decision, comment) VALUES ($1,$2,$3,$4)
		ON CONFLICT (run_id, user_id) DO UPDATE SET decision=EXCLUDED.decision, comment=EXCLUDED.comment, created_at=now()`, run.ID, sess.UserID, in.Decision, in.Comment); err != nil {
		fail(w, err)
		return
	}
	ev := notify.Event{ProjectID: run.ProjectID, Project: run.ProjectName, Environment: run.EnvironmentName, Actor: sess.Username, Link: "/runs/" + run.ID}
	if in.Decision == "reject" {
		_, _ = s.core.DB.Exec(ctx, `UPDATE runs SET status='rejected' WHERE id=$1`, run.ID)
		ev.Type, ev.Summary = notify.EvApprovalRejected, "Plan refusé par "+sess.Username+" : "+in.Comment
	} else {
		ok, _, _ := s.core.Approvals(ctx, run.ID)
		ev.Type, ev.Summary = notify.EvApprovalGranted, "Plan approuvé par "+sess.Username+" ("+strconv.Itoa(ok)+"/"+strconv.Itoa(run.ApprovalsRequired)+")"
	}
	s.core.Notifier.Emit(ctx, ev)
	s.audit(r, "run."+in.Decision, "run", run.ID, in)
	w.WriteHeader(http.StatusNoContent)
}

func (s *Server) logPath(runID string) string {
	return filepath.Join(s.core.Cfg.DataDir, "logs", runID+".log")
}

// runLogs renvoie le log à partir d'un offset (ou en téléchargement complet).
func (s *Server) runLogs(w http.ResponseWriter, r *http.Request) {
	run := s.runFor(w, r)
	if run == nil {
		return
	}
	f, err := os.Open(s.logPath(run.ID))
	if err != nil {
		writeJSON(w, http.StatusOK, map[string]any{"content": "", "offset": 0, "finished": run.FinishedAt != nil})
		return
	}
	defer f.Close()
	if r.URL.Query().Get("download") == "1" {
		w.Header().Set("Content-Type", "text/plain; charset=utf-8")
		w.Header().Set("Content-Disposition", `attachment; filename="run-`+run.ID+`.log"`)
		_, _ = io.Copy(w, f)
		return
	}
	off, _ := strconv.ParseInt(r.URL.Query().Get("offset"), 10, 64)
	_, _ = f.Seek(off, io.SeekStart)
	b, _ := io.ReadAll(io.LimitReader(f, 2<<20))
	writeJSON(w, http.StatusOK, map[string]any{"content": string(b), "offset": off + int64(len(b)), "finished": run.FinishedAt != nil})
}

// runLogsWS diffuse le log en temps réel jusqu'à la fin du run.
func (s *Server) runLogsWS(w http.ResponseWriter, r *http.Request) {
	run := s.runFor(w, r)
	if run == nil {
		return
	}
	conn, err := websocket.Accept(w, r, nil) // l'Origin doit correspondre à l'hôte (protection CSWSH)
	if err != nil {
		return
	}
	defer conn.CloseNow()
	ctx, cancel := context.WithTimeout(context.Background(), 6*time.Hour)
	defer cancel()
	ctx = conn.CloseRead(ctx)
	var off int64
	buf := make([]byte, 64*1024)
	for {
		finished := false
		var status string
		_ = s.core.DB.QueryRow(ctx, `SELECT status, finished_at IS NOT NULL FROM runs WHERE id=$1`, run.ID).Scan(&status, &finished)
		if f, err := os.Open(s.logPath(run.ID)); err == nil {
			_, _ = f.Seek(off, io.SeekStart)
			for {
				n, err := f.Read(buf)
				if n > 0 {
					off += int64(n)
					if werr := conn.Write(ctx, websocket.MessageText, buf[:n]); werr != nil {
						f.Close()
						return
					}
				}
				if err != nil {
					break
				}
			}
			f.Close()
		}
		if finished {
			msg, _ := json.Marshal(map[string]string{"event": "finished", "status": status})
			_ = conn.Write(ctx, websocket.MessageBinary, msg)
			conn.Close(websocket.StatusNormalClosure, "fin")
			return
		}
		select {
		case <-ctx.Done():
			return
		case <-time.After(400 * time.Millisecond):
		}
	}
}

// runPlan renvoie le détail du plan, valeurs sensibles masquées.
func (s *Server) runPlan(w http.ResponseWriter, r *http.Request) {
	run := s.runFor(w, r)
	if run == nil {
		return
	}
	raw, err := s.core.Vault.ReadFile(filepath.Join(s.core.Cfg.DataDir, "artifacts", run.ID, "plan.json.enc"))
	if errors.Is(err, os.ErrNotExist) && run.PlanRunID != nil {
		raw, err = s.core.Vault.ReadFile(filepath.Join(s.core.Cfg.DataDir, "artifacts", *run.PlanRunID, "plan.json.enc"))
	}
	if err != nil {
		writeError(w, http.StatusNotFound, "plan indisponible (expiré ou purgé)")
		return
	}
	writeJSON(w, http.StatusOK, maskedPlan(raw))
}

// maskedPlan extrait les changements et remplace les valeurs sensibles par "(sensible)".
func maskedPlan(raw []byte) map[string]any {
	var pj struct {
		ResourceChanges []struct {
			Address string `json:"address"`
			Type    string `json:"type"`
			Mode    string `json:"mode"`
			Change  struct {
				Actions         []string `json:"actions"`
				Before          any      `json:"before"`
				After           any      `json:"after"`
				AfterUnknown    any      `json:"after_unknown"`
				BeforeSensitive any      `json:"before_sensitive"`
				AfterSensitive  any      `json:"after_sensitive"`
			} `json:"change"`
		} `json:"resource_changes"`
		ResourceDrift []struct {
			Address string `json:"address"`
			Change  struct {
				Actions []string `json:"actions"`
			} `json:"change"`
		} `json:"resource_drift"`
	}
	_ = json.Unmarshal(raw, &pj)
	changes := []map[string]any{}
	for _, rc := range pj.ResourceChanges {
		changes = append(changes, map[string]any{
			"address": rc.Address, "type": rc.Type, "mode": rc.Mode, "actions": rc.Change.Actions,
			"before": mask(rc.Change.Before, rc.Change.BeforeSensitive), "after": mask(rc.Change.After, rc.Change.AfterSensitive),
			"afterUnknown": rc.Change.AfterUnknown,
		})
	}
	drift := []map[string]any{}
	for _, d := range pj.ResourceDrift {
		drift = append(drift, map[string]any{"address": d.Address, "actions": d.Change.Actions})
	}
	return map[string]any{"changes": changes, "drift": drift}
}

// mask applique la structure *_sensitive de Terraform (bool ou objet/liste parallèle).
func mask(v any, sens any) any {
	switch s := sens.(type) {
	case bool:
		if s {
			return "(sensible)"
		}
		return v
	case map[string]any:
		m, ok := v.(map[string]any)
		if !ok {
			return v
		}
		out := map[string]any{}
		for k, val := range m {
			out[k] = mask(val, s[k])
		}
		return out
	case []any:
		l, ok := v.([]any)
		if !ok {
			return v
		}
		out := make([]any, len(l))
		for i := range l {
			var si any
			if i < len(s) {
				si = s[i]
			}
			out[i] = mask(l[i], si)
		}
		return out
	}
	return v
}

func (s *Server) runFiles(w http.ResponseWriter, r *http.Request) {
	run := s.runFor(w, r)
	if run == nil || !can(w, r, "code.view", run.ProjectID, "") {
		return
	}
	snap, err := s.core.RunSnapshot(r.Context(), run.ID)
	if err != nil {
		fail(w, err)
		return
	}
	writeJSON(w, http.StatusOK, snap)
}
