// Commande hcldesigner : un seul binaire, plusieurs rôles.
//
//	hcldesigner api        API REST/WebSocket (et frontend si HCLD_STATIC_DIR est défini)
//	hcldesigner worker     exécution des runs Terraform et résolution des schémas
//	hcldesigner scheduler  tâches planifiées, notifications, rétention
//	hcldesigner all        les trois dans le même processus (développement, petites installations)
//	hcldesigner migrate    applique les migrations puis quitte
//	hcldesigner healthcheck  sonde HTTP locale (HEALTHCHECK Docker)
package main

import (
	"context"
	"errors"
	"fmt"
	"log/slog"
	"net/http"
	"os"
	"os/signal"
	"sync"
	"syscall"
	"time"

	"github.com/jackc/pgx/v5/pgxpool"

	"github.com/AZIZI-Sajjad/hcldesigner/internal/api"
	"github.com/AZIZI-Sajjad/hcldesigner/internal/auth"
	"github.com/AZIZI-Sajjad/hcldesigner/internal/config"
	"github.com/AZIZI-Sajjad/hcldesigner/internal/core"
	"github.com/AZIZI-Sajjad/hcldesigner/internal/db"
	"github.com/AZIZI-Sajjad/hcldesigner/internal/rbac"
	"github.com/AZIZI-Sajjad/hcldesigner/internal/runner"
	"github.com/AZIZI-Sajjad/hcldesigner/internal/scheduler"
	"github.com/AZIZI-Sajjad/hcldesigner/internal/settings"
	"github.com/AZIZI-Sajjad/hcldesigner/internal/vault"
)

func main() {
	slog.SetDefault(slog.New(slog.NewJSONHandler(os.Stdout, &slog.HandlerOptions{Level: slog.LevelInfo})))
	role := "all"
	if len(os.Args) > 1 {
		role = os.Args[1]
	}
	if role == "healthcheck" {
		os.Exit(healthcheck())
	}
	if err := run(role); err != nil {
		slog.Error("arrêt sur erreur", "err", err)
		os.Exit(1)
	}
}

func run(role string) error {
	cfg, err := config.Load()
	if err != nil {
		return err
	}
	ctx, stop := signal.NotifyContext(context.Background(), syscall.SIGINT, syscall.SIGTERM)
	defer stop()

	pool, err := db.Open(ctx, cfg.DatabaseURL)
	if err != nil {
		return err
	}
	defer pool.Close()
	if err := db.Migrate(ctx, pool); err != nil {
		return err
	}
	if err := rbac.SeedBuiltins(ctx, pool); err != nil {
		return err
	}
	if err := bootstrapAdmin(ctx, pool, cfg); err != nil {
		return err
	}
	if role == "migrate" {
		slog.Info("migrations appliquées")
		return nil
	}
	v, err := vault.New(cfg.MasterKey)
	if err != nil {
		return err
	}
	c := core.New(pool, cfg, v)
	var syslogCfg settings.Syslog
	_ = c.Settings.Get(ctx, settings.KeySyslog, &syslogCfg)
	c.Audit.SetSyslog(syslogCfg.Addr)

	var wg sync.WaitGroup
	start := func(name string, fn func(context.Context)) {
		wg.Add(1)
		go func() {
			defer wg.Done()
			fn(ctx)
			slog.Info("arrêté", "composant", name)
		}()
	}
	switch role {
	case "api":
		start("api", func(ctx context.Context) { serveAPI(ctx, c) })
	case "worker":
		start("worker", runner.New(c, cfg.WorkerConcurrency).Run)
	case "scheduler":
		start("scheduler", scheduler.New(c).Run)
	case "all":
		start("api", func(ctx context.Context) { serveAPI(ctx, c) })
		start("worker", runner.New(c, cfg.WorkerConcurrency).Run)
		start("scheduler", scheduler.New(c).Run)
	default:
		return fmt.Errorf("rôle inconnu %q (api | worker | scheduler | all | migrate)", role)
	}
	wg.Wait()
	return nil
}

func serveAPI(ctx context.Context, c *core.Core) {
	srv := &http.Server{
		Addr:              c.Cfg.Listen,
		Handler:           api.New(c).Router(),
		ReadHeaderTimeout: 15 * time.Second,
		IdleTimeout:       120 * time.Second,
	}
	go func() {
		<-ctx.Done()
		sctx, cancel := context.WithTimeout(context.Background(), 20*time.Second)
		defer cancel()
		_ = srv.Shutdown(sctx)
	}()
	slog.Info("API à l'écoute", "addr", c.Cfg.Listen)
	if err := srv.ListenAndServe(); err != nil && !errors.Is(err, http.ErrServerClosed) {
		slog.Error("serveur HTTP", "err", err)
	}
}

// bootstrapAdmin crée le premier super admin si la base n'a aucun utilisateur.
func bootstrapAdmin(ctx context.Context, pool *pgxpool.Pool, cfg *config.Config) error {
	var n int
	if err := pool.QueryRow(ctx, `SELECT count(*) FROM users`).Scan(&n); err != nil || n > 0 {
		return err
	}
	if cfg.AdminPassword == "" {
		slog.Warn("aucun utilisateur : définir HCLD_ADMIN_PASSWORD pour créer le compte administrateur initial")
		return nil
	}
	if err := auth.DefaultPolicy.Check(cfg.AdminPassword); err != nil {
		return fmt.Errorf("HCLD_ADMIN_PASSWORD : %w", err)
	}
	hash, err := auth.HashPassword(cfg.AdminPassword)
	if err != nil {
		return err
	}
	var id string
	if err := pool.QueryRow(ctx, `INSERT INTO users(username, email, display_name, password_hash, is_super) VALUES ($1,$2,'Administrateur',$3,true) RETURNING id`,
		cfg.AdminUser, cfg.AdminEmail, hash).Scan(&id); err != nil {
		return err
	}
	_, err = pool.Exec(ctx, `INSERT INTO role_bindings(role_id, user_id, scope) SELECT id, $1, 'global' FROM roles WHERE name='Super admin'`, id)
	slog.Info("compte administrateur initial créé", "username", cfg.AdminUser)
	return err
}

// healthcheck interroge /healthz sur l'adresse d'écoute locale ; code de sortie 0 si sain.
func healthcheck() int {
	addr := os.Getenv("HCLD_LISTEN")
	if addr == "" {
		addr = ":8080"
	}
	if addr[0] == ':' {
		addr = "127.0.0.1" + addr
	}
	client := &http.Client{Timeout: 4 * time.Second}
	resp, err := client.Get("http://" + addr + "/healthz")
	if err != nil {
		return 1
	}
	defer resp.Body.Close()
	if resp.StatusCode != http.StatusOK {
		return 1
	}
	return 0
}
