module github.com/AZIZI-Sajjad/hcldesigner

go 1.24

replace golang.org/x/text => github.com/golang/text v0.25.0

replace golang.org/x/crypto => github.com/golang/crypto v0.38.0

replace golang.org/x/sync => github.com/golang/sync v0.14.0

replace golang.org/x/sys => github.com/golang/sys v0.33.0

replace golang.org/x/net => github.com/golang/net v0.40.0

replace golang.org/x/mod => github.com/golang/mod v0.24.0

replace golang.org/x/tools => github.com/golang/tools v0.33.0

replace golang.org/x/term => github.com/golang/term v0.32.0

replace gopkg.in/yaml.v3 => github.com/go-yaml/yaml v0.0.0-20220521103104-8f96da9f5d5e

replace gopkg.in/check.v1 => github.com/go-check/check v0.0.0-20201130134442-10cb98267c6c

require (
	github.com/agext/levenshtein v1.2.1 // indirect
	github.com/apparentlymart/go-textseg/v15 v15.0.0 // indirect
	github.com/coder/websocket v1.8.13 // indirect
	github.com/go-chi/chi/v5 v5.2.1 // indirect
	github.com/goccy/go-yaml v1.17.1 // indirect
	github.com/google/go-cmp v0.6.0 // indirect
	github.com/google/uuid v1.6.0
	github.com/hashicorp/hcl/v2 v2.24.0 // indirect
	github.com/jackc/pgpassfile v1.0.0 // indirect
	github.com/jackc/pgservicefile v0.0.0-20240606120523-5a60cdf6a761 // indirect
	github.com/jackc/pgx/v5 v5.7.5 // indirect
	github.com/jackc/puddle/v2 v2.2.2 // indirect
	github.com/mitchellh/go-wordwrap v1.0.1 // indirect
	github.com/robfig/cron/v3 v3.0.1 // indirect
	github.com/zclconf/go-cty v1.16.3 // indirect
	golang.org/x/crypto v0.38.0 // indirect
	golang.org/x/mod v0.24.0 // indirect
	golang.org/x/sync v0.14.0 // indirect
	golang.org/x/sys v0.33.0 // indirect
	golang.org/x/text v0.25.0 // indirect
	golang.org/x/tools v0.21.1-0.20240508182429-e35e4ccd0d2d // indirect
)
