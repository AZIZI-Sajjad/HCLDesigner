# Architecture de HCLDesigner

## 1. Vue d'ensemble

HCLDesigner est une application client/serveur. Elle est composée de :

- un **frontend** React servi par nginx ;
- un **binaire Go unique** lancé sous trois rôles : `api`, `worker` et `scheduler` ;
- une base **PostgreSQL** ;
- un **volume de données** partagé entre les trois rôles. Il contient les logs, les artefacts de plan chiffrés, les states internes chiffrés, le cache des providers et les binaires Terraform/OpenTofu.

```mermaid
flowchart LR
  subgraph Navigateur
    UI[Frontend React<br/>canvas React Flow, Monaco, TanStack Table]
  end
  subgraph Docker
    NGX[nginx<br/>statique + proxy /api]
    API[hcldesigner api<br/>REST + WebSocket]
    WRK[hcldesigner worker<br/>runs Terraform / OpenTofu]
    SCH[hcldesigner scheduler<br/>cron, mails, rétention]
    PG[(PostgreSQL)]
    VOL[(Volume /data<br/>logs, plans, states, cache)]
  end
  REG[(Registry / mirror<br/>providers, modules)]
  CLOUD[(Clouds / backends<br/>AWS, Azure, GCP, vSphere, S3…)]
  SMTP[(SMTP / Teams / Slack)]

  UI --> NGX --> API
  API <--> PG
  WRK <--> PG
  SCH <--> PG
  API --- VOL
  WRK --- VOL
  SCH --- VOL
  WRK --> REG
  WRK --> CLOUD
  SCH --> SMTP
  API --> REG
```

| Composant | Rôle |
|---|---|
| `internal/model` | Modèle interne (projet, nœuds, valeurs, références). Les liens sont **dérivés** des références et jamais stockés à part. |
| `internal/schema` | Lecture et normalisation de `terraform providers schema -json`, catalogue, catégories. |
| `internal/connection` | Moteur de liaison : règles YAML, inférence par nom et type, arguments cibles avec obligatoires et défauts. |
| `internal/hclgen` | Génération HCL déterministe (hclwrite), découpage des fichiers, modules internes, backend, `import`/`moved`. |
| `internal/hclimport` | Import de code existant : `.tf` / `.zip` → modèle (hclsyntax, deux passes : nœuds puis valeurs et références), rapport des blocs non repris. |
| `internal/modules` | Extraction d'une sélection en module : variables entrantes et outputs sortants. |
| `internal/policy` | Conformité sur le modèle (statique) et sur le plan JSON. |
| `internal/runner` | Worker : file de runs, workspace éphémère, init/plan/apply/state, masquage des secrets, archivage du state. |
| `internal/scheduler` | Tâches cron, outbox de notifications, digests, expiration des plans, rétention. |
| `internal/notify` | Rendu des modèles de mails, outbox, SMTP, webhooks. |
| `internal/rbac` | Permissions, rôles prédéfinis, contrôle par portée (global, projet, environnement). |
| `internal/core` | Services partagés : projets, environnements, backends, credentials, création de runs, state. |
| `internal/api` | Routes HTTP par domaine, authentification, CSRF, limitation de débit, audit. |
| `rules/*.yaml` | Règles de connexion et valeurs par défaut par provider (embarquées dans le binaire). |

## 2. Modèle de données

```mermaid
erDiagram
  users ||--o{ sessions : ""
  users ||--o{ api_tokens : ""
  users }o--o{ teams : team_members
  roles ||--o{ role_bindings : ""
  users ||--o{ role_bindings : ""
  teams ||--o{ role_bindings : ""
  projects ||--o{ project_versions : ""
  projects ||--o{ environments : ""
  environments }o--o{ credentials : credential_ids
  environments ||--o{ runs : ""
  runs ||--o{ approvals : ""
  runs ||--o| runs : plan_run_id
  environments ||--o{ state_versions : ""
  modules ||--o{ module_versions : ""
  provider_schemas ||--o{ catalog_entries : ""
  scheduled_tasks ||--o{ task_executions : ""
  task_executions }o--o| runs : ""
  users ||--o{ notification_rules : ""
  users ||--o{ table_prefs : ""
  users ||--o{ saved_views : ""
```

Points clés :

- Les liens sont dérivés des valeurs : référence (`ref`), adresse citée dans une expression brute (`expr`, en pointillés, lecture seule) et `depends_on`. Le calcul est identique côté Go (`model.Edges`) et frontend (`lib/model.ts`).
- `projects.model` (JSONB) contient le modèle complet ; chaque enregistrement crée une ligne `project_versions`. La sauvegarde utilise un verrouillage optimiste sur `projects.version`.
- `runs.snapshot` fige les fichiers exécutés. Un apply rejoue exactement le snapshot de son plan.
- `runs.options.backend` fige le backend à la création du run : modifier l'environnement ensuite n'a pas d'effet sur un run en file.
- `audit_events` est en ajout seul : un trigger interdit UPDATE et DELETE, sauf pendant la purge de rétention.
- Secrets chiffrés AES-256-GCM avec `HCLD_MASTER_KEY` : `credentials.data_enc`, `webhooks.url_enc`, `users.totp_secret`, mot de passe SMTP, fichiers `*.enc` (plans, states).

## 3. Flux principaux

### 3.1 Liaison entre deux objets

```mermaid
sequenceDiagram
  actor U as Utilisateur
  participant C as Canvas
  participant A as API
  participant E as Moteur de liaison
  U->>C: début du drag depuis la poignée source
  C->>A: POST /connections/compatible
  A->>E: Suggest(source, cible) pour chaque nœud
  A-->>C: ids compatibles (surlignés)
  U->>C: relâche sur la cible
  C->>C: contrôle de cycle
  C->>A: POST /connections/suggest
  A->>E: règles YAML, puis inférence
  E-->>A: suggestions + arguments (obligatoires, défauts, types)
  A-->>C: panneau de liaison
  U->>C: choix + saisie des obligatoires manquants
  C->>C: référence écrite dans attrs (liste si cardinalité list), blocs créés si besoin
```

### 3.2 Génération multi-fichiers

Le modèle est envoyé à `POST /projects/:id/generate` à chaque modification (après 700 ms sans saisie). Le générateur résout le schéma de chaque nœud (cache LRU puis requête JSONB ciblée), affecte chaque nœud à un fichier, puis assemble les blocs triés :

```mermaid
flowchart LR
  M[Modèle] --> V[Validation structurelle<br/>labels, cycles, providers]
  M --> F{Découpage}
  F -->|single| S[main.tf]
  F -->|standard| ST[versions, providers, backend,<br/>variables, locals, main, outputs]
  F -->|category| CA[network.tf, security.tf…]
  F -->|service| SE[ec2.tf, s3.tf, vpc.tf…]
  F -->|custom| CU[fichier choisi par nœud<br/>+ règles glob]
  S & ST & CA & SE & CU --> H[hclwrite + fmt<br/>ordre stable]
  H --> R[fichiers + plages de lignes par nœud + diagnostics]
  M --> MOD[modules internes<br/>modules/&lt;nom&gt;/]
```

### 3.3 Création d'un module depuis une sélection

```mermaid
sequenceDiagram
  actor U
  participant A as API
  participant X as modules.Extract
  U->>A: POST /projects/:id/extract-module (nœuds, nom)
  A->>A: INSERT modules
  A->>X: Extract(modèle, sélection)
  X-->>A: module (variables = refs sortantes, outputs = refs entrantes) + projet réécrit
  A->>A: INSERT module_versions 1.0.0
  A->>A: SaveModel (nouvelle version du projet)
  A-->>U: modèle mis à jour (nœud module.<nom>)
```

### 3.4 Plan, approbation, apply

```mermaid
sequenceDiagram
  actor O as Opérateur
  actor P as Approbateur
  participant A as API
  participant W as Worker
  participant N as Notifier
  O->>A: POST runs {operation: plan}
  A->>A: génération + contrôle local-exec/file() + snapshot
  W->>W: claim (SKIP LOCKED + verrou consultatif par environnement)
  W->>W: init, state pull (serial), plan -out, show -json
  W->>W: conformité sur le plan, artefacts chiffrés
  W->>N: plan.finished, approval.requested
  P->>A: POST runs/:id/approve (auteur exclu)
  O->>A: POST runs {operation: apply, planRunId}
  A->>A: CheckApplicable : statut, expiration, approbations, conformité bloquante, fenêtre, destroy autorisé
  W->>W: state pull : serial identique au plan ?
  W->>W: apply plan.tfplan, archivage du state
  W->>N: apply.succeeded / apply.failed
```

Le **destroy** suit le même chemin : un `plan -destroy` nécessite `runs.destroy` et un environnement qui l'autorise ; l'apply demande une confirmation forte dans l'interface (saisie de `projet/environnement`).

### 3.5 Migration de backend

```mermaid
sequenceDiagram
  participant A as API
  participant W as Worker
  A->>A: run 1 : state pull (backend actuel figé dans le run)
  A->>A: mise à jour du backend de l'environnement (secrets dans le coffre)
  A->>A: run 2 : state push (nouveau backend)
  W->>W: run 1 → copie chiffrée archivée
  W->>W: run 2 → vérifie que le run 1 a réussi, puis state push
```

### 3.6 Tâche planifiée de drift

```mermaid
sequenceDiagram
  participant S as Scheduler
  participant W as Worker
  participant N as Notifier
  S->>S: échéance cron atteinte (réservation atomique)
  S->>S: exécution précédente encore active ? sinon on continue
  S->>W: run plan {drift: true}
  W->>W: plan + show -json → resource_drift
  W->>S: task_executions mis à jour
  W->>N: drift.detected si écart
```

## 4. Sécurité

| Sujet | Mesure |
|---|---|
| Mots de passe | argon2id (m=64 Mo, t=3, p=2), politique configurable |
| MFA | TOTP RFC 6238, imposable globalement |
| Sessions | jeton aléatoire 256 bits, seule l'empreinte SHA-256 est stockée, cookie HttpOnly SameSite=Strict (Secure configurable) |
| CSRF | en-tête `X-Requested-With` obligatoire sur les requêtes modifiantes par cookie ; Origin vérifiée pour le WebSocket |
| API | jetons personnels `hcld_…` (empreinte stockée), expiration |
| Débit | seau à jetons par IP (API) et limitation stricte de `/auth/login` |
| RBAC | permissions par domaine, portée globale / projet / environnement, rôles personnalisés ; `*` réservé au super admin |
| Secrets | AES-256-GCM (`HCLD_MASTER_KEY`), jamais renvoyés au frontend, absents des logs d'audit |
| Runs | environnement minimal (aucune variable du processus héritée), credentials injectés par variables d'environnement, masquage des secrets dans les logs, workspace éphémère supprimé à la fin, groupe de processus signalé à l'annulation (SIGINT puis SIGKILL), délai maximal, conteneur worker non root avec limites CPU/mémoire |
| Code | blocage configurable de `local-exec` et des fonctions `file()` hors workspace |
| Plans | artefacts chiffrés, durée de validité, invalidation si le state a changé |
| Audit | ajout seul, diff avant/après, export CSV et syslog |

## 5. Choix techniques et écarts au cahier des charges

| Demandé | Retenu | Raison |
|---|---|---|
| Redis (file de jobs, pub/sub des logs) | File de jobs PostgreSQL (`FOR UPDATE SKIP LOCKED` + verrou consultatif), logs en fichiers suivis par WebSocket | Un composant de moins à exploiter on-premise ; le débit visé (dizaines de runs simultanés) le permet. |
| MinIO / stockage objet | Volume partagé `/data` | Même raison ; un montage NFS ou un volume CSI couvre le multi-hôte. |
| Un conteneur éphémère par run | Sous-processus isolé dans le conteneur worker (non root, limites cgroups du conteneur, environnement minimal) | Lancer des conteneurs depuis le worker imposerait le socket Docker, soit un accès root à l'hôte. |
| react-hook-form + zod | Formulaires générés directement depuis les schémas providers | Les formulaires sont dynamiques (schéma provider) : un validateur statique n'apporte rien. |
| Nœud « provider » sur le canvas | Providers et alias configurés dans Paramètres du projet, sélection de l'alias par nœud | Un provider n'a pas de liaison à porter. Le mettre sur le canvas encombre sans valeur. |
| shadcn/ui | Composants Tailwind maison (`components/ui`) | Même rendu sans générateur de code. |
