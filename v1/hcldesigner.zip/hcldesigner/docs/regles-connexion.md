# Ajouter ou modifier des règles de connexion

Les règles sont dans `backend/rules/<provider>.yaml` et sont embarquées dans le binaire : il faut recompiler l'image après une modification.

## Format

```yaml
provider: aws
connections:
  # source.attr alimente target.arg
  - { source: aws_vpc, attr: id, target: aws_subnet, arg: vpc_id }
  # argument dans un bloc imbriqué : chemin pointé (le bloc est créé si absent)
  - { source: aws_subnet, attr: id, target: aws_eks_cluster, arg: vpc_config.subnet_ids }
  # "*" : toute ressource du même provider qui possède l'argument
  - { source: azurerm_resource_group, attr: name, target: "*", arg: resource_group_name }
  # règle limitée aux data sources en source
  - { source: aws_ami, attr: id, target: aws_instance, arg: ami, sourceKind: data }
defaults:
  # valeurs par défaut documentées du provider (le schéma JSON ne les expose pas)
  aws_vpc: { enable_dns_support: true, instance_tenancy: "default" }
```

## Comportement

1. Les **règles** ont le score 100 et passent devant toute inférence. Une règle dont l'argument n'existe pas dans la version du provider résolue est ignorée.
2. L'**inférence** (sans règle) relie par exemple `*_id` / `*_ids` / `<type>s` à `id`, `*_arn` à `arn` et `*_name` à `name`, à condition que les types soient compatibles.
3. La **cardinalité** vient du type de l'argument : un `list(...)` ou `set(...)` reçoit l'ajout d'un élément, sans écraser les éléments déjà présents.
4. Si la source utilise `count` ou `for_each`, une forme d'index est proposée : `[0]`, `[*]`, `["clé"]` ou `values(...)[*]`.
5. Les **défauts** sont affichés dans le panneau de liaison et le formulaire. Ils ne sont écrits dans le code que si l'option « Écrire explicitement les valeurs par défaut » du projet est active.

## Tests

Ajouter un cas à `backend/internal/connection/connection_test.go` (matrice source/cible → liaison attendue), puis lancer :

```bash
cd backend && go test ./internal/connection/
```
