# HCLDesigner

Application web de conception Terraform / OpenTofu sur un canvas. On place des ressources, on les relie, on génère le code HCL (un seul fichier ou plusieurs), et on exécute init, plan, apply et destroy avec approbations, gestion du state, planification, notifications et contrôle d'accès par rôles.

## Fonctionnalités

| Domaine | Contenu |
|---|---|
| Canvas | Catalogue de tous les providers résolus (schéma lu depuis `terraform providers schema -json`), glisser-déposer, liaisons guidées par règles YAML et inférence, arguments obligatoires et valeurs par défaut affichés à la liaison, contrôle de cycles, annuler/rétablir, mise en page automatique (ELK), groupes, recherche |
| Code | Génération déterministe ; découpages `single`, `standard`, `category`, `service` (ec2.tf, s3.tf…) ou `custom` (fichier par nœud + règles glob) ; aperçu Monaco en direct, synchronisé avec le canvas ; blocs `import` et `moved` ; export zip |
| Import | Code Terraform existant (fichiers `.tf` ou archive `.zip` du dépôt) converti en objets et liens sur le canvas, fichiers d'origine conservés, rapport des éléments non repris ; modèle HCLDesigner exporté (JSON) |
| Modules | Modules internes (versions semver, interface variables/outputs, diff d'interface), extraction d'une sélection en module, modules du registry, Git et locaux |
| Exécution | init, validate, plan, apply du plan sauvegardé, destroy ; logs en direct (WebSocket), secrets masqués, annulation ; plans chiffrés avec date d'expiration |
| Environnements | Variables, credentials, backend, fenêtres de modification, protection (approbations obligatoires, destroy interdit), auto-apply |
| State | Backends `internal` (chiffré, versionné), s3, azurerm, gcs, http, gitlab, pg, consul, kubernetes, oss, cos, remote ; explorateur (list/show/mv/rm/import/unlock), versions, migration entre backends. `.terraform.lock.hcl` reste avec le code (export, Git) et n'est pas envoyé dans le backend. |
| Conformité | Tags obligatoires, valeurs autorisées, nommage, ingress ouvert interdit, régions autorisées, version minimale de provider ; évaluée sur le modèle et sur le plan ; mode bloquant |
| Planification | Drift, plan (+ auto-apply), apply d'un plan, destroy d'environnement éphémère, montée de versions, sauvegarde du state, scan de conformité, rapport ; cron, fuseau horaire, reprises, historique |
| Notifications | Mail SMTP (starttls/tls), webhooks génériques / Teams / Slack, modèles éditables, règles par événement et périmètre, digests |
| Administration | Utilisateurs, équipes, MFA TOTP, jetons d'API, rôles prédéfinis et personnalisés (matrice de permissions, portée globale/projet/environnement), credentials, catalogue des providers, paramètres, audit immuable |
| Tableaux | Colonnes déplaçables par glisser-déposer, redimensionnement manuel, épinglage, masquage, filtres multichoix, recherche globale, vues enregistrées, préférences persistées par utilisateur, export CSV/HTML |
| Tableau de bord | Runs par statut et par jour, drift, conformité, projets les plus modifiés |

## Démarrage rapide (Docker)

Prérequis : Debian/Ubuntu en root. Le script installe Docker si besoin, crée le `.env`, construit et démarre :

```bash
unzip hcldesigner.zip && cd hcldesigner
sudo ./install.sh            # installation, ou mise à jour (le .env est conservé)
sudo ./install.sh --reset    # repartir de zéro (supprime les données)
```

Installation manuelle (Docker 24+ et Compose v2) :

```bash
cp .env.example .env
# Clé maître (32 octets en base64). À sauvegarder hors du serveur :
# sans elle, credentials, states internes et plans sont illisibles.
sed -i "s|^HCLD_MASTER_KEY=.*|HCLD_MASTER_KEY=$(openssl rand -base64 32)|" .env
# Mot de passe du compte admin initial et mot de passe PostgreSQL
vi .env

docker compose up -d --build
docker compose logs -f api
```

Interface : `http://<hôte>:8080`, compte `admin` avec le mot de passe `HCLD_ADMIN_PASSWORD`. Le compte n'est créé qu'au premier démarrage.

Services lancés :

| Service | Commande | Rôle |
|---|---|---|
| `postgres` | — | Données, file des runs, verrous |
| `api` | `hcldesigner api` | REST + WebSocket ; applique les migrations au démarrage |
| `worker` | `hcldesigner worker` | Exécute Terraform/OpenTofu (limites CPU/mémoire dans le compose) |
| `scheduler` | `hcldesigner scheduler` | Tâches planifiées, envoi des notifications, rétention |
| `frontend` | nginx | Fichiers statiques + proxy `/api` |

Pour exécuter plusieurs runs en parallèle : `docker compose up -d --scale worker=3`. Deux runs sur un même environnement ne tournent jamais en même temps (verrou PostgreSQL par environnement).

### Variables principales

| Variable | Défaut | Rôle |
|---|---|---|
| `HCLD_DATABASE_URL` | défini par le compose | DSN PostgreSQL |
| `HCLD_MASTER_KEY` | — | Clé AES-256 en base64 (obligatoire) |
| `HCLD_ADMIN_USER` / `HCLD_ADMIN_PASSWORD` / `HCLD_ADMIN_EMAIL` | `admin` / — / — | Compte super admin créé au premier démarrage |
| `HCLD_DATA_DIR` | `/data` | Logs, plans, states internes, cache des providers |
| `HCLD_LISTEN` | `:8000` | Adresse d'écoute de l'API |
| `HCLD_BASE_URL` | — | URL publique utilisée dans les liens des mails |
| `HCLD_SECURE_COOKIES` | `false` | Passer à `true` derrière HTTPS |
| `HCLD_TRUST_PROXY` | `true` | Lire l'IP client dans `X-Forwarded-For` (limitation de débit, audit) |
| `HCLD_SESSION_TTL` | `12h` | Durée de vie des sessions |
| `HCLD_WORKER_CONCURRENCY` | `2` | Runs simultanés par worker |
| `HCLD_RUN_TIMEOUT` | `2h` | Durée maximale d'un run |
| `TERRAFORM_BIN` / `TOFU_BIN` | préinstallés dans l'image | Binaires utilisés pour leur version ; les autres versions sont téléchargées et vérifiées (SHA256SUMS) |
| `HCLD_TERRAFORM_URL` / `HCLD_TOFU_URL` | dépôts officiels | Dépôt interne des binaires (`{v}`, `{os}`, `{arch}` remplacés) |
| `HCLD_REGISTRY_URL` | `https://registry.terraform.io` | Registry consulté pour les providers et les modules |
| `HCLD_STATIC_DIR` | — | Sert le frontend compilé depuis l'API (sans nginx) |
| `HTTPS_PROXY` / `NO_PROXY` | — | Proxy sortant, transmis aux exécutions |

Le SMTP, le miroir de providers (filesystem ou réseau), la politique de mots de passe, la MFA obligatoire, la rétention, le blocage de `local-exec` et la durée de validité des plans se règlent dans **Administration → Paramètres**.

### Mise en production

- Placer un reverse proxy TLS devant le port 8080, puis définir `HCLD_SECURE_COOKIES=true` et `HCLD_BASE_URL=https://…`.
- Sauvegarder PostgreSQL (`pg_dump`), le volume `tcdata` et `HCLD_MASTER_KEY`, séparément.
- Environnement isolé : renseigner `HCLD_REGISTRY_URL`, `HCLD_TERRAFORM_URL`/`HCLD_TOFU_URL` et le miroir de providers (Paramètres) vers vos dépôts internes.

## Utilisation

1. **Administration → Credentials** : créer les accès cloud (AWS, Azure, GCP, vSphere, VCD, Proxmox, Kubernetes, Cloudflare, OVH, variables libres ou accès backend).
2. **Projets → Nouveau** : choisir Terraform ou OpenTofu et sa version.
3. **Paramètres du projet → Providers** : ajouter les providers (`hashicorp/aws ~> 5.0`…) puis **Résoudre**. Le worker télécharge le provider et importe son schéma, et le catalogue se remplit.
4. **Éditeur** : glisser les ressources depuis le catalogue, relier les poignées. Le panneau de liaison propose l'argument cible, montre les obligatoires et les défauts. Le formulaire de droite liste tous les arguments du schéma (obligatoires en premier, valeurs par défaut affichées).
5. **Code** : choisir le découpage des fichiers dans les paramètres ; cliquer sur un nœud surligne son bloc dans le code.
6. **Environnements** : créer `dev`, `prod`… avec backend, variables, credentials et protection.
7. **Run** depuis l'éditeur : plan, puis approbation si l'environnement l'exige, puis apply.
8. **Planifications** : drift quotidien, destroy des environnements éphémères le soir, etc.

### Importer un projet Terraform existant

**Projets → Importer (Terraform)** : choisir les fichiers `.tf` du dossier, ou une archive `.zip` du dépôt. Un rapport s'affiche avant la création du projet.

| Repris | Comportement |
|---|---|
| `resource`, `data`, `module`, `variable`, `locals`, `output` | Un objet par bloc, placé en colonnes selon les dépendances |
| Références simples (`aws_vpc.main.id`, `aws_subnet.a[0].id`, `aws_subnet.a[*].id`, `var.x`, `module.m.out`) | Liens éditables sur le canvas |
| Expressions (`"${…}"`, fonctions, conditions) | Conservées telles quelles ; les objets cités sont reliés en pointillés |
| `provider` (alias compris), `required_providers`, `required_version` | Paramètres du projet ; version résolue reprise si le provider est déjà en cache sur l'instance |
| `count`, `for_each`, `provider`, `depends_on`, `lifecycle`, `import`, `moved` | Méta-arguments du nœud |
| Fichiers d'origine | Découpage « fichier par nœud » : chaque ressource reste dans son fichier |

Non repris, et signalé dans le rapport : blocs `dynamic`, provisioners, `check`, `removed`, `backend` / `cloud` (à configurer dans l'environnement), modules à source locale, sous-dossiers d'une archive. Dans une archive, seul le dossier le moins profond contenant des `.tf` est importé. Les fichiers `.tfvars` et `.tf.json` sont ignorés.

Pour reprendre l'infrastructure existante sans la recréer : importer le code, configurer le backend de l'environnement sur le state existant (ou migrer le state), puis lancer un plan, qui doit annoncer « No changes ».

## Développement

Prérequis : Go 1.24, Node 20+, PostgreSQL 16, et Terraform ou OpenTofu dans le `PATH` (ou `TERRAFORM_BIN` / `TOFU_BIN`).

```bash
# Base locale
createdb hcldesigner
export HCLD_DATABASE_URL=postgres://localhost/hcldesigner?sslmode=disable
export HCLD_MASTER_KEY=$(openssl rand -base64 32) HCLD_ADMIN_PASSWORD='Admin-Terra-2026!'
export HCLD_DATA_DIR=/tmp/tcdata

make dev-api     # API + worker + scheduler dans un seul processus (rôle "all"), port 8000
make dev-front   # Vite sur :5173, proxy /api vers :8000
```

Le `go.mod` remplace `golang.org/x/*` et `gopkg.in/yaml.v3` par leurs miroirs GitHub (le réseau de développement bloquait les domaines vanity). Si votre réseau y accède, ces `replace` peuvent être supprimés. Sinon, compiler avec :

```bash
GOPROXY=direct GOSUMDB=off go build ./...
```

### Tests

```bash
make test                      # go vet + go test, tsc + vitest
cd backend && go test ./...    # golden files hclgen, moteur de liaison, conformité, extraction de modules, RBAC
cd frontend && npm test        # vitest
CHROME_PATH=/usr/bin/chromium npm run e2e   # Playwright : liaison sur le canvas, génération, formulaire
./scripts/smoke.sh             # E2E API : providers → génération → validate → plan → apply → state → destroy → export
```

`smoke.sh` attend une instance lancée sur `:8000`. `MIRROR_PATH=/chemin/miroir` permet de résoudre les providers hors ligne.

Pour régénérer les golden files après une évolution voulue du générateur : `cd backend && go test ./internal/hclgen -update`.

## Arborescence

```
backend/
  cmd/hcldesigner/        point d'entrée : api | worker | scheduler | all | migrate | healthcheck
  internal/
    api/                  routes HTTP par domaine (auth, projets, runs, state, admin…)
    core/                 services partagés : projets, backends, credentials, runs, state
    model/                modèle de projet (nœuds, valeurs, références, cycles)
    schema/               schémas providers, catalogue, lock file
    connection/           moteur de liaison (règles + inférence)
    hclgen/               génération HCL, découpage, backend, modules internes
    modules/              extraction d'une sélection en module
    policy/               règles de conformité (modèle et plan)
    runner/               worker : file, exécution, state, masquage
    scheduler/            cron, notifications, rétention
    notify/ rbac/ auth/ vault/ audit/ settings/ config/ db/ tfbin/
  rules/                  règles de connexion et défauts par provider (YAML embarqués)
frontend/src/
  api/ types/ store/ lib/            client HTTP, types, store de l'éditeur (zustand + immer)
  components/ui, components/table    composants de base, DataTable générique
  pages/editor/                      canvas, catalogue, propriétés, liaison, code, runs
  pages/project/ runs/ modules/ admin/
docs/
  architecture.md         composants, modèle de données, séquences, sécurité, écarts
  regles-connexion.md     ajouter des règles de liaison et des défauts
  openapi.yaml            135 routes
scripts/smoke.sh
docker-compose.yml  .env.example  Makefile  .gitlab-ci.yml
```

Détails dans [docs/architecture.md](docs/architecture.md).

## Rôles prédéfinis

| Rôle | Droits |
|---|---|
| Super admin | Tout (`*`) |
| Admin | Tout sauf la gestion des super admins |
| Concepteur | Projets et modules en écriture, plan, lecture des runs |
| Opérateur | Plan, apply, opérations de state, lecture des projets |
| Approbateur | Lecture, approbation des plans (ne peut pas approuver ses propres runs) |
| Lecteur | Lecture seule |

Les rôles personnalisés se créent dans **Administration → Rôles** (matrice domaine × action) et s'attribuent à un utilisateur ou une équipe, globalement ou sur un projet ou un environnement.

## Limites et écarts

Écarts d'architecture au cahier des charges (justifiés dans `docs/architecture.md` §5) :

- File de jobs PostgreSQL au lieu de Redis, volume partagé au lieu de MinIO.
- Runs exécutés en sous-processus isolé dans le conteneur worker, et non dans un conteneur par run (cela évite d'exposer le socket Docker).
- Providers et alias configurés dans les paramètres du projet, et non comme nœuds du canvas.
- Formulaires générés depuis les schémas, sans react-hook-form/zod ; composants UI maison au lieu de shadcn/ui.

Non implémenté (phase 2) :

- Import d'un `.tfstate` vers le canvas (l'import de code `.tf` est fait, voir ci-dessous)
- Push Git / merge request
- Intégration OPA, checkov, tfsec, Infracost
- LDAP / OIDC / SAML (comptes locaux + MFA uniquement)
- Édition collaborative temps réel (un verrou optimiste protège des écrasements)
- Assistant IA, bibliothèque de modèles de projets, chart Helm

Non vérifié dans l'environnement de développement : `docker compose up` (aucun démon Docker disponible). Les images ont été écrites mais pas construites ici. Tout le reste a été testé : binaire, migrations, smoke E2E avec OpenTofu, tests Go, vitest, Playwright.

## Marques

Terraform est une marque déposée de HashiCorp, Inc. OpenTofu est une marque de la Linux Foundation. HCLDesigner est un projet indépendant, sans lien avec HashiCorp ni la Linux Foundation, et n'est ni approuvé ni soutenu par eux.
