#!/usr/bin/env bash
# Installation / mise à jour de HCLDesigner avec Docker Compose.
#
#   sudo ./install.sh            installation, ou mise à jour si un .env existe déjà (le .env est conservé)
#   sudo ./install.sh --reset    supprime les données (base + volume) et réinstalle (nouveau .env)
#   sudo ./install.sh --help
#
# Le script :
#   1. installe Docker Engine + le plugin Compose si absents (Debian / Ubuntu, dépôt officiel Docker) ;
#   2. crée le .env au premier lancement (clé maître, mot de passe PostgreSQL et admin générés) ;
#   3. sauvegarde le .env dans /root/hcldesigner.env.bak ;
#   4. construit les images, démarre la pile et attend que l'application réponde.
set -Eeuo pipefail

cd "$(dirname "$(readlink -f "$0")")"

ENV_FILE=.env
ENV_BACKUP=/root/hcldesigner.env.bak
RESET=false

# ---- Affichage ------------------------------------------------------------------
info() { printf '\033[1;34m[INFO]\033[0m %s\n' "$*"; }
ok()   { printf '\033[1;32m[OK]\033[0m   %s\n' "$*"; }
warn() { printf '\033[1;33m[WARN]\033[0m %s\n' "$*"; }
die()  { printf '\033[1;31m[ERR]\033[0m  %s\n' "$*" >&2; exit 1; }
trap 'die "échec ligne $LINENO : $BASH_COMMAND"' ERR

usage() { sed -n '2,12p' "$0" | sed 's/^# \{0,1\}//'; exit 0; }

for arg in "$@"; do
  case "$arg" in
    --reset) RESET=true ;;
    -h|--help) usage ;;
    *) die "option inconnue : $arg (voir --help)" ;;
  esac
done

# ---- Prérequis ------------------------------------------------------------------
[[ $EUID -eq 0 ]] || die "lancer en root (sudo ./install.sh)"
[[ -f docker-compose.yml && -f .env.example ]] || die "lancer le script depuis le dossier hcldesigner (docker-compose.yml introuvable)"

install_docker() {
  # Dépôt officiel Docker : le paquet docker.io de Debian ne fournit pas toujours "docker compose" v2.
  . /etc/os-release
  case "$ID" in debian|ubuntu) ;; *) die "installation automatique de Docker gérée pour Debian/Ubuntu uniquement ($ID détecté)";; esac
  info "installation de Docker Engine et du plugin Compose ($PRETTY_NAME)"
  apt-get update -qq
  apt-get install -y -qq ca-certificates curl gnupg >/dev/null
  install -m 0755 -d /etc/apt/keyrings
  curl -fsSL "https://download.docker.com/linux/$ID/gpg" -o /etc/apt/keyrings/docker.asc
  chmod a+r /etc/apt/keyrings/docker.asc
  echo "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.asc] https://download.docker.com/linux/$ID $VERSION_CODENAME stable" \
    > /etc/apt/sources.list.d/docker.list
  apt-get update -qq
  apt-get install -y -qq docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin >/dev/null
  systemctl enable --now docker >/dev/null
}

if ! command -v docker >/dev/null || ! docker compose version >/dev/null 2>&1; then
  install_docker
fi
docker info >/dev/null 2>&1 || die "le démon Docker ne répond pas (systemctl status docker)"
command -v openssl >/dev/null || { apt-get install -y -qq openssl >/dev/null || die "openssl requis"; }
command -v curl >/dev/null || { apt-get install -y -qq curl >/dev/null || die "curl requis"; }
ok "$(docker --version | cut -d, -f1), $(docker compose version --short 2>/dev/null || echo compose v2)"

# ---- Fonctions .env ---------------------------------------------------------------
# Lit une valeur du .env (vide si absente).
env_get() { grep -E "^$1=" "$ENV_FILE" 2>/dev/null | tail -1 | cut -d= -f2- || true; }

# Écrit ou remplace une clé du .env. Les valeurs générées ici ne contiennent ni | ni & ni $.
env_set() {
  if grep -qE "^$1=" "$ENV_FILE"; then
    sed -i "s|^$1=.*|$1=$2|" "$ENV_FILE"
  else
    printf '%s=%s\n' "$1" "$2" >> "$ENV_FILE"
  fi
}

# Mot de passe sans $ ni ! (interprétés par Compose et par bash) : minuscules, majuscules, chiffres, tiret.
gen_password() { printf '%s-Tc9\n' "$(openssl rand -base64 24 | tr -dc 'A-Za-z0-9' | head -c 16)"; }

# ---- Réinitialisation ---------------------------------------------------------------
if $RESET; then
  warn "--reset : la base, les states internes, les plans et le .env actuel vont être supprimés."
  read -r -p "Taper RESET pour confirmer : " answer
  [[ $answer == RESET ]] || die "abandon"
  docker compose down -v --remove-orphans || true
  [[ -f $ENV_FILE ]] && mv "$ENV_FILE" "$ENV_FILE.old.$(date +%Y%m%d%H%M%S)"
  ok "données supprimées"
fi

# ---- .env -----------------------------------------------------------------------------
FIRST_INSTALL=false
ADMIN_PASSWORD_SHOWN=""
if [[ ! -f $ENV_FILE ]]; then
  # Volumes présents sans .env : PostgreSQL et la clé maître ne correspondraient plus.
  project=hcldesigner # "name:" du docker-compose.yml
  if docker volume ls -q | grep -qE "^${project}_(pgdata|tcdata)$"; then
    die "des volumes ${project}_pgdata / ${project}_tcdata existent mais le .env est absent.
       Restaurer le .env (sauvegarde : $ENV_BACKUP) ou relancer avec --reset (perte des données)."
  fi

  info "création du .env"
  cp .env.example "$ENV_FILE"
  chmod 600 "$ENV_FILE"
  FIRST_INSTALL=true

  ip=$(hostname -I 2>/dev/null | awk '{print $1}')
  read -r -p "Port HTTP de l'interface [8080] : " port; port=${port:-8080}
  read -r -p "URL publique [http://${ip:-localhost}:$port] : " base_url; base_url=${base_url:-http://${ip:-localhost}:$port}
  read -r -s -p "Mot de passe admin (vide = généré ; 12 car. min., 3 types, sans \$ ni !) : " admin_pw; echo
  if [[ -z $admin_pw ]]; then
    admin_pw=$(gen_password)
    ADMIN_PASSWORD_SHOWN=$admin_pw
  fi
  [[ ${#admin_pw} -ge 12 ]] || die "mot de passe admin trop court (12 caractères minimum)"
  [[ $admin_pw != *'$'* && $admin_pw != *'|'* && $admin_pw != *'&'* ]] || die "mot de passe admin : caractères \$ | & interdits"

  env_set HCLD_MASTER_KEY "$(openssl rand -base64 32)"
  env_set POSTGRES_PASSWORD "$(openssl rand -hex 24)"
  env_set HCLD_ADMIN_PASSWORD "$admin_pw"
  env_set HCLD_HTTP_PORT "$port"
  env_set HCLD_BASE_URL "$base_url"
  [[ $base_url == https://* ]] && env_set HCLD_SECURE_COOKIES true
else
  info ".env existant conservé (mise à jour)"
  for key in HCLD_MASTER_KEY POSTGRES_PASSWORD HCLD_ADMIN_PASSWORD; do
    [[ -n $(env_get "$key") ]] || die "$key est vide dans $ENV_FILE : le compléter ou relancer avec --reset"
  done
fi

cp "$ENV_FILE" "$ENV_BACKUP"
chmod 600 "$ENV_BACKUP"
ok ".env sauvegardé dans $ENV_BACKUP (contient la clé maître : à copier aussi hors du serveur)"

# ---- Construction et démarrage ----------------------------------------------------------
info "construction des images (plusieurs minutes au premier lancement)"
docker compose build --pull
info "démarrage"
docker compose up -d --remove-orphans

port=$(env_get HCLD_HTTP_PORT); port=${port:-8080}
info "attente de l'application sur http://127.0.0.1:$port/healthz"
for _ in $(seq 1 90); do
  if curl -fsS -o /dev/null "http://127.0.0.1:$port/healthz"; then
    break
  fi
  sleep 2
done
if ! curl -fsS -o /dev/null "http://127.0.0.1:$port/healthz"; then
  docker compose ps
  docker compose logs --tail 40 api
  die "l'application ne répond pas après 3 minutes (voir les logs ci-dessus)"
fi

docker compose ps
ok "HCLDesigner est démarré"
echo
echo "  URL         : $(env_get HCLD_BASE_URL)"
echo "  Identifiant : $(env_get HCLD_ADMIN_USER)"
if [[ -n $ADMIN_PASSWORD_SHOWN ]]; then
  echo "  Mot de passe: $ADMIN_PASSWORD_SHOWN   (généré, à noter : il ne sera plus affiché)"
elif $FIRST_INSTALL; then
  echo "  Mot de passe: celui saisi pendant l'installation"
else
  echo "  Mot de passe: inchangé (le compte admin n'est créé qu'à la première installation)"
fi
echo
echo "  Logs        : docker compose logs -f api worker"
echo "  Mise à jour : décompresser la nouvelle archive par-dessus (unzip -o), puis relancer ./install.sh"
