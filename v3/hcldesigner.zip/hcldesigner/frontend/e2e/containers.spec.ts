import { expect, test, type Locator, type Page } from "@playwright/test";

// Cadres conteneurs : imbrication à l'import, sortie d'un objet d'un cadre, repli du cadre.
async function login(page: Page) {
  await page.goto("/");
  await page.getByLabel("Identifiant").fill(process.env.E2E_USER ?? "admin");
  await page.getByLabel("Mot de passe").fill(process.env.E2E_PASS ?? "");
  await page.getByRole("button", { name: "Se connecter" }).click();
  await expect(page.getByText("Tableau de bord").first()).toBeVisible();
}

const box = async (l: Locator) => (await l.boundingBox())!;
const inside = (inner: { x: number; y: number; width: number; height: number }, outer: typeof inner) =>
  inner.x >= outer.x && inner.y >= outer.y && inner.x + inner.width <= outer.x + outer.width && inner.y + inner.height <= outer.y + outer.height;

test("cadres : VPC > subnet > instance, sortie du cadre, repli", async ({ page }) => {
  const errs: string[] = [];
  page.on("pageerror", (e) => errs.push(e.message));
  await login(page);
  await page.goto("/projects");
  await page.locator('input[type=file][accept=".tf,.zip"]').setInputFiles(new URL("./fixtures/nested.tf", import.meta.url).pathname);
  await page.getByLabel("Nom").fill(`cadres-${Date.now()}`);
  await page.getByRole("button", { name: "Créer" }).click();

  const vpc = page.locator(".react-flow__node-container", { hasText: "aws_vpc" });
  const subnet = page.locator(".react-flow__node-container", { hasText: "aws_subnet" });
  const web = page.locator(".react-flow__node", { hasText: "aws_instance" });
  const s3 = page.locator(".react-flow__node", { hasText: "aws_s3_bucket" });
  await expect(vpc).toBeVisible();
  await page.waitForTimeout(500); // fitView initial
  expect(inside(await box(subnet), await box(vpc))).toBe(true);
  expect(inside(await box(web), await box(subnet))).toBe(true);
  expect(inside(await box(s3), await box(vpc))).toBe(false);

  // Repli du VPC : le subnet et l'instance disparaissent.
  await vpc.getByTitle("Replier").click();
  await expect(web).toBeHidden();
  await expect(subnet).toBeHidden();
  await vpc.getByTitle("Déplier").click();
  await expect(web).toBeVisible();

  // Sortie de l'instance hors du VPC : elle reste visible quand on replie le VPC.
  const w = await box(web);
  const v = await box(vpc);
  await page.mouse.move(w.x + 40, w.y + 15);
  await page.mouse.down();
  await page.mouse.move(v.x + v.width + 150, v.y + v.height + 80, { steps: 12 });
  await page.mouse.up();
  await vpc.getByTitle("Replier").click();
  await expect(subnet).toBeHidden();
  await expect(web).toBeVisible();
  expect(errs).toEqual([]);
});
