import { expect, test, type Page } from "@playwright/test";

// v3 : workers (cycle de vie, commande d'installation) et intégration Git.
// FORGE_URL : forge Gitea joignable par l'API (fausse forge en local, voir docs).
/** Liste déroulante d'un champ (le <label> englobe le <select>). */
const select = (page: Page, label: string) => page.locator("label", { hasText: new RegExp("^" + label) }).locator("select");

async function login(page: Page) {
  await page.goto("/");
  await page.getByLabel("Identifiant").fill(process.env.E2E_USER ?? "admin");
  await page.getByLabel("Mot de passe").fill(process.env.E2E_PASS ?? "");
  await page.getByRole("button", { name: "Se connecter" }).click();
  await expect(page.getByText("Tableau de bord").first()).toBeVisible();
}

test("workers : worker par défaut, pause / reprise, commande d'installation", async ({ page }) => {
  await login(page);
  await page.goto("/admin/workers");
  const row = page.locator("tr", { hasText: "par défaut" });
  await expect(row).toBeVisible();
  await expect(row.getByText("Actif")).toBeVisible();
  await row.getByTitle("Mettre en pause (les runs en cours se terminent)").click();
  await expect(row.getByText("En pause")).toBeVisible();
  await row.getByTitle("Reprendre").click();
  await expect(row.getByText("Actif")).toBeVisible();

  await page.getByRole("button", { name: "Ajouter un worker" }).click();
  await page.getByLabel("Nom").fill(`e2e-${Date.now() % 100000}`);
  await page.getByLabel("Labels").fill("dc1");
  await page.getByRole("button", { name: "Générer la commande" }).click();
  const cmd = page.locator("pre").first();
  await expect(cmd).toContainText("/api/agent/install.sh");
  await expect(cmd).toContainText("--token hcldj_");
});

test("git : connexion personnelle, import d'un sous-dossier, push", async ({ page }) => {
  const forge = process.env.FORGE_URL;
  test.skip(!forge, "FORGE_URL non défini");
  await login(page);
  await page.goto("/account");
  await page.getByRole("button", { name: "Ajouter" }).click();
  await select(page, "Fournisseur").selectOption("gitea");
  await page.getByLabel("URL du serveur").fill(forge!);
  await page.getByLabel("Nom de la connexion").fill(`forge-${Date.now() % 100000}`);
  await page.getByLabel("Nom d'utilisateur").fill("alice");
  await page.getByLabel("Jeton d'accès personnel").fill("secret-token");
  await page.getByLabel("Auteur des commits").fill("Alice Ops");
  await page.getByRole("button", { name: "Enregistrer" }).click();
  await expect(page.getByText("Connexion enregistrée et vérifiée")).toBeVisible();

  await page.goto("/projects");
  await page.getByRole("button", { name: "Importer (Git)" }).click();
  const conn = select(page, "Connexion");
  await expect(conn.locator("option").first()).toBeAttached();
  await conn.selectOption({ index: (await conn.locator("option").count()) - 1 });
  await select(page, "Dépôt").selectOption("ops/infra");
  await expect(select(page, "Branche")).toHaveValue("main");
  await expect(select(page, "Dossier du code Terraform")).toHaveValue("infra/prod");
  await page.getByRole("button", { name: "Analyser le code" }).click();
  await expect(page.getByText("Importer ops/infra")).toBeVisible();
  await page.locator("label", { hasText: /^Nom/ }).locator("input").first().fill(`git-e2e-${Date.now()}`);
  await page.getByRole("button", { name: "Créer" }).click();
  await expect(page.locator(".react-flow__node").first()).toBeVisible();

  await page.getByRole("button", { name: "Paramètres", exact: true }).click();
  await expect(page.getByText("infra/prod").first()).toBeVisible();
  await page.getByRole("button", { name: "Pousser le code" }).click();
  await select(page, "Mode").selectOption("direct");
  await page.getByRole("button", { name: "Pousser sur main" }).click();
  await expect(page.getByText(/poussé sur main|Aucun changement/)).toBeVisible();
});
