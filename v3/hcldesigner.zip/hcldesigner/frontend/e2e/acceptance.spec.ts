import { expect, test, type APIRequestContext, type Page } from "@playwright/test";

const USER = process.env.E2E_USER ?? "admin";
const PASS = process.env.E2E_PASS ?? "";
const headers = { "X-Requested-With": "hcldesigner" };

async function login(page: Page) {
  await page.goto("/");
  await page.getByLabel("Identifiant").fill(USER);
  await page.getByLabel("Mot de passe").fill(PASS);
  await page.getByRole("button", { name: "Se connecter" }).click();
  await expect(page.getByText("Tableau de bord").first()).toBeVisible();
}

/** Projet préparé par l'API : provider random résolu (doit être en cache côté serveur). */
async function prepareProject(request: APIRequestContext): Promise<string> {
  await request.post("/api/auth/login", { data: { username: USER, password: PASS }, headers });
  const providers = await (await request.get("/api/providers")).json();
  const random = providers.find((p: { source: string }) => p.source === "hashicorp/random");
  test.skip(!random, "provider hashicorp/random non résolu sur le serveur");
  const project = await (await request.post("/api/projects", { data: { name: `e2e-${Date.now()}` }, headers })).json();
  const detail = await (await request.get(`/api/projects/${project.id}`)).json();
  const model = detail.project.model;
  model.engine = process.env.E2E_ENGINE ?? "terraform";
  model.providers = [{ localName: "random", source: "hashicorp/random", version: "~> 3.6", resolved: random.version, alias: "", config: {} }];
  await request.put(`/api/projects/${project.id}/model`, { data: { version: detail.project.version, model, message: "e2e" }, headers });
  return project.id;
}

test("conception : drag & drop, liaison avec panneau, code généré, enregistrement", async ({ page, request }) => {
  const id = await prepareProject(request);
  await login(page);
  await page.goto(`/projects/${id}`);
  const canvas = page.locator(".react-flow");
  await expect(canvas).toBeVisible();

  // Variable depuis l'onglet « Objets »
  await page.getByRole("button", { name: "Objets" }).click();
  await page.getByText("Variable", { exact: true }).dragTo(canvas, { targetPosition: { x: 200, y: 200 } });
  // random_pet depuis le catalogue du provider
  await page.getByRole("button", { name: "Providers" }).first().click();
  await page.getByPlaceholder("Rechercher (ex. vpc, bucket)…").fill("pet");
  await page.locator("[draggable=true]", { hasText: "random_pet" }).dragTo(canvas, { targetPosition: { x: 600, y: 200 } });
  await expect(page.locator(".react-flow__node")).toHaveCount(2);

  await page.locator(".react-flow__controls-fitview").click();
  await page.waitForTimeout(600); // fin de l animation du fitView
  // Liaison variable -> random_pet : le panneau de liaison s'ouvre
  const source = page.locator(".react-flow__node", { hasText: "variable" }).locator(".react-flow__handle-right");
  const target = page.locator(".react-flow__node", { hasText: "random_pet" }).locator(".react-flow__handle-left");
  const a = (await source.boundingBox())!;
  const b = (await target.boundingBox())!;
  await page.mouse.move(a.x + a.width / 2, a.y + a.height / 2);
  await page.mouse.down();
  await page.mouse.move(b.x + b.width / 2, b.y + b.height / 2, { steps: 15 });
  await page.mouse.up();
  await expect(page.getByText("Liaison", { exact: false }).first()).toBeVisible();
  await page.getByRole("radio").first().check();
  await page.getByRole("button", { name: "Relier" }).click();

  // Le code généré référence la variable
  await page.getByRole("button", { name: "Code" }).click();
  await expect(page.locator(".monaco-editor").first()).toBeVisible();
  await page.getByRole("button", { name: "main.tf" }).click();
  await expect(page.locator(".view-lines").first()).toContainText("var.variable");

  // Enregistrement (Ctrl+S ouvre la saisie du message)
  page.once("dialog", (d) => d.accept("e2e"));
  await page.getByRole("button", { name: "Enregistrer" }).click();
  await expect(page.getByText(/Version \d+ enregistrée/)).toBeVisible();
});

test("tableaux : ordre et largeur des colonnes persistés", async ({ page }) => {
  await login(page);
  // Repart des préférences par défaut : la largeur est persistée d'une exécution à l'autre.
  await page.request.delete("/api/prefs/tables/runs", { headers });
  await page.goto("/runs");
  const header = page.locator("thead th").filter({ hasText: "Statut" }).first();
  await expect(header).toBeVisible();
  const before = (await header.boundingBox())!.width;
  const delta = 120;
  const handle = header.locator(".col-resizer");
  const box = (await handle.boundingBox())!;
  await page.mouse.move(box.x + 2, box.y + box.height / 2);
  await page.mouse.down();
  await page.mouse.move(box.x + 2 + delta, box.y + box.height / 2, { steps: 8 });
  await page.mouse.up();
  await page.waitForTimeout(1200); // sauvegarde différée des préférences
  await page.reload();
  // Les préférences sont chargées après le premier rendu du tableau : on attend qu'elles s'appliquent.
  await expect
    .poll(async () => (await page.locator("thead th").filter({ hasText: "Statut" }).first().boundingBox())?.width ?? 0)
    .toBeGreaterThan(before + 60);
});
