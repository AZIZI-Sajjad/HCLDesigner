// Connexions Git personnelles (Mon compte) : chaque utilisateur a ses propres jetons et son
// identité de commit. GitHub, GitLab et Gitea, en SaaS ou auto-hébergés (CA interne possible).
import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { CheckCircle2, Pencil, Plus, Trash2 } from "lucide-react";
import { api } from "@/api/client";
import type { GitConnection } from "@/types/api";
import { Badge, Button, Card, ErrorBox, Field, IconButton, Input, Modal, Select, Textarea, Toggle, toast } from "@/components/ui";

export const providerLabels: Record<GitConnection["provider"], string> = { github: "GitHub", gitlab: "GitLab", gitea: "Gitea / Forgejo" };

/** Aide à la création du jeton selon le fournisseur. */
const tokenHelp: Record<GitConnection["provider"], string> = {
  github: "Jeton personnel (fine-grained : Contents et Pull requests en lecture/écriture, Metadata en lecture).",
  gitlab: "Jeton d'accès personnel ou de projet avec les portées api, read_repository et write_repository.",
  gitea: "Paramètres > Applications > jeton avec les droits repository (lecture/écriture).",
};

export function useGitConnections() {
  return useQuery({ queryKey: ["git-connections"], queryFn: () => api.get<GitConnection[]>("/me/git-connections") });
}

export function GitConnectionsCard() {
  const list = useGitConnections();
  const [editing, setEditing] = useState<GitConnection | "new" | null>(null);
  const test = (c: GitConnection) =>
    api.post<{ login: string; name: string }>(`/me/git-connections/${c.id}/test`).then((u) => toast.success(`Connexion valide : ${u.name || u.login}`), toast.error);
  return (
    <Card
      title="Connexions Git"
      actions={
        <Button size="sm" icon={<Plus className="h-3.5 w-3.5" />} onClick={() => setEditing("new")}>
          Ajouter
        </Button>
      }
    >
      <p className="mb-2 text-sm text-slate-500">Utilisées pour importer des projets depuis Git et pousser le code généré. Les jetons sont chiffrés et ne sont jamais réaffichés.</p>
      {(list.data ?? []).length === 0 && <p className="text-sm text-slate-500">Aucune connexion.</p>}
      <ul className="divide-y divide-slate-100 dark:divide-slate-800">
        {(list.data ?? []).map((c) => (
          <li key={c.id} className="flex items-center gap-2 py-2 text-sm">
            <Badge tone="blue">{providerLabels[c.provider]}</Badge>
            <span className="font-medium">{c.name}</span>
            <span className="truncate text-xs text-slate-500">
              {c.baseUrl}
              {c.username ? ` — ${c.username}` : ""}
              {c.authorEmail ? ` — commits : ${c.authorName || c.username} <${c.authorEmail}>` : ""}
            </span>
            <span className="flex-1" />
            <IconButton title="Tester" onClick={() => void test(c)}>
              <CheckCircle2 className="h-4 w-4" />
            </IconButton>
            <IconButton title="Modifier" onClick={() => setEditing(c)}>
              <Pencil className="h-4 w-4" />
            </IconButton>
            <IconButton title="Supprimer" onClick={() => void api.del(`/me/git-connections/${c.id}`).then(() => void list.refetch(), toast.error)}>
              <Trash2 className="h-4 w-4" />
            </IconButton>
          </li>
        ))}
      </ul>
      {editing && <GitConnectionForm conn={editing === "new" ? null : editing} onClose={() => setEditing(null)} onSaved={() => (setEditing(null), void list.refetch())} />}
    </Card>
  );
}

function GitConnectionForm({ conn, onClose, onSaved }: { conn: GitConnection | null; onClose: () => void; onSaved: () => void }) {
  const [f, setF] = useState({
    name: conn?.name ?? "",
    provider: conn?.provider ?? ("github" as GitConnection["provider"]),
    baseUrl: conn?.baseUrl ?? "",
    username: conn?.username ?? "",
    token: "",
    authorName: conn?.authorName ?? "",
    authorEmail: conn?.authorEmail ?? "",
    caCert: conn?.caCert ?? "",
    insecureTls: conn?.insecureTls ?? false,
  });
  const [error, setError] = useState<unknown>(null);
  const set = <K extends keyof typeof f>(k: K, v: (typeof f)[K]) => setF((x) => ({ ...x, [k]: v }));
  const save = async () => {
    try {
      const saved = conn ? await api.put<GitConnection>(`/me/git-connections/${conn.id}`, f) : await api.post<GitConnection>("/me/git-connections", f);
      // Test immédiat : un jeton invalide est signalé sans attendre le premier import.
      await api.post(`/me/git-connections/${saved.id}/test`).then(
        () => toast.success("Connexion enregistrée et vérifiée"),
        (e) => toast.error(`Connexion enregistrée, mais le test échoue : ${e instanceof Error ? e.message : String(e)}`),
      );
      onSaved();
    } catch (e) {
      setError(e);
    }
  };
  const placeholder = { github: "https://github.com (ou GitHub Enterprise)", gitlab: "https://gitlab.com (ou https://gitlab.interne.lan)", gitea: "https://gitea.interne.lan" }[f.provider];
  return (
    <Modal
      open
      wide
      onClose={onClose}
      title={conn ? conn.name : "Nouvelle connexion Git"}
      footer={
        <>
          <Button onClick={onClose}>Annuler</Button>
          <Button variant="primary" onClick={save}>
            Enregistrer
          </Button>
        </>
      }
    >
      <div className="space-y-3">
        <ErrorBox error={error} />
        <div className="grid gap-3 md:grid-cols-2">
          <Field label="Fournisseur">
            <Select value={f.provider} onChange={(e) => set("provider", e.target.value as GitConnection["provider"])}>
              {Object.entries(providerLabels).map(([k, v]) => (
                <option key={k} value={k}>
                  {v}
                </option>
              ))}
            </Select>
          </Field>
          <Field label="URL du serveur" help={f.provider === "gitea" ? "Obligatoire." : "Vide = service public."} required={f.provider === "gitea"}>
            <Input value={f.baseUrl} placeholder={placeholder} onChange={(e) => set("baseUrl", e.target.value)} />
          </Field>
          <Field label="Nom de la connexion">
            <Input value={f.name} placeholder="GitLab interne" onChange={(e) => set("name", e.target.value)} />
          </Field>
          <Field label="Nom d'utilisateur" required={f.provider === "gitea"} help={f.provider === "gitea" ? "Requis pour l'authentification git." : "Facultatif."}>
            <Input value={f.username} onChange={(e) => set("username", e.target.value)} />
          </Field>
          <Field label="Jeton d'accès personnel" required={!conn} help={conn ? "Vide = inchangé. " + tokenHelp[f.provider] : tokenHelp[f.provider]}>
            <Input type="password" autoComplete="new-password" value={f.token} onChange={(e) => set("token", e.target.value)} />
          </Field>
          <div />
          <Field label="Auteur des commits" help="Nom affiché dans l'historique Git.">
            <Input value={f.authorName} placeholder="Prénom Nom" onChange={(e) => set("authorName", e.target.value)} />
          </Field>
          <Field label="E-mail de l'auteur">
            <Input type="email" value={f.authorEmail} placeholder="prenom.nom@entreprise.fr" onChange={(e) => set("authorEmail", e.target.value)} />
          </Field>
        </div>
        <Field label="CA interne (PEM)" help="Pour un serveur auto-hébergé dont le certificat est signé par une autorité interne.">
          <Textarea rows={3} className="font-mono text-xs" value={f.caCert} placeholder="-----BEGIN CERTIFICATE-----" onChange={(e) => set("caCert", e.target.value)} />
        </Field>
        <Toggle checked={f.insecureTls} onChange={(v) => set("insecureTls", v)} label="Ne pas vérifier le certificat TLS (déconseillé)" />
      </div>
    </Modal>
  );
}
