// Choix d'une source Git : connexion personnelle, dépôt, branche et sous-dossier où se trouve
// le code Terraform (liste des dossiers contenant des .tf, ou saisie libre).
import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { api } from "@/api/client";
import type { GitRepo } from "@/types/api";
import { Field, Input, Select } from "@/components/ui";
import { providerLabels, useGitConnections } from "./GitConnectionsCard";

export interface GitSource {
  connectionId: string;
  repo: string;
  branch: string;
  path: string;
}

export const emptySource: GitSource = { connectionId: "", repo: "", branch: "", path: "" };

export function GitSourcePicker({ value, onChange, allowNewFolder }: { value: GitSource; onChange: (v: GitSource) => void; allowNewFolder?: boolean }) {
  const conns = useGitConnections();
  const [query, setQuery] = useState("");
  const [debounced, setDebounced] = useState("");
  useEffect(() => {
    const t = setTimeout(() => setDebounced(query), 300);
    return () => clearTimeout(t);
  }, [query]);
  // Première connexion sélectionnée par défaut.
  useEffect(() => {
    if (!value.connectionId && conns.data?.length) onChange({ ...emptySource, connectionId: conns.data[0].id });
  }, [conns.data, value.connectionId, onChange]);

  const cid = value.connectionId;
  const repos = useQuery({
    queryKey: ["git-repos", cid, debounced],
    queryFn: () => api.get<GitRepo[]>(`/me/git-connections/${cid}/repos?q=${encodeURIComponent(debounced)}`),
    enabled: !!cid,
  });
  const branches = useQuery({
    queryKey: ["git-branches", cid, value.repo],
    queryFn: () => api.get<string[]>(`/me/git-connections/${cid}/branches?repo=${encodeURIComponent(value.repo)}`),
    enabled: !!cid && !!value.repo,
  });
  const dirs = useQuery({
    queryKey: ["git-dirs", cid, value.repo, value.branch],
    queryFn: () => api.get<string[]>(`/me/git-connections/${cid}/dirs?repo=${encodeURIComponent(value.repo)}&branch=${encodeURIComponent(value.branch)}`),
    enabled: !!cid && !!value.repo && !!value.branch,
  });
  // Un seul dossier Terraform dans le dépôt : sélectionné d'office.
  useEffect(() => {
    if (dirs.data?.length === 1 && value.path === "" && !allowNewFolder) onChange({ ...value, path: dirs.data[0] });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [dirs.data]);

  if (conns.data && conns.data.length === 0) {
    return <p className="text-sm text-slate-500">Aucune connexion Git : ajoutez-en une dans Mon compte &gt; Connexions Git.</p>;
  }
  const selectRepo = (full: string) => {
    const r = repos.data?.find((x) => x.fullName === full);
    onChange({ ...value, repo: full, branch: r?.defaultBranch ?? "", path: "" });
  };
  const dirList = dirs.data ?? [];
  return (
    <div className="grid gap-3 md:grid-cols-2">
      <Field label="Connexion">
        <Select value={cid} onChange={(e) => onChange({ ...emptySource, connectionId: e.target.value })}>
          {(conns.data ?? []).map((c) => (
            <option key={c.id} value={c.id}>
              {c.name} ({providerLabels[c.provider]})
            </option>
          ))}
        </Select>
      </Field>
      <Field label="Rechercher un dépôt">
        <Input value={query} placeholder="nom du dépôt" onChange={(e) => setQuery(e.target.value)} />
      </Field>
      <Field label="Dépôt" required help={repos.error ? String((repos.error as Error).message) : repos.isFetching ? "Chargement…" : undefined}>
        <Select value={value.repo} onChange={(e) => selectRepo(e.target.value)}>
          <option value="">— choisir —</option>
          {value.repo && !repos.data?.some((r) => r.fullName === value.repo) && <option value={value.repo}>{value.repo}</option>}
          {(repos.data ?? []).map((r) => (
            <option key={r.fullName} value={r.fullName}>
              {r.fullName}
              {r.private ? " (privé)" : ""}
            </option>
          ))}
        </Select>
      </Field>
      <Field label="Branche" required>
        <Select value={value.branch} disabled={!value.repo} onChange={(e) => onChange({ ...value, branch: e.target.value, path: "" })}>
          <option value="">— choisir —</option>
          {value.branch && !branches.data?.includes(value.branch) && <option value={value.branch}>{value.branch}</option>}
          {(branches.data ?? []).map((b) => (
            <option key={b} value={b}>
              {b}
            </option>
          ))}
        </Select>
      </Field>
      <Field
        label="Dossier du code Terraform"
        className="md:col-span-2"
        help={
          dirs.isFetching
            ? "Analyse du dépôt…"
            : dirs.error
              ? String((dirs.error as Error).message)
              : allowNewFolder
                ? "Dossier existant ou nouveau dossier (créé au premier push). Vide = racine du dépôt."
                : dirList.length === 0 && value.branch
                  ? "Aucun fichier .tf trouvé dans cette branche."
                  : "Dossiers du dépôt qui contiennent des fichiers .tf."
        }
      >
        {allowNewFolder ? (
          <>
            <Input list="git-dirs" value={value.path} placeholder="infra/prod" onChange={(e) => onChange({ ...value, path: e.target.value })} />
            <datalist id="git-dirs">
              {dirList.map((d) => (
                <option key={d} value={d} />
              ))}
            </datalist>
          </>
        ) : (
          <Select value={value.path} disabled={!dirList.length} onChange={(e) => onChange({ ...value, path: e.target.value })}>
            {dirList.map((d) => (
              <option key={d} value={d}>
                {d === "" ? "(racine du dépôt)" : d}
              </option>
            ))}
          </Select>
        )}
      </Field>
    </div>
  );
}
