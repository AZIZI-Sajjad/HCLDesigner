// Disposition automatique du graphe (ELK, algorithme en couches, de gauche à droite).
// Seuls les objets à la racine sont replacés : le contenu d'un cadre garde sa disposition et
// suit son cadre ; un lien vers un objet imbriqué compte comme un lien vers son cadre racine.
import type { Project, TfNode } from "@/types/model";
import { deriveEdges } from "./model";

export async function autoLayout(p: Project, sizeOf: (n: TfNode) => { w: number; h: number }): Promise<Record<string, { x: number; y: number }>> {
  // ELK (~1,5 Mo) n'est chargé qu'au premier usage de la disposition automatique.
  const { default: ELK } = await import("elkjs/lib/elk.bundled.js");
  const elk = new ELK();
  const byId = new Map(p.nodes.map((n) => [n.id, n]));
  const isRoot = (n: TfNode) => !n.parent || !byId.has(n.parent);
  const roots = p.nodes.filter(isRoot);
  /** Cadre racine contenant un objet (lui-même s'il est à la racine). */
  const rootOf = (id: string): string | undefined => {
    const seen = new Set<string>();
    let n = byId.get(id);
    while (n && !isRoot(n) && !seen.has(n.id)) {
      seen.add(n.id);
      n = byId.get(n.parent!);
    }
    return n?.id;
  };
  const graph = {
    id: "root",
    layoutOptions: {
      "elk.algorithm": "layered",
      "elk.direction": "RIGHT",
      "elk.spacing.nodeNode": "40",
      "elk.layered.spacing.nodeNodeBetweenLayers": "90",
      "elk.layered.nodePlacement.strategy": "BRANDES_KOEPF",
    },
    children: roots.map((n) => ({ id: n.id, width: sizeOf(n).w, height: sizeOf(n).h })),
    edges: [...new Set(
      deriveEdges(p)
        .map((e) => [rootOf(e.source), rootOf(e.target)])
        .filter(([s, t]) => s && t && s !== t)
        .map(([s, t]) => `${s}>${t}`),
    )].map((k, i) => ({ id: `e${i}`, sources: [k.split(">")[0]], targets: [k.split(">")[1]] })),
  };
  const res = await elk.layout(graph);
  const out: Record<string, { x: number; y: number }> = {};
  for (const c of res.children ?? []) out[c.id] = { x: c.x ?? 0, y: c.y ?? 0 };
  return out;
}
