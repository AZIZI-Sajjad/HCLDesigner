import { describe, expect, it } from "vitest";
import type { Project, TfNode } from "@/types/model";
import { absolutePosition, descendants, frameAt, isAncestor, isHidden, relativeTo, releaseChildren, renderOrder } from "./containers";

const node = (id: string, type: string, x: number, y: number, extra: Partial<TfNode> = {}): TfNode =>
  ({ id, kind: "resource", type, label: id, attrs: {}, meta: {}, position: { x, y }, ...extra }) as TfNode;

// VPC (0,0 600x400) > subnet (40,60 300x200) > instance (24,48)
function project(): Project {
  return {
    nodes: [
      node("ec2", "aws_instance", 24, 48, { parent: "sub" }),
      node("sub", "aws_subnet", 40, 60, { parent: "vpc", size: { w: 300, h: 200 } }),
      node("vpc", "aws_vpc", 0, 0, { size: { w: 600, h: 400 } }),
      node("s3", "aws_s3_bucket", 800, 0),
    ],
  } as unknown as Project;
}
const types = new Set(["aws_vpc", "aws_subnet"]);

describe("imbrication", () => {
  it("calcule la position absolue le long des cadres", () => {
    expect(absolutePosition(project(), "ec2")).toEqual({ x: 64, y: 108 });
  });

  it("ordonne parents avant enfants, cadres avant cartes", () => {
    expect(renderOrder(project(), types).map((n) => n.id)).toEqual(["vpc", "s3", "sub", "ec2"]);
  });

  it("trouve le cadre le plus profond sous un point", () => {
    const p = project();
    expect(frameAt(p, { x: 100, y: 100 }, types)?.id).toBe("sub");
    expect(frameAt(p, { x: 500, y: 350 }, types)?.id).toBe("vpc");
    expect(frameAt(p, { x: 900, y: 10 }, types)).toBeUndefined();
    // un cadre ne peut pas être rangé dans lui-même ni dans son contenu
    expect(frameAt(p, { x: 100, y: 100 }, types, new Set(["vpc", ...descendants(p, "vpc")]))).toBeUndefined();
  });

  it("reconnaît les liens de contenance", () => {
    const p = project();
    expect(isAncestor(p, "vpc", "ec2")).toBe(true);
    expect(isAncestor(p, "sub", "ec2")).toBe(true);
    expect(isAncestor(p, "ec2", "vpc")).toBe(false);
    expect(isAncestor(p, "s3", "ec2")).toBe(false);
  });

  it("convertit une position absolue en position relative au cadre", () => {
    expect(relativeTo(project(), "sub", { x: 100, y: 100 })).toEqual({ x: 60, y: 40 });
    expect(relativeTo(project(), undefined, { x: 100.4, y: 99.6 })).toEqual({ x: 100, y: 100 });
  });

  it("masque le contenu d'un cadre replié, à toute profondeur", () => {
    const p = project();
    p.nodes.find((n) => n.id === "vpc")!.collapsed = true;
    expect(isHidden(p, p.nodes[0])).toBe(true);
    expect(isHidden(p, p.nodes[2])).toBe(false);
  });

  it("remonte le contenu d'un cadre supprimé sans le déplacer à l'écran", () => {
    const p = project();
    releaseChildren(p.nodes, "sub");
    const ec2 = p.nodes[0];
    expect(ec2.parent).toBe("vpc");
    expect(ec2.position).toEqual({ x: 64, y: 108 });
  });
});
