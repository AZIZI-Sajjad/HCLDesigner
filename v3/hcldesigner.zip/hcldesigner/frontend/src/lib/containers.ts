// Imbrication visuelle : certains types (VPC, subnet, resource group…) s'affichent comme des cadres
// qui contiennent d'autres objets. La position d'un objet imbriqué est relative à son cadre.
// Fonctions pures (testées dans containers.test.ts) + hook de chargement de la liste des types.
import { useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { api } from "@/api/client";
import type { Project, TfNode } from "@/types/model";

/** Dimensions par défaut (cohérentes avec internal/hclimport/layout.go). */
export const CARD = { w: 224, h: 80 };
export const FRAME = { w: 480, h: 320, header: 48, pad: 24, collapsedH: 56 };

type Point = { x: number; y: number };

/** Types conteneurs déclarés dans les règles (rules/*.yaml, clé containers). */
export function useContainerTypes(): Set<string> {
  const q = useQuery({
    queryKey: ["rules"],
    queryFn: () => api.get<{ containers?: string[] }>("/rules"),
    staleTime: Infinity,
  });
  // Ensemble stable entre deux rendus : sinon le canvas se recalculerait en boucle.
  return useMemo(() => new Set(q.data?.containers ?? []), [q.data]);
}

export function isFrame(n: TfNode, types: Set<string>): boolean {
  return (n.kind === "resource" || n.kind === "data") && types.has(n.type);
}

/** Un objet peut être rangé dans un cadre (pas les variables, locals ni outputs). */
export function isNestable(n: TfNode): boolean {
  return n.kind === "resource" || n.kind === "data" || n.kind === "module";
}

export function frameSize(n: TfNode): { w: number; h: number } {
  return n.size ?? { w: FRAME.w, h: FRAME.h };
}

/** Taille affichée : un cadre replié ne garde que son bandeau. */
export function displaySize(n: TfNode, types: Set<string>): { w: number; h: number } {
  if (!isFrame(n, types)) return CARD;
  const s = frameSize(n);
  return n.collapsed ? { w: s.w, h: FRAME.collapsedH } : s;
}

/** Parent effectif : un parent absent du modèle est ignoré (objet affiché hors cadre). */
export function parentOf(p: Project, n: TfNode): TfNode | undefined {
  return n.parent ? p.nodes.find((x) => x.id === n.parent) : undefined;
}

/** Position absolue (somme des positions relatives le long de la chaîne de cadres). */
export function absolutePosition(p: Project, id: string): Point {
  let x = 0;
  let y = 0;
  const seen = new Set<string>();
  for (let n = p.nodes.find((v) => v.id === id); n && !seen.has(n.id); n = parentOf(p, n)) {
    seen.add(n.id);
    x += n.position.x;
    y += n.position.y;
  }
  return { x, y };
}

/** Ids des descendants (contenu des cadres, récursivement). */
export function descendants(p: Project, id: string): Set<string> {
  const out = new Set<string>();
  const queue = [id];
  while (queue.length) {
    const cur = queue.shift()!;
    for (const n of p.nodes) {
      if (n.parent === cur && !out.has(n.id)) {
        out.add(n.id);
        queue.push(n.id);
      }
    }
  }
  return out;
}

/** Profondeur d'imbrication (0 = à la racine). */
export function depthOf(p: Project, n: TfNode): number {
  let d = 0;
  const seen = new Set([n.id]);
  for (let cur = parentOf(p, n); cur && !seen.has(cur.id); cur = parentOf(p, cur)) {
    seen.add(cur.id);
    d++;
  }
  return d;
}

/** Un objet est masqué si l'un de ses cadres ancêtres est replié. */
export function isHidden(p: Project, n: TfNode): boolean {
  const seen = new Set([n.id]);
  for (let cur = parentOf(p, n); cur && !seen.has(cur.id); cur = parentOf(p, cur)) {
    if (cur.collapsed) return true;
    seen.add(cur.id);
  }
  return false;
}

/**
 * Ordre d'affichage exigé par React Flow : un parent avant ses enfants ; à profondeur égale,
 * les cadres avant les cartes pour qu'une carte glissée au-dessus d'un cadre reste visible.
 */
export function renderOrder(p: Project, types: Set<string>): TfNode[] {
  return [...p.nodes].sort((a, b) => depthOf(p, a) - depthOf(p, b) || Number(isFrame(b, types)) - Number(isFrame(a, types)));
}

/**
 * Cadre le plus profond (le plus petit) contenant le point absolu donné.
 * exclude : l'objet déplacé et ses descendants (on ne range pas un cadre dans lui-même).
 */
export function frameAt(p: Project, point: Point, types: Set<string>, exclude: Set<string> = new Set()): TfNode | undefined {
  let best: TfNode | undefined;
  let bestArea = Infinity;
  for (const n of p.nodes) {
    if (!isFrame(n, types) || n.collapsed || exclude.has(n.id) || isHidden(p, n)) continue;
    const a = absolutePosition(p, n.id);
    const s = frameSize(n);
    const inside = point.x >= a.x && point.x <= a.x + s.w && point.y >= a.y && point.y <= a.y + s.h;
    if (inside && s.w * s.h < bestArea) {
      best = n;
      bestArea = s.w * s.h;
    }
  }
  return best;
}

/** Position relative au nouveau cadre (ou absolue à la racine) d'un point absolu. */
export function relativeTo(p: Project, parentId: string | undefined, abs: Point): Point {
  if (!parentId) return { x: Math.round(abs.x), y: Math.round(abs.y) };
  const o = absolutePosition(p, parentId);
  return { x: Math.round(abs.x - o.x), y: Math.round(abs.y - o.y) };
}

/**
 * Suppression d'un cadre : son contenu remonte d'un niveau, à la même place à l'écran.
 * Modifie les nœuds fournis (brouillon immer) et renvoie les ids déplacés.
 */
export function releaseChildren(nodes: TfNode[], frameId: string): string[] {
  const frame = nodes.find((n) => n.id === frameId);
  if (!frame) return [];
  const moved: string[] = [];
  for (const n of nodes) {
    if (n.parent !== frameId) continue;
    n.position = { x: n.position.x + frame.position.x, y: n.position.y + frame.position.y };
    n.parent = frame.parent;
    if (!n.parent) delete n.parent;
    moved.push(n.id);
  }
  return moved;
}

/** a est-il un cadre ancêtre de b ? (lien de contenance, déjà montré par l'imbrication) */
export function isAncestor(p: Project, a: string, b: string): boolean {
  const n = p.nodes.find((x) => x.id === b);
  const seen = new Set<string>();
  for (let cur = n && parentOf(p, n); cur && !seen.has(cur.id); cur = parentOf(p, cur)) {
    if (cur.id === a) return true;
    seen.add(cur.id);
  }
  return false;
}
