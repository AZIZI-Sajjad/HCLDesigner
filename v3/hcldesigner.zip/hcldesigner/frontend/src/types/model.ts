// Modèle interne d'un projet — miroir de backend/internal/model/model.go (garder aligné).

export type NodeKind = "resource" | "data" | "module" | "variable" | "local" | "output";
export type ValueMode = "literal" | "ref" | "expr" | "list" | "null";
export type LayoutMode = "single" | "standard" | "category" | "service" | "custom";
export type IndexMode = "" | "index" | "splat" | "values" | "each" | "key";

export interface Ref {
  node: string;
  attr: string;
  indexMode?: IndexMode;
  index?: string;
}

export interface Value {
  mode: ValueMode;
  value?: unknown; // littéral JSON
  ref?: Ref;
  expr?: string;
  items?: Value[];
}

export interface Block {
  attrs: Record<string, Value>;
  blocks?: Record<string, Block[]>;
  key?: string;
}

export interface Lifecycle {
  createBeforeDestroy: boolean;
  preventDestroy: boolean;
  ignoreChanges: string[];
  ignoreAll: boolean;
  replaceTriggeredBy: string[];
}

export interface Condition {
  kind: "precondition" | "postcondition";
  condition: string;
  errorMessage: string;
}

export interface Meta {
  count?: Value;
  forEach?: Value;
  dependsOn?: string[];
  lifecycle?: Lifecycle;
  conditions?: Condition[];
}

export interface ModuleVar {
  name: string;
  type: string;
  default?: string;
  required: boolean;
  description?: string;
  sensitive: boolean;
}

export interface ModuleOutput {
  name: string;
  description?: string;
}

export interface ModuleRef {
  sourceKind: "internal" | "registry" | "git" | "local";
  moduleId?: string;
  name?: string;
  source?: string;
  version?: string;
  inputs?: ModuleVar[];
  outputs?: ModuleOutput[];
}

export interface TfNode {
  id: string;
  kind: NodeKind;
  type: string;
  label: string;
  provider?: string;
  attrs: Record<string, Value>;
  blocks?: Record<string, Block[]>;
  meta: Meta;
  file?: string;
  position: { x: number; y: number };
  importId?: string;
  movedFrom?: string;
  module?: ModuleRef;
  group?: string;
  /** Imbrication visuelle : id du cadre conteneur ; position relative à ce cadre. */
  parent?: string;
  /** Taille d'un cadre conteneur (VPC, subnet…). */
  size?: { w: number; h: number };
  collapsed?: boolean;
}

export interface ProviderConfig {
  localName: string;
  source: string;
  version: string;
  resolved: string;
  alias: string;
  config: Record<string, Value>;
}

export interface LayoutRule {
  pattern: string;
  file: string;
}

export interface FileLayout {
  mode: LayoutMode;
  rules: LayoutRule[];
  customFiles: string[];
}

export interface Project {
  schemaVersion: number;
  engine: "terraform" | "opentofu";
  engineVersion: string;
  requiredVersion: string;
  providers: ProviderConfig[];
  nodes: TfNode[];
  fileLayout: FileLayout;
  settings: { includeDefaults: boolean };
}

export interface Diagnostic {
  severity: "error" | "warning" | string;
  nodeId?: string;
  path?: string;
  summary: string;
  detail?: string;
  file?: string;
  line?: number;
}

export interface Edge {
  id: string;
  source: string;
  sourceAttr: string;
  target: string;
  targetPath: string;
  kind: "ref" | "expr" | "depends_on"; // expr : adresse citée dans une expression brute (lecture seule)
}

export function emptyProject(): Project {
  return {
    schemaVersion: 1,
    engine: "terraform",
    engineVersion: "",
    requiredVersion: ">= 1.5.0",
    providers: [],
    nodes: [],
    fileLayout: { mode: "standard", rules: [], customFiles: [] },
    settings: { includeDefaults: false },
  };
}
