// Types des réponses de l'API (miroir des DTO Go).
import type { Diagnostic, ModuleOutput, ModuleVar, Project } from "./model";

export interface Binding {
  id: string;
  roleId: string;
  roleName: string;
  perms: string[];
  scope: "global" | "project" | "environment";
  projectId?: string;
  environment?: string;
  viaTeam?: string;
}

export interface Me {
  id: string;
  username: string;
  email: string;
  displayName: string;
  isSuper: boolean;
  bindings: Binding[] | null;
  mfaOk: boolean;
  totpEnabled: boolean;
  mfaSetupRequired: boolean;
  branding: { name: string; logoUrl: string; language: string };
}

export interface ProjectRow {
  id: string;
  name: string;
  description: string;
  teamId: string | null;
  model: Project;
  version: number;
  lockFile: string;
  createdAt: string;
  updatedAt: string;
}

export interface ProjectListItem {
  id: string;
  name: string;
  description: string;
  nodes: number;
  providers: string[];
  environments: number;
  lastRunStatus: string;
  lastRunAt: string | null;
  version: number;
  updatedAt: string;
}

export interface ProjectDetail {
  project: ProjectRow;
  diagnostics: Diagnostic[];
  permissions: Record<string, boolean>;
}

// ---- Schémas de providers ----
export interface SchemaAttribute {
  type?: unknown;
  nested_type?: { attributes: Record<string, SchemaAttribute>; nesting_mode: string; min_items?: number; max_items?: number };
  description?: string;
  required?: boolean;
  optional?: boolean;
  computed?: boolean;
  sensitive?: boolean;
  deprecated?: boolean;
}

export interface SchemaBlock {
  attributes?: Record<string, SchemaAttribute>;
  block_types?: Record<string, { nesting_mode: string; block: SchemaBlock; min_items?: number; max_items?: number }>;
  description?: string;
  deprecated?: boolean;
}

export interface CatalogEntry {
  source: string;
  version: string;
  kind: "resource" | "data" | "ephemeral";
  type: string;
  category: string;
  description: string;
  deprecated: boolean;
}

export interface ProviderSchemaRow {
  source: string;
  version: string;
  address: string;
  fetchedAt: string;
  resources: number;
  dataSources: number;
}

// ---- Connexions ----
export interface Suggestion {
  sourceAttr: string;
  targetPath: string;
  targetType: string;
  cardinality: "single" | "list";
  score: number;
  origin: "rule" | "inference";
  reason: string;
  indexMode?: string;
}

export interface TargetArg {
  path: string;
  type: string;
  required: boolean;
  computed: boolean;
  sensitive: boolean;
  deprecated: boolean;
  description?: string;
  default?: unknown;
  defaultFrom?: string;
  inBlock?: string;
}

export interface AttrInfo {
  name: string;
  type: string;
  required: boolean;
  optional: boolean;
  computed: boolean;
  sensitive: boolean;
  description?: string;
}

export interface SuggestResult {
  suggestions: Suggestion[];
  sourceAttrs: AttrInfo[];
  targetArgs: TargetArg[];
  allowed: boolean;
  message?: string;
}

// ---- Environnements / runs ----
export interface ChangeWindow {
  enabled: boolean;
  days: number[];
  start: string;
  end: string;
  timezone: string;
}

export interface Environment {
  id: string;
  projectId: string;
  name: string;
  backendType: string;
  backendConfig: Record<string, unknown>;
  backendSecretId: string | null;
  tfvars?: string;
  tfvarsVisible: boolean;
  hasBackendSecrets: boolean;
  workspace: string;
  credentialIds: string[];
  protected: boolean;
  requireApprovals: number;
  allowDestroy: boolean;
  changeWindow: ChangeWindow;
  /** Labels exigés : seuls les workers qui les portent tous exécutent les runs. */
  workerLabels: string[];
}

export interface FieldDef {
  name: string;
  label: string;
  type: "string" | "bool" | "number" | "text" | "select";
  required?: boolean;
  secret?: boolean;
  default?: unknown;
  options?: string[];
  help?: string;
}

export interface BackendType {
  type: string;
  label: string;
  fields: FieldDef[] | null;
  tfType: string;
  description: string;
}

export interface CredentialKind {
  kind: string;
  label: string;
  fields: FieldDef[];
}

export interface PlanSummary {
  add: number;
  change: number;
  destroy: number;
  replace: number;
  import: number;
  changes: { address: string; type: string; actions: string[]; nodeId?: string }[];
  drift: { address: string; actions: string[] }[];
  outputs: string[];
  byNode: Record<string, string>;
}

export interface Run {
  id: string;
  /** Worker qui a exécuté le run. */
  worker?: string;
  projectId: string;
  projectName: string;
  environmentId: string;
  environmentName: string;
  operation: "init" | "validate" | "plan" | "apply" | "state";
  destroy: boolean;
  status: string;
  options: Record<string, unknown>;
  snapshotHash: string;
  projectVersion: number;
  planRunId: string | null;
  summary: Partial<PlanSummary>;
  diagnostics: Diagnostic[];
  policyReport: { violations?: Violation[]; blocking?: boolean } | null;
  approvalsRequired: number;
  planExpiresAt: string | null;
  exitCode: number | null;
  error: string;
  triggeredBy: string;
  createdByName: string;
  createdAt: string;
  startedAt: string | null;
  finishedAt: string | null;
}

export interface Violation {
  policyId: string;
  policy: string;
  severity: "info" | "warning" | "blocking";
  nodeId?: string;
  address: string;
  path?: string;
  message: string;
}

export interface ModuleRow {
  id: string;
  name: string;
  description: string;
  scope: string;
  projectId: string | null;
  teamId: string | null;
  tags: string[];
  versions: string[];
  latest: string;
  inputs: ModuleVar[];
  outputs: ModuleOutput[];
  updatedAt: string;
  draft?: Project;
}

export interface GenerateResult {
  files: Record<string, string>;
  ranges: { nodeId: string; file: string; start: number; end: number }[];
  diagnostics: Diagnostic[];
}

/** Worker d'exécution (agent) — Administration > Workers. */
export interface Worker {
  id: string;
  name: string;
  state: "active" | "paused" | "revoked";
  slots: number;
  labels: string[];
  isDefault: boolean;
  version: string;
  hostname: string;
  osArch: string;
  remoteAddr: string;
  running: number;
  lastSeenAt: string | null;
  online: boolean;
  createdAt: string;
}

/** Connexion Git personnelle (le jeton n'est jamais renvoyé). */
export interface GitConnection {
  id: string;
  name: string;
  provider: "github" | "gitlab" | "gitea";
  baseUrl: string;
  username: string;
  authorName: string;
  authorEmail: string;
  caCert: string;
  insecureTls: boolean;
  hasToken: boolean;
  createdAt: string;
}

export interface GitRepo {
  fullName: string;
  defaultBranch: string;
  private: boolean;
  webUrl: string;
  description: string;
}

/** Dépôt lié à un projet ; path = sous-dossier du code Terraform ("" = racine). */
export interface ProjectGit {
  provider: GitConnection["provider"];
  baseUrl: string;
  repo: string;
  branch: string;
  path: string;
  webUrl?: string;
  lastCommit?: string;
  lastSyncAt?: string | null;
  lastSyncBy?: string;
  lastSyncKind?: string;
}
