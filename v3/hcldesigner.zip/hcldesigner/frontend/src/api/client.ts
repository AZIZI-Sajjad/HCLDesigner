// Client HTTP : ajoute l'en-tête anti-CSRF, décode les erreurs JSON de l'API.

export class ApiError extends Error {
  constructor(public status: number, message: string) {
    super(message);
  }
}

type Listener = (status: number, message: string) => void;
const authListeners = new Set<Listener>();

/** Permet à l'application de réagir aux 401 (session expirée, MFA requise). */
export function onAuthError(fn: Listener): () => void {
  authListeners.add(fn);
  return () => authListeners.delete(fn);
}

async function request<T>(method: string, path: string, body?: unknown): Promise<T> {
  // FormData (envoi de fichiers) : le navigateur pose lui-même le Content-Type multipart et sa frontière.
  const isForm = body instanceof FormData;
  const res = await fetch("/api" + path, {
    method,
    credentials: "same-origin",
    headers: {
      "X-Requested-With": "hcldesigner",
      ...(body !== undefined && !isForm ? { "Content-Type": "application/json" } : {}),
    },
    body: body === undefined ? undefined : isForm ? body : JSON.stringify(body),
  });
  if (res.status === 204) return undefined as T;
  const text = await res.text();
  let data: unknown = undefined;
  try {
    data = text ? JSON.parse(text) : undefined;
  } catch {
    data = text;
  }
  if (!res.ok) {
    const msg = (data as { error?: string })?.error ?? res.statusText;
    if (res.status === 401) authListeners.forEach((l) => l(401, msg));
    throw new ApiError(res.status, msg);
  }
  return data as T;
}

export const api = {
  get: <T>(path: string) => request<T>("GET", path),
  post: <T>(path: string, body?: unknown) => request<T>("POST", path, body ?? {}),
  put: <T>(path: string, body?: unknown) => request<T>("PUT", path, body ?? {}),
  patch: <T>(path: string, body?: unknown) => request<T>("PATCH", path, body),
  del: <T = void>(path: string) => request<T>("DELETE", path),
  /** Envoi multipart : chaque fichier est ajouté sous le champ `field`. */
  upload: <T>(path: string, files: File[], field = "files") => {
    const form = new FormData();
    for (const f of files) form.append(field, f, f.name);
    return request<T>("POST", path, form);
  },
};

/** Construit une query string en ignorant les valeurs vides. */
export function qs(params: Record<string, string | number | undefined | null>): string {
  const p = new URLSearchParams();
  for (const [k, v] of Object.entries(params)) if (v !== undefined && v !== null && v !== "") p.set(k, String(v));
  const s = p.toString();
  return s ? "?" + s : "";
}

/** Téléchargement d'un fichier servi par l'API (cookie de session). */
export function download(path: string) {
  const a = document.createElement("a");
  a.href = "/api" + path;
  a.rel = "noopener";
  document.body.appendChild(a);
  a.click();
  a.remove();
}
