// Liste des projets : création, import (modèle JSON exporté ou code Terraform .tf / .zip), tableau personnalisable.
import { useMemo, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import type { ColumnDef } from "@tanstack/react-table";
import { FileCode, GitBranch, Plus, Upload } from "lucide-react";
import { api } from "@/api/client";
import type { ProjectListItem, ProjectRow } from "@/types/api";
import type { Diagnostic, Project } from "@/types/model";
import type { ProjectGit } from "@/types/api";
import { GitSourcePicker, emptySource, type GitSource } from "@/components/git/GitSourcePicker";
import { useCan } from "@/lib/auth";
import { DataTable } from "@/components/table/DataTable";
import { Badge, Button, ErrorBox, Field, Input, Modal, PageHeader, RunStatus, formatDate, runStatusMeta, toast } from "@/components/ui";

/** Réponse de POST /projects/import-hcl et /projects/import-git (git : dépôt à lier au projet créé). */
interface HclImport {
  model: Project;
  diagnostics: Diagnostic[];
  files: string[];
  git?: ProjectGit;
}

export default function Projects() {
  const navigate = useNavigate();
  const can = useCan();
  const list = useQuery({ queryKey: ["projects"], queryFn: () => api.get<ProjectListItem[]>("/projects") });
  const [creating, setCreating] = useState<Project | null | undefined>(undefined);
  const [hcl, setHcl] = useState<HclImport | null>(null);
  const [importing, setImporting] = useState(false);
  const fileInput = useRef<HTMLInputElement>(null);
  const tfInput = useRef<HTMLInputElement>(null);
  const [gitOpen, setGitOpen] = useState(false);

  const columns = useMemo<ColumnDef<ProjectListItem, unknown>[]>(
    () => [
      { id: "name", header: "Nom", accessorKey: "name", size: 220 },
      { id: "description", header: "Description", accessorKey: "description", size: 280 },
      { id: "providers", header: "Providers", accessorFn: (p) => p.providers.join(", "), size: 220, meta: { text: (p) => p.providers.join(", ") } },
      { id: "nodes", header: "Objets", accessorKey: "nodes", size: 80 },
      { id: "environments", header: "Environnements", accessorKey: "environments", size: 120 },
      {
        id: "lastRun",
        header: "Dernière exécution",
        accessorKey: "lastRunStatus",
        size: 160,
        cell: (c) => (c.getValue() ? <RunStatus status={c.getValue() as string} /> : null),
        meta: { filter: "multi", text: (p) => runStatusMeta[p.lastRunStatus]?.label ?? p.lastRunStatus },
      },
      { id: "lastRunAt", header: "Le", accessorKey: "lastRunAt", size: 150, cell: (c) => formatDate(c.getValue() as string), meta: { text: (p) => formatDate(p.lastRunAt) } },
      { id: "version", header: "Version", accessorKey: "version", size: 80 },
      { id: "updatedAt", header: "Modifié", accessorKey: "updatedAt", size: 150, cell: (c) => formatDate(c.getValue() as string), meta: { text: (p) => formatDate(p.updatedAt) } },
    ],
    [],
  );

  const importFile = async (f: File) => {
    try {
      setCreating(JSON.parse(await f.text()) as Project);
    } catch {
      setCreating(undefined);
      toast.error("Fichier JSON invalide");
    }
  };

  /** Conversion côté serveur du code Terraform ; le projet n'est créé qu'à la validation du dialogue. */
  const importTerraform = async (files: File[]) => {
    setImporting(true);
    try {
      const res = await api.upload<HclImport>("/projects/import-hcl", files);
      setHcl(res);
      setCreating(res.model);
    } catch (e) {
      toast.error(e);
    } finally {
      setImporting(false);
      if (tfInput.current) tfInput.current.value = ""; // permet de renvoyer les mêmes fichiers
    }
  };

  return (
    <div className="p-6">
      <PageHeader
        title="Projets"
        actions={
          can("projects.create") && (
            <>
              <input ref={fileInput} type="file" accept="application/json" hidden onChange={(e) => e.target.files?.[0] && void importFile(e.target.files[0])} />
              <Button icon={<Upload className="h-4 w-4" />} onClick={() => fileInput.current?.click()}>
                Importer (JSON)
              </Button>
              <input
                ref={tfInput}
                type="file"
                accept=".tf,.zip"
                multiple
                hidden
                onChange={(e) => e.target.files?.length && void importTerraform([...e.target.files])}
              />
              <Button icon={<FileCode className="h-4 w-4" />} loading={importing} onClick={() => tfInput.current?.click()} title="Fichiers .tf ou archive .zip du dossier Terraform">
                Importer (Terraform)
              </Button>
              <Button icon={<GitBranch className="h-4 w-4" />} onClick={() => setGitOpen(true)} title="Code Terraform d'un dépôt GitHub, GitLab ou Gitea (sous-dossier possible)">
                Importer (Git)
              </Button>
              <Button variant="primary" icon={<Plus className="h-4 w-4" />} onClick={() => setCreating(null)}>
                Nouveau projet
              </Button>
            </>
          )
        }
      />
      <div className="h-[calc(100vh-140px)]">
        <DataTable id="projects" title="Projets" data={list.data ?? []} columns={columns} loading={list.isFetching} onRefresh={() => void list.refetch()} onRowClick={(p) => navigate(`/projects/${p.id}`)} getRowId={(p) => p.id} />
      </div>
      {gitOpen && (
        <GitImportDialog
          onClose={() => setGitOpen(false)}
          onImported={(res) => {
            setGitOpen(false);
            setHcl(res);
            setCreating(res.model);
          }}
        />
      )}
      {creating !== undefined && (
        <CreateDialog
          imported={creating}
          hcl={hcl}
          onClose={() => {
            setCreating(undefined);
            setHcl(null);
          }}
          onCreated={(id) => navigate(`/projects/${id}`)}
        />
      )}
    </div>
  );
}

function CreateDialog({ imported, hcl, onClose, onCreated }: { imported: Project | null; hcl: HclImport | null; onClose: () => void; onCreated: (id: string) => void }) {
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [error, setError] = useState<unknown>(null);
  const [loading, setLoading] = useState(false);
  const create = async () => {
    setLoading(true);
    try {
      const p = await api.post<ProjectRow>("/projects", { name, description, model: imported ?? undefined });
      // Import depuis Git : le projet est lié au dépôt (même branche, même sous-dossier).
      if (hcl?.git) await api.put(`/projects/${p.id}/git`, hcl.git).catch((e) => toast.error(e));
      onCreated(p.id);
    } catch (e) {
      setError(e);
    } finally {
      setLoading(false);
    }
  };
  return (
    <Modal
      open
      onClose={onClose}
      wide={!!hcl}
      title={hcl?.git ? `Importer ${hcl.git.repo}` : hcl ? "Importer du code Terraform" : imported ? "Importer un projet" : "Nouveau projet"}
      footer={
        <>
          <Button onClick={onClose}>Annuler</Button>
          <Button variant="primary" loading={loading} disabled={!name.trim()} onClick={create}>
            Créer
          </Button>
        </>
      }
    >
      <div className="space-y-3">
        <ErrorBox error={error} />
        {imported && <p className="text-sm text-slate-500">Modèle importé : {imported.nodes?.length ?? 0} objet(s), {imported.providers?.length ?? 0} provider(s).</p>}
        {hcl && <ImportReport report={hcl} />}
        <Field label="Nom" required>
          <Input autoFocus value={name} onChange={(e) => setName(e.target.value)} />
        </Field>
        <Field label="Description">
          <Input value={description} onChange={(e) => setDescription(e.target.value)} />
        </Field>
        <p className="text-xs text-slate-500">Un environnement « dev » avec backend interne est créé automatiquement.</p>
      </div>
    </Modal>
  );
}

const severityTone = { error: "red", warning: "yellow", info: "blue" } as const;

/** Fichiers convertis et points d'attention de l'import Terraform. */
function ImportReport({ report }: { report: HclImport }) {
  const diagnostics = report.diagnostics ?? [];
  const errors = diagnostics.filter((d) => d.severity === "error").length;
  return (
    <div className="space-y-2 text-sm">
      <p className="text-slate-500">
        Fichiers convertis : <span className="font-mono">{(report.files ?? []).join(", ")}</span>. Le découpage d'origine est conservé (mode « fichier par nœud »).
      </p>
      {diagnostics.length > 0 && (
        <div className="max-h-56 overflow-auto rounded-md border border-slate-200 dark:border-slate-700">
          {diagnostics.map((d, i) => (
            <div key={i} className="flex gap-2 border-b border-slate-100 px-2 py-1.5 last:border-0 dark:border-slate-800" title={d.detail}>
              <Badge tone={severityTone[d.severity as keyof typeof severityTone] ?? "gray"}>{d.severity}</Badge>
              <span className="flex-1">
                {d.summary}
                {d.detail && <span className="block text-xs text-slate-500">{d.detail}</span>}
              </span>
              {d.file && (
                <span className="shrink-0 font-mono text-xs text-slate-500">
                  {d.file}
                  {d.line ? `:${d.line}` : ""}
                </span>
              )}
            </div>
          ))}
        </div>
      )}
      {errors > 0 && <p className="text-xs text-red-600">{errors} bloc(s) en erreur n'ont pas été importés : corriger le code source puis réimporter, ou les recréer sur le canvas.</p>}
    </div>
  );
}

/** Étape 1 de l'import Git : choix de la source, puis conversion côté serveur. */
function GitImportDialog({ onClose, onImported }: { onClose: () => void; onImported: (r: HclImport) => void }) {
  const [src, setSrc] = useState<GitSource>(emptySource);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<unknown>(null);
  const run = async () => {
    setLoading(true);
    setError(null);
    try {
      onImported(await api.post<HclImport>("/projects/import-git", src));
    } catch (e) {
      setError(e);
    } finally {
      setLoading(false);
    }
  };
  return (
    <Modal
      open
      wide
      onClose={onClose}
      title="Importer depuis Git"
      footer={
        <>
          <Button onClick={onClose}>Annuler</Button>
          <Button variant="primary" loading={loading} disabled={!src.repo || !src.branch} onClick={run}>
            Analyser le code
          </Button>
        </>
      }
    >
      <div className="space-y-3">
        <ErrorBox error={error} />
        <GitSourcePicker value={src} onChange={setSrc} />
        <p className="text-xs text-slate-500">Le projet créé reste lié au dépôt : vous pourrez y pousser le code généré (commit direct ou pull/merge request).</p>
      </div>
    </Modal>
  );
}
