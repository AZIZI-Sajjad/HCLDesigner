// Paramètres du projet : identité, moteur Terraform/OpenTofu, providers (résolution des schémas,
// alias, configuration), découpage des fichiers générés, valeurs par défaut, suppression.
import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Plus, RefreshCw, Trash2 } from "lucide-react";
import type { Draft } from "immer";
import { api, download } from "@/api/client";
import type { ProjectRow } from "@/types/api";
import type { LayoutMode, ProviderConfig, Value } from "@/types/model";
import { schemaKey, useEditor } from "@/store/editor";
import { loadSchema } from "@/lib/useSchema";
import { Badge, Button, Card, ConfirmDialog, Field, IconButton, Input, Select, Toggle, toast } from "@/components/ui";
import { SchemaForm } from "../editor/SchemaForm";
import { GitCard } from "./GitCard";

export default function ProjectSettings({ project, canEdit, canDelete }: { project: ProjectRow; canEdit: boolean; canDelete: boolean }) {
  const model = useEditor((s) => s.model)!;
  const update = useEditor((s) => s.update);
  const qc = useQueryClient();
  const navigate = useNavigate();
  const [name, setName] = useState(project.name);
  const [description, setDescription] = useState(project.description);
  const [confirmDelete, setConfirmDelete] = useState(false);
  const engines = useQuery({ queryKey: ["engines"], queryFn: () => api.get<{ versions: { engine: string; version: string }[]; preinstalled: Record<string, string> }>("/engines") });

  const saveMeta = async () => {
    try {
      await api.put(`/projects/${project.id}`, { name, description, teamId: project.teamId });
      void qc.invalidateQueries({ queryKey: ["project", project.id] });
      toast.success("Projet mis à jour");
    } catch (e) {
      toast.error(e);
    }
  };

  const versions = (engines.data?.versions ?? []).filter((v) => v.engine === model.engine);
  const pre = engines.data?.preinstalled?.[model.engine];

  return (
    <div className="mx-auto max-w-5xl space-y-4">
      <p className="text-xs text-slate-500">Les réglages du modèle (moteur, providers, fichiers) sont enregistrés avec le bouton « Enregistrer » du projet.</p>
      <Card title="Projet" actions={canEdit && <Button size="sm" onClick={saveMeta}>Enregistrer</Button>}>
        <div className="grid gap-3 md:grid-cols-2">
          <Field label="Nom">
            <Input value={name} disabled={!canEdit} onChange={(e) => setName(e.target.value)} />
          </Field>
          <Field label="Description">
            <Input value={description} disabled={!canEdit} onChange={(e) => setDescription(e.target.value)} />
          </Field>
        </div>
      </Card>

      <Card title="Moteur">
        <div className="grid gap-3 md:grid-cols-3">
          <Field label="Moteur">
            <Select value={model.engine} disabled={!canEdit} onChange={(e) => update((d) => void (d.engine = e.target.value as "terraform" | "opentofu"))}>
              <option value="terraform">Terraform</option>
              <option value="opentofu">OpenTofu</option>
            </Select>
          </Field>
          <Field label="Version exacte du binaire" help={pre ? `Préinstallé : ${pre}` : "Téléchargée et mise en cache par le worker."}>
            <Select value={model.engineVersion} disabled={!canEdit} onChange={(e) => update((d) => void (d.engineVersion = e.target.value))}>
              <option value="">binaire préinstallé{pre ? ` (${pre})` : ""}</option>
              {versions.map((v) => (
                <option key={v.version}>{v.version}</option>
              ))}
            </Select>
          </Field>
          <Field label="required_version">
            <Input value={model.requiredVersion} disabled={!canEdit} onChange={(e) => update((d) => void (d.requiredVersion = e.target.value))} />
          </Field>
        </div>
        <div className="mt-3">
          <Toggle
            checked={model.settings.includeDefaults}
            disabled={!canEdit}
            onChange={(v) => update((d) => void (d.settings.includeDefaults = v))}
            label="Écrire explicitement les valeurs par défaut connues dans le code généré"
          />
        </div>
      </Card>

      <ProvidersCard canEdit={canEdit} />
      <FileLayoutCard canEdit={canEdit} />

      <GitCard projectId={project.id} projectName={project.name} />

      <Card title="Import / export">
        <div className="flex flex-wrap gap-2">
          <Button onClick={() => download(`/projects/${project.id}/export?format=json`)}>Exporter le modèle (JSON)</Button>
          <Button onClick={() => download(`/projects/${project.id}/export?format=mermaid`)}>Diagramme Mermaid</Button>
          <Button onClick={() => download(`/projects/${project.id}/export`)}>Arborescence complète (ZIP)</Button>
        </div>
      </Card>

      {canDelete && (
        <Card title="Zone sensible">
          <Button variant="danger" onClick={() => setConfirmDelete(true)}>
            Supprimer le projet
          </Button>
        </Card>
      )}
      <ConfirmDialog
        open={confirmDelete}
        danger
        onClose={() => setConfirmDelete(false)}
        title="Supprimer le projet"
        message="Le modèle, l'historique des versions, les environnements et les exécutions seront supprimés. L'infrastructure déployée n'est pas détruite."
        typeToConfirm={project.name}
        confirmText="Supprimer"
        onConfirm={async () => {
          try {
            await api.del(`/projects/${project.id}`);
            navigate("/projects");
          } catch (e) {
            toast.error(e);
          }
        }}
      />
    </div>
  );
}

const providerKey = (p: ProviderConfig) => (p.alias ? `${p.localName}.${p.alias}` : p.localName);

export function ProvidersCard({ canEdit }: { canEdit: boolean }) {
  const model = useEditor((s) => s.model)!;
  const update = useEditor((s) => s.update);
  const schemas = useEditor((s) => s.schemas);
  const [source, setSource] = useState("");
  const [version, setVersion] = useState("");
  const [alias, setAlias] = useState("");
  const [busy, setBusy] = useState<string | null>(null);
  const [open, setOpen] = useState<string | null>(null);
  const versions = useQuery({
    queryKey: ["provider-versions", source],
    queryFn: () => api.get<string[]>(`/registry/providers/${source}/versions`),
    enabled: /^[\w-]+\/[\w-]+$/.test(source),
    retry: false,
  });

  /** Résout le provider côté worker (init + providers schema) puis enregistre la version exacte. */
  const resolve = async (src: string, constraint: string, localName: string) => {
    setBusy(src);
    try {
      const { jobId } = await api.post<{ jobId: string }>("/providers/resolve", { source: src, version: constraint, localName, engine: model.engine, engineVersion: model.engineVersion });
      for (;;) {
        await new Promise((r) => setTimeout(r, 2000));
        const j = await api.get<{ status: string; version: string; error: string }>(`/providers/jobs/${jobId}`);
        if (j.status === "succeeded") return j.version;
        if (j.status === "failed") throw new Error(j.error);
      }
    } finally {
      setBusy(null);
    }
  };

  const add = async () => {
    const localName = source.split("/")[1];
    if (model.providers.some((p) => providerKey(p) === (alias ? `${localName}.${alias}` : localName))) return toast.error("Ce provider (ou alias) existe déjà.");
    try {
      const existing = model.providers.find((p) => p.source === source);
      const resolved = existing && !version ? existing.resolved : await resolve(source, version, localName);
      update((d) => {
        d.providers.push({ localName, source, version: version || existing?.version || "", resolved: resolved ?? "", alias, config: {} });
      });
      setSource("");
      setVersion("");
      setAlias("");
      toast.success(`${source} ${resolved} ajouté`);
    } catch (e) {
      toast.error(e);
    }
  };

  const refresh = async (p: ProviderConfig) => {
    try {
      const v = await resolve(p.source, p.version, p.localName);
      update((d) => {
        for (const x of d.providers) if (x.source === p.source) x.resolved = v ?? x.resolved;
      });
      toast.success(`${p.source} résolu en ${v}`);
    } catch (e) {
      toast.error(e);
    }
  };

  useEffect(() => {
    const p = model.providers.find((x) => providerKey(x) === open);
    if (p) void loadSchema(p.source, p.resolved, "provider", p.localName);
  }, [open, model.providers]);

  return (
    <Card title="Providers">
      <div className="space-y-2">
        {model.providers.map((p, i) => {
          const key = providerKey(p);
          const sch = schemas[schemaKey(p.source, p.resolved, "provider", p.localName)];
          return (
            <div key={key} className="rounded-md border border-slate-200 dark:border-slate-700">
              <div className="flex flex-wrap items-center gap-2 px-3 py-2">
                <span className="font-mono text-sm font-medium">{key}</span>
                <Badge>{p.source}</Badge>
                <Input className="w-32" value={p.version} disabled={!canEdit} placeholder="contrainte" onChange={(e) => update((d) => void (d.providers[i].version = e.target.value))} />
                <Badge tone={p.resolved ? "green" : "red"}>{p.resolved ? `résolu ${p.resolved}` : "non résolu"}</Badge>
                <span className="flex-1" />
                <Button size="sm" variant="ghost" onClick={() => setOpen(open === key ? null : key)}>
                  Configuration
                </Button>
                {canEdit && (
                  <>
                    <IconButton title="Re-résoudre (nouvelle contrainte)" onClick={() => void refresh(p)} disabled={busy === p.source}>
                      <RefreshCw className={busy === p.source ? "h-4 w-4 animate-spin" : "h-4 w-4"} />
                    </IconButton>
                    <IconButton
                      title="Retirer"
                      onClick={() => {
                        if (model.nodes.some((n) => n.type.startsWith(p.localName + "_") && (!p.alias || n.provider === key))) return toast.error("Des objets utilisent ce provider.");
                        update((d) => void d.providers.splice(i, 1));
                      }}
                    >
                      <Trash2 className="h-4 w-4" />
                    </IconButton>
                  </>
                )}
              </div>
              {open === key && (
                <div className="border-t border-slate-100 p-3 dark:border-slate-800">
                  {sch?.block ? (
                    <SchemaForm
                      block={sch.block}
                      attrs={p.config}
                      onAttr={(name, v) =>
                        update((d) => {
                          if (v === undefined) delete d.providers[i].config[name];
                          else d.providers[i].config[name] = v as Draft<Value>;
                        })
                      }
                      onBlocks={() => toast.info("Les blocs imbriqués de configuration provider se saisissent en expression.")}
                      model={model}
                      disabled={!canEdit}
                    />
                  ) : (
                    <p className="text-xs text-slate-500">{sch?.error ?? "Chargement du schéma…"}</p>
                  )}
                  <p className="mt-2 text-xs text-slate-500">Les secrets (clés d'accès, mots de passe) ne se saisissent pas ici : associez un credential à l'environnement.</p>
                </div>
              )}
            </div>
          );
        })}
      </div>
      {canEdit && (
        <div className="mt-4 flex flex-wrap items-end gap-2 border-t border-slate-200 pt-3 dark:border-slate-800">
          <Field label="Source" help="namespace/nom (Registry public, privé ou mirror)">
            <Input className="w-56" placeholder="hashicorp/aws" value={source} onChange={(e) => setSource(e.target.value.trim())} />
          </Field>
          <Field label="Contrainte de version">
            <Input className="w-36" list="provider-versions" placeholder="~> 5.0" value={version} onChange={(e) => setVersion(e.target.value)} />
            <datalist id="provider-versions">
              {(versions.data ?? []).map((v) => (
                <option key={v} value={`~> ${v}`} />
              ))}
            </datalist>
          </Field>
          <Field label="Alias (optionnel)" help="Plusieurs régions / comptes">
            <Input className="w-32" value={alias} onChange={(e) => setAlias(e.target.value)} />
          </Field>
          <Button variant="primary" icon={<Plus className="h-4 w-4" />} disabled={!source.includes("/")} loading={busy === source} onClick={add}>
            Ajouter
          </Button>
        </div>
      )}
    </Card>
  );
}

const layoutModes: { id: LayoutMode; label: string; help: string }[] = [
  { id: "single", label: "Fichier unique", help: "Tout dans main.tf" },
  { id: "standard", label: "Standard", help: "versions.tf, providers.tf, backend.tf, variables.tf, locals.tf, main.tf, outputs.tf" },
  { id: "category", label: "Par catégorie", help: "network.tf, security.tf, compute.tf, storage.tf…" },
  { id: "service", label: "Par service", help: "ec2.tf, s3.tf, vpc.tf, rds.tf, iam.tf, security.tf…" },
  { id: "custom", label: "Personnalisé", help: "Fichiers libres, affectation par nœud ou par règle" },
];

function FileLayoutCard({ canEdit }: { canEdit: boolean }) {
  const model = useEditor((s) => s.model)!;
  const update = useEditor((s) => s.update);
  const fl = model.fileLayout;
  const [newFile, setNewFile] = useState("");
  return (
    <Card title="Organisation des fichiers générés">
      <div className="grid gap-2 md:grid-cols-5">
        {layoutModes.map((m) => (
          <label key={m.id} className={`cursor-pointer rounded-md border p-2 text-sm ${fl.mode === m.id ? "border-indigo-500 bg-indigo-50 dark:bg-indigo-950/40" : "border-slate-200 dark:border-slate-700"}`}>
            <input type="radio" className="mr-1" disabled={!canEdit} checked={fl.mode === m.id} onChange={() => update((d) => void (d.fileLayout.mode = m.id))} />
            {m.label}
            <p className="mt-1 text-[11px] text-slate-500">{m.help}</p>
          </label>
        ))}
      </div>
      {fl.mode !== "single" && (
        <div className="mt-4 space-y-2">
          <p className="text-xs font-medium">Règles d'affectation automatique (prioritaires sur le mode)</p>
          {fl.rules.map((r, i) => (
            <div key={i} className="flex gap-2">
              <Input className="w-64 font-mono" placeholder="aws_instance*" value={r.pattern} disabled={!canEdit} onChange={(e) => update((d) => void (d.fileLayout.rules[i].pattern = e.target.value))} />
              <span className="self-center">→</span>
              <Input className="w-48 font-mono" placeholder="ec2.tf" value={r.file} disabled={!canEdit} onChange={(e) => update((d) => void (d.fileLayout.rules[i].file = e.target.value))} />
              {canEdit && (
                <IconButton title="Supprimer la règle" onClick={() => update((d) => void d.fileLayout.rules.splice(i, 1))}>
                  <Trash2 className="h-4 w-4" />
                </IconButton>
              )}
            </div>
          ))}
          {canEdit && (
            <Button size="sm" icon={<Plus className="h-3 w-3" />} onClick={() => update((d) => void d.fileLayout.rules.push({ pattern: "", file: "" }))}>
              Ajouter une règle
            </Button>
          )}
        </div>
      )}
      {fl.mode === "custom" && (
        <div className="mt-4 space-y-2">
          <p className="text-xs font-medium">Fichiers personnalisés (affectés depuis le panneau de propriétés de chaque objet)</p>
          <div className="flex flex-wrap gap-1">
            {fl.customFiles.map((f, i) => (
              <Badge key={f}>
                {f}
                {canEdit && (
                  <button onClick={() => update((d) => void d.fileLayout.customFiles.splice(i, 1))} aria-label="Retirer">
                    ×
                  </button>
                )}
              </Badge>
            ))}
          </div>
          {canEdit && (
            <div className="flex gap-2">
              <Input className="w-48 font-mono" placeholder="network.tf" value={newFile} onChange={(e) => setNewFile(e.target.value)} />
              <Button
                size="sm"
                disabled={!newFile.trim()}
                onClick={() => {
                  const f = newFile.trim().endsWith(".tf") ? newFile.trim() : `${newFile.trim()}.tf`;
                  update((d) => void (d.fileLayout.customFiles = [...new Set([...d.fileLayout.customFiles, f])]));
                  setNewFile("");
                }}
              >
                Ajouter
              </Button>
            </div>
          )}
        </div>
      )}
    </Card>
  );
}
