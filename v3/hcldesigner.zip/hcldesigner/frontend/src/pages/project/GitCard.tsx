// Dépôt Git du projet : liaison (dépôt, branche, sous-dossier du code Terraform), push du code
// généré (commit direct ou nouvelle branche + pull/merge request), mise à jour depuis Git.
// Chaque utilisateur pousse avec sa propre connexion Git (Mon compte > Connexions Git).
import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { ExternalLink, GitBranch, GitPullRequest, Upload } from "lucide-react";
import { api } from "@/api/client";
import type { ProjectGit } from "@/types/api";
import type { Diagnostic } from "@/types/model";
import { useEditor } from "@/store/editor";
import { useCan } from "@/lib/auth";
import { Badge, Button, Card, ConfirmDialog, ErrorBox, Field, Input, Modal, Select, Textarea, formatDate, toast } from "@/components/ui";
import { GitSourcePicker, emptySource, type GitSource } from "@/components/git/GitSourcePicker";
import { providerLabels, useGitConnections } from "@/components/git/GitConnectionsCard";

interface GitStatus {
  linked: boolean;
  git?: ProjectGit;
  hasConnection?: boolean;
}

export function GitCard({ projectId, projectName }: { projectId: string; projectName: string }) {
  const can = useCan();
  const qc = useQueryClient();
  const dirty = useEditor((s) => s.dirty);
  const status = useQuery({ queryKey: ["project-git", projectId], queryFn: () => api.get<GitStatus>(`/projects/${projectId}/git`) });
  const [linking, setLinking] = useState(false);
  const [pushing, setPushing] = useState(false);
  const [pulling, setPulling] = useState(false);
  const [unlinking, setUnlinking] = useState(false);
  const canLink = can("git.link", projectId);
  const canPush = can("git.push", projectId);
  const refresh = () => void qc.invalidateQueries({ queryKey: ["project-git", projectId] });
  const g = status.data?.git;

  const pull = async () => {
    try {
      const r = await api.post<{ version: number; commit: string; diagnostics: Diagnostic[] }>(`/projects/${projectId}/git/pull`);
      const warnings = r.diagnostics.filter((d) => d.severity !== "info").length;
      toast.success(`Modèle mis à jour depuis ${r.commit.slice(0, 8)} (version ${r.version})${warnings ? `, ${warnings} avertissement(s)` : ""}`);
      await qc.invalidateQueries({ queryKey: ["project", projectId] });
      refresh();
    } catch (e) {
      toast.error(e);
    } finally {
      setPulling(false);
    }
  };

  return (
    <Card
      title={
        <span className="flex items-center gap-2">
          <GitBranch className="h-4 w-4" /> Dépôt Git
        </span>
      }
      actions={
        canLink &&
        (status.data?.linked ? (
          <>
            <Button size="sm" onClick={() => setLinking(true)}>
              Modifier la liaison
            </Button>
            <Button size="sm" variant="ghost" onClick={() => setUnlinking(true)}>
              Délier
            </Button>
          </>
        ) : (
          <Button size="sm" variant="primary" onClick={() => setLinking(true)}>
            Lier à un dépôt
          </Button>
        ))
      }
    >
      {!status.data?.linked || !g ? (
        <p className="text-sm text-slate-500">Projet non lié. Liez-le à un dépôt GitHub, GitLab ou Gitea pour y pousser le code généré, dans un sous-dossier si besoin.</p>
      ) : (
        <div className="space-y-3">
          <dl className="grid grid-cols-[max-content_1fr] gap-x-6 gap-y-1 text-sm">
            <dt className="text-slate-500">Dépôt</dt>
            <dd>
              <a href={g.webUrl} target="_blank" rel="noreferrer" className="inline-flex items-center gap-1 text-indigo-600 hover:underline dark:text-indigo-400">
                {g.repo} <ExternalLink className="h-3 w-3" />
              </a>{" "}
              <Badge>{providerLabels[g.provider]}</Badge> <span className="text-xs text-slate-500">{g.baseUrl}</span>
            </dd>
            <dt className="text-slate-500">Branche</dt>
            <dd className="font-mono">{g.branch}</dd>
            <dt className="text-slate-500">Dossier</dt>
            <dd className="font-mono">{g.path || "(racine du dépôt)"}</dd>
            <dt className="text-slate-500">Dernier échange</dt>
            <dd>
              {g.lastSyncAt ? (
                <>
                  {{ import: "import", push: "push", pr: "pull/merge request" }[g.lastSyncKind ?? ""] ?? g.lastSyncKind} par {g.lastSyncBy} le {formatDate(g.lastSyncAt)}
                  {g.lastCommit && <span className="ml-1 font-mono text-xs text-slate-500">{g.lastCommit.slice(0, 8)}</span>}
                </>
              ) : (
                "—"
              )}
            </dd>
          </dl>
          {!status.data.hasConnection && (
            <p className="rounded-md bg-amber-50 px-3 py-2 text-sm text-amber-800 dark:bg-amber-950 dark:text-amber-200">
              Vous n'avez pas de connexion Git vers {g.baseUrl} : ajoutez-la dans Mon compte &gt; Connexions Git pour pousser ou mettre à jour.
            </p>
          )}
          <div className="flex flex-wrap gap-2">
            {canPush && (
              <Button variant="primary" icon={<Upload className="h-4 w-4" />} disabled={!status.data.hasConnection} onClick={() => setPushing(true)}>
                Pousser le code
              </Button>
            )}
            {canLink && (
              <Button disabled={!status.data.hasConnection || dirty} title={dirty ? "Enregistrez ou annulez vos modifications d'abord" : undefined} loading={pulling} onClick={() => setPulling(true)}>
                Mettre à jour depuis Git
              </Button>
            )}
          </div>
        </div>
      )}
      {linking && <LinkDialog projectId={projectId} current={g} onClose={() => setLinking(false)} onSaved={() => (setLinking(false), refresh())} />}
      {pushing && g && <PushDialog projectId={projectId} projectName={projectName} git={g} dirty={dirty} onClose={() => setPushing(false)} onDone={() => (setPushing(false), refresh())} />}
      <ConfirmDialog
        open={pulling && !!g}
        title="Mettre à jour depuis Git ?"
        message={`Le modèle est remplacé par le code de ${g?.repo} (${g?.branch}, ${g?.path || "racine"}) dans une nouvelle version. Les versions précédentes restent restaurables ; environnements et states ne changent pas.`}
        confirmText="Mettre à jour"
        onClose={() => setPulling(false)}
        onConfirm={() => void pull()}
      />
      <ConfirmDialog
        open={unlinking}
        title="Délier le dépôt ?"
        message="Le dépôt n'est pas modifié ; le projet ne pourra plus y pousser tant qu'il n'est pas relié."
        danger
        confirmText="Délier"
        onClose={() => setUnlinking(false)}
        onConfirm={() =>
          void api
            .del(`/projects/${projectId}/git`)
            .then(() => (toast.success("Dépôt délié"), refresh()), toast.error)
            .finally(() => setUnlinking(false))
        }
      />
    </Card>
  );
}

function LinkDialog({ projectId, current, onClose, onSaved }: { projectId: string; current?: ProjectGit; onClose: () => void; onSaved: () => void }) {
  const conns = useGitConnections();
  // Liaison existante : la connexion vers la même forge est présélectionnée.
  const initial = current ? conns.data?.find((c) => c.provider === current.provider && c.baseUrl === current.baseUrl) : undefined;
  const [src, setSrc] = useState<GitSource>(current && initial ? { connectionId: initial.id, repo: current.repo, branch: current.branch, path: current.path } : emptySource);
  const [error, setError] = useState<unknown>(null);
  const save = async () => {
    const c = conns.data?.find((x) => x.id === src.connectionId);
    if (!c) return;
    try {
      await api.put(`/projects/${projectId}/git`, { provider: c.provider, baseUrl: c.baseUrl, repo: src.repo, branch: src.branch, path: src.path });
      toast.success("Projet lié au dépôt");
      onSaved();
    } catch (e) {
      setError(e);
    }
  };
  if (conns.isLoading) return null;
  return (
    <Modal
      open
      wide
      onClose={onClose}
      title="Lier le projet à un dépôt Git"
      footer={
        <>
          <Button onClick={onClose}>Annuler</Button>
          <Button variant="primary" disabled={!src.repo || !src.branch} onClick={save}>
            Lier
          </Button>
        </>
      }
    >
      <div className="space-y-3">
        <ErrorBox error={error} />
        <GitSourcePicker value={src} onChange={setSrc} allowNewFolder />
        <p className="text-xs text-slate-500">Le dépôt est partagé par tous les membres du projet ; chacun pousse avec sa propre connexion vers ce serveur.</p>
      </div>
    </Modal>
  );
}

function PushDialog({ projectId, projectName, git, dirty, onClose, onDone }: { projectId: string; projectName: string; git: ProjectGit; dirty: boolean; onClose: () => void; onDone: () => void }) {
  const stamp = new Date().toISOString().slice(0, 16).replace(/[-:T]/g, "");
  const [mode, setMode] = useState<"direct" | "pr">("pr");
  const [message, setMessage] = useState(`HCLDesigner : mise à jour de ${projectName}`);
  const [newBranch, setNewBranch] = useState(`hcldesigner/${projectName.toLowerCase().replace(/[^a-z0-9]+/g, "-")}-${stamp}`);
  const [prTitle, setPrTitle] = useState("");
  const [prBody, setPrBody] = useState("Code généré par HCLDesigner.");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<unknown>(null);
  const changeLabel = git.provider === "gitlab" ? "merge request" : "pull request";
  const push = async () => {
    setLoading(true);
    setError(null);
    try {
      const r = await api.post<{ nothing?: boolean; commit: string; branch: string; prUrl?: string; prError?: string }>(`/projects/${projectId}/git/push`, {
        message,
        mode,
        newBranch,
        prTitle,
        prBody,
      });
      if (r.nothing) toast.success("Aucun changement : le dépôt contient déjà ce code");
      else if (r.prUrl) {
        toast.success(`Commit ${r.commit.slice(0, 8)} poussé sur ${r.branch}, ${changeLabel} ouverte`);
        window.open(r.prUrl, "_blank", "noopener");
      } else if (r.prError) toast.error(`Branche ${r.branch} poussée, mais ${changeLabel} non ouverte : ${r.prError}`);
      else toast.success(`Commit ${r.commit.slice(0, 8)} poussé sur ${r.branch}`);
      onDone();
    } catch (e) {
      setError(e);
    } finally {
      setLoading(false);
    }
  };
  return (
    <Modal
      open
      wide
      onClose={onClose}
      title={`Pousser vers ${git.repo}`}
      footer={
        <>
          <Button onClick={onClose}>Annuler</Button>
          <Button variant="primary" loading={loading} icon={mode === "pr" ? <GitPullRequest className="h-4 w-4" /> : <Upload className="h-4 w-4" />} onClick={push}>
            {mode === "pr" ? `Pousser et ouvrir la ${changeLabel}` : `Pousser sur ${git.branch}`}
          </Button>
        </>
      }
    >
      <div className="space-y-3">
        <ErrorBox error={error} />
        {dirty && <p className="rounded-md bg-amber-50 px-3 py-2 text-sm text-amber-800 dark:bg-amber-950 dark:text-amber-200">Des modifications ne sont pas enregistrées : seule la dernière version enregistrée est poussée.</p>}
        <p className="text-sm text-slate-500">
          Les fichiers .tf du dossier <span className="font-mono">{git.path || "(racine)"}</span> sont remplacés par le code généré (un .tf absent du modèle est supprimé) ; le reste du dépôt n'est pas modifié.
        </p>
        <Field label="Mode">
          <Select value={mode} onChange={(e) => setMode(e.target.value as "direct" | "pr")}>
            <option value="pr">Nouvelle branche + {changeLabel} vers {git.branch} (recommandé)</option>
            <option value="direct">Commit direct sur {git.branch}</option>
          </Select>
        </Field>
        <Field label="Message de commit">
          <Input value={message} onChange={(e) => setMessage(e.target.value)} />
        </Field>
        {mode === "pr" && (
          <div className="grid gap-3 md:grid-cols-2">
            <Field label="Nouvelle branche">
              <Input value={newBranch} onChange={(e) => setNewBranch(e.target.value)} />
            </Field>
            <Field label={`Titre de la ${changeLabel}`} help="Vide = message de commit.">
              <Input value={prTitle} onChange={(e) => setPrTitle(e.target.value)} />
            </Field>
            <Field label="Description" className="md:col-span-2">
              <Textarea rows={3} value={prBody} onChange={(e) => setPrBody(e.target.value)} />
            </Field>
          </div>
        )}
      </div>
    </Modal>
  );
}
