// Panneau de liaison : à la création d'un lien entre deux objets, propose les liaisons
// possibles (règles + inférence + choix manuel), affiche les arguments obligatoires encore vides
// de la cible et les optionnels avec leur valeur par défaut, puis applique le tout en une étape.
import { useEffect, useMemo, useState } from "react";
import type { Draft } from "immer";
import { api } from "@/api/client";
import type { SuggestResult, TargetArg } from "@/types/api";
import type { IndexMode, Project, TfNode, Value } from "@/types/model";
import { applyAtPath, multiOf, nodeAddress, refExpression } from "@/lib/model";
import { isEmptyValue } from "@/lib/schema";
import { useEditor } from "@/store/editor";
import { Badge, Button, ErrorBox, Field, Modal, Select, Spinner, Toggle, cx } from "@/components/ui";
import { ValueInput } from "./ValueInput";

interface Props {
  sourceId: string;
  targetId: string;
  onClose: () => void;
}

export function endpointSpec(n: TfNode) {
  return { id: n.id, kind: n.kind, type: n.type, label: n.label, provider: n.provider ?? "", module: n.module, multi: multiOf(n) };
}

/** Valeur actuelle d'un argument à un chemin de schéma ("bloc.attr" : premier bloc). */
export function valueAt(node: TfNode, path: string): Value | undefined {
  const parts = path.split(".");
  const attr = parts.pop()!;
  let attrs = node.attrs;
  let blocks = node.blocks;
  for (const bn of parts) {
    const b = blocks?.[bn]?.[0];
    if (!b) return undefined;
    attrs = b.attrs;
    blocks = b.blocks;
  }
  return attrs[attr];
}

export default function ConnectionDialog({ sourceId, targetId, onClose }: Props) {
  const model = useEditor((s) => s.model)!;
  const update = useEditor((s) => s.update);
  const source = model.nodes.find((n) => n.id === sourceId)!;
  const target = model.nodes.find((n) => n.id === targetId)!;
  const [result, setResult] = useState<SuggestResult | null>(null);
  const [error, setError] = useState<unknown>(null);
  const [choice, setChoice] = useState<string>(""); // "attr->path" ou "manual" ou "depends_on"
  const [manualAttr, setManualAttr] = useState("");
  const [manualPath, setManualPath] = useState("");
  const [indexMode, setIndexMode] = useState<IndexMode>("");
  const [index, setIndex] = useState("0");
  const [extra, setExtra] = useState<Record<string, Value | undefined>>({});
  const [showOptional, setShowOptional] = useState(false);

  useEffect(() => {
    api
      .post<SuggestResult>("/connections/suggest", { providers: model.providers, source: endpointSpec(source), target: endpointSpec(target) })
      .then((r) => {
        setResult(r);
        const top = r.suggestions[0];
        if (top) {
          setChoice(`${top.sourceAttr}->${top.targetPath}`);
          setIndexMode((top.indexMode ?? "") as IndexMode);
        } else setChoice(r.allowed ? "manual" : "depends_on");
      })
      .catch(setError);
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const selected = useMemo(() => {
    if (!result || choice === "depends_on") return null;
    if (choice === "manual") {
      const arg = result.targetArgs.find((a) => a.path === manualPath);
      return manualPath ? { sourceAttr: manualAttr, targetPath: manualPath, cardinality: arg?.type.startsWith("list(") || arg?.type.startsWith("set(") ? "list" : "single" } : null;
    }
    const s = result.suggestions.find((x) => `${x.sourceAttr}->${x.targetPath}` === choice);
    return s ? { sourceAttr: s.sourceAttr, targetPath: s.targetPath, cardinality: s.cardinality } : null;
  }, [choice, manualAttr, manualPath, result]);

  const multi = multiOf(source);
  const ref = selected ? { node: source.id, attr: selected.sourceAttr, indexMode, index: indexMode === "index" || indexMode === "key" ? index : undefined } : null;
  const requiredMissing: TargetArg[] = (result?.targetArgs ?? []).filter((a) => a.required && !a.inBlock && a.path !== selected?.targetPath && isEmptyValue(valueAt(target, a.path)));
  const optionalArgs: TargetArg[] = (result?.targetArgs ?? []).filter((a) => !a.required && !a.inBlock && a.path !== selected?.targetPath);

  const apply = () => {
    // Calcul sur l'objet courant (non brouillon immer) puis remplacement dans le modèle.
    const current = useEditor.getState().model!.nodes.find((n) => n.id === target.id)!;
    update((d) => {
      const i = d.nodes.findIndex((n) => n.id === target.id);
      let n: TfNode = current;
      if (choice === "depends_on" || !selected || !ref) {
        n = { ...n, meta: { ...n.meta, dependsOn: [...new Set([...(n.meta.dependsOn ?? []), source.id])] } };
      } else {
        n = applyAtPath(n, selected.targetPath, { mode: "ref", ref }, selected.cardinality as "single" | "list");
      }
      for (const [path, v] of Object.entries(extra)) if (v && !isEmptyValue(v)) n = applyAtPath(n, path, v);
      d.nodes[i] = n as Draft<TfNode>;
    });
    onClose();
  };

  return (
    <Modal
      open
      wide
      onClose={onClose}
      title={
        <span>
          Liaison <span className="font-mono text-indigo-600">{nodeAddress(source)}</span> → <span className="font-mono text-indigo-600">{nodeAddress(target)}</span>
        </span>
      }
      footer={
        <>
          <Button onClick={onClose}>Annuler</Button>
          <Button variant="primary" disabled={!result || (choice !== "depends_on" && !selected)} onClick={apply}>
            Relier
          </Button>
        </>
      }
    >
      <ErrorBox error={error} />
      {!result && !error && <Spinner label="Analyse des schémas…" />}
      {result && (
        <div className="grid gap-5 md:grid-cols-2">
          <section className="space-y-2">
            <h3 className="text-sm font-semibold">Liaison</h3>
            {!result.allowed && <p className="rounded bg-amber-50 p-2 text-xs text-amber-900 dark:bg-amber-950 dark:text-amber-200">{result.message}</p>}
            {result.suggestions.map((s) => {
              const key = `${s.sourceAttr}->${s.targetPath}`;
              return (
                <label key={key} className={cx("flex cursor-pointer items-start gap-2 rounded-md border p-2 text-sm", choice === key ? "border-indigo-500 bg-indigo-50 dark:bg-indigo-950/40" : "border-slate-200 dark:border-slate-700")}>
                  <input type="radio" checked={choice === key} onChange={() => (setChoice(key), setIndexMode((s.indexMode ?? "") as IndexMode))} className="mt-1" />
                  <div className="min-w-0">
                    <div className="font-mono text-xs">
                      {s.sourceAttr ? `${source.label}.${s.sourceAttr}` : nodeAddress(source)} → {s.targetPath}
                    </div>
                    <div className="mt-0.5 flex flex-wrap gap-1">
                      <Badge tone={s.origin === "rule" ? "green" : "blue"}>{s.origin === "rule" ? "règle" : "inférence"}</Badge>
                      <Badge>{s.targetType}</Badge>
                      {s.cardinality === "list" && <Badge tone="purple">ajout à la liste</Badge>}
                    </div>
                    <p className="mt-0.5 text-[11px] text-slate-500">{s.reason}</p>
                  </div>
                </label>
              );
            })}
            {result.allowed && (
              <label className={cx("block cursor-pointer rounded-md border p-2 text-sm", choice === "manual" ? "border-indigo-500" : "border-slate-200 dark:border-slate-700")}>
                <div className="flex items-center gap-2">
                  <input type="radio" checked={choice === "manual"} onChange={() => setChoice("manual")} /> Liaison manuelle
                </div>
                {choice === "manual" && (
                  <div className="mt-2 grid grid-cols-2 gap-2">
                    <Select value={manualAttr} onChange={(e) => setManualAttr(e.target.value)}>
                      <option value="">{source.kind === "variable" || source.kind === "local" ? "(valeur)" : "— attribut source —"}</option>
                      {result.sourceAttrs.filter((a) => a.name).map((a) => (
                        <option key={a.name} value={a.name}>
                          {a.name} ({a.type})
                        </option>
                      ))}
                    </Select>
                    <Select value={manualPath} onChange={(e) => setManualPath(e.target.value)}>
                      <option value="">— argument cible —</option>
                      {result.targetArgs.map((a) => (
                        <option key={a.path} value={a.path}>
                          {a.path} ({a.type})
                        </option>
                      ))}
                    </Select>
                  </div>
                )}
              </label>
            )}
            <label className={cx("flex cursor-pointer items-center gap-2 rounded-md border p-2 text-sm", choice === "depends_on" ? "border-indigo-500" : "border-slate-200 dark:border-slate-700")}>
              <input type="radio" checked={choice === "depends_on"} onChange={() => setChoice("depends_on")} /> Dépendance seule (depends_on)
            </label>
            {multi && choice !== "depends_on" && (
              <Field label={`La source utilise ${multi} : forme de la référence`}>
                <div className="flex gap-2">
                  <Select value={indexMode} onChange={(e) => setIndexMode(e.target.value as IndexMode)}>
                    {multi === "count" && <option value="index">un élément [n]</option>}
                    {multi === "count" && <option value="splat">tous les éléments [*]</option>}
                    {multi === "for_each" && <option value="key">une clé ["…"]</option>}
                    {multi === "for_each" && <option value="values">tous values(…)[*]</option>}
                    <option value="each">[each.key] (même for_each)</option>
                  </Select>
                  {(indexMode === "index" || indexMode === "key") && <input className="w-24 rounded border border-slate-300 px-2 dark:border-slate-600 dark:bg-slate-900" value={index} onChange={(e) => setIndex(e.target.value)} />}
                </div>
              </Field>
            )}
            {ref && (
              <p className="rounded bg-slate-100 p-2 font-mono text-xs dark:bg-slate-800">
                {selected?.targetPath} = {selected?.cardinality === "list" ? `[${refExpression(ref, source)}]` : refExpression(ref, source)}
              </p>
            )}
          </section>

          <section className="space-y-3">
            <h3 className="text-sm font-semibold">Arguments de {nodeAddress(target)}</h3>
            {requiredMissing.length === 0 ? (
              <p className="text-xs text-emerald-700 dark:text-emerald-400">Tous les arguments obligatoires sont renseignés.</p>
            ) : (
              <div className="space-y-2">
                <p className="text-[11px] font-semibold uppercase tracking-wide text-rose-600">Obligatoires à compléter</p>
                {requiredMissing.map((a) => (
                  <ArgInput key={a.path} arg={a} model={model} targetId={target.id} value={extra[a.path]} onChange={(v) => setExtra((e) => ({ ...e, [a.path]: v }))} />
                ))}
              </div>
            )}
            <div>
              <Toggle checked={showOptional} onChange={setShowOptional} label={`Optionnels et valeurs par défaut (${optionalArgs.length})`} />
              {showOptional && (
                <div className="mt-2 max-h-80 space-y-2 overflow-y-auto pr-1">
                  {optionalArgs.map((a) => (
                    <ArgInput key={a.path} arg={a} model={model} targetId={target.id} value={extra[a.path] ?? valueAt(target, a.path)} onChange={(v) => setExtra((e) => ({ ...e, [a.path]: v }))} />
                  ))}
                </div>
              )}
            </div>
          </section>
        </div>
      )}
    </Modal>
  );
}

function ArgInput({ arg, model, targetId, value, onChange }: { arg: TargetArg; model: Project; targetId: string; value?: Value; onChange: (v: Value | undefined) => void }) {
  return (
    <div className="space-y-1">
      <div className="flex flex-wrap items-center gap-1.5 text-xs">
        <span className="font-mono font-medium">{arg.path}</span>
        <span className="text-slate-400">{arg.type}</span>
        {arg.default !== undefined && (
          <Badge tone="gray" title={arg.defaultFrom === "module" ? "défaut du module" : "défaut documenté du provider (fichier de règles HCLDesigner)"}>
            défaut : {JSON.stringify(arg.default)}
          </Badge>
        )}
        {arg.default === undefined && !arg.required && arg.computed && <Badge tone="gray">calculé si vide</Badge>}
      </div>
      <ValueInput value={value} onChange={onChange} type={arg.type.startsWith("nested(") ? "dynamic" : arg.type} model={model} selfId={targetId} sensitive={arg.sensitive} />
      {arg.description && <p className="line-clamp-2 text-[11px] text-slate-500">{arg.description}</p>}
    </div>
  );
}
