// Cadre conteneur sur le canvas (VPC, subnet, resource group…) : bandeau avec label et badges,
// zone d'accueil des objets imbriqués, redimensionnement à la souris, repli du contenu.
import { memo } from "react";
import { Handle, NodeResizer, Position, type NodeProps, type Node } from "@xyflow/react";
import { ChevronDown, ChevronRight, Frame } from "lucide-react";
import type { Draft } from "immer";
import type { TfNode } from "@/types/model";
import { useEditor } from "@/store/editor";
import { cx } from "@/components/ui";
import { FRAME } from "@/lib/containers";
import type { TfNodeData } from "./TfNodeCard";

export interface ContainerData extends TfNodeData {
  childCount: number;
  dropTarget?: boolean; // un objet est en train d'être glissé au-dessus
}

function ContainerNodeInner({ data, selected }: NodeProps<Node<ContainerData>>) {
  const { node, missing, errors, plan, compatible, dimmed, childCount, dropTarget } = data;
  const update = useEditor((s) => s.update);
  const readOnly = useEditor((s) => s.readOnly);

  const edit = (fn: (n: Draft<TfNode>) => void) =>
    update((d) => {
      const n = d.nodes.find((x) => x.id === node.id);
      if (n) fn(n);
    });

  return (
    <div
      className={cx(
        "h-full w-full rounded-lg border-2 border-dashed bg-indigo-50/40 text-xs transition-opacity dark:bg-indigo-950/20",
        selected ? "border-indigo-500" : "border-indigo-300 dark:border-indigo-800",
        dropTarget && "border-solid border-emerald-500 bg-emerald-50/50 dark:bg-emerald-950/30",
        compatible && "ring-2 ring-indigo-400 ring-offset-1",
        plan && "ring-2 ring-amber-500",
        dimmed && "opacity-40",
      )}
    >
      {!readOnly && !node.collapsed && (
        <NodeResizer
          isVisible={selected}
          minWidth={240}
          minHeight={FRAME.header + 40}
          lineClassName="!border-indigo-400"
          handleClassName="!h-2.5 !w-2.5 !rounded-sm !border-indigo-500 !bg-white"
          onResizeEnd={(_e, r) =>
            edit((n) => {
              n.size = { w: Math.round(r.width), h: Math.round(r.height) };
              n.position = { x: Math.round(r.x), y: Math.round(r.y) };
            })
          }
        />
      )}
      <Handle type="target" position={Position.Left} style={{ top: FRAME.header / 2 }} className="!h-3 !w-3 !border-2 !border-white !bg-slate-400" />
      <Handle type="source" position={Position.Right} style={{ top: FRAME.header / 2 }} className="!h-3 !w-3 !border-2 !border-white !bg-indigo-500" />
      <div className="flex items-center gap-2 rounded-t-md border-b border-indigo-200 bg-white/80 px-2 dark:border-indigo-900 dark:bg-slate-900/80" style={{ height: FRAME.header }}>
        <button
          type="button"
          className="nodrag rounded p-0.5 text-slate-500 hover:bg-slate-200 dark:hover:bg-slate-700"
          title={node.collapsed ? "Déplier" : "Replier"}
          onClick={(e) => {
            e.stopPropagation();
            edit((n) => {
              if (n.collapsed) delete n.collapsed;
              else n.collapsed = true;
            });
          }}
        >
          {node.collapsed ? <ChevronRight className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
        </button>
        <Frame className="h-4 w-4 shrink-0 text-indigo-500" />
        <div className="min-w-0 flex-1">
          <div className="truncate font-semibold" title={node.label}>
            {node.label}
          </div>
          <div className="truncate font-mono text-[10px] text-slate-500">
            {node.kind === "data" ? "data." : ""}
            {node.type}
          </div>
        </div>
        {missing > 0 && <span className="rounded bg-rose-100 px-1 text-[10px] text-rose-700 dark:bg-rose-950 dark:text-rose-300">{missing} requis</span>}
        {errors > 0 && <span className="rounded bg-rose-600 px-1 text-[10px] text-white">{errors}</span>}
        <span className="rounded bg-indigo-100 px-1.5 text-[10px] text-indigo-700 dark:bg-indigo-950 dark:text-indigo-300" title="Objets dans ce cadre">
          {childCount}
        </span>
      </div>
    </div>
  );
}

export const ContainerNode = memo(ContainerNodeInner);
