// Workers : agents qui exécutent Terraform / OpenTofu. Cycle de vie complet, worker par défaut
// compris : pause (les runs en cours se terminent), reprise, révocation, suppression, slots,
// labels, ajout d'un worker sur une autre machine par une commande générée.
import { useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import type { ColumnDef } from "@tanstack/react-table";
import { Copy, Pause, Play, Plus, RefreshCw, RotateCcw, ShieldOff, Trash2 } from "lucide-react";
import { api } from "@/api/client";
import type { Worker } from "@/types/api";
import { DataTable } from "@/components/table/DataTable";
import { Badge, Button, ConfirmDialog, ErrorBox, Field, IconButton, Input, Modal, PageHeader, Select, formatDate, toast } from "@/components/ui";
import { copyText } from "@/lib/model";

const stateMeta: Record<Worker["state"], { label: string; tone: "green" | "yellow" | "red" }> = {
  active: { label: "Actif", tone: "green" },
  paused: { label: "En pause", tone: "yellow" },
  revoked: { label: "Révoqué", tone: "red" },
};

export default function Workers() {
  const q = useQuery({
    queryKey: ["workers"],
    queryFn: () => api.get<{ workers: Worker[]; defaultDisabled: boolean }>("/workers"),
    refetchInterval: 10_000,
  });
  const [editing, setEditing] = useState<Worker | null>(null);
  const [join, setJoin] = useState<{ worker?: Worker } | null>(null);
  const [confirm, setConfirm] = useState<{ title: string; message: string; action: () => Promise<unknown> } | null>(null);
  const refresh = () => void q.refetch();

  const patch = (w: Worker, body: Partial<Pick<Worker, "state" | "slots" | "labels" | "name">>, msg: string) =>
    api.patch(`/workers/${w.id}`, body).then(() => (toast.success(msg), refresh()), toast.error);

  const columns = useMemo<ColumnDef<Worker, unknown>[]>(
    () => [
      {
        id: "name",
        header: "Nom",
        accessorKey: "name",
        size: 200,
        cell: (c) => (
          <span className="flex items-center gap-1.5">
            <span className={c.row.original.online ? "h-2 w-2 rounded-full bg-emerald-500" : "h-2 w-2 rounded-full bg-slate-400"} title={c.row.original.online ? "En ligne" : "Hors ligne"} />
            <span className="font-medium">{c.row.original.name}</span>
            {c.row.original.isDefault && <Badge tone="blue">par défaut</Badge>}
          </span>
        ),
      },
      {
        id: "state",
        header: "État",
        accessorFn: (w) => stateMeta[w.state].label,
        size: 110,
        meta: { filter: "multi" },
        cell: (c) => <Badge tone={stateMeta[c.row.original.state].tone}>{stateMeta[c.row.original.state].label}</Badge>,
      },
      { id: "online", header: "Connexion", accessorFn: (w) => (w.online ? "En ligne" : "Hors ligne"), size: 110, meta: { filter: "multi" } },
      { id: "running", header: "Runs en cours", accessorFn: (w) => `${w.running} / ${w.slots}`, size: 110 },
      { id: "labels", header: "Labels", accessorFn: (w) => w.labels.join(", "), size: 160 },
      { id: "host", header: "Hôte", accessorFn: (w) => [w.hostname, w.osArch].filter(Boolean).join(" · "), size: 180 },
      { id: "remoteAddr", header: "IP", accessorKey: "remoteAddr", size: 120 },
      { id: "version", header: "Version", accessorKey: "version", size: 80 },
      { id: "lastSeenAt", header: "Dernier signal", accessorKey: "lastSeenAt", size: 150, cell: (c) => formatDate(c.getValue() as string) },
      {
        id: "actions",
        header: "",
        size: 170,
        enableSorting: false,
        cell: (c) => {
          const w = c.row.original;
          return (
            <span className="flex gap-0.5" onClick={(e) => e.stopPropagation()}>
              {w.state === "active" && (
                <IconButton title="Mettre en pause (les runs en cours se terminent)" onClick={() => void patch(w, { state: "paused" }, `${w.name} en pause`)}>
                  <Pause className="h-4 w-4" />
                </IconButton>
              )}
              {w.state === "paused" && (
                <IconButton title="Reprendre" onClick={() => void patch(w, { state: "active" }, `${w.name} actif`)}>
                  <Play className="h-4 w-4" />
                </IconButton>
              )}
              {w.isDefault ? (
                <IconButton
                  title={w.state === "revoked" ? "Réactiver (nouveau jeton)" : "Renouveler le jeton"}
                  onClick={() =>
                    w.state === "revoked"
                      ? void patch(w, { state: "active" }, "Worker par défaut réactivé")
                      : void api.post(`/workers/${w.id}/rotate`).then(() => toast.success("Jeton renouvelé : le worker le recharge automatiquement"), toast.error)
                  }
                >
                  <RefreshCw className="h-4 w-4" />
                </IconButton>
              ) : (
                <IconButton title="Réenrôler (nouvelle commande d'installation)" onClick={() => setJoin({ worker: w })}>
                  <RotateCcw className="h-4 w-4" />
                </IconButton>
              )}
              {w.state !== "revoked" && (
                <IconButton
                  title="Révoquer"
                  onClick={() =>
                    setConfirm({
                      title: `Révoquer ${w.name} ?`,
                      message: "Le jeton du worker est refusé immédiatement et ses runs en cours sont marqués en échec.",
                      action: () => patch(w, { state: "revoked" }, `${w.name} révoqué`),
                    })
                  }
                >
                  <ShieldOff className="h-4 w-4" />
                </IconButton>
              )}
              <IconButton
                title="Supprimer"
                onClick={() =>
                  setConfirm({
                    title: `Supprimer ${w.name} ?`,
                    message: w.isDefault
                      ? "Le worker par défaut ne sera pas recréé au redémarrage. Sans autre worker actif, aucun run ne s'exécutera."
                      : "Pensez à désinstaller l'agent sur la machine (commande dans le dialogue d'ajout).",
                    action: () => api.del(`/workers/${w.id}`).then(() => (toast.success(`${w.name} supprimé`), refresh()), toast.error),
                  })
                }
              >
                <Trash2 className="h-4 w-4" />
              </IconButton>
            </span>
          );
        },
      },
    ],
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [],
  );

  const workers = q.data?.workers ?? [];
  const active = workers.filter((w) => w.state === "active" && w.online).length;
  return (
    <div className="p-6">
      <PageHeader
        title="Workers"
        subtitle={`Exécutent Terraform / OpenTofu. ${active} actif(s) en ligne. Un environnement peut exiger des labels (ex. réseau d'un site).`}
      />
      {workers.length > 0 && active === 0 && (
        <div className="mb-3 rounded-md border border-amber-300 bg-amber-50 px-3 py-2 text-sm text-amber-800 dark:border-amber-800 dark:bg-amber-950 dark:text-amber-200">
          Aucun worker actif en ligne : les runs restent en file d'attente.
        </div>
      )}
      <div className="h-[calc(100vh-170px)]">
        <DataTable
          id="workers"
          data={workers}
          columns={columns}
          loading={q.isLoading}
          onRefresh={refresh}
          onRowClick={setEditing}
          getRowId={(w) => w.id}
          toolbar={
            <>
              {q.data?.defaultDisabled && (
                <Button size="sm" onClick={() => void api.post("/workers/default").then(() => (toast.success("Worker par défaut recréé"), refresh()), toast.error)}>
                  Recréer le worker par défaut
                </Button>
              )}
              <Button size="sm" variant="primary" icon={<Plus className="h-3.5 w-3.5" />} onClick={() => setJoin({})}>
                Ajouter un worker
              </Button>
            </>
          }
        />
      </div>
      {editing && <EditWorker worker={editing} onClose={() => setEditing(null)} onSaved={() => (setEditing(null), refresh())} />}
      {join && <JoinDialog worker={join.worker} onClose={() => (setJoin(null), refresh())} />}
      {confirm && (
        <ConfirmDialog
          open
          title={confirm.title}
          message={confirm.message}
          danger
          confirmText="Confirmer"
          onClose={() => setConfirm(null)}
          onConfirm={() => void confirm.action().finally(() => setConfirm(null))}
        />
      )}
    </div>
  );
}

/** Saisie de labels séparés par des virgules ou des espaces. */
function parseLabels(s: string): string[] {
  return [...new Set(s.split(/[\s,]+/).map((x) => x.trim().toLowerCase()).filter(Boolean))];
}

function EditWorker({ worker, onClose, onSaved }: { worker: Worker; onClose: () => void; onSaved: () => void }) {
  const [name, setName] = useState(worker.name);
  const [slots, setSlots] = useState(worker.slots);
  const [labels, setLabels] = useState(worker.labels.join(", "));
  const [error, setError] = useState<unknown>(null);
  const save = async () => {
    try {
      await api.patch(`/workers/${worker.id}`, { name, slots, labels: parseLabels(labels) });
      toast.success("Worker modifié");
      onSaved();
    } catch (e) {
      setError(e);
    }
  };
  return (
    <Modal
      open
      onClose={onClose}
      title={`Worker ${worker.name}`}
      footer={
        <>
          <Button onClick={onClose}>Annuler</Button>
          <Button variant="primary" onClick={save}>
            Enregistrer
          </Button>
        </>
      }
    >
      <div className="space-y-3">
        <ErrorBox error={error} />
        <Field label="Nom">
          <Input value={name} onChange={(e) => setName(e.target.value)} />
        </Field>
        <Field label="Slots" help="Runs exécutés en parallèle sur ce worker (appliqué au prochain signal de vie).">
          <Input type="number" min={1} max={64} value={slots} onChange={(e) => setSlots(Number(e.target.value))} />
        </Field>
        <Field label="Labels" help="Séparés par des virgules. Un environnement qui exige des labels n'est exécuté que par les workers qui les portent tous.">
          <Input value={labels} onChange={(e) => setLabels(e.target.value)} placeholder="dc1, vsphere" />
        </Field>
        <dl className="grid grid-cols-2 gap-1 text-xs text-slate-500">
          <dt>Hôte</dt>
          <dd>{worker.hostname || "—"}</dd>
          <dt>Système</dt>
          <dd>{worker.osArch || "—"}</dd>
          <dt>IP</dt>
          <dd>{worker.remoteAddr || "—"}</dd>
          <dt>Enrôlé le</dt>
          <dd>{formatDate(worker.createdAt)}</dd>
        </dl>
      </div>
    </Modal>
  );
}

/** Commandes d'installation : générées avec un jeton d'enrôlement à usage unique. */
export function installCommands(origin: string, token: string, name: string, insecure: boolean) {
  const k = insecure ? "k" : "";
  const opt = insecure ? " --insecure" : "";
  return {
    linux: `curl -fsSL${k} ${origin}/api/agent/install.sh | sudo bash -s -- --url ${origin} --token ${token}${opt}`,
    docker:
      `docker run -d --name hcld-${name} --restart unless-stopped \\\n` +
      `  -e HCLD_SERVER_URL=${origin} -e HCLD_JOIN_TOKEN=${token} -e HCLD_DATA_DIR=/data${insecure ? " -e HCLD_INSECURE_TLS=true" : ""} \\\n` +
      `  -v hcld-${name}:/data hcldesigner-backend:latest agent`,
    uninstall: `curl -fsSL${k} ${origin}/api/agent/install.sh | sudo bash -s -- --uninstall`,
  };
}

function JoinDialog({ worker, onClose }: { worker?: Worker; onClose: () => void }) {
  const [name, setName] = useState(worker?.name ?? "");
  const [slots, setSlots] = useState(worker?.slots ?? 2);
  const [labels, setLabels] = useState(worker?.labels.join(", ") ?? "");
  const [ttl, setTtl] = useState(24);
  const [origin, setOrigin] = useState(window.location.origin);
  const [insecure, setInsecure] = useState(false);
  const [result, setResult] = useState<{ token: string; expiresAt: string; name: string } | null>(null);
  const [error, setError] = useState<unknown>(null);
  const generate = async () => {
    try {
      setResult(await api.post("/workers/join", { name, slots, labels: parseLabels(labels), ttlHours: ttl, workerId: worker?.id }));
    } catch (e) {
      setError(e);
    }
  };
  const cmds = result ? installCommands(origin.replace(/\/$/, ""), result.token, result.name, insecure) : null;
  return (
    <Modal open wide onClose={onClose} title={worker ? `Réenrôler ${worker.name}` : "Ajouter un worker"} footer={<Button onClick={onClose}>Fermer</Button>}>
      <div className="space-y-3">
        <ErrorBox error={error} />
        {!result ? (
          <>
            <p className="text-sm text-slate-500">
              {worker
                ? "Génère une commande à lancer sur la machine du worker : l'ancien jeton devient invalide dès l'enrôlement."
                : "Le worker s'installe sur n'importe quel Linux avec systemd (Debian, Ubuntu, RHEL, Rocky…) qui joint cette URL. Il ne reçoit aucun accès à la base."}
            </p>
            <div className="grid gap-3 md:grid-cols-2">
              <Field label="Nom" required>
                <Input value={name} disabled={!!worker} onChange={(e) => setName(e.target.value.toLowerCase())} placeholder="worker-dc1-01" />
              </Field>
              <Field label="Validité de la commande">
                <Select value={ttl} onChange={(e) => setTtl(Number(e.target.value))}>
                  <option value={1}>1 heure</option>
                  <option value={24}>24 heures</option>
                  <option value={168}>7 jours</option>
                </Select>
              </Field>
              <Field label="Slots" help="Runs en parallèle.">
                <Input type="number" min={1} max={64} value={slots} disabled={!!worker} onChange={(e) => setSlots(Number(e.target.value))} />
              </Field>
              <Field label="Labels" help="Ex. dc1, vsphere.">
                <Input value={labels} disabled={!!worker} onChange={(e) => setLabels(e.target.value)} />
              </Field>
              <Field label="URL de HCLDesigner vue depuis le worker" help="L'URL doit être joignable depuis la machine du worker.">
                <Input value={origin} onChange={(e) => setOrigin(e.target.value)} />
              </Field>
              <Field label="Certificat TLS">
                <Select value={insecure ? "1" : "0"} onChange={(e) => setInsecure(e.target.value === "1")}>
                  <option value="0">Vérifié (recommandé)</option>
                  <option value="1">Non vérifié (certificat auto-signé)</option>
                </Select>
              </Field>
            </div>
            <Button variant="primary" disabled={!name} onClick={generate}>
              Générer la commande
            </Button>
          </>
        ) : (
          cmds && (
            <>
              <p className="text-sm">
                Commande valable jusqu'au <b>{formatDate(result.expiresAt)}</b>, utilisable une seule fois. Le worker apparaît dans la liste dès son premier signal de vie.
              </p>
              <Command label="Linux (service systemd) — à lancer sur la machine du worker" text={cmds.linux} />
              <Command label="Docker — sur l'hôte HCLDesigner (image déjà construite)" text={cmds.docker} />
              <Command label="Désinstallation (Linux)" text={cmds.uninstall} />
            </>
          )
        )}
      </div>
    </Modal>
  );
}

function Command({ label, text }: { label: string; text: string }) {
  return (
    <div>
      <div className="mb-1 flex items-center justify-between text-xs font-medium text-slate-500">
        {label}
        <Button size="sm" icon={<Copy className="h-3.5 w-3.5" />} onClick={() => void copyText(text).then(() => toast.success("Copié"), () => toast.error("Copie impossible"))}>
          Copier
        </Button>
      </div>
      <pre className="overflow-x-auto whitespace-pre-wrap break-all rounded-md bg-slate-900 p-3 font-mono text-xs text-slate-100">{text}</pre>
    </div>
  );
}
