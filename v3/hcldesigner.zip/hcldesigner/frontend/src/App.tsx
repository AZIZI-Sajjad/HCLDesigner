import { useEffect, lazy, Suspense } from "react";
import { Navigate, Route, Routes } from "react-router-dom";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { api, ApiError, onAuthError } from "@/api/client";
import type { Me } from "@/types/api";
import { AuthProvider } from "@/lib/auth";
import { Spinner, Toaster } from "@/components/ui";
import Layout from "@/components/Layout";
import Login from "@/pages/Login";

// Chargement à la demande : l'éditeur (Monaco, React Flow) n'est téléchargé que s'il est ouvert.
const Dashboard = lazy(() => import("@/pages/Dashboard"));
const Projects = lazy(() => import("@/pages/Projects"));
const ProjectEditor = lazy(() => import("@/pages/editor/ProjectEditor"));
const Runs = lazy(() => import("@/pages/runs/Runs"));
const RunDetail = lazy(() => import("@/pages/runs/RunDetail"));
const Modules = lazy(() => import("@/pages/modules/Modules"));
const ModuleEditor = lazy(() => import("@/pages/modules/ModuleEditor"));
const Account = lazy(() => import("@/pages/Account"));
const Users = lazy(() => import("@/pages/admin/Users"));
const Roles = lazy(() => import("@/pages/admin/Roles"));
const Notifications = lazy(() => import("@/pages/admin/Notifications"));
const Schedules = lazy(() => import("@/pages/admin/Schedules"));
const Policies = lazy(() => import("@/pages/admin/Policies"));
const Credentials = lazy(() => import("@/pages/admin/Credentials"));
const Providers = lazy(() => import("@/pages/admin/Providers"));
const Workers = lazy(() => import("@/pages/admin/Workers"));
const Settings = lazy(() => import("@/pages/admin/Settings"));
const Audit = lazy(() => import("@/pages/admin/Audit"));

export default function App() {
  const qc = useQueryClient();
  const me = useQuery({
    queryKey: ["me"],
    queryFn: () => api.get<Me>("/auth/me"),
    retry: false,
  });
  // Une réponse 401 ailleurs dans l'application (session expirée) renvoie à la connexion.
  useEffect(() => onAuthError(() => void qc.invalidateQueries({ queryKey: ["me"] })), [qc]);

  if (me.isLoading) return <Spinner />;
  const unauthenticated = me.error instanceof ApiError && me.error.status === 401;
  if (unauthenticated || !me.data || !me.data.mfaOk) {
    return (
      <>
        <Login mfaPending={!!me.data && !me.data.mfaOk} onDone={() => void me.refetch()} />
        <Toaster />
      </>
    );
  }
  return (
    <AuthProvider me={me.data} refresh={() => void me.refetch()}>
      <Layout>
        <Suspense fallback={<Spinner />}>
          <Routes>
            <Route path="/" element={<Dashboard />} />
            <Route path="/projects" element={<Projects />} />
            <Route path="/projects/:id/*" element={<ProjectEditor />} />
            <Route path="/runs" element={<Runs />} />
            <Route path="/runs/:id" element={<RunDetail />} />
            <Route path="/modules" element={<Modules />} />
            <Route path="/modules/:id" element={<ModuleEditor />} />
            <Route path="/account" element={<Account />} />
            <Route path="/admin/users" element={<Users />} />
            <Route path="/admin/roles" element={<Roles />} />
            <Route path="/admin/notifications" element={<Notifications />} />
            <Route path="/admin/schedules" element={<Schedules />} />
            <Route path="/admin/policies" element={<Policies />} />
            <Route path="/admin/credentials" element={<Credentials />} />
            <Route path="/admin/providers" element={<Providers />} />
            <Route path="/admin/workers" element={<Workers />} />
            <Route path="/admin/settings" element={<Settings />} />
            <Route path="/admin/audit" element={<Audit />} />
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </Suspense>
      </Layout>
      <Toaster />
    </AuthProvider>
  );
}
