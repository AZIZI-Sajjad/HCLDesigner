package api

import (
	"net/http"
	"sort"
	"time"

	"github.com/go-chi/chi/v5"

	"github.com/AZIZI-Sajjad/hcldesigner/internal/core"
)

// workerRoutes : administration des workers (cycle de vie complet, worker par défaut compris).
func (s *Server) workerRoutes(r chi.Router) {
	r.Get("/workers", s.listWorkers)
	r.Get("/workers/labels", s.workerLabels)
	r.Post("/workers/join", s.createJoinToken)
	r.Post("/workers/default", s.recreateDefaultWorker)
	r.Patch("/workers/{wid}", s.updateWorker)
	r.Delete("/workers/{wid}", s.deleteWorker)
	r.Post("/workers/{wid}/rotate", s.rotateWorkerToken)
}

func (s *Server) listWorkers(w http.ResponseWriter, r *http.Request) {
	if !can(w, r, "admin.workers", "", "") {
		return
	}
	ws, err := s.core.ListWorkers(r.Context())
	if err != nil {
		fail(w, err)
		return
	}
	var flag struct {
		Disabled bool `json:"disabled"`
	}
	_ = s.core.Settings.Get(r.Context(), "default_worker", &flag)
	writeJSON(w, http.StatusOK, map[string]any{"workers": ws, "defaultDisabled": flag.Disabled})
}

// workerLabels : labels disponibles (formulaire d'environnement), sans détail des workers.
func (s *Server) workerLabels(w http.ResponseWriter, r *http.Request) {
	ws, err := s.core.ListWorkers(r.Context())
	if err != nil {
		fail(w, err)
		return
	}
	set := map[string]bool{}
	for _, wk := range ws {
		if wk.State != "revoked" {
			for _, l := range wk.Labels {
				set[l] = true
			}
		}
	}
	out := make([]string, 0, len(set))
	for l := range set {
		out = append(out, l)
	}
	sort.Strings(out)
	writeJSON(w, http.StatusOK, out)
}

// createJoinToken prépare la commande d'installation d'un nouveau worker (ou le réenrôlement d'un worker existant).
func (s *Server) createJoinToken(w http.ResponseWriter, r *http.Request) {
	if !can(w, r, "admin.workers", "", "") {
		return
	}
	var req struct {
		Name     string   `json:"name"`
		Slots    int      `json:"slots"`
		Labels   []string `json:"labels"`
		TTLHours int      `json:"ttlHours"`
		WorkerID string   `json:"workerId"` // réenrôlement
	}
	if !readJSON(w, r, &req) {
		return
	}
	if req.WorkerID != "" {
		wk, err := s.core.GetWorker(r.Context(), req.WorkerID)
		if err != nil {
			fail(w, err)
			return
		}
		if wk.IsDefault {
			writeError(w, http.StatusBadRequest, "le worker par défaut se renouvelle avec « Renouveler le jeton »")
			return
		}
		req.Name, req.Slots, req.Labels = wk.Name, wk.Slots, wk.Labels
	}
	if req.Slots == 0 {
		req.Slots = 2
	}
	if req.TTLHours <= 0 || req.TTLHours > 168 {
		req.TTLHours = 24
	}
	tok, exp, err := s.core.CreateJoinToken(r.Context(), req.Name, req.Slots, req.Labels, time.Duration(req.TTLHours)*time.Hour, sessionOf(r).UserID, req.WorkerID)
	if err != nil {
		fail(w, bad(err.Error()))
		return
	}
	s.audit(r, "worker.join_token", "worker", req.WorkerID, map[string]any{"name": req.Name, "expiresAt": exp})
	writeJSON(w, http.StatusOK, map[string]any{"token": tok, "expiresAt": exp, "name": req.Name})
}

func (s *Server) updateWorker(w http.ResponseWriter, r *http.Request) {
	if !can(w, r, "admin.workers", "", "") {
		return
	}
	var p core.WorkerPatch
	if !readJSON(w, r, &p) {
		return
	}
	id := chi.URLParam(r, "wid")
	before, err := s.core.GetWorker(r.Context(), id)
	if err != nil {
		fail(w, err)
		return
	}
	wk, err := s.core.UpdateWorker(r.Context(), id, p)
	if err != nil {
		fail(w, bad(err.Error()))
		return
	}
	s.audit(r, "worker.update", "worker", id, map[string]any{"before": before, "after": wk})
	writeJSON(w, http.StatusOK, wk)
}

func (s *Server) deleteWorker(w http.ResponseWriter, r *http.Request) {
	if !can(w, r, "admin.workers", "", "") {
		return
	}
	id := chi.URLParam(r, "wid")
	wk, err := s.core.GetWorker(r.Context(), id)
	if err != nil {
		fail(w, err)
		return
	}
	if err := s.core.DeleteWorker(r.Context(), id); err != nil {
		fail(w, bad(err.Error()))
		return
	}
	s.audit(r, "worker.delete", "worker", id, map[string]any{"name": wk.Name, "default": wk.IsDefault})
	w.WriteHeader(http.StatusNoContent)
}

// rotateWorkerToken renouvelle le jeton du worker par défaut (transmis par le volume partagé).
func (s *Server) rotateWorkerToken(w http.ResponseWriter, r *http.Request) {
	if !can(w, r, "admin.workers", "", "") {
		return
	}
	id := chi.URLParam(r, "wid")
	wk, err := s.core.GetWorker(r.Context(), id)
	if err != nil {
		fail(w, err)
		return
	}
	if !wk.IsDefault {
		writeError(w, http.StatusBadRequest, "worker distant : générez une commande de réenrôlement")
		return
	}
	if err := s.core.RotateDefaultWorkerToken(r.Context()); err != nil {
		fail(w, err)
		return
	}
	s.audit(r, "worker.rotate", "worker", id, nil)
	w.WriteHeader(http.StatusNoContent)
}

func (s *Server) recreateDefaultWorker(w http.ResponseWriter, r *http.Request) {
	if !can(w, r, "admin.workers", "", "") {
		return
	}
	if err := s.core.RecreateDefaultWorker(r.Context()); err != nil {
		fail(w, err)
		return
	}
	s.audit(r, "worker.default_recreate", "worker", "", nil)
	w.WriteHeader(http.StatusNoContent)
}
