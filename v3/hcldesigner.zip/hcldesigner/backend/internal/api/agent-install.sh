#!/usr/bin/env bash
# Installation d'un worker HCLDesigner (agent d'exécution Terraform / OpenTofu).
# Commande générée par HCLDesigner : Administration > Workers > Ajouter un worker.
#
#   curl -fsSL <URL>/api/agent/install.sh | sudo bash -s -- --url <URL> --token <jeton> [options]
#
# Options :
#   --url URL        URL de HCLDesigner (obligatoire)
#   --token TOKEN    jeton d'enrôlement à usage unique (obligatoire sauf --uninstall)
#   --ca-file FILE   CA privée pour une URL https à certificat interne
#   --insecure       ne pas vérifier le certificat TLS (déconseillé)
#   --uninstall      arrêter et supprimer le worker de cette machine
#
# Le worker tourne sous l'utilisateur système hcld-agent (service systemd hcldesigner-agent),
# sans accès à la base de données : il reçoit ses jobs de l'API.
set -Eeuo pipefail

URL="" TOKEN="" CA_FILE="" INSECURE=false UNINSTALL=false
PREFIX=/opt/hcldesigner-agent
DATA=/var/lib/hcldesigner-agent
CONF=/etc/hcldesigner-agent
UNIT=/etc/systemd/system/hcldesigner-agent.service
SVC_USER=hcld-agent

info() { printf '\033[1;34m[INFO]\033[0m %s\n' "$*"; }
ok()   { printf '\033[1;32m[OK]\033[0m   %s\n' "$*"; }
die()  { printf '\033[1;31m[ERR]\033[0m  %s\n' "$*" >&2; exit 1; }

while [[ $# -gt 0 ]]; do
  case "$1" in
    --url) URL="${2%/}"; shift 2 ;;
    --token) TOKEN="$2"; shift 2 ;;
    --ca-file) CA_FILE="$2"; shift 2 ;;
    --insecure) INSECURE=true; shift ;;
    --uninstall) UNINSTALL=true; shift ;;
    *) die "option inconnue : $1" ;;
  esac
done

[[ $EUID -eq 0 ]] || die "lancer en root (sudo)"
command -v systemctl >/dev/null || die "systemd requis"

if $UNINSTALL; then
  info "désinstallation du worker"
  systemctl disable --now hcldesigner-agent 2>/dev/null || true
  rm -f "$UNIT"; systemctl daemon-reload
  rm -rf "$PREFIX" "$DATA" "$CONF"
  id "$SVC_USER" >/dev/null 2>&1 && userdel "$SVC_USER" 2>/dev/null || true
  ok "worker supprimé de cette machine (supprimez-le aussi dans HCLDesigner > Workers)"
  exit 0
fi

[[ -n $URL && -n $TOKEN ]] || die "--url et --token sont obligatoires"
[[ $TOKEN == hcldj_* ]] || die "jeton d'enrôlement invalide (préfixe hcldj_ attendu)"

# ---- Prérequis : curl, git (sources de modules), ca-certificates ----------------------------
install_pkgs() {
  if command -v apt-get >/dev/null; then apt-get update -qq && apt-get install -y -qq "$@" >/dev/null
  elif command -v dnf >/dev/null; then dnf install -y -q "$@" >/dev/null
  elif command -v yum >/dev/null; then yum install -y -q "$@" >/dev/null
  elif command -v zypper >/dev/null; then zypper -q install -y "$@" >/dev/null
  elif command -v apk >/dev/null; then apk add -q "$@" >/dev/null
  else die "gestionnaire de paquets non reconnu : installez $* manuellement"; fi
}
missing=()
for c in curl git; do command -v "$c" >/dev/null || missing+=("$c"); done
[[ -e /etc/ssl/certs/ca-certificates.crt || -e /etc/pki/tls/certs/ca-bundle.crt ]] || missing+=(ca-certificates)
if ((${#missing[@]})); then info "installation de : ${missing[*]}"; install_pkgs "${missing[@]}"; fi

CURL=(curl -fsSL --retry 3)
$INSECURE && CURL+=(-k)
[[ -n $CA_FILE ]] && CURL+=(--cacert "$CA_FILE")

# ---- Architecture : le binaire distribué est celui du serveur --------------------------------
case "$(uname -m)" in
  x86_64|amd64) ARCH=amd64 ;;
  aarch64|arm64) ARCH=arm64 ;;
  *) die "architecture non prise en charge : $(uname -m)" ;;
esac

info "téléchargement du binaire depuis $URL"
TMP=$(mktemp -d); trap 'rm -rf "$TMP"' EXIT
HDRS="$TMP/headers"
"${CURL[@]}" -D "$HDRS" -H "X-Join-Token: $TOKEN" -o "$TMP/hcldesigner" "$URL/api/agent/binary" \
  || die "téléchargement refusé : jeton expiré ou déjà utilisé ? Générez une nouvelle commande dans HCLDesigner"
SERVER_ARCH=$(grep -i '^x-hcld-arch:' "$HDRS" | awk '{print $2}' | tr -d '\r' || true)
[[ -z $SERVER_ARCH || $SERVER_ARCH == "linux/$ARCH" ]] || die "le serveur distribue un binaire $SERVER_ARCH, cette machine est linux/$ARCH"
EXPECTED=$("${CURL[@]}" "$URL/api/agent/binary.sha256" | awk '{print $1}')
ACTUAL=$(sha256sum "$TMP/hcldesigner" | awk '{print $1}')
[[ -n $EXPECTED && $EXPECTED == "$ACTUAL" ]] || die "empreinte SHA-256 du binaire incorrecte"
ok "binaire vérifié (sha256 $ACTUAL)"

# ---- Utilisateur, dossiers, configuration -----------------------------------------------------
id "$SVC_USER" >/dev/null 2>&1 || useradd --system --home-dir "$DATA" --shell /usr/sbin/nologin "$SVC_USER"
install -d -m 0755 "$PREFIX/bin"
install -d -m 0700 -o "$SVC_USER" -g "$SVC_USER" "$DATA"
install -d -m 0750 -g "$SVC_USER" "$CONF"
install -m 0755 "$TMP/hcldesigner" "$PREFIX/bin/hcldesigner"
if [[ -n $CA_FILE ]]; then install -m 0644 "$CA_FILE" "$CONF/ca.pem"; CA_FILE="$CONF/ca.pem"; fi

# Un worker déjà enrôlé garde son identité : on ne remplace que le binaire.
if [[ -s $DATA/agent.token ]]; then
  info "worker déjà enrôlé sur cette machine : mise à jour du binaire uniquement"
else
  umask 027
  cat > "$CONF/agent.env" <<EOF
HCLD_SERVER_URL=$URL
HCLD_JOIN_TOKEN=$TOKEN
HCLD_DATA_DIR=$DATA
HCLD_CA_FILE=$CA_FILE
HCLD_INSECURE_TLS=$INSECURE
EOF
  chgrp "$SVC_USER" "$CONF/agent.env"
fi

cat > "$UNIT" <<EOF
[Unit]
Description=HCLDesigner worker (Terraform / OpenTofu)
After=network-online.target
Wants=network-online.target

[Service]
User=$SVC_USER
Group=$SVC_USER
EnvironmentFile=$CONF/agent.env
ExecStart=$PREFIX/bin/hcldesigner agent
Restart=always
RestartSec=5
KillSignal=SIGINT
TimeoutStopSec=90
NoNewPrivileges=yes
PrivateTmp=yes
ProtectSystem=full
ProtectHome=yes
ReadWritePaths=$DATA

[Install]
WantedBy=multi-user.target
EOF
systemctl daemon-reload
systemctl enable hcldesigner-agent >/dev/null 2>&1
systemctl restart hcldesigner-agent

info "enrôlement auprès de $URL"
for _ in $(seq 1 30); do
  if [[ -s $DATA/agent.token ]]; then
    sed -i '/^HCLD_JOIN_TOKEN=/d' "$CONF/agent.env" # jeton à usage unique : inutile désormais
    ok "worker enrôlé et démarré (service hcldesigner-agent)"
    echo "  Logs      : journalctl -u hcldesigner-agent -f"
    echo "  Gestion   : HCLDesigner > Administration > Workers"
    echo "  Supprimer : curl -fsSL $URL/api/agent/install.sh | sudo bash -s -- --uninstall"
    exit 0
  fi
  sleep 2
done
journalctl -u hcldesigner-agent -n 30 --no-pager || true
die "le worker ne s'est pas enrôlé en 60 s (voir les logs ci-dessus)"
