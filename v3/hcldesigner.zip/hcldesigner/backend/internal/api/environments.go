package api

import (
	"encoding/json"
	"net/http"
	"strings"

	"github.com/go-chi/chi/v5"

	"github.com/AZIZI-Sajjad/hcldesigner/internal/core"
)

func (s *Server) environmentRoutes(r chi.Router) {
	r.Get("/backends", func(w http.ResponseWriter, r *http.Request) { writeJSON(w, http.StatusOK, core.BackendTypes) })
	r.Get("/projects/{pid}/environments", s.listEnvironments)
	r.Post("/projects/{pid}/environments", s.saveEnvironment)
	r.Put("/environments/{eid}", s.saveEnvironment)
	r.Delete("/environments/{eid}", s.deleteEnvironment)
	r.Post("/environments/{eid}/migrate", s.migrateBackend)
}

// envDTO masque les tfvars si l'utilisateur n'a pas le droit de les voir.
type envDTO struct {
	*core.Environment
	TFVarsVisible bool `json:"tfvarsVisible"`
	HasSecrets    bool `json:"hasBackendSecrets"`
}

func (s *Server) listEnvironments(w http.ResponseWriter, r *http.Request) {
	pid := chi.URLParam(r, "pid")
	if !can(w, r, "projects.view", pid, "") {
		return
	}
	envs, err := s.core.ListEnvironments(r.Context(), pid)
	if err != nil {
		fail(w, err)
		return
	}
	sub := subjectOf(r)
	out := make([]envDTO, 0, len(envs))
	for _, e := range envs {
		d := envDTO{Environment: e, TFVarsVisible: sub.Can("variables.sensitive.view", pid, e.Name), HasSecrets: e.BackendSecretID != nil}
		if !d.TFVarsVisible {
			e.TFVars = ""
		}
		out = append(out, d)
	}
	writeJSON(w, http.StatusOK, out)
}

type envInput struct {
	Name             string                     `json:"name"`
	BackendType      string                     `json:"backendType"`
	BackendConfig    map[string]json.RawMessage `json:"backendConfig"` // valeurs publiques et secrètes mélangées
	TFVars           *string                    `json:"tfvars"`        // nil = inchangé
	Workspace        string                     `json:"workspace"`
	CredentialIDs    []string                   `json:"credentialIds"`
	Protected        bool                       `json:"protected"`
	RequireApprovals int                        `json:"requireApprovals"`
	AllowDestroy     bool                       `json:"allowDestroy"`
	ChangeWindow     core.ChangeWindow          `json:"changeWindow"`
	WorkerLabels     []string                   `json:"workerLabels"`
}

// saveEnvironment crée (POST projet) ou modifie (PUT environnement) un environnement.
func (s *Server) saveEnvironment(w http.ResponseWriter, r *http.Request) {
	ctx := r.Context()
	var env *core.Environment
	if eid := chi.URLParam(r, "eid"); eid != "" {
		e, err := s.core.GetEnvironment(ctx, eid)
		if err != nil {
			fail(w, err)
			return
		}
		env = e
	} else {
		env = &core.Environment{ProjectID: chi.URLParam(r, "pid"), BackendType: "internal", CredentialIDs: []string{}, AllowDestroy: true}
	}
	if !can(w, r, "environments.manage", env.ProjectID, "") {
		return
	}
	var in envInput
	if !readJSON(w, r, &in) {
		return
	}
	in.Name = strings.TrimSpace(in.Name)
	if in.Name == "" || strings.ContainsAny(in.Name, " /\\") {
		writeError(w, http.StatusBadRequest, "nom d'environnement invalide")
		return
	}
	if in.RequireApprovals < 0 || in.RequireApprovals > 10 {
		writeError(w, http.StatusBadRequest, "nombre d'approbations entre 0 et 10")
		return
	}
	sub := subjectOf(r)
	if in.TFVars != nil && *in.TFVars != env.TFVars && !sub.Can("variables.sensitive.edit", env.ProjectID, in.Name) {
		writeError(w, http.StatusForbidden, "permission requise : variables.sensitive.edit")
		return
	}
	if !sameSet(in.CredentialIDs, env.CredentialIDs) && !sub.Can("credentials.use", "", "") {
		writeError(w, http.StatusForbidden, "permission requise : credentials.use")
		return
	}
	// Un changement de backend sur un environnement qui a déjà un state passe par la migration.
	if env.ID != "" && in.BackendType != env.BackendType && s.hasState(r, env.ID) {
		writeError(w, http.StatusConflict, "l'environnement possède un state : utilisez la migration de backend")
		return
	}
	if in.BackendType == "" {
		in.BackendType = "internal"
	}
	public, secrets, err := core.SplitBackendConfig(in.BackendType, in.BackendConfig)
	if err != nil {
		writeError(w, http.StatusBadRequest, err.Error())
		return
	}
	before := *env
	env.Name, env.BackendType, env.BackendConfig, env.Workspace = in.Name, in.BackendType, public, in.Workspace
	env.CredentialIDs, env.Protected, env.RequireApprovals, env.AllowDestroy, env.ChangeWindow = in.CredentialIDs, in.Protected, in.RequireApprovals, in.AllowDestroy, in.ChangeWindow
	env.WorkerLabels = in.WorkerLabels
	if env.CredentialIDs == nil {
		env.CredentialIDs = []string{}
	}
	// Environnement protégé (ex. prod) : au moins une approbation, destroy désactivé.
	if env.Protected {
		env.AllowDestroy = false
		if env.RequireApprovals < 1 {
			env.RequireApprovals = 1
		}
	}
	if in.TFVars != nil {
		env.TFVars = *in.TFVars
	}
	if err := s.storeBackendSecrets(r, env, secrets); err != nil {
		fail(w, err)
		return
	}
	if err := s.core.SaveEnvironment(ctx, env); err != nil {
		fail(w, err)
		return
	}
	before.TFVars, before.BackendConfig = "", nil // jamais de secret dans l'audit
	after := *env
	after.TFVars = ""
	s.audit(r, "environment.save", "environment", env.ID, map[string]any{"before": before, "after": after, "secretsUpdated": len(secrets) > 0})
	writeJSON(w, http.StatusOK, env)
}

func sameSet(a, b []string) bool {
	if len(a) != len(b) {
		return false
	}
	m := map[string]bool{}
	for _, x := range a {
		m[x] = true
	}
	for _, x := range b {
		if !m[x] {
			return false
		}
	}
	return true
}

func (s *Server) hasState(r *http.Request, envID string) bool {
	var has bool
	_ = s.core.DB.QueryRow(r.Context(), `SELECT EXISTS(SELECT 1 FROM state_versions WHERE environment_id=$1) OR EXISTS(SELECT 1 FROM runs WHERE environment_id=$1 AND status='applied')`, envID).Scan(&has)
	return has
}

// storeBackendSecrets fusionne les secrets saisis avec ceux du coffre (un champ vide conserve l'existant).
func (s *Server) storeBackendSecrets(r *http.Request, env *core.Environment, secrets map[string]string) error {
	if len(secrets) == 0 {
		return nil
	}
	ctx := r.Context()
	data := map[string]string{}
	id := ""
	if env.BackendSecretID != nil {
		id = *env.BackendSecretID
		if old, err := s.core.CredentialData(ctx, id); err == nil {
			data = old
		}
	}
	for k, v := range secrets {
		data[k] = v
	}
	name := "backend-" + env.ProjectID[:8] + "-" + env.Name
	newID, err := s.core.SaveCredentialData(ctx, id, name, "backend", "Secrets du backend "+env.BackendType, sessionOf(r).UserID, data)
	if err != nil {
		return err
	}
	env.BackendSecretID = &newID
	return nil
}

func (s *Server) deleteEnvironment(w http.ResponseWriter, r *http.Request) {
	env, err := s.core.GetEnvironment(r.Context(), chi.URLParam(r, "eid"))
	if err != nil {
		fail(w, err)
		return
	}
	if !can(w, r, "environments.manage", env.ProjectID, "") {
		return
	}
	if env.Protected {
		writeError(w, http.StatusConflict, "environnement protégé : retirez la protection avant suppression")
		return
	}
	if s.hasState(r, env.ID) {
		writeError(w, http.StatusConflict, "l'environnement possède un state : détruisez l'infrastructure ou supprimez le state avant")
		return
	}
	if _, err := s.core.DB.Exec(r.Context(), `DELETE FROM environments WHERE id=$1`, env.ID); err != nil {
		fail(w, err)
		return
	}
	if env.BackendSecretID != nil {
		_, _ = s.core.DB.Exec(r.Context(), `DELETE FROM credentials WHERE id=$1 AND kind='backend'`, *env.BackendSecretID)
	}
	s.audit(r, "environment.delete", "environment", env.ID, map[string]string{"name": env.Name})
	w.WriteHeader(http.StatusNoContent)
}

// migrateBackend : sauvegarde du state sur l'ancien backend (pull), bascule de configuration,
// puis push de la sauvegarde dans le nouveau backend. Les deux runs s'enchaînent dans la file.
func (s *Server) migrateBackend(w http.ResponseWriter, r *http.Request) {
	ctx := r.Context()
	env, err := s.core.GetEnvironment(ctx, chi.URLParam(r, "eid"))
	if err != nil {
		fail(w, err)
		return
	}
	if !can(w, r, "environments.manage", env.ProjectID, "") || !can(w, r, "state.edit", env.ProjectID, env.Name) {
		return
	}
	var in struct {
		BackendType   string                     `json:"backendType"`
		BackendConfig map[string]json.RawMessage `json:"backendConfig"`
	}
	if !readJSON(w, r, &in) {
		return
	}
	public, secrets, err := core.SplitBackendConfig(in.BackendType, in.BackendConfig)
	if err != nil {
		writeError(w, http.StatusBadRequest, err.Error())
		return
	}
	userID := sessionOf(r).UserID
	pull, err := s.core.CreateRun(ctx, core.RunRequest{ProjectID: env.ProjectID, EnvironmentID: env.ID, Operation: core.OpState,
		Options: core.RunOptions{StateCmd: "pull"}, UserID: userID})
	if err != nil {
		fail(w, err)
		return
	}
	newEnv := *env
	newEnv.BackendType, newEnv.BackendConfig = in.BackendType, public
	newEnv.BackendSecretID = nil
	if err := s.storeBackendSecrets(r, &newEnv, secrets); err != nil {
		fail(w, err)
		return
	}
	if err := s.core.SaveEnvironment(ctx, &newEnv); err != nil {
		fail(w, err)
		return
	}
	push, err := s.core.CreateRun(ctx, core.RunRequest{ProjectID: env.ProjectID, EnvironmentID: env.ID, Operation: core.OpState,
		Options: core.RunOptions{StateCmd: "push"}, UserID: userID})
	if err != nil {
		fail(w, err)
		return
	}
	s.audit(r, "environment.migrate_backend", "environment", env.ID, map[string]any{"from": env.BackendType, "to": in.BackendType, "pullRun": pull.ID, "pushRun": push.ID})
	writeJSON(w, http.StatusAccepted, map[string]string{"pullRunId": pull.ID, "pushRunId": push.ID})
}
