package api

import (
	"compress/gzip"
	"context"
	"crypto/sha256"
	_ "embed"
	"encoding/hex"
	"encoding/json"
	"errors"
	"io"
	"net/http"
	"os"
	"runtime"
	"strings"
	"sync"

	"github.com/go-chi/chi/v5"

	"github.com/AZIZI-Sajjad/hcldesigner/internal/agent"
	"github.com/AZIZI-Sajjad/hcldesigner/internal/core"
	"github.com/AZIZI-Sajjad/hcldesigner/internal/runner"
)

// Limites des corps envoyés par les agents (plans et schémas de providers volumineux).
const (
	maxAgentBody = 512 << 20 // résultat d'un run (plan binaire, state)
	maxLogChunk  = 4 << 20
)

type ctxWorker struct{}

func workerOf(r *http.Request) *core.Worker {
	w, _ := r.Context().Value(ctxWorker{}).(*core.Worker)
	return w
}

// agentRoutes : protocole des workers (authentification par jeton de worker, pas de session).
func (s *Server) agentRoutes(r chi.Router) {
	r.Get("/agent/install.sh", s.agentInstallScript)
	r.Get("/agent/binary", s.agentBinary)
	r.Get("/agent/binary.sha256", s.agentBinarySum)
	r.Post("/agent/register", s.agentRegister)
	r.Group(func(r chi.Router) {
		r.Use(s.authenticateWorker)
		r.Post("/agent/heartbeat", s.agentHeartbeat)
		r.Post("/agent/claim", s.agentClaim)
		r.Post("/agent/runs/{rid}/log", s.agentLog)
		r.Post("/agent/runs/{rid}/complete", s.agentComplete)
		r.Post("/agent/schema/{sid}/complete", s.agentSchemaComplete)
	})
}

func (s *Server) authenticateWorker(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		tok, ok := strings.CutPrefix(r.Header.Get("Authorization"), "Bearer ")
		if !ok || !strings.HasPrefix(tok, agent.WorkerTokenPrefix) {
			writeError(w, http.StatusUnauthorized, "jeton de worker requis")
			return
		}
		wk, err := s.core.WorkerByToken(r.Context(), tok)
		if err != nil {
			writeError(w, http.StatusUnauthorized, "jeton de worker refusé")
			return
		}
		next.ServeHTTP(w, r.WithContext(context.WithValue(r.Context(), ctxWorker{}, wk)))
	})
}

// readAgentJSON décode un corps JSON éventuellement compressé (gzip).
func readAgentJSON(w http.ResponseWriter, r *http.Request, v any) bool {
	var body io.Reader = http.MaxBytesReader(w, r.Body, maxAgentBody)
	if r.Header.Get("Content-Encoding") == "gzip" {
		gz, err := gzip.NewReader(body)
		if err != nil {
			writeError(w, http.StatusBadRequest, "gzip invalide")
			return false
		}
		defer gz.Close()
		body = io.LimitReader(gz, maxAgentBody)
	}
	if err := json.NewDecoder(body).Decode(v); err != nil {
		writeError(w, http.StatusBadRequest, "JSON invalide : "+err.Error())
		return false
	}
	return true
}

func (s *Server) agentRegister(w http.ResponseWriter, r *http.Request) {
	if !s.loginLim.allow(clientIP(r)) { // même protection anti-bruteforce que la connexion
		writeError(w, http.StatusTooManyRequests, "trop de tentatives")
		return
	}
	var req agent.RegisterRequest
	if !readJSON(w, r, &req) {
		return
	}
	if req.Protocol != agent.ProtocolVersion {
		writeError(w, http.StatusConflict, "version de protocole agent incompatible : mettez à jour le worker")
		return
	}
	wk, tok, err := s.core.RegisterWorker(r.Context(), req.JoinToken, req.Hostname, req.OSArch, req.Version, clientIP(r))
	if errors.Is(err, core.ErrJoinToken) {
		writeError(w, http.StatusUnauthorized, err.Error())
		return
	}
	if err != nil {
		fail(w, err)
		return
	}
	s.core.Audit.Log(r.Context(), auditEvent(clientIP(r), "worker:"+wk.Name, "worker.register"))
	writeJSON(w, http.StatusOK, agent.RegisterResponse{WorkerID: wk.ID, Name: wk.Name, Token: tok})
}

func (s *Server) agentHeartbeat(w http.ResponseWriter, r *http.Request) {
	wk := workerOf(r)
	var hb agent.Heartbeat
	if !readJSON(w, r, &hb) {
		return
	}
	if err := s.core.TouchWorker(r.Context(), wk.ID, hb.Hostname, hb.OSArch, hb.Version, clientIP(r), hb.Running); err != nil {
		fail(w, err)
		return
	}
	writeJSON(w, http.StatusOK, agent.HeartbeatResponse{Name: wk.Name, State: wk.State, Slots: wk.Slots,
		Cancel: runner.New(s.core).CancelRequested(r.Context(), wk)})
}

func (s *Server) agentClaim(w http.ResponseWriter, r *http.Request) {
	c, err := runner.New(s.core).Claim(r.Context(), workerOf(r))
	if err != nil {
		fail(w, err)
		return
	}
	if c == nil {
		w.WriteHeader(http.StatusNoContent)
		return
	}
	writeJSON(w, http.StatusOK, c)
}

func (s *Server) agentLog(w http.ResponseWriter, r *http.Request) {
	chunk, err := io.ReadAll(http.MaxBytesReader(w, r.Body, maxLogChunk))
	if err != nil {
		writeError(w, http.StatusRequestEntityTooLarge, "morceau de log trop volumineux")
		return
	}
	cancel, err := runner.New(s.core).AppendLog(r.Context(), workerOf(r), chi.URLParam(r, "rid"), chunk)
	if err != nil {
		writeJSON(w, http.StatusOK, agent.LogResponse{Cancel: true}) // run repris ou annulé : le worker s'arrête
		return
	}
	writeJSON(w, http.StatusOK, agent.LogResponse{Cancel: cancel})
}

func (s *Server) agentComplete(w http.ResponseWriter, r *http.Request) {
	var res agent.Result
	if !readAgentJSON(w, r, &res) {
		return
	}
	if err := runner.New(s.core).Complete(r.Context(), workerOf(r), chi.URLParam(r, "rid"), &res); err != nil {
		writeError(w, http.StatusConflict, err.Error())
		return
	}
	w.WriteHeader(http.StatusNoContent)
}

func (s *Server) agentSchemaComplete(w http.ResponseWriter, r *http.Request) {
	var res agent.SchemaResult
	if !readAgentJSON(w, r, &res) {
		return
	}
	if err := runner.New(s.core).CompleteSchema(r.Context(), workerOf(r), chi.URLParam(r, "sid"), &res); err != nil {
		writeError(w, http.StatusConflict, err.Error())
		return
	}
	w.WriteHeader(http.StatusNoContent)
}

// ---- Distribution du binaire et du script d'installation ----------------------------------

var (
	binSumOnce sync.Once
	binSum     string
)

// agentBinaryPath : le binaire du serveur sert aussi d'agent (même exécutable, rôle "agent").
func agentBinaryPath() (string, error) { return os.Executable() }

func (s *Server) agentBinarySum(w http.ResponseWriter, r *http.Request) {
	binSumOnce.Do(func() {
		p, err := agentBinaryPath()
		if err != nil {
			return
		}
		f, err := os.Open(p)
		if err != nil {
			return
		}
		defer f.Close()
		h := sha256.New()
		if _, err := io.Copy(h, f); err == nil {
			binSum = hex.EncodeToString(h.Sum(nil))
		}
	})
	if binSum == "" {
		writeError(w, http.StatusInternalServerError, "empreinte du binaire indisponible")
		return
	}
	w.Header().Set("Content-Type", "text/plain; charset=utf-8")
	_, _ = io.WriteString(w, binSum+"  hcldesigner\n")
}

// agentBinary : téléchargement réservé aux porteurs d'un jeton d'enrôlement valide ou d'un jeton de worker.
func (s *Server) agentBinary(w http.ResponseWriter, r *http.Request) {
	tok := r.Header.Get("X-Join-Token")
	if !s.validInstallToken(r.Context(), tok) {
		writeError(w, http.StatusUnauthorized, "jeton d'enrôlement requis (en-tête X-Join-Token)")
		return
	}
	p, err := agentBinaryPath()
	if err != nil {
		fail(w, err)
		return
	}
	w.Header().Set("Content-Type", "application/octet-stream")
	w.Header().Set("X-HCLD-Arch", runtime.GOOS+"/"+runtime.GOARCH)
	w.Header().Set("Content-Disposition", `attachment; filename="hcldesigner"`)
	http.ServeFile(w, r, p)
}

func (s *Server) validInstallToken(ctx context.Context, tok string) bool {
	switch {
	case strings.HasPrefix(tok, agent.JoinTokenPrefix):
		var ok bool
		_ = s.core.DB.QueryRow(ctx, `SELECT EXISTS(SELECT 1 FROM worker_join_tokens WHERE token_hash=$1 AND used_at IS NULL AND expires_at > now())`,
			core.HashSecret(tok)).Scan(&ok)
		return ok
	case strings.HasPrefix(tok, agent.WorkerTokenPrefix):
		_, err := s.core.WorkerByToken(ctx, tok)
		return err == nil
	}
	return false
}

func (s *Server) agentInstallScript(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "text/x-shellscript; charset=utf-8")
	_, _ = io.WriteString(w, agentInstallSh)
}

//go:embed agent-install.sh
var agentInstallSh string
