package api

import (
	"context"
	"errors"
	"fmt"
	"net/http"
	"os"
	"path/filepath"
	"strings"

	"github.com/go-chi/chi/v5"

	"github.com/AZIZI-Sajjad/hcldesigner/internal/core"
	"github.com/AZIZI-Sajjad/hcldesigner/internal/gitprov"
	"github.com/AZIZI-Sajjad/hcldesigner/internal/hclimport"
)

// gitRoutes : connexions Git personnelles (Mon compte) et dépôt lié à chaque projet.
func (s *Server) gitRoutes(r chi.Router) {
	r.Get("/me/git-connections", s.listGitConnections)
	r.Post("/me/git-connections", s.saveGitConnection)
	r.Put("/me/git-connections/{gid}", s.saveGitConnection)
	r.Delete("/me/git-connections/{gid}", s.deleteGitConnection)
	r.Post("/me/git-connections/{gid}/test", s.testGitConnection)
	r.Get("/me/git-connections/{gid}/repos", s.gitRepos)
	r.Get("/me/git-connections/{gid}/branches", s.gitBranches)
	r.Get("/me/git-connections/{gid}/dirs", s.gitDirs)

	r.Post("/projects/import-git", s.importGit)
	r.Get("/projects/{pid}/git", s.getProjectGit)
	r.Put("/projects/{pid}/git", s.linkProjectGit)
	r.Delete("/projects/{pid}/git", s.unlinkProjectGit)
	r.Post("/projects/{pid}/git/push", s.pushProjectGit)
	r.Post("/projects/{pid}/git/pull", s.pullProjectGit)
}

// ---- Connexions personnelles ----------------------------------------------------------------

func (s *Server) listGitConnections(w http.ResponseWriter, r *http.Request) {
	list, err := s.core.ListGitConnections(r.Context(), sessionOf(r).UserID)
	if err != nil {
		fail(w, err)
		return
	}
	writeJSON(w, http.StatusOK, list)
}

func (s *Server) saveGitConnection(w http.ResponseWriter, r *http.Request) {
	var in core.GitConnectionInput
	if !readJSON(w, r, &in) {
		return
	}
	id := chi.URLParam(r, "gid")
	g, err := s.core.SaveGitConnection(r.Context(), sessionOf(r).UserID, id, in)
	if err != nil {
		fail(w, bad(err.Error()))
		return
	}
	s.audit(r, "git.connection_save", "git_connection", g.ID, map[string]any{"name": g.Name, "provider": g.Provider, "baseUrl": g.BaseURL, "tokenChanged": in.Token != ""})
	writeJSON(w, http.StatusOK, g)
}

func (s *Server) deleteGitConnection(w http.ResponseWriter, r *http.Request) {
	id := chi.URLParam(r, "gid")
	if err := s.core.DeleteGitConnection(r.Context(), sessionOf(r).UserID, id); err != nil {
		fail(w, err)
		return
	}
	s.audit(r, "git.connection_delete", "git_connection", id, nil)
	w.WriteHeader(http.StatusNoContent)
}

// userConn charge une connexion de l'utilisateur courant (404 si elle appartient à un autre).
func (s *Server) userConn(w http.ResponseWriter, r *http.Request) *gitprov.Conn {
	c, err := s.core.GitConn(r.Context(), sessionOf(r).UserID, chi.URLParam(r, "gid"))
	if err != nil {
		fail(w, err)
		return nil
	}
	return c
}

func (s *Server) testGitConnection(w http.ResponseWriter, r *http.Request) {
	c := s.userConn(w, r)
	if c == nil {
		return
	}
	u, err := c.CurrentUser(r.Context())
	if err != nil {
		writeError(w, http.StatusBadGateway, err.Error())
		return
	}
	writeJSON(w, http.StatusOK, u)
}

func (s *Server) gitRepos(w http.ResponseWriter, r *http.Request) {
	c := s.userConn(w, r)
	if c == nil {
		return
	}
	repos, err := c.Repos(r.Context(), r.URL.Query().Get("q"))
	if err != nil {
		writeError(w, http.StatusBadGateway, err.Error())
		return
	}
	writeJSON(w, http.StatusOK, repos)
}

func (s *Server) gitBranches(w http.ResponseWriter, r *http.Request) {
	c := s.userConn(w, r)
	if c == nil {
		return
	}
	br, err := c.Branches(r.Context(), r.URL.Query().Get("repo"))
	if err != nil {
		writeError(w, http.StatusBadGateway, err.Error())
		return
	}
	writeJSON(w, http.StatusOK, br)
}

// gitDirs liste les dossiers du dépôt qui contiennent du code Terraform (choix du sous-dossier).
func (s *Server) gitDirs(w http.ResponseWriter, r *http.Request) {
	c := s.userConn(w, r)
	if c == nil {
		return
	}
	q := r.URL.Query()
	ws, err := s.clone(r.Context(), c, q.Get("repo"), q.Get("branch"))
	if err != nil {
		writeError(w, http.StatusBadGateway, err.Error())
		return
	}
	defer ws.Close()
	dirs, err := ws.TerraformDirs(r.Context())
	if err != nil {
		writeError(w, http.StatusBadGateway, err.Error())
		return
	}
	writeJSON(w, http.StatusOK, dirs)
}

func (s *Server) clone(ctx context.Context, c *gitprov.Conn, repo, branch string) (*gitprov.Workspace, error) {
	if strings.TrimSpace(repo) == "" {
		return nil, errors.New("dépôt obligatoire")
	}
	return gitprov.Clone(ctx, c, c.CloneURL(repo), branch, s.gitWorkRoot())
}

func (s *Server) gitWorkRoot() string {
	root := filepath.Join(s.core.Cfg.DataDir, "git")
	_ = osMkdirAll(root)
	return root
}

// ---- Import d'un projet depuis Git -----------------------------------------------------------

type gitSource struct {
	ConnectionID string `json:"connectionId"`
	Repo         string `json:"repo"`
	Branch       string `json:"branch"`
	Path         string `json:"path"` // sous-dossier contenant le code Terraform
}

// importGit lit le code Terraform d'un dépôt (sous-dossier compris) et le convertit en modèle,
// sans rien enregistrer : le frontend crée le projet puis le lie au dépôt.
func (s *Server) importGit(w http.ResponseWriter, r *http.Request) {
	if !can(w, r, "projects.create", "", "") {
		return
	}
	var in gitSource
	if !readJSON(w, r, &in) {
		return
	}
	c, err := s.core.GitConn(r.Context(), sessionOf(r).UserID, in.ConnectionID)
	if err != nil {
		fail(w, err)
		return
	}
	res, commit, sub, err := s.readRepo(r.Context(), c, in.Repo, in.Branch, in.Path)
	if err != nil {
		writeError(w, http.StatusBadGateway, err.Error())
		return
	}
	s.audit(r, "project.import_git", "project", "", map[string]any{"repo": in.Repo, "branch": in.Branch, "path": sub, "commit": commit})
	writeJSON(w, http.StatusOK, map[string]any{
		"model": res.Model, "diagnostics": res.Diagnostics, "files": res.Files,
		"git": core.ProjectGit{Provider: c.Provider, BaseURL: c.BaseURL, Repo: strings.Trim(in.Repo, "/"), Branch: in.Branch, Path: sub, LastCommit: commit},
	})
}

// readRepo clone la branche et convertit les .tf du sous-dossier.
func (s *Server) readRepo(ctx context.Context, c *gitprov.Conn, repo, branch, path string) (*hclimport.Result, string, string, error) {
	sub, err := gitprov.CleanPath(path)
	if err != nil {
		return nil, "", "", err
	}
	ws, err := s.clone(ctx, c, repo, branch)
	if err != nil {
		return nil, "", "", err
	}
	defer ws.Close()
	files, err := ws.ReadTerraform(sub)
	if err != nil {
		return nil, "", "", err
	}
	commit, _ := ws.Head(ctx)
	return s.importModel(ctx, files, nil), commit, sub, nil
}

// ---- Dépôt lié au projet ----------------------------------------------------------------------

func (s *Server) getProjectGit(w http.ResponseWriter, r *http.Request) {
	p := s.projectFor(w, r, "projects.view")
	if p == nil {
		return
	}
	g, err := s.core.GetProjectGit(r.Context(), p.ID)
	if err != nil {
		writeJSON(w, http.StatusOK, map[string]any{"linked": false})
		return
	}
	// L'utilisateur courant peut-il pousser ? (connexion personnelle vers cette forge)
	_, connErr := s.core.GitConnFor(r.Context(), sessionOf(r).UserID, g.Provider, g.BaseURL)
	writeJSON(w, http.StatusOK, map[string]any{"linked": true, "git": g, "hasConnection": connErr == nil})
}

func (s *Server) linkProjectGit(w http.ResponseWriter, r *http.Request) {
	p := s.projectFor(w, r, "git.link")
	if p == nil {
		return
	}
	var in core.ProjectGit
	if !readJSON(w, r, &in) {
		return
	}
	g, err := s.core.LinkProjectGit(r.Context(), p.ID, in)
	if err != nil {
		fail(w, bad(err.Error()))
		return
	}
	s.audit(r, "project.git_link", "project", p.ID, map[string]any{"repo": g.Repo, "branch": g.Branch, "path": g.Path, "baseUrl": g.BaseURL})
	writeJSON(w, http.StatusOK, g)
}

func (s *Server) unlinkProjectGit(w http.ResponseWriter, r *http.Request) {
	p := s.projectFor(w, r, "git.link")
	if p == nil {
		return
	}
	if err := s.core.UnlinkProjectGit(r.Context(), p.ID); err != nil {
		fail(w, err)
		return
	}
	s.audit(r, "project.git_unlink", "project", p.ID, nil)
	w.WriteHeader(http.StatusNoContent)
}

// pushProjectGit génère le code et le pousse dans le sous-dossier du dépôt, directement sur la
// branche liée ou sur une nouvelle branche avec ouverture d'une pull/merge request.
func (s *Server) pushProjectGit(w http.ResponseWriter, r *http.Request) {
	p := s.projectFor(w, r, "git.push")
	if p == nil {
		return
	}
	var in struct {
		Message   string `json:"message"`
		Mode      string `json:"mode"` // direct | pr
		NewBranch string `json:"newBranch"`
		PRTitle   string `json:"prTitle"`
		PRBody    string `json:"prBody"`
	}
	if !readJSON(w, r, &in) {
		return
	}
	g, err := s.core.GetProjectGit(r.Context(), p.ID)
	if err != nil {
		writeError(w, http.StatusBadRequest, "projet non lié à un dépôt Git")
		return
	}
	sess := sessionOf(r)
	c, err := s.core.GitConnFor(r.Context(), sess.UserID, g.Provider, g.BaseURL)
	if err != nil {
		writeError(w, http.StatusPreconditionFailed, err.Error())
		return
	}
	res, err := s.core.Generate(r.Context(), &p.Model, core.GenerateOptions{})
	if err != nil {
		fail(w, err)
		return
	}
	for _, d := range res.Diags {
		if d.Severity == "error" {
			writeError(w, http.StatusUnprocessableEntity, "génération impossible : "+d.Summary)
			return
		}
	}
	files := map[string]string{}
	for k, v := range res.Files {
		files[k] = v
	}
	if p.LockFile != "" {
		files[".terraform.lock.hcl"] = p.LockFile
	}
	target := g.Branch
	if in.Mode == "pr" {
		target = strings.TrimSpace(in.NewBranch)
		if target == "" || target == g.Branch {
			writeError(w, http.StatusBadRequest, "nom de la nouvelle branche obligatoire (différent de "+g.Branch+")")
			return
		}
	}
	msg := strings.TrimSpace(in.Message)
	if msg == "" {
		msg = fmt.Sprintf("HCLDesigner : %s v%d", p.Name, p.Version)
	}
	ws, err := s.clone(r.Context(), c, g.Repo, g.Branch)
	if err != nil {
		writeError(w, http.StatusBadGateway, err.Error())
		return
	}
	defer ws.Close()
	pr, err := ws.Commit(r.Context(), g.Path, files, target, msg)
	if head, nothing := gitprov.IsNothingToCommit(err); nothing {
		writeJSON(w, http.StatusOK, map[string]any{"nothing": true, "commit": head, "branch": target})
		return
	}
	if err != nil {
		writeError(w, http.StatusBadGateway, err.Error())
		return
	}
	out := map[string]any{"commit": pr.Commit, "branch": pr.Branch}
	kind := "push"
	if in.Mode == "pr" {
		title := strings.TrimSpace(in.PRTitle)
		if title == "" {
			title = msg
		}
		url, err := c.OpenChangeRequest(r.Context(), g.Repo, target, g.Branch, title, in.PRBody)
		if err != nil {
			// La branche est poussée : on le signale même si l'ouverture de la PR/MR échoue.
			out["prError"] = err.Error()
		} else {
			out["prUrl"] = url
			kind = "pr"
		}
	}
	s.core.RecordGitSync(r.Context(), p.ID, sess.UserID, kind, pr.Commit)
	s.audit(r, "project.git_push", "project", p.ID, map[string]any{"repo": g.Repo, "branch": target, "path": g.Path, "commit": pr.Commit, "mode": in.Mode})
	writeJSON(w, http.StatusOK, out)
}

// pullProjectGit réimporte le code du dépôt dans une nouvelle version du modèle
// (les environnements, credentials et runs du projet sont conservés).
func (s *Server) pullProjectGit(w http.ResponseWriter, r *http.Request) {
	p := s.projectFor(w, r, "projects.edit")
	if p == nil {
		return
	}
	g, err := s.core.GetProjectGit(r.Context(), p.ID)
	if err != nil {
		writeError(w, http.StatusBadRequest, "projet non lié à un dépôt Git")
		return
	}
	sess := sessionOf(r)
	c, err := s.core.GitConnFor(r.Context(), sess.UserID, g.Provider, g.BaseURL)
	if err != nil {
		writeError(w, http.StatusPreconditionFailed, err.Error())
		return
	}
	res, commit, _, err := s.readRepo(r.Context(), c, g.Repo, g.Branch, g.Path)
	if err != nil {
		writeError(w, http.StatusBadGateway, err.Error())
		return
	}
	m := res.Model
	m.Engine, m.EngineVersion = p.Model.Engine, p.Model.EngineVersion // le moteur reste un réglage du projet
	short := commit
	if len(short) > 8 {
		short = short[:8]
	}
	saved, err := s.core.SaveModel(r.Context(), p.ID, p.Version, m, sess.UserID, "import Git "+g.Branch+"@"+short)
	if err != nil {
		fail(w, err)
		return
	}
	s.core.RecordGitSync(r.Context(), p.ID, sess.UserID, "import", commit)
	s.audit(r, "project.git_pull", "project", p.ID, map[string]any{"repo": g.Repo, "branch": g.Branch, "path": g.Path, "commit": commit})
	writeJSON(w, http.StatusOK, map[string]any{"version": saved.Version, "commit": commit, "diagnostics": res.Diagnostics})
}

func osMkdirAll(dir string) error { return os.MkdirAll(dir, 0o700) }
