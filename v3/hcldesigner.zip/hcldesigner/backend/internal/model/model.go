// Package model définit le modèle interne d'un projet HCLDesigner.
// Il est sérialisé en JSON (colonne projects.model) et partagé avec le frontend
// (frontend/src/types/model.ts doit rester aligné).
package model

import (
	"encoding/json"
	"fmt"
	"regexp"
	"sort"
	"strings"
)

const SchemaVersion = 1

// Kinds de nœuds.
const (
	KindResource = "resource"
	KindData     = "data"
	KindModule   = "module"
	KindVariable = "variable"
	KindLocal    = "local"
	KindOutput   = "output"
)

// Modes de valeur.
const (
	ModeLiteral = "literal"
	ModeRef     = "ref"
	ModeExpr    = "expr"
	ModeList    = "list"
	ModeNull    = "null"
)

// Modes de découpage des fichiers.
const (
	LayoutSingle   = "single"
	LayoutStandard = "standard"
	LayoutCategory = "category"
	LayoutService  = "service"
	LayoutCustom   = "custom"
)

var LabelRegexp = regexp.MustCompile(`^[a-zA-Z_][a-zA-Z0-9_-]*$`)

type Project struct {
	SchemaVersion int              `json:"schemaVersion"`
	Engine        string           `json:"engine"`          // terraform | opentofu
	EngineVersion string           `json:"engineVersion"`   // version exacte du binaire
	RequiredVer   string           `json:"requiredVersion"` // contrainte required_version
	Providers     []ProviderConfig `json:"providers"`
	Nodes         []Node           `json:"nodes"`
	FileLayout    FileLayout       `json:"fileLayout"`
	Settings      Settings         `json:"settings"`
}

type Settings struct {
	IncludeDefaults bool `json:"includeDefaults"`
}

type ProviderConfig struct {
	LocalName  string             `json:"localName"` // ex: aws
	Source     string             `json:"source"`    // ex: hashicorp/aws
	Version    string             `json:"version"`   // contrainte ex: ~> 5.0
	Resolved   string             `json:"resolved"`  // version exacte résolue (cache schéma)
	Alias      string             `json:"alias"`
	Config     map[string]Value   `json:"config"`
	ConfigBlks map[string][]Block `json:"configBlocks,omitempty"`
}

// Key identifie un provider configuré : "aws" ou "aws.eu".
func (p ProviderConfig) Key() string {
	if p.Alias != "" {
		return p.LocalName + "." + p.Alias
	}
	return p.LocalName
}

type FileLayout struct {
	Mode        string       `json:"mode"`
	Rules       []LayoutRule `json:"rules"`
	CustomFiles []string     `json:"customFiles"`
}

type LayoutRule struct {
	Pattern string `json:"pattern"` // glob sur le type, ex: aws_instance*
	File    string `json:"file"`    // ex: ec2.tf
}

type Position struct {
	X float64 `json:"x"`
	Y float64 `json:"y"`
}

type Node struct {
	ID        string             `json:"id"`
	Kind      string             `json:"kind"`
	Type      string             `json:"type"`               // type Terraform, ou id du module pour un nœud module
	Label     string             `json:"label"`              // nom logique HCL
	Provider  string             `json:"provider,omitempty"` // clé ProviderConfig (aws, aws.eu)
	Attrs     map[string]Value   `json:"attrs"`
	Blocks    map[string][]Block `json:"blocks,omitempty"`
	Meta      Meta               `json:"meta"`
	File      string             `json:"file,omitempty"` // fichier cible (mode custom)
	Position  Position           `json:"position"`
	ImportID  string             `json:"importId,omitempty"`
	MovedFrom string             `json:"movedFrom,omitempty"`
	Module    *ModuleRef         `json:"module,omitempty"`
	Group     string             `json:"group,omitempty"`
	// Imbrication visuelle (sans effet sur le code) : Parent = id du cadre conteneur,
	// Position est alors relative au coin du cadre. Size et Collapsed ne servent qu'aux cadres.
	Parent    string `json:"parent,omitempty"`
	Size      *Size  `json:"size,omitempty"`
	Collapsed bool   `json:"collapsed,omitempty"`
}

// Size est la taille d'un cadre conteneur sur le canvas.
type Size struct {
	W float64 `json:"w"`
	H float64 `json:"h"`
}

type ModuleRef struct {
	SourceKind string `json:"sourceKind"` // internal | registry | git | local
	ModuleID   string `json:"moduleId,omitempty"`
	Name       string `json:"name,omitempty"` // nom du module interne
	Source     string `json:"source,omitempty"`
	Version    string `json:"version,omitempty"`
	// Interface connue d'un module externe (lue sur le Registry ou déclarée à la main).
	Inputs  []ModuleVar    `json:"inputs,omitempty"`
	Outputs []ModuleOutput `json:"outputs,omitempty"`
}

// ModuleVar est une variable d'entrée de module.
type ModuleVar struct {
	Name        string `json:"name"`
	Type        string `json:"type"`
	Default     string `json:"default,omitempty"` // littéral JSON
	Required    bool   `json:"required"`
	Description string `json:"description,omitempty"`
	Sensitive   bool   `json:"sensitive"`
}

// ModuleOutput est une sortie de module.
type ModuleOutput struct {
	Name        string `json:"name"`
	Description string `json:"description,omitempty"`
}

type Block struct {
	Attrs  map[string]Value   `json:"attrs"`
	Blocks map[string][]Block `json:"blocks,omitempty"`
	Key    string             `json:"key,omitempty"` // nesting_mode map
}

type Meta struct {
	Count      *Value      `json:"count,omitempty"`
	ForEach    *Value      `json:"forEach,omitempty"`
	DependsOn  []string    `json:"dependsOn,omitempty"` // ids de nœuds
	Lifecycle  *Lifecycle  `json:"lifecycle,omitempty"`
	Conditions []Condition `json:"conditions,omitempty"`
}

type Lifecycle struct {
	CreateBeforeDestroy bool     `json:"createBeforeDestroy"`
	PreventDestroy      bool     `json:"preventDestroy"`
	IgnoreChanges       []string `json:"ignoreChanges"`
	IgnoreAll           bool     `json:"ignoreAll"`
	ReplaceTriggeredBy  []string `json:"replaceTriggeredBy"` // expressions
}

type Condition struct {
	Kind         string `json:"kind"` // precondition | postcondition
	Condition    string `json:"condition"`
	ErrorMessage string `json:"errorMessage"`
}

// Value est une valeur d'attribut : littérale, référence, expression, liste ou null.
type Value struct {
	Mode  string          `json:"mode"`
	Value json.RawMessage `json:"value,omitempty"`
	Ref   *Ref            `json:"ref,omitempty"`
	Expr  string          `json:"expr,omitempty"`
	Items []Value         `json:"items,omitempty"`
}

type Ref struct {
	NodeID    string `json:"node"`
	Attr      string `json:"attr"`      // attribut source (id, arn, ... ou nom d'output de module)
	IndexMode string `json:"indexMode"` // "" | "index" | "splat" | "values" | "each"
	Index     string `json:"index,omitempty"`
}

func (v Value) IsEmpty() bool {
	switch v.Mode {
	case "", ModeNull:
		return true
	case ModeLiteral:
		return len(v.Value) == 0 || string(v.Value) == "null"
	case ModeExpr:
		return v.Expr == ""
	case ModeRef:
		return v.Ref == nil || v.Ref.NodeID == ""
	case ModeList:
		return len(v.Items) == 0
	}
	return true
}

// NodeByID indexe les nœuds.
func (p *Project) NodeByID() map[string]*Node {
	m := make(map[string]*Node, len(p.Nodes))
	for i := range p.Nodes {
		m[p.Nodes[i].ID] = &p.Nodes[i]
	}
	return m
}

func (p *Project) ProviderByKey(key string) *ProviderConfig {
	for i := range p.Providers {
		if p.Providers[i].Key() == key {
			return &p.Providers[i]
		}
	}
	return nil
}

// Address renvoie l'adresse Terraform d'un nœud (aws_vpc.main, data.x.y, var.a, local.b, module.c).
func (n *Node) Address() string {
	switch n.Kind {
	case KindResource:
		return n.Type + "." + n.Label
	case KindData:
		return "data." + n.Type + "." + n.Label
	case KindModule:
		return "module." + n.Label
	case KindVariable:
		return "var." + n.Label
	case KindLocal:
		return "local." + n.Label
	case KindOutput:
		return "output." + n.Label
	}
	return n.Label
}

// IsMulti indique si le nœud utilise count ou for_each.
func (n *Node) IsMulti() (count, forEach bool) {
	return n.Meta.Count != nil && !n.Meta.Count.IsEmpty(), n.Meta.ForEach != nil && !n.Meta.ForEach.IsEmpty()
}

// Edge est dérivé du modèle : il n'est pas stocké, la source de vérité reste Attrs/Meta.
type Edge struct {
	ID         string `json:"id"`
	Source     string `json:"source"`
	SourceAttr string `json:"sourceAttr"`
	Target     string `json:"target"`
	TargetPath string `json:"targetPath"`
	Kind       string `json:"kind"` // ref | expr | depends_on
}

// exprAddrRe repère les chaînes pointées (aws_vpc.main.id, var.x, data.a.b.c) dans une expression.
var exprAddrRe = regexp.MustCompile(`[A-Za-z_][A-Za-z0-9_-]*(?:\.[A-Za-z_][A-Za-z0-9_-]*)+`)

// ExprRefs renvoie les ids des nœuds référencés dans une expression brute (sans doublon, ordre d'apparition).
// Une chaîne n'est retenue que si elle correspond à l'adresse d'un nœud existant : les faux positifs
// (texte entre guillemets ressemblant à une adresse) restent donc limités aux homonymes exacts.
func ExprRefs(expr string, byAddr map[string]string) []string {
	var out []string
	seen := map[string]bool{}
	for _, m := range exprAddrRe.FindAllString(expr, -1) {
		parts := strings.Split(m, ".")
		n := 2
		if parts[0] == "data" {
			n = 3
		}
		if len(parts) < n {
			continue
		}
		if id, ok := byAddr[strings.Join(parts[:n], ".")]; ok && !seen[id] {
			seen[id] = true
			out = append(out, id)
		}
	}
	return out
}

// Edges reconstruit la liste des liens depuis les références.
func (p *Project) Edges() []Edge {
	var out []Edge
	byAddr := make(map[string]string, len(p.Nodes))
	for _, n := range p.Nodes {
		if n.Kind != KindOutput {
			byAddr[n.Address()] = n.ID
		}
	}
	for _, n := range p.Nodes {
		var walk func(path string, v Value)
		walk = func(path string, v Value) {
			switch v.Mode {
			case ModeRef:
				if v.Ref != nil && v.Ref.NodeID != "" {
					out = append(out, Edge{
						ID:     fmt.Sprintf("%s:%s->%s:%s", v.Ref.NodeID, v.Ref.Attr, n.ID, path),
						Source: v.Ref.NodeID, SourceAttr: v.Ref.Attr, Target: n.ID, TargetPath: path, Kind: "ref",
					})
				}
			case ModeList:
				for i, it := range v.Items {
					walk(fmt.Sprintf("%s[%d]", path, i), it)
				}
			case ModeExpr:
				for _, src := range ExprRefs(v.Expr, byAddr) {
					if src == n.ID {
						continue
					}
					out = append(out, Edge{
						ID:     fmt.Sprintf("%s:expr->%s:%s", src, n.ID, path),
						Source: src, Target: n.ID, TargetPath: path, Kind: "expr",
					})
				}
			}
		}
		for _, k := range SortedKeys(n.Attrs) {
			walk(k, n.Attrs[k])
		}
		var walkBlocks func(prefix string, blocks map[string][]Block)
		walkBlocks = func(prefix string, blocks map[string][]Block) {
			for _, bn := range SortedKeys(blocks) {
				for i, b := range blocks[bn] {
					p := fmt.Sprintf("%s%s[%d]", prefix, bn, i)
					for _, k := range SortedKeys(b.Attrs) {
						walk(p+"."+k, b.Attrs[k])
					}
					walkBlocks(p+".", b.Blocks)
				}
			}
		}
		walkBlocks("", n.Blocks)
		if n.Meta.Count != nil {
			walk("count", *n.Meta.Count)
		}
		if n.Meta.ForEach != nil {
			walk("for_each", *n.Meta.ForEach)
		}
		for _, d := range n.Meta.DependsOn {
			out = append(out, Edge{ID: d + "->" + n.ID + ":depends_on", Source: d, Target: n.ID, TargetPath: "depends_on", Kind: "depends_on"})
		}
	}
	return out
}

func SortedKeys[V any](m map[string]V) []string {
	keys := make([]string, 0, len(m))
	for k := range m {
		keys = append(keys, k)
	}
	sort.Strings(keys)
	return keys
}

// Validate effectue les contrôles structurels (niveau 2) sur le modèle.
func (p *Project) Validate() []Diagnostic {
	diags := []Diagnostic{}
	nodes := p.NodeByID()
	seen := map[string]string{}
	for _, n := range p.Nodes {
		if !LabelRegexp.MatchString(n.Label) {
			diags = append(diags, Diagnostic{Severity: "error", NodeID: n.ID, Summary: fmt.Sprintf("label HCL invalide : %q", n.Label)})
		}
		key := n.Kind + ":" + n.Type + ":" + n.Label
		if n.Kind == KindVariable || n.Kind == KindLocal || n.Kind == KindOutput || n.Kind == KindModule {
			key = n.Kind + ":" + n.Label
		}
		if other, ok := seen[key]; ok {
			diags = append(diags, Diagnostic{Severity: "error", NodeID: n.ID, Summary: fmt.Sprintf("label %q déjà utilisé (nœud %s)", n.Label, other)})
		}
		seen[key] = n.ID
		if n.Provider != "" && p.ProviderByKey(n.Provider) == nil {
			diags = append(diags, Diagnostic{Severity: "error", NodeID: n.ID, Summary: fmt.Sprintf("provider %q non déclaré dans le projet", n.Provider)})
		}
	}
	for _, e := range p.Edges() {
		if _, ok := nodes[e.Source]; !ok {
			diags = append(diags, Diagnostic{Severity: "error", NodeID: e.Target, Path: e.TargetPath, Summary: "référence vers un nœud supprimé"})
		}
	}
	for _, n := range p.Nodes {
		if n.Parent == "" {
			continue
		}
		if _, ok := nodes[n.Parent]; !ok {
			diags = append(diags, Diagnostic{Severity: "warning", NodeID: n.ID, Summary: "cadre parent introuvable : l'objet sera affiché hors cadre"})
		} else if p.parentLoop(n.ID) {
			diags = append(diags, Diagnostic{Severity: "error", NodeID: n.ID, Summary: "imbrication circulaire de cadres"})
		}
	}
	if cyc := p.FindCycle(); len(cyc) > 0 {
		diags = append(diags, Diagnostic{Severity: "error", NodeID: cyc[0], Summary: fmt.Sprintf("cycle de dépendances : %v", cyc)})
	}
	return diags
}

// parentLoop détecte une chaîne de parents qui revient sur le nœud de départ.
func (p *Project) parentLoop(id string) bool {
	byID := p.NodeByID()
	seen := map[string]bool{id: true}
	for cur := byID[id]; cur != nil && cur.Parent != ""; cur = byID[cur.Parent] {
		if seen[cur.Parent] {
			return true
		}
		seen[cur.Parent] = true
	}
	return false
}

type Diagnostic struct {
	Severity string `json:"severity"`
	NodeID   string `json:"nodeId,omitempty"`
	Path     string `json:"path,omitempty"`
	Summary  string `json:"summary"`
	Detail   string `json:"detail,omitempty"`
	File     string `json:"file,omitempty"`
	Line     int    `json:"line,omitempty"`
}

// FindCycle renvoie un cycle (liste d'ids) s'il en existe un.
func (p *Project) FindCycle() []string {
	adj := map[string][]string{}
	for _, e := range p.Edges() {
		adj[e.Source] = append(adj[e.Source], e.Target)
	}
	const (
		white = 0
		grey  = 1
		black = 2
	)
	color := map[string]int{}
	var stack []string
	var cycle []string
	var dfs func(u string) bool
	dfs = func(u string) bool {
		color[u] = grey
		stack = append(stack, u)
		for _, v := range adj[u] {
			if color[v] == grey {
				for i := len(stack) - 1; i >= 0; i-- {
					if stack[i] == v {
						cycle = append([]string{}, stack[i:]...)
						break
					}
				}
				return true
			}
			if color[v] == white && dfs(v) {
				return true
			}
		}
		stack = stack[:len(stack)-1]
		color[u] = black
		return false
	}
	ids := make([]string, 0, len(p.Nodes))
	for _, n := range p.Nodes {
		ids = append(ids, n.ID)
	}
	sort.Strings(ids)
	for _, id := range ids {
		if color[id] == white && dfs(id) {
			return cycle
		}
	}
	return nil
}

// WouldCycle indique si l'ajout du lien source -> target crée un cycle.
func (p *Project) WouldCycle(source, target string) bool {
	if source == target {
		return true
	}
	adj := map[string][]string{}
	for _, e := range p.Edges() {
		adj[e.Source] = append(adj[e.Source], e.Target)
	}
	// existe-t-il un chemin target -> source ?
	seen := map[string]bool{}
	var q = []string{target}
	for len(q) > 0 {
		u := q[0]
		q = q[1:]
		if u == source {
			return true
		}
		if seen[u] {
			continue
		}
		seen[u] = true
		q = append(q, adj[u]...)
	}
	return false
}

func New() Project {
	return Project{
		SchemaVersion: SchemaVersion,
		Engine:        "terraform",
		RequiredVer:   ">= 1.5.0",
		Providers:     []ProviderConfig{},
		Nodes:         []Node{},
		FileLayout:    FileLayout{Mode: LayoutStandard, Rules: []LayoutRule{}, CustomFiles: []string{}},
		Settings:      Settings{IncludeDefaults: false},
	}
}
