package core

import (
	"context"
	"crypto/rand"
	"crypto/sha256"
	"encoding/base64"
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"regexp"
	"strings"
	"time"

	"github.com/jackc/pgx/v5"

	"github.com/AZIZI-Sajjad/hcldesigner/internal/db"
)

// Worker : agent d'exécution enrôlé (le worker par défaut tourne dans le conteneur "worker").
type Worker struct {
	ID         string     `json:"id"`
	Name       string     `json:"name"`
	State      string     `json:"state"` // active | paused | revoked
	Slots      int        `json:"slots"`
	Labels     []string   `json:"labels"`
	IsDefault  bool       `json:"isDefault"`
	Version    string     `json:"version"`
	Hostname   string     `json:"hostname"`
	OSArch     string     `json:"osArch"`
	RemoteAddr string     `json:"remoteAddr"`
	Running    int        `json:"running"`
	LastSeenAt *time.Time `json:"lastSeenAt"`
	Online     bool       `json:"online"` // signal de vie depuis moins de 45 s
	CreatedAt  time.Time  `json:"createdAt"`
}

// Délai sans signal de vie au-delà duquel un worker est considéré hors ligne.
const workerOnlineWindow = 45 * time.Second

// DefaultWorkerName : nom du worker livré avec l'installation.
const DefaultWorkerName = "default"

var (
	ErrWorkerRevoked = errors.New("worker révoqué")
	ErrJoinToken     = errors.New("jeton d'enrôlement invalide, expiré ou déjà utilisé")
	workerNameRe     = regexp.MustCompile(`^[a-z0-9][a-z0-9._-]{0,62}$`)
	labelRe          = regexp.MustCompile(`^[a-z0-9][a-z0-9._-]{0,31}$`)
)

// settingsKeyDefaultWorker : {"disabled": true} quand l'administrateur a supprimé le worker par défaut.
const settingsKeyDefaultWorker = "default_worker"

const workerCols = `id, name, state, slots, labels, is_default, version, hostname, os_arch, remote_addr, running, last_seen_at, created_at`

func scanWorker(row pgx.Row) (*Worker, error) {
	var w Worker
	if err := row.Scan(&w.ID, &w.Name, &w.State, &w.Slots, &w.Labels, &w.IsDefault, &w.Version, &w.Hostname, &w.OSArch,
		&w.RemoteAddr, &w.Running, &w.LastSeenAt, &w.CreatedAt); err != nil {
		return nil, db.NotFound(err)
	}
	w.Online = w.LastSeenAt != nil && time.Since(*w.LastSeenAt) < workerOnlineWindow
	if w.Labels == nil {
		w.Labels = []string{}
	}
	return &w, nil
}

// NewSecret génère un jeton aléatoire de 256 bits avec le préfixe donné.
func NewSecret(prefix string) string {
	b := make([]byte, 32)
	_, _ = rand.Read(b)
	return prefix + base64.RawURLEncoding.EncodeToString(b)
}

// HashSecret : seule l'empreinte des jetons est stockée.
func HashSecret(s string) []byte {
	h := sha256.Sum256([]byte(s))
	return h[:]
}

// ValidateWorkerSpec contrôle nom, slots et labels saisis par l'administrateur.
func ValidateWorkerSpec(name string, slots int, labels []string) error {
	if !workerNameRe.MatchString(name) {
		return fmt.Errorf("nom de worker invalide %q (minuscules, chiffres, . _ -)", name)
	}
	if slots < 1 || slots > 64 {
		return fmt.Errorf("slots : entre 1 et 64")
	}
	for _, l := range labels {
		if !labelRe.MatchString(l) {
			return fmt.Errorf("label invalide %q (minuscules, chiffres, . _ -)", l)
		}
	}
	return nil
}

func (c *Core) ListWorkers(ctx context.Context) ([]Worker, error) {
	rows, err := c.DB.Query(ctx, `SELECT `+workerCols+` FROM workers ORDER BY is_default DESC, name`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	out := []Worker{}
	for rows.Next() {
		w, err := scanWorker(rows)
		if err != nil {
			return nil, err
		}
		out = append(out, *w)
	}
	return out, rows.Err()
}

func (c *Core) GetWorker(ctx context.Context, id string) (*Worker, error) {
	return scanWorker(c.DB.QueryRow(ctx, `SELECT `+workerCols+` FROM workers WHERE id=$1`, id))
}

// WorkerByToken authentifie un agent. Un worker révoqué est refusé.
func (c *Core) WorkerByToken(ctx context.Context, token string) (*Worker, error) {
	w, err := scanWorker(c.DB.QueryRow(ctx, `SELECT `+workerCols+` FROM workers WHERE token_hash=$1`, HashSecret(token)))
	if err != nil {
		return nil, err
	}
	if w.State == "revoked" {
		return nil, ErrWorkerRevoked
	}
	return w, nil
}

// CreateJoinToken prépare l'enrôlement d'un nouveau worker (ou le réenrôlement de workerID).
func (c *Core) CreateJoinToken(ctx context.Context, name string, slots int, labels []string, ttl time.Duration, by, workerID string) (string, time.Time, error) {
	if labels == nil {
		labels = []string{}
	}
	if err := ValidateWorkerSpec(name, slots, labels); err != nil {
		return "", time.Time{}, err
	}
	if workerID == "" {
		var exists bool
		_ = c.DB.QueryRow(ctx, `SELECT EXISTS(SELECT 1 FROM workers WHERE name=$1)`, name).Scan(&exists)
		if exists {
			return "", time.Time{}, fmt.Errorf("un worker %q existe déjà", name)
		}
	}
	tok := NewSecret("hcldj_")
	exp := time.Now().Add(ttl)
	_, err := c.DB.Exec(ctx, `INSERT INTO worker_join_tokens(token_hash, name, slots, labels, expires_at, created_by, worker_id)
		VALUES ($1,$2,$3,$4,$5,NULLIF($6,'')::uuid,NULLIF($7,'')::uuid)`, HashSecret(tok), name, slots, labels, exp, by, workerID)
	return tok, exp, err
}

// RegisterWorker consomme un jeton d'enrôlement et renvoie le worker et son jeton propre.
func (c *Core) RegisterWorker(ctx context.Context, joinToken, hostname, osArch, version, remoteAddr string) (*Worker, string, error) {
	tx, err := c.DB.Begin(ctx)
	if err != nil {
		return nil, "", err
	}
	defer tx.Rollback(ctx)
	var jid, name string
	var slots int
	var labels []string
	var workerID *string
	err = tx.QueryRow(ctx, `SELECT id, name, slots, labels, worker_id FROM worker_join_tokens
		WHERE token_hash=$1 AND used_at IS NULL AND expires_at > now() FOR UPDATE`, HashSecret(joinToken)).Scan(&jid, &name, &slots, &labels, &workerID)
	if err != nil {
		return nil, "", ErrJoinToken
	}
	tok := NewSecret("hcldw_")
	var id string
	if workerID != nil { // réenrôlement : nouveau jeton, l'ancien devient invalide
		err = tx.QueryRow(ctx, `UPDATE workers SET token_hash=$2, state='active', hostname=$3, os_arch=$4, version=$5, remote_addr=$6, last_seen_at=now()
			WHERE id=$1 RETURNING id`, *workerID, HashSecret(tok), hostname, osArch, version, remoteAddr).Scan(&id)
	} else {
		err = tx.QueryRow(ctx, `INSERT INTO workers(name, token_hash, slots, labels, hostname, os_arch, version, remote_addr, last_seen_at,
			created_by) SELECT $1,$2,$3,$4,$5,$6,$7,$8,now(), created_by FROM worker_join_tokens WHERE id=$9 RETURNING id`,
			name, HashSecret(tok), slots, labels, hostname, osArch, version, remoteAddr, jid).Scan(&id)
	}
	if err != nil {
		return nil, "", fmt.Errorf("enrôlement : %w", err)
	}
	if _, err := tx.Exec(ctx, `UPDATE worker_join_tokens SET used_at=now(), worker_id=$2 WHERE id=$1`, jid, id); err != nil {
		return nil, "", err
	}
	if err := tx.Commit(ctx); err != nil {
		return nil, "", err
	}
	w, err := c.GetWorker(ctx, id)
	return w, tok, err
}

// TouchWorker enregistre un signal de vie et les runs en cours annoncés par l'agent.
func (c *Core) TouchWorker(ctx context.Context, id, hostname, osArch, version, remoteAddr string, running []string) error {
	if running == nil {
		running = []string{}
	}
	if _, err := c.DB.Exec(ctx, `UPDATE workers SET hostname=$2, os_arch=$3, version=$4, remote_addr=$5, running=$6, last_seen_at=now() WHERE id=$1`,
		id, hostname, osArch, version, remoteAddr, len(running)); err != nil {
		return err
	}
	_, err := c.DB.Exec(ctx, `UPDATE runs SET last_seen_at=now() WHERE worker_id=$1 AND status='running' AND id::text = ANY($2)`, id, running)
	return err
}

// WorkerPatch : modifications autorisées depuis l'administration (nil = inchangé).
type WorkerPatch struct {
	Name   *string   `json:"name"`
	State  *string   `json:"state"`
	Slots  *int      `json:"slots"`
	Labels *[]string `json:"labels"`
}

// UpdateWorker applique le cycle de vie : pause (plus de nouveaux jobs, les runs en cours
// se terminent), reprise, révocation (jeton refusé, runs en cours marqués en échec).
func (c *Core) UpdateWorker(ctx context.Context, id string, p WorkerPatch) (*Worker, error) {
	w, err := c.GetWorker(ctx, id)
	if err != nil {
		return nil, err
	}
	name, slots, labels, state := w.Name, w.Slots, w.Labels, w.State
	if p.Name != nil {
		name = strings.TrimSpace(*p.Name)
	}
	if p.Slots != nil {
		slots = *p.Slots
	}
	if p.Labels != nil {
		labels = *p.Labels
	}
	if p.State != nil {
		switch *p.State {
		case "active", "paused", "revoked":
			state = *p.State
		default:
			return nil, fmt.Errorf("état inconnu %q", *p.State)
		}
		if w.State == "revoked" && state != "revoked" && !w.IsDefault {
			return nil, errors.New("worker révoqué : générez une commande de réenrôlement pour le réactiver")
		}
	}
	if err := ValidateWorkerSpec(name, slots, labels); err != nil {
		return nil, err
	}
	if _, err := c.DB.Exec(ctx, `UPDATE workers SET name=$2, slots=$3, labels=$4, state=$5 WHERE id=$1`, id, name, slots, labels, state); err != nil {
		if strings.Contains(err.Error(), "workers_name_key") {
			return nil, fmt.Errorf("un worker %q existe déjà", name)
		}
		return nil, err
	}
	if state == "revoked" && w.State != "revoked" {
		c.failWorkerRuns(ctx, id, "worker révoqué pendant l'exécution")
	}
	// Réactivation du worker par défaut : nouveau jeton, transmis par le volume partagé.
	if w.IsDefault && w.State == "revoked" && state != "revoked" {
		if err := c.RotateDefaultWorkerToken(ctx); err != nil {
			return nil, err
		}
	}
	return c.GetWorker(ctx, id)
}

// DeleteWorker supprime un worker sans run en cours. Supprimer le worker par défaut le désactive
// durablement (il n'est pas recréé au redémarrage, voir RecreateDefaultWorker).
func (c *Core) DeleteWorker(ctx context.Context, id string) error {
	w, err := c.GetWorker(ctx, id)
	if err != nil {
		return err
	}
	var running int
	_ = c.DB.QueryRow(ctx, `SELECT count(*) FROM runs WHERE worker_id=$1 AND status='running'`, id).Scan(&running)
	if running > 0 {
		return fmt.Errorf("%d run(s) en cours sur ce worker : mettez-le en pause et attendez la fin", running)
	}
	if _, err := c.DB.Exec(ctx, `DELETE FROM workers WHERE id=$1`, id); err != nil {
		return err
	}
	if w.IsDefault {
		_ = os.Remove(c.defaultTokenFile())
		return c.Settings.Set(ctx, settingsKeyDefaultWorker, map[string]bool{"disabled": true})
	}
	return nil
}

// failWorkerRuns marque en échec les runs en cours d'un worker (révocation, perte de contact).
func (c *Core) failWorkerRuns(ctx context.Context, workerID, reason string) {
	_, _ = c.DB.Exec(ctx, `UPDATE runs SET status='failed', error=$2, finished_at=now() WHERE worker_id=$1 AND status='running'`, workerID, reason)
	_, _ = c.DB.Exec(ctx, `UPDATE schema_jobs SET status='failed', error=$2, finished_at=now() WHERE worker_id=$1 AND status='running'`, workerID, reason)
}

// FailLostRuns : runs sans nouvelles de leur worker depuis plus de 5 minutes (appelé par le scheduler).
func (c *Core) FailLostRuns(ctx context.Context) (int64, error) {
	tag, err := c.DB.Exec(ctx, `UPDATE runs SET status='failed', error='worker injoignable pendant l''exécution', finished_at=now()
		WHERE status='running' AND worker_id IS NOT NULL AND COALESCE(last_seen_at, started_at) < now() - interval '5 minutes'`)
	if err != nil {
		return 0, err
	}
	_, _ = c.DB.Exec(ctx, `UPDATE schema_jobs SET status='failed', error='worker injoignable', finished_at=now()
		WHERE status='running' AND started_at < now() - interval '30 minutes'`)
	return tag.RowsAffected(), nil
}

// ---- Worker par défaut --------------------------------------------------------------------

// defaultTokenFile : jeton du worker par défaut, partagé avec le conteneur "worker" par le volume /data.
func (c *Core) defaultTokenFile() string {
	return filepath.Join(c.Cfg.DataDir, "agent", "default.token")
}

// DefaultWorkerTokenFile expose le chemin (rôle "all" : agent intégré au processus).
func (c *Core) DefaultWorkerTokenFile() string { return c.defaultTokenFile() }

// EnsureDefaultWorker crée le worker par défaut au premier démarrage et garantit que son jeton
// est disponible sur le volume partagé. Ne fait rien si l'administrateur l'a supprimé.
func (c *Core) EnsureDefaultWorker(ctx context.Context) error {
	var flag struct {
		Disabled bool `json:"disabled"`
	}
	_ = c.Settings.Get(ctx, settingsKeyDefaultWorker, &flag)
	if flag.Disabled {
		return nil
	}
	var id string
	var hash []byte
	err := c.DB.QueryRow(ctx, `SELECT id, token_hash FROM workers WHERE is_default`).Scan(&id, &hash)
	if errors.Is(err, pgx.ErrNoRows) {
		tok := NewSecret("hcldw_")
		name := DefaultWorkerName
		var taken bool
		_ = c.DB.QueryRow(ctx, `SELECT EXISTS(SELECT 1 FROM workers WHERE name=$1)`, name).Scan(&taken)
		if taken {
			name = "default-" + strings.ToLower(NewSecret("")[:6])
		}
		if _, err := c.DB.Exec(ctx, `INSERT INTO workers(name, token_hash, slots, is_default) VALUES ($1,$2,$3,true)`,
			name, HashSecret(tok), c.Cfg.WorkerConcurrency); err != nil {
			return err
		}
		return writeSecretFile(c.defaultTokenFile(), tok)
	}
	if err != nil {
		return err
	}
	// Fichier absent ou différent (volume recréé) : nouveau jeton.
	if b, err := os.ReadFile(c.defaultTokenFile()); err == nil && string(HashSecret(strings.TrimSpace(string(b)))) == string(hash) {
		return nil
	}
	return c.RotateDefaultWorkerToken(ctx)
}

// RotateDefaultWorkerToken renouvelle le jeton du worker par défaut (l'agent le relit automatiquement).
func (c *Core) RotateDefaultWorkerToken(ctx context.Context) error {
	tok := NewSecret("hcldw_")
	tag, err := c.DB.Exec(ctx, `UPDATE workers SET token_hash=$1 WHERE is_default`, HashSecret(tok))
	if err != nil {
		return err
	}
	if tag.RowsAffected() == 0 {
		return db.ErrNotFound
	}
	return writeSecretFile(c.defaultTokenFile(), tok)
}

// RecreateDefaultWorker annule la suppression du worker par défaut.
func (c *Core) RecreateDefaultWorker(ctx context.Context) error {
	if err := c.Settings.Set(ctx, settingsKeyDefaultWorker, map[string]bool{"disabled": false}); err != nil {
		return err
	}
	return c.EnsureDefaultWorker(ctx)
}

func writeSecretFile(path, secret string) error {
	if err := os.MkdirAll(filepath.Dir(path), 0o700); err != nil {
		return err
	}
	tmp := path + ".tmp"
	if err := os.WriteFile(tmp, []byte(secret+"\n"), 0o600); err != nil {
		return err
	}
	return os.Rename(tmp, path)
}
