package core

import (
	"context"
	"errors"
	"fmt"
	"strings"
	"time"

	"github.com/jackc/pgx/v5"

	"github.com/AZIZI-Sajjad/hcldesigner/internal/db"
	"github.com/AZIZI-Sajjad/hcldesigner/internal/gitprov"
)

// GitConnection : connexion personnelle d'un utilisateur à une forge. Le jeton n'est jamais renvoyé.
type GitConnection struct {
	ID          string    `json:"id"`
	Name        string    `json:"name"`
	Provider    string    `json:"provider"`
	BaseURL     string    `json:"baseUrl"`
	Username    string    `json:"username"`
	AuthorName  string    `json:"authorName"`
	AuthorEmail string    `json:"authorEmail"`
	CACert      string    `json:"caCert"`
	Insecure    bool      `json:"insecureTls"`
	HasToken    bool      `json:"hasToken"`
	CreatedAt   time.Time `json:"createdAt"`
}

// GitConnectionInput : création / modification (Token vide = inchangé).
type GitConnectionInput struct {
	Name        string `json:"name"`
	Provider    string `json:"provider"`
	BaseURL     string `json:"baseUrl"`
	Username    string `json:"username"`
	Token       string `json:"token"`
	AuthorName  string `json:"authorName"`
	AuthorEmail string `json:"authorEmail"`
	CACert      string `json:"caCert"`
	Insecure    bool   `json:"insecureTls"`
}

// ErrNoGitConnection : l'utilisateur n'a pas de connexion vers la forge du projet.
var ErrNoGitConnection = errors.New("aucune connexion Git personnelle vers ce serveur : ajoutez-la dans Mon compte > Connexions Git")

const gitConnCols = `id, name, provider, base_url, username, author_name, author_email, ca_cert, insecure_tls, token_enc <> ''::bytea, created_at`

func scanGitConn(row pgx.Row) (*GitConnection, error) {
	var g GitConnection
	if err := row.Scan(&g.ID, &g.Name, &g.Provider, &g.BaseURL, &g.Username, &g.AuthorName, &g.AuthorEmail, &g.CACert, &g.Insecure, &g.HasToken, &g.CreatedAt); err != nil {
		return nil, db.NotFound(err)
	}
	return &g, nil
}

func (c *Core) ListGitConnections(ctx context.Context, userID string) ([]GitConnection, error) {
	rows, err := c.DB.Query(ctx, `SELECT `+gitConnCols+` FROM git_connections WHERE user_id=$1 ORDER BY name`, userID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	out := []GitConnection{}
	for rows.Next() {
		g, err := scanGitConn(rows)
		if err != nil {
			return nil, err
		}
		out = append(out, *g)
	}
	return out, rows.Err()
}

// SaveGitConnection crée (id vide) ou modifie une connexion de l'utilisateur.
func (c *Core) SaveGitConnection(ctx context.Context, userID, id string, in GitConnectionInput) (*GitConnection, error) {
	base, err := gitprov.Normalize(in.Provider, in.BaseURL)
	if err != nil {
		return nil, err
	}
	in.Name = strings.TrimSpace(in.Name)
	if in.Name == "" {
		in.Name = in.Provider + " " + strings.TrimPrefix(strings.TrimPrefix(base, "https://"), "http://")
	}
	if in.Provider == gitprov.Gitea && strings.TrimSpace(in.Username) == "" {
		return nil, errors.New("Gitea : nom d'utilisateur obligatoire (authentification git)")
	}
	if id == "" {
		if in.Token == "" {
			return nil, errors.New("jeton d'accès personnel obligatoire")
		}
		enc, err := c.Vault.Encrypt([]byte(in.Token))
		if err != nil {
			return nil, err
		}
		err = c.DB.QueryRow(ctx, `INSERT INTO git_connections(user_id, name, provider, base_url, username, token_enc, author_name, author_email, ca_cert, insecure_tls)
			VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10) RETURNING id`, userID, in.Name, in.Provider, base, in.Username, enc, in.AuthorName, in.AuthorEmail,
			in.CACert, in.Insecure).Scan(&id)
		if err != nil {
			return nil, err
		}
	} else {
		tag, err := c.DB.Exec(ctx, `UPDATE git_connections SET name=$3, provider=$4, base_url=$5, username=$6, author_name=$7, author_email=$8,
			ca_cert=$9, insecure_tls=$10 WHERE id=$1 AND user_id=$2`, id, userID, in.Name, in.Provider, base, in.Username, in.AuthorName, in.AuthorEmail,
			in.CACert, in.Insecure)
		if err != nil {
			return nil, err
		}
		if tag.RowsAffected() == 0 {
			return nil, db.ErrNotFound
		}
		if in.Token != "" {
			enc, err := c.Vault.Encrypt([]byte(in.Token))
			if err != nil {
				return nil, err
			}
			if _, err := c.DB.Exec(ctx, `UPDATE git_connections SET token_enc=$3 WHERE id=$1 AND user_id=$2`, id, userID, enc); err != nil {
				return nil, err
			}
		}
	}
	return scanGitConn(c.DB.QueryRow(ctx, `SELECT `+gitConnCols+` FROM git_connections WHERE id=$1`, id))
}

func (c *Core) DeleteGitConnection(ctx context.Context, userID, id string) error {
	tag, err := c.DB.Exec(ctx, `DELETE FROM git_connections WHERE id=$1 AND user_id=$2`, id, userID)
	if err == nil && tag.RowsAffected() == 0 {
		return db.ErrNotFound
	}
	return err
}

// GitConn renvoie la connexion déchiffrée d'un utilisateur (contrôle de propriété inclus).
func (c *Core) GitConn(ctx context.Context, userID, id string) (*gitprov.Conn, error) {
	return c.gitConnWhere(ctx, `id=$1 AND user_id=$2`, id, userID)
}

// GitConnFor renvoie la connexion de l'utilisateur vers la forge d'un projet : chaque
// utilisateur pousse avec son propre jeton et sa propre identité de commit.
func (c *Core) GitConnFor(ctx context.Context, userID, provider, baseURL string) (*gitprov.Conn, error) {
	conn, err := c.gitConnWhere(ctx, `user_id=$1 AND provider=$2 AND base_url=$3 ORDER BY created_at LIMIT 1`, userID, provider, baseURL)
	if errors.Is(err, db.ErrNotFound) {
		return nil, ErrNoGitConnection
	}
	return conn, err
}

func (c *Core) gitConnWhere(ctx context.Context, where string, args ...any) (*gitprov.Conn, error) {
	var g gitprov.Conn
	var enc []byte
	err := c.DB.QueryRow(ctx, `SELECT provider, base_url, username, token_enc, author_name, author_email, ca_cert, insecure_tls FROM git_connections WHERE `+where, args...).
		Scan(&g.Provider, &g.BaseURL, &g.Username, &enc, &g.AuthorName, &g.AuthorEmail, &g.CACert, &g.Insecure)
	if err != nil {
		return nil, db.NotFound(err)
	}
	tok, err := c.Vault.Decrypt(enc)
	if err != nil {
		return nil, err
	}
	g.Token = string(tok)
	return &g, nil
}

// ---- Dépôt lié à un projet ----------------------------------------------------------------

// ProjectGit : dépôt et sous-dossier où vit le code Terraform du projet.
type ProjectGit struct {
	Provider     string     `json:"provider"`
	BaseURL      string     `json:"baseUrl"`
	Repo         string     `json:"repo"`
	Branch       string     `json:"branch"`
	Path         string     `json:"path"` // sous-dossier ("" = racine du dépôt)
	WebURL       string     `json:"webUrl"`
	LastCommit   string     `json:"lastCommit"`
	LastSyncAt   *time.Time `json:"lastSyncAt"`
	LastSyncBy   string     `json:"lastSyncBy"`
	LastSyncKind string     `json:"lastSyncKind"`
}

func (c *Core) GetProjectGit(ctx context.Context, projectID string) (*ProjectGit, error) {
	var g ProjectGit
	err := c.DB.QueryRow(ctx, `SELECT pg.provider, pg.base_url, pg.repo, pg.branch, pg.path, pg.last_commit, pg.last_sync_at, COALESCE(u.username,''), pg.last_sync_kind
		FROM project_git pg LEFT JOIN users u ON u.id=pg.last_sync_by WHERE pg.project_id=$1`, projectID).
		Scan(&g.Provider, &g.BaseURL, &g.Repo, &g.Branch, &g.Path, &g.LastCommit, &g.LastSyncAt, &g.LastSyncBy, &g.LastSyncKind)
	if err != nil {
		return nil, db.NotFound(err)
	}
	g.WebURL = (&gitprov.Conn{BaseURL: g.BaseURL}).WebURL(g.Repo)
	return &g, nil
}

// LinkProjectGit lie (ou relie) un projet à un dépôt.
func (c *Core) LinkProjectGit(ctx context.Context, projectID string, g ProjectGit) (*ProjectGit, error) {
	base, err := gitprov.Normalize(g.Provider, g.BaseURL)
	if err != nil {
		return nil, err
	}
	sub, err := gitprov.CleanPath(g.Path)
	if err != nil {
		return nil, err
	}
	g.Repo = strings.Trim(strings.TrimSpace(g.Repo), "/")
	if g.Repo == "" || strings.TrimSpace(g.Branch) == "" {
		return nil, fmt.Errorf("dépôt et branche obligatoires")
	}
	_, err = c.DB.Exec(ctx, `INSERT INTO project_git(project_id, provider, base_url, repo, branch, path) VALUES ($1,$2,$3,$4,$5,$6)
		ON CONFLICT (project_id) DO UPDATE SET provider=EXCLUDED.provider, base_url=EXCLUDED.base_url, repo=EXCLUDED.repo,
		branch=EXCLUDED.branch, path=EXCLUDED.path`, projectID, g.Provider, base, g.Repo, strings.TrimSpace(g.Branch), sub)
	if err != nil {
		return nil, err
	}
	return c.GetProjectGit(ctx, projectID)
}

func (c *Core) UnlinkProjectGit(ctx context.Context, projectID string) error {
	_, err := c.DB.Exec(ctx, `DELETE FROM project_git WHERE project_id=$1`, projectID)
	return err
}

// RecordGitSync mémorise le dernier échange (import, push ou PR/MR).
func (c *Core) RecordGitSync(ctx context.Context, projectID, userID, kind, commit string) {
	_, _ = c.DB.Exec(ctx, `UPDATE project_git SET last_commit=CASE WHEN $4='' THEN last_commit ELSE $4 END, last_sync_at=now(),
		last_sync_by=$2, last_sync_kind=$3 WHERE project_id=$1`, projectID, userID, kind, commit)
}
