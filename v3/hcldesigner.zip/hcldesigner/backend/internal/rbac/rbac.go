// Package rbac définit les permissions, les rôles prédéfinis et le contrôle d'accès
// par portée (globale, projet, environnement).
package rbac

import (
	"context"
	"sort"

	"github.com/jackc/pgx/v5/pgxpool"
)

// Permission est un droit élémentaire "domaine.action".
type Permission string

const All Permission = "*"

// Catalogue des permissions, regroupées par domaine pour la matrice du control panel.
var Groups = []struct {
	Domain string     `json:"domain"`
	Label  string     `json:"label"`
	Perms  []PermInfo `json:"perms"`
}{
	{"projects", "Projets", []PermInfo{
		{"projects.view", "Voir", ScopeProject}, {"projects.create", "Créer", ScopeGlobal},
		{"projects.edit", "Modifier (canvas, paramètres)", ScopeProject}, {"projects.delete", "Supprimer", ScopeProject},
		{"projects.share", "Partager (attribuer des rôles sur le projet)", ScopeProject},
	}},
	{"modules", "Modules", []PermInfo{
		{"modules.create", "Créer / modifier", ScopeGlobal}, {"modules.publish", "Publier une version", ScopeGlobal}, {"modules.use", "Utiliser", ScopeGlobal},
	}},
	{"providers", "Providers", []PermInfo{{"providers.add", "Ajouter / résoudre", ScopeGlobal}}},
	{"variables", "Variables sensibles", []PermInfo{
		{"variables.sensitive.view", "Voir les tfvars", ScopeEnvironment}, {"variables.sensitive.edit", "Modifier les tfvars", ScopeEnvironment},
	}},
	{"code", "Code", []PermInfo{
		{"code.view", "Voir", ScopeProject}, {"code.export", "Exporter", ScopeProject},
	}},
	{"runs", "Exécutions", []PermInfo{
		{"runs.init", "init / validate", ScopeEnvironment}, {"runs.plan", "plan", ScopeEnvironment},
		{"runs.apply", "apply", ScopeEnvironment}, {"runs.destroy", "destroy", ScopeEnvironment},
		{"runs.cancel", "Annuler", ScopeEnvironment}, {"runs.approve", "Approuver", ScopeEnvironment},
		{"runs.bypass_window", "Hors fenêtre de changement", ScopeEnvironment},
	}},
	{"state", "State", []PermInfo{
		{"state.view", "Voir", ScopeEnvironment}, {"state.download", "Télécharger", ScopeEnvironment},
		{"state.edit", "Modifier (mv, rm, import)", ScopeEnvironment}, {"state.unlock", "force-unlock", ScopeEnvironment},
	}},
	{"environments", "Environnements / backends", []PermInfo{{"environments.manage", "Configurer", ScopeProject}}},
	{"git", "Git", []PermInfo{
		{"git.link", "Lier le projet à un dépôt", ScopeProject}, {"git.push", "Pousser le code (commit, PR/MR)", ScopeProject},
	}},
	{"credentials", "Credentials", []PermInfo{
		{"credentials.manage", "Gérer le coffre", ScopeGlobal}, {"credentials.use", "Associer à un environnement", ScopeGlobal},
	}},
	{"schedules", "Planification", []PermInfo{{"schedules.manage", "Créer / modifier", ScopeProject}}},
	{"policies", "Conformité", []PermInfo{{"policies.manage", "Gérer les règles", ScopeGlobal}}},
	{"admin", "Control panel", []PermInfo{
		{"admin.users", "Utilisateurs et équipes", ScopeGlobal}, {"admin.roles", "Rôles et attributions", ScopeGlobal},
		{"admin.smtp", "SMTP, webhooks, templates", ScopeGlobal}, {"admin.settings", "Paramètres généraux", ScopeGlobal},
		{"admin.workers", "Workers (ajout, cycle de vie)", ScopeGlobal},
	}},
	{"audit", "Audit", []PermInfo{{"audit.view", "Voir", ScopeGlobal}, {"audit.export", "Exporter", ScopeGlobal}}},
}

// Portées possibles d'une permission.
const (
	ScopeGlobal      = "global"
	ScopeProject     = "project"
	ScopeEnvironment = "environment"
)

type PermInfo struct {
	Name  Permission `json:"name"`
	Label string     `json:"label"`
	Scope string     `json:"scope"`
}

// Known indique si une permission existe.
func Known(p Permission) bool {
	if p == All {
		return true
	}
	for _, g := range Groups {
		for _, pi := range g.Perms {
			if pi.Name == p {
				return true
			}
		}
	}
	return false
}

// BuiltinRole est un rôle prédéfini, non supprimable.
type BuiltinRole struct {
	Name        string
	Description string
	Perms       []Permission
}

var Builtins = []BuiltinRole{
	{"Super admin", "Tous les droits", []Permission{All}},
	{"Admin", "Administration complète sauf rôle Super admin", []Permission{
		"projects.view", "projects.create", "projects.edit", "projects.delete", "projects.share", "modules.create", "modules.publish", "modules.use",
		"providers.add", "variables.sensitive.view", "variables.sensitive.edit", "code.view", "code.export",
		"runs.init", "runs.plan", "runs.apply", "runs.destroy", "runs.cancel", "runs.approve", "state.view", "state.download", "state.edit", "state.unlock",
		"environments.manage", "credentials.manage", "credentials.use", "schedules.manage", "policies.manage",
		"admin.users", "admin.roles", "admin.smtp", "admin.settings", "admin.workers", "audit.view", "audit.export", "git.link", "git.push",
	}},
	{"Opérateur", "Exécute plans et applies", []Permission{
		"projects.view", "code.view", "code.export", "runs.init", "runs.plan", "runs.apply", "runs.cancel", "state.view", "modules.use", "credentials.use",
	}},
	{"Concepteur", "Conçoit l'infrastructure et les modules", []Permission{
		"projects.view", "projects.create", "projects.edit", "code.view", "code.export", "modules.create", "modules.publish", "modules.use",
		"providers.add", "runs.init", "runs.plan", "environments.manage", "git.link", "git.push",
	}},
	{"Lecteur", "Lecture seule", []Permission{"projects.view", "code.view", "state.view"}},
	{"Approbateur", "Valide les plans", []Permission{"projects.view", "code.view", "runs.approve", "state.view"}},
}

// Binding est une attribution effective (directe ou via équipe).
type Binding struct {
	ID          string       `json:"id"`
	RoleID      string       `json:"roleId"`
	RoleName    string       `json:"roleName"`
	Perms       []Permission `json:"perms"`
	Scope       string       `json:"scope"`
	ProjectID   string       `json:"projectId,omitempty"`
	Environment string       `json:"environment,omitempty"`
	ViaTeam     string       `json:"viaTeam,omitempty"`
}

// Subject regroupe l'utilisateur courant et ses attributions (chargées une fois par requête).
type Subject struct {
	UserID   string
	Username string
	IsSuper  bool
	Bindings []Binding
}

// viewPerms : perms de lecture qu'une attribution limitée à un environnement accorde aussi au niveau projet.
var viewPerms = map[Permission]bool{"projects.view": true, "code.view": true}

// Can vérifie une permission sur une portée. projectID et env peuvent être vides.
func (s *Subject) Can(p Permission, projectID, env string) bool {
	if s == nil {
		return false
	}
	if s.IsSuper {
		return true
	}
	for _, b := range s.Bindings {
		if !hasPerm(b.Perms, p) {
			continue
		}
		switch b.Scope {
		case ScopeGlobal:
			return true
		case ScopeProject:
			if projectID != "" && b.ProjectID == projectID {
				return true
			}
		case ScopeEnvironment:
			if projectID != "" && b.ProjectID == projectID && (b.Environment == env || (env == "" && viewPerms[p])) {
				return true
			}
		}
	}
	return false
}

// CanAnyProject : la permission est-elle détenue sur au moins un projet (affichage des menus) ?
func (s *Subject) CanAnyProject(p Permission) bool {
	if s.IsSuper {
		return true
	}
	for _, b := range s.Bindings {
		if hasPerm(b.Perms, p) {
			return true
		}
	}
	return false
}

// VisibleProjects renvoie nil si tous les projets sont visibles, sinon la liste des ids autorisés.
func (s *Subject) VisibleProjects() []string {
	if s.IsSuper {
		return nil
	}
	ids := map[string]bool{}
	for _, b := range s.Bindings {
		if !hasPerm(b.Perms, "projects.view") {
			continue
		}
		if b.Scope == ScopeGlobal {
			return nil
		}
		ids[b.ProjectID] = true
	}
	out := make([]string, 0, len(ids))
	for id := range ids {
		out = append(out, id)
	}
	sort.Strings(out)
	return out
}

func hasPerm(list []Permission, p Permission) bool {
	for _, x := range list {
		if x == p || x == All {
			return true
		}
	}
	return false
}

// Load charge les attributions d'un utilisateur, directes et via ses équipes.
func Load(ctx context.Context, pool *pgxpool.Pool, userID, username string, isSuper bool) (*Subject, error) {
	s := &Subject{UserID: userID, Username: username, IsSuper: isSuper}
	rows, err := pool.Query(ctx, `
		SELECT b.id, r.id, r.name, r.permissions, b.scope, COALESCE(b.project_id::text,''), b.environment, COALESCE(t.name,'')
		FROM role_bindings b
		JOIN roles r ON r.id = b.role_id
		LEFT JOIN teams t ON t.id = b.team_id
		WHERE b.user_id = $1
		   OR b.team_id IN (SELECT team_id FROM team_members WHERE user_id = $1)`, userID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	for rows.Next() {
		var b Binding
		var perms []string
		if err := rows.Scan(&b.ID, &b.RoleID, &b.RoleName, &perms, &b.Scope, &b.ProjectID, &b.Environment, &b.ViaTeam); err != nil {
			return nil, err
		}
		for _, p := range perms {
			b.Perms = append(b.Perms, Permission(p))
			if Permission(p) == All && b.Scope == ScopeGlobal {
				s.IsSuper = true
			}
		}
		s.Bindings = append(s.Bindings, b)
	}
	return s, rows.Err()
}

// SeedBuiltins crée ou met à jour les rôles prédéfinis.
func SeedBuiltins(ctx context.Context, pool *pgxpool.Pool) error {
	for _, r := range Builtins {
		perms := make([]string, len(r.Perms))
		for i, p := range r.Perms {
			perms[i] = string(p)
		}
		if _, err := pool.Exec(ctx, `
			INSERT INTO roles(name, description, builtin, permissions) VALUES ($1,$2,true,$3)
			ON CONFLICT (name) DO UPDATE SET description=EXCLUDED.description, permissions=EXCLUDED.permissions, builtin=true`,
			r.Name, r.Description, perms); err != nil {
			return err
		}
	}
	return nil
}
