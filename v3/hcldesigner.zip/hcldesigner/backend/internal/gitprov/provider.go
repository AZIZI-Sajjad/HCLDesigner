// Package gitprov relie HCLDesigner aux forges Git : GitHub (github.com et Enterprise Server),
// GitLab (gitlab.com et auto-hébergé) et Gitea / Forgejo. Les appels d'API servent à lister
// dépôts et branches et à ouvrir des pull/merge requests ; le contenu passe par git (workspace.go).
package gitprov

import (
	"context"
	"crypto/tls"
	"crypto/x509"
	"encoding/base64"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"sort"
	"strings"
	"time"
)

// Fournisseurs pris en charge.
const (
	GitHub = "github"
	GitLab = "gitlab"
	Gitea  = "gitea"
)

// Conn : connexion d'un utilisateur à une forge (jeton personnel déchiffré).
type Conn struct {
	Provider    string
	BaseURL     string // https://github.com, https://gitlab.interne.lan, https://gitea.example.com
	Username    string // requis pour Gitea (authentification git), facultatif ailleurs
	Token       string
	AuthorName  string
	AuthorEmail string
	CACert      string // PEM d'une CA interne
	Insecure    bool
}

// Repo : dépôt accessible avec la connexion.
type Repo struct {
	FullName      string `json:"fullName"` // owner/name ou groupe/sous-groupe/name
	DefaultBranch string `json:"defaultBranch"`
	Private       bool   `json:"private"`
	WebURL        string `json:"webUrl"`
	Description   string `json:"description"`
}

// User : identité associée au jeton (test de la connexion).
type User struct {
	Login string `json:"login"`
	Name  string `json:"name"`
	Email string `json:"email"`
}

// Normalize contrôle le fournisseur et nettoie l'URL de base (valeur par défaut pour les SaaS).
func Normalize(provider, baseURL string) (string, error) {
	baseURL = strings.TrimRight(strings.TrimSpace(baseURL), "/")
	switch provider {
	case GitHub:
		if baseURL == "" {
			baseURL = "https://github.com"
		}
	case GitLab:
		if baseURL == "" {
			baseURL = "https://gitlab.com"
		}
	case Gitea:
		if baseURL == "" {
			return "", errors.New("URL du serveur Gitea obligatoire")
		}
	default:
		return "", fmt.Errorf("fournisseur inconnu %q (github, gitlab, gitea)", provider)
	}
	u, err := url.Parse(baseURL)
	if err != nil || (u.Scheme != "https" && u.Scheme != "http") || u.Host == "" {
		return "", fmt.Errorf("URL invalide %q (https://serveur attendu)", baseURL)
	}
	return baseURL, nil
}

// apiBase renvoie la racine de l'API REST du fournisseur.
func (c *Conn) apiBase() string {
	switch c.Provider {
	case GitHub:
		if c.BaseURL == "https://github.com" {
			return "https://api.github.com"
		}
		return c.BaseURL + "/api/v3" // GitHub Enterprise Server
	case GitLab:
		return c.BaseURL + "/api/v4"
	default:
		return c.BaseURL + "/api/v1"
	}
}

// CloneURL : URL HTTPS du dépôt (le jeton passe par un en-tête, jamais dans l'URL).
func (c *Conn) CloneURL(repo string) string {
	return c.BaseURL + "/" + strings.Trim(repo, "/") + ".git"
}

// WebURL : page du dépôt (lien affiché dans l'interface).
func (c *Conn) WebURL(repo string) string {
	return c.BaseURL + "/" + strings.Trim(repo, "/")
}

// GitAuthHeader : en-tête HTTP d'authentification pour git (Basic, selon le fournisseur).
func (c *Conn) GitAuthHeader() string {
	user := c.Username
	switch c.Provider {
	case GitHub:
		user = "x-access-token"
	case GitLab:
		if user == "" {
			user = "oauth2"
		}
	}
	return "Authorization: Basic " + base64.StdEncoding.EncodeToString([]byte(user+":"+c.Token))
}

func (c *Conn) httpClient() (*http.Client, error) {
	tr := http.DefaultTransport.(*http.Transport).Clone()
	tr.TLSClientConfig = &tls.Config{MinVersion: tls.VersionTLS12, InsecureSkipVerify: c.Insecure} //nolint:gosec // choix explicite de l'utilisateur (forge interne)
	if strings.TrimSpace(c.CACert) != "" {
		pool, _ := x509.SystemCertPool()
		if pool == nil {
			pool = x509.NewCertPool()
		}
		if !pool.AppendCertsFromPEM([]byte(c.CACert)) {
			return nil, errors.New("certificat de CA illisible (PEM attendu)")
		}
		tr.TLSClientConfig.RootCAs = pool
	}
	return &http.Client{Transport: tr, Timeout: 30 * time.Second}, nil
}

// call exécute une requête d'API authentifiée et décode la réponse JSON.
func (c *Conn) call(ctx context.Context, method, path string, in, out any) error {
	hc, err := c.httpClient()
	if err != nil {
		return err
	}
	var body io.Reader
	if in != nil {
		raw, _ := json.Marshal(in)
		body = strings.NewReader(string(raw))
	}
	req, err := http.NewRequestWithContext(ctx, method, c.apiBase()+path, body)
	if err != nil {
		return err
	}
	req.Header.Set("Accept", "application/json")
	if in != nil {
		req.Header.Set("Content-Type", "application/json")
	}
	switch c.Provider {
	case GitHub:
		req.Header.Set("Authorization", "Bearer "+c.Token)
		req.Header.Set("X-GitHub-Api-Version", "2022-11-28")
	case GitLab:
		req.Header.Set("PRIVATE-TOKEN", c.Token)
	default:
		req.Header.Set("Authorization", "token "+c.Token)
	}
	resp, err := hc.Do(req)
	if err != nil {
		return fmt.Errorf("%s injoignable : %w", c.BaseURL, err)
	}
	defer resp.Body.Close()
	if resp.StatusCode >= 300 {
		msg, _ := io.ReadAll(io.LimitReader(resp.Body, 2048))
		switch resp.StatusCode {
		case http.StatusUnauthorized:
			return errors.New("jeton refusé par la forge (expiré ou révoqué ?)")
		case http.StatusForbidden:
			return fmt.Errorf("accès refusé par la forge (droits du jeton insuffisants) : %s", apiMessage(msg))
		case http.StatusNotFound:
			return errors.New("introuvable sur la forge (dépôt inexistant ou inaccessible avec ce jeton)")
		}
		return fmt.Errorf("API %s : HTTP %d %s", c.Provider, resp.StatusCode, apiMessage(msg))
	}
	if out != nil {
		return json.NewDecoder(resp.Body).Decode(out)
	}
	return nil
}

// apiMessage extrait le message d'erreur d'une réponse JSON de forge.
func apiMessage(raw []byte) string {
	var m struct {
		Message any `json:"message"`
		Error   any `json:"error"`
	}
	if json.Unmarshal(raw, &m) == nil {
		if m.Message != nil {
			return fmt.Sprint(m.Message)
		}
		if m.Error != nil {
			return fmt.Sprint(m.Error)
		}
	}
	return strings.TrimSpace(string(raw))
}

// CurrentUser vérifie le jeton et renvoie l'identité associée.
func (c *Conn) CurrentUser(ctx context.Context) (*User, error) {
	var raw struct {
		Login    string `json:"login"`
		Username string `json:"username"`
		Name     string `json:"name"`
		FullName string `json:"full_name"`
		Email    string `json:"email"`
	}
	if err := c.call(ctx, "GET", "/user", nil, &raw); err != nil {
		return nil, err
	}
	u := &User{Login: raw.Login, Name: raw.Name, Email: raw.Email}
	if u.Login == "" {
		u.Login = raw.Username
	}
	if u.Name == "" {
		u.Name = raw.FullName
	}
	return u, nil
}

// Repos liste les dépôts accessibles, filtrés par query (sous-chaîne, insensible à la casse).
func (c *Conn) Repos(ctx context.Context, query string) ([]Repo, error) {
	q := url.QueryEscape(query)
	out := []Repo{}
	switch c.Provider {
	case GitHub:
		var raw []struct {
			FullName      string `json:"full_name"`
			DefaultBranch string `json:"default_branch"`
			Private       bool   `json:"private"`
			HTMLURL       string `json:"html_url"`
			Description   string `json:"description"`
		}
		if err := c.call(ctx, "GET", "/user/repos?per_page=100&sort=updated&affiliation=owner,collaborator,organization_member", nil, &raw); err != nil {
			return nil, err
		}
		for _, r := range raw {
			out = append(out, Repo{r.FullName, r.DefaultBranch, r.Private, r.HTMLURL, r.Description})
		}
	case GitLab:
		var raw []struct {
			Path          string `json:"path_with_namespace"`
			DefaultBranch string `json:"default_branch"`
			Visibility    string `json:"visibility"`
			WebURL        string `json:"web_url"`
			Description   string `json:"description"`
		}
		if err := c.call(ctx, "GET", "/projects?membership=true&simple=true&per_page=100&order_by=last_activity_at&search="+q, nil, &raw); err != nil {
			return nil, err
		}
		for _, r := range raw {
			out = append(out, Repo{r.Path, r.DefaultBranch, r.Visibility != "public", r.WebURL, r.Description})
		}
	default:
		var raw struct {
			Data []struct {
				FullName      string `json:"full_name"`
				DefaultBranch string `json:"default_branch"`
				Private       bool   `json:"private"`
				HTMLURL       string `json:"html_url"`
				Description   string `json:"description"`
			} `json:"data"`
		}
		if err := c.call(ctx, "GET", "/repos/search?limit=50&q="+q, nil, &raw); err != nil {
			return nil, err
		}
		for _, r := range raw.Data {
			out = append(out, Repo{r.FullName, r.DefaultBranch, r.Private, r.HTMLURL, r.Description})
		}
	}
	if query != "" {
		lq := strings.ToLower(query)
		filtered := out[:0]
		for _, r := range out {
			if strings.Contains(strings.ToLower(r.FullName), lq) {
				filtered = append(filtered, r)
			}
		}
		out = filtered
	}
	return out, nil
}

// repoPath : identifiant du dépôt dans les URL d'API (GitLab attend le chemin encodé).
func (c *Conn) repoPath(repo string) string {
	repo = strings.Trim(repo, "/")
	if c.Provider == GitLab {
		return "/projects/" + url.PathEscape(repo)
	}
	return "/repos/" + repo
}

// Branches liste les branches d'un dépôt (triées, branche par défaut incluse).
func (c *Conn) Branches(ctx context.Context, repo string) ([]string, error) {
	var raw []struct {
		Name string `json:"name"`
	}
	path := c.repoPath(repo) + "/branches?per_page=100&limit=50"
	if c.Provider == GitLab {
		path = c.repoPath(repo) + "/repository/branches?per_page=100"
	}
	if err := c.call(ctx, "GET", path, nil, &raw); err != nil {
		return nil, err
	}
	out := make([]string, 0, len(raw))
	for _, b := range raw {
		out = append(out, b.Name)
	}
	sort.Strings(out)
	return out, nil
}

// OpenChangeRequest ouvre une pull request (GitHub, Gitea) ou une merge request (GitLab)
// et renvoie son URL.
func (c *Conn) OpenChangeRequest(ctx context.Context, repo, head, base, title, body string) (string, error) {
	var raw struct {
		HTMLURL string `json:"html_url"`
		WebURL  string `json:"web_url"`
	}
	var err error
	if c.Provider == GitLab {
		err = c.call(ctx, "POST", c.repoPath(repo)+"/merge_requests", map[string]any{
			"source_branch": head, "target_branch": base, "title": title, "description": body, "remove_source_branch": true}, &raw)
	} else {
		err = c.call(ctx, "POST", c.repoPath(repo)+"/pulls", map[string]any{"head": head, "base": base, "title": title, "body": body}, &raw)
	}
	if err != nil {
		return "", err
	}
	if raw.WebURL != "" {
		return raw.WebURL, nil
	}
	return raw.HTMLURL, nil
}
