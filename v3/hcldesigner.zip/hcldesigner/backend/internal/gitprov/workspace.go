package gitprov

import (
	"bytes"
	"context"
	"errors"
	"fmt"
	"os"
	"os/exec"
	"path"
	"path/filepath"
	"sort"
	"strings"
	"time"
)

// Workspace : clone temporaire d'un dépôt. Le jeton est transmis à git par variables
// d'environnement (GIT_CONFIG_*), jamais dans l'URL ni sur la ligne de commande.
type Workspace struct {
	Dir    string
	conn   *Conn
	env    []string
	tmpDir string
}

// Clone récupère une branche (historique minimal). cloneURL vide = URL HTTPS de la forge
// (paramètre utilisé par les tests avec un dépôt local).
func Clone(ctx context.Context, c *Conn, cloneURL, branch, workRoot string) (*Workspace, error) {
	if cloneURL == "" {
		return nil, errors.New("URL de clone vide")
	}
	tmp, err := os.MkdirTemp(workRoot, "git-*")
	if err != nil {
		return nil, err
	}
	ws := &Workspace{Dir: filepath.Join(tmp, "repo"), conn: c, tmpDir: tmp}
	if err := ws.prepareEnv(); err != nil {
		ws.Close()
		return nil, err
	}
	args := []string{"clone", "--depth", "1", "--no-tags"}
	if branch != "" {
		args = append(args, "--branch", branch, "--single-branch")
	}
	if _, err := ws.git(ctx, tmp, append(args, cloneURL, ws.Dir)...); err != nil {
		ws.Close()
		return nil, err
	}
	return ws, nil
}

// prepareEnv isole git de la configuration du système (HOME temporaire) et injecte
// l'authentification et les options TLS.
func (w *Workspace) prepareEnv() error {
	home := filepath.Join(w.tmpDir, "home")
	if err := os.MkdirAll(home, 0o700); err != nil {
		return err
	}
	w.env = []string{
		"PATH=" + os.Getenv("PATH"), "HOME=" + home, "GIT_TERMINAL_PROMPT=0", "GIT_ASKPASS=/bin/false",
		"GIT_CONFIG_NOSYSTEM=1", "LANG=C",
	}
	cfg := [][2]string{}
	if w.conn != nil && w.conn.Token != "" {
		cfg = append(cfg, [2]string{"http.extraHeader", w.conn.GitAuthHeader()})
	}
	if w.conn != nil && w.conn.Insecure {
		cfg = append(cfg, [2]string{"http.sslVerify", "false"})
	}
	if w.conn != nil && strings.TrimSpace(w.conn.CACert) != "" {
		ca := filepath.Join(w.tmpDir, "ca.pem")
		if err := os.WriteFile(ca, []byte(w.conn.CACert), 0o600); err != nil {
			return err
		}
		cfg = append(cfg, [2]string{"http.sslCAInfo", ca})
	}
	w.env = append(w.env, fmt.Sprintf("GIT_CONFIG_COUNT=%d", len(cfg)))
	for i, kv := range cfg {
		w.env = append(w.env, fmt.Sprintf("GIT_CONFIG_KEY_%d=%s", i, kv[0]), fmt.Sprintf("GIT_CONFIG_VALUE_%d=%s", i, kv[1]))
	}
	return nil
}

// git exécute une commande ; le jeton n'apparaît jamais dans les erreurs renvoyées.
func (w *Workspace) git(ctx context.Context, dir string, args ...string) (string, error) {
	ctx, cancel := context.WithTimeout(ctx, 5*time.Minute)
	defer cancel()
	cmd := exec.CommandContext(ctx, "git", args...)
	cmd.Dir = dir
	cmd.Env = w.env
	var out, errb bytes.Buffer
	cmd.Stdout, cmd.Stderr = &out, &errb
	if err := cmd.Run(); err != nil {
		msg := strings.TrimSpace(errb.String())
		if w.conn != nil && w.conn.Token != "" {
			msg = strings.ReplaceAll(msg, w.conn.Token, "***")
		}
		if msg == "" {
			msg = err.Error()
		}
		return "", fmt.Errorf("git %s : %s", args[0], msg)
	}
	return strings.TrimSpace(out.String()), nil
}

// Close supprime le clone.
func (w *Workspace) Close() { _ = os.RemoveAll(w.tmpDir) }

// Head renvoie le commit courant.
func (w *Workspace) Head(ctx context.Context) (string, error) {
	return w.git(ctx, w.Dir, "rev-parse", "HEAD")
}

// TerraformDirs liste les dossiers qui contiennent des fichiers .tf ("" = racine du dépôt) :
// le code Terraform peut se trouver dans un sous-dossier.
func (w *Workspace) TerraformDirs(ctx context.Context) ([]string, error) {
	out, err := w.git(ctx, w.Dir, "ls-files")
	if err != nil {
		return nil, err
	}
	set := map[string]bool{}
	for _, f := range strings.Split(out, "\n") {
		if strings.HasSuffix(f, ".tf") && !strings.Contains(f, ".terraform/") {
			d := path.Dir(f)
			if d == "." {
				d = ""
			}
			set[d] = true
		}
	}
	dirs := make([]string, 0, len(set))
	for d := range set {
		dirs = append(dirs, d)
	}
	sort.Strings(dirs)
	return dirs, nil
}

// CleanPath valide un sous-dossier relatif du dépôt ("" = racine).
func CleanPath(p string) (string, error) {
	p = strings.Trim(strings.ReplaceAll(strings.TrimSpace(p), "\\", "/"), "/")
	if p == "" || p == "." {
		return "", nil
	}
	clean := path.Clean(p)
	if strings.HasPrefix(clean, "..") || strings.HasPrefix(clean, "/") || strings.Contains(clean, "/../") {
		return "", fmt.Errorf("chemin invalide %q", p)
	}
	return clean, nil
}

// ReadTerraform renvoie les fichiers .tf d'un sous-dossier (sans descendre dans ses sous-dossiers).
func (w *Workspace) ReadTerraform(sub string) (map[string][]byte, error) {
	dir := filepath.Join(w.Dir, filepath.FromSlash(sub))
	entries, err := os.ReadDir(dir)
	if err != nil {
		return nil, fmt.Errorf("dossier %q introuvable dans le dépôt", sub)
	}
	files := map[string][]byte{}
	for _, e := range entries {
		if e.IsDir() || !strings.HasSuffix(e.Name(), ".tf") {
			continue
		}
		b, err := os.ReadFile(filepath.Join(dir, e.Name()))
		if err != nil {
			return nil, err
		}
		files[e.Name()] = b
	}
	if len(files) == 0 {
		return nil, fmt.Errorf("aucun fichier .tf dans %q", displayPath(sub))
	}
	return files, nil
}

// PushResult : commit poussé (Commit vide si rien n'avait changé).
type PushResult struct {
	Branch string `json:"branch"`
	Commit string `json:"commit"`
}

// Commit écrit les fichiers générés dans sub, supprime les .tf qui n'en font plus partie,
// commite et pousse sur targetBranch (créée si elle diffère de la branche clonée).
func (w *Workspace) Commit(ctx context.Context, sub string, files map[string]string, targetBranch, message string) (*PushResult, error) {
	dir := filepath.Join(w.Dir, filepath.FromSlash(sub))
	if err := os.MkdirAll(dir, 0o755); err != nil {
		return nil, err
	}
	// Les .tf du dossier reflètent le modèle : un fichier disparu du modèle est supprimé.
	entries, _ := os.ReadDir(dir)
	for _, e := range entries {
		if !e.IsDir() && strings.HasSuffix(e.Name(), ".tf") {
			if _, keep := files[e.Name()]; !keep {
				_ = os.Remove(filepath.Join(dir, e.Name()))
			}
		}
	}
	for name, content := range files {
		clean := filepath.Clean(name)
		if filepath.IsAbs(clean) || strings.HasPrefix(clean, "..") {
			return nil, fmt.Errorf("chemin de fichier interdit : %s", name)
		}
		p := filepath.Join(dir, clean)
		if err := os.MkdirAll(filepath.Dir(p), 0o755); err != nil {
			return nil, err
		}
		if err := os.WriteFile(p, []byte(content), 0o644); err != nil {
			return nil, err
		}
	}
	if _, err := w.git(ctx, w.Dir, "checkout", "-B", targetBranch); err != nil {
		return nil, err
	}
	addPath := sub
	if addPath == "" {
		addPath = "."
	}
	if _, err := w.git(ctx, w.Dir, "add", "-A", "--", addPath); err != nil {
		return nil, err
	}
	if st, _ := w.git(ctx, w.Dir, "status", "--porcelain", "--", addPath); st == "" {
		head, err := w.Head(ctx)
		return &PushResult{Branch: targetBranch, Commit: ""}, errors.Join(err, ErrNothingToCommit(head))
	}
	name, email := "HCLDesigner", "hcldesigner@localhost"
	if w.conn != nil {
		if w.conn.AuthorName != "" {
			name = w.conn.AuthorName
		}
		if w.conn.AuthorEmail != "" {
			email = w.conn.AuthorEmail
		}
	}
	if _, err := w.git(ctx, w.Dir, "-c", "user.name="+name, "-c", "user.email="+email, "commit", "-q", "-m", message); err != nil {
		return nil, err
	}
	commit, err := w.Head(ctx)
	if err != nil {
		return nil, err
	}
	if _, err := w.git(ctx, w.Dir, "push", "origin", "HEAD:refs/heads/"+targetBranch); err != nil {
		return nil, err
	}
	return &PushResult{Branch: targetBranch, Commit: commit}, nil
}

// nothingToCommit : le dépôt contient déjà exactement le code généré.
type nothingToCommit struct{ head string }

func (n nothingToCommit) Error() string { return "aucun changement : le dépôt est déjà à jour" }

// ErrNothingToCommit construit l'erreur « rien à pousser » (commit courant joint).
func ErrNothingToCommit(head string) error { return nothingToCommit{head} }

// IsNothingToCommit indique qu'aucun commit n'était nécessaire, et renvoie le commit courant.
func IsNothingToCommit(err error) (string, bool) {
	var n nothingToCommit
	if errors.As(err, &n) {
		return n.head, true
	}
	return "", false
}

func displayPath(p string) string {
	if p == "" {
		return "racine du dépôt"
	}
	return p
}
