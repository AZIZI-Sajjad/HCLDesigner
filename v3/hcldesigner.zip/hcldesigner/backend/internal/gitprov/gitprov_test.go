package gitprov

import (
	"context"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"testing"
)

// bareRepo crée un dépôt nu avec du code Terraform dans infra/prod (sous-dossier).
func bareRepo(t *testing.T) string {
	t.Helper()
	root := t.TempDir()
	src := filepath.Join(root, "src")
	bare := filepath.Join(root, "bare.git")
	run := func(dir string, args ...string) {
		t.Helper()
		cmd := exec.Command("git", args...)
		cmd.Dir = dir
		cmd.Env = append(os.Environ(), "GIT_AUTHOR_NAME=t", "GIT_AUTHOR_EMAIL=t@t", "GIT_COMMITTER_NAME=t", "GIT_COMMITTER_EMAIL=t@t")
		if out, err := cmd.CombinedOutput(); err != nil {
			t.Fatalf("git %v : %v\n%s", args, err, out)
		}
	}
	_ = os.MkdirAll(filepath.Join(src, "infra", "prod"), 0o755)
	_ = os.WriteFile(filepath.Join(src, "README.md"), []byte("# demo\n"), 0o644)
	_ = os.WriteFile(filepath.Join(src, "infra", "prod", "main.tf"), []byte(`resource "null_resource" "a" {}`+"\n"), 0o644)
	_ = os.WriteFile(filepath.Join(src, "infra", "prod", "old.tf"), []byte(`resource "null_resource" "old" {}`+"\n"), 0o644)
	run(src, "init", "-q", "-b", "main")
	run(src, "add", ".")
	run(src, "commit", "-q", "-m", "init")
	run(root, "clone", "-q", "--bare", src, bare)
	return bare
}

func TestWorkspaceSubfolderImportAndPush(t *testing.T) {
	ctx := context.Background()
	bare := bareRepo(t)
	conn := &Conn{Provider: Gitea, AuthorName: "Alice", AuthorEmail: "alice@example.com"}

	ws, err := Clone(ctx, conn, "file://"+bare, "main", t.TempDir())
	if err != nil {
		t.Fatal(err)
	}
	defer ws.Close()
	dirs, err := ws.TerraformDirs(ctx)
	if err != nil || len(dirs) != 1 || dirs[0] != "infra/prod" {
		t.Fatalf("dossiers Terraform : %v %v", dirs, err)
	}
	files, err := ws.ReadTerraform("infra/prod")
	if err != nil || len(files) != 2 {
		t.Fatalf("lecture du sous-dossier : %v %v", len(files), err)
	}
	if _, err := ws.ReadTerraform(""); err == nil {
		t.Errorf("la racine ne contient pas de .tf : erreur attendue")
	}

	// Push sur une nouvelle branche : old.tf disparaît du modèle, main.tf change, README intact.
	res, err := ws.Commit(ctx, "infra/prod", map[string]string{"main.tf": "resource \"null_resource\" \"b\" {}\n"}, "hcld/update", "maj depuis HCLDesigner")
	if err != nil || res.Commit == "" || res.Branch != "hcld/update" {
		t.Fatalf("commit : %+v %v", res, err)
	}
	// Deuxième push identique : rien à commiter.
	if _, err := ws.Commit(ctx, "infra/prod", map[string]string{"main.tf": "resource \"null_resource\" \"b\" {}\n"}, "hcld/update", "x"); err == nil {
		t.Errorf("rien à commiter : erreur attendue")
	} else if head, ok := IsNothingToCommit(err); !ok || head != res.Commit {
		t.Errorf("erreur « rien à commiter » attendue avec le commit courant : %v", err)
	}

	check, err := Clone(ctx, nil, "file://"+bare, "hcld/update", t.TempDir())
	if err != nil {
		t.Fatal(err)
	}
	defer check.Close()
	if _, err := os.Stat(filepath.Join(check.Dir, "infra/prod/old.tf")); !os.IsNotExist(err) {
		t.Errorf("old.tf aurait dû être supprimé")
	}
	if _, err := os.Stat(filepath.Join(check.Dir, "README.md")); err != nil {
		t.Errorf("README.md ne doit pas être touché")
	}
	author, _ := check.git(ctx, check.Dir, "log", "-1", "--format=%an <%ae>")
	if author != "Alice <alice@example.com>" {
		t.Errorf("auteur du commit : %q", author)
	}
}

func TestCleanPath(t *testing.T) {
	for in, want := range map[string]string{"": "", "/": "", "infra/prod/": "infra/prod", " a\\b ": "a/b"} {
		if got, err := CleanPath(in); err != nil || got != want {
			t.Errorf("CleanPath(%q) = %q, %v", in, got, err)
		}
	}
	if _, err := CleanPath("../etc"); err == nil {
		t.Errorf("chemin remontant refusé attendu")
	}
}

// Les trois fournisseurs : chemins d'API, en-têtes d'authentification et décodage.
func TestProviders(t *testing.T) {
	var seen []string
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		seen = append(seen, r.Method+" "+r.URL.Path+" "+r.Header.Get("Authorization")+r.Header.Get("PRIVATE-TOKEN"))
		w.Header().Set("Content-Type", "application/json")
		switch {
		case strings.HasSuffix(r.URL.Path, "/user"):
			_ = json.NewEncoder(w).Encode(map[string]string{"login": "alice", "username": "alice", "name": "Alice"})
		case strings.Contains(r.URL.Path, "/repos/search"): // Gitea
			_ = json.NewEncoder(w).Encode(map[string]any{"data": []map[string]any{{"full_name": "ops/infra", "default_branch": "main"}}})
		case strings.HasSuffix(r.URL.Path, "/user/repos"): // GitHub
			_ = json.NewEncoder(w).Encode([]map[string]any{{"full_name": "ops/infra", "default_branch": "main"}, {"full_name": "ops/web"}})
		case strings.HasSuffix(r.URL.Path, "/projects"): // GitLab
			_ = json.NewEncoder(w).Encode([]map[string]any{{"path_with_namespace": "ops/sub/infra", "default_branch": "main", "visibility": "private"}})
		case strings.Contains(r.URL.Path, "branches"):
			_ = json.NewEncoder(w).Encode([]map[string]string{{"name": "main"}, {"name": "dev"}})
		case strings.HasSuffix(r.URL.Path, "/pulls"):
			_ = json.NewEncoder(w).Encode(map[string]string{"html_url": "https://forge/pr/1"})
		case strings.HasSuffix(r.URL.Path, "/merge_requests"):
			_ = json.NewEncoder(w).Encode(map[string]string{"web_url": "https://forge/mr/1"})
		default:
			http.NotFound(w, r)
		}
	}))
	defer srv.Close()
	ctx := context.Background()

	for _, tc := range []struct {
		provider, wantAuth, wantRepo, wantPR, apiPrefix string
	}{
		{GitHub, "Bearer tok", "ops/infra", "https://forge/pr/1", "/api/v3"},
		{GitLab, "tok", "ops/sub/infra", "https://forge/mr/1", "/api/v4"},
		{Gitea, "token tok", "ops/infra", "https://forge/pr/1", "/api/v1"},
	} {
		seen = nil
		c := &Conn{Provider: tc.provider, BaseURL: srv.URL, Token: "tok", Username: "alice"}
		u, err := c.CurrentUser(ctx)
		if err != nil || u.Login != "alice" {
			t.Fatalf("%s user : %+v %v", tc.provider, u, err)
		}
		repos, err := c.Repos(ctx, "infra")
		if err != nil || len(repos) != 1 || repos[0].FullName != tc.wantRepo {
			t.Errorf("%s repos : %+v %v", tc.provider, repos, err)
		}
		br, err := c.Branches(ctx, tc.wantRepo)
		if err != nil || strings.Join(br, ",") != "dev,main" {
			t.Errorf("%s branches : %v %v", tc.provider, br, err)
		}
		url, err := c.OpenChangeRequest(ctx, tc.wantRepo, "hcld/x", "main", "titre", "corps")
		if err != nil || url != tc.wantPR {
			t.Errorf("%s PR/MR : %q %v", tc.provider, url, err)
		}
		if !strings.HasPrefix(strings.SplitN(seen[0], " ", 3)[1], tc.apiPrefix) || !strings.HasSuffix(seen[0], tc.wantAuth) {
			t.Errorf("%s : appel %q (préfixe %s, auth %q attendus)", tc.provider, seen[0], tc.apiPrefix, tc.wantAuth)
		}
	}
	// GitLab : chemin de dépôt encodé (groupes imbriqués).
	if p := (&Conn{Provider: GitLab}).repoPath("ops/sub/infra"); p != "/projects/ops%2Fsub%2Finfra" {
		t.Errorf("chemin GitLab : %s", p)
	}
	if (&Conn{Provider: GitHub, BaseURL: "https://github.com"}).apiBase() != "https://api.github.com" {
		t.Errorf("API github.com")
	}
}
