package hclimport

import (
	"sort"

	"github.com/AZIZI-Sajjad/hcldesigner/internal/model"
)

// Dimensions du canvas (doivent rester cohérentes avec TfNodeCard / ContainerNode du frontend).
const (
	cardW, cardH   = 224, 80 // carte d'un objet simple
	colGap, rowGap = 96, 32  // espacement entre colonnes / lignes
	framePad       = 24      // marge intérieure d'un cadre
	frameHeader    = 48      // hauteur du bandeau d'un cadre
	frameMinW      = 320     // taille minimale d'un cadre
	frameMinH      = 200
)

// assignParents range chaque objet dans le cadre conteneur qu'il référence (subnet_id ->
// aws_subnet, resource_group_name -> azurerm_resource_group…). Si plusieurs cadres sont
// référencés, le plus profond l'emporte (une instance va dans le subnet plutôt que dans le VPC).
func assignParents(p *model.Project, isContainer func(string) bool) {
	if isContainer == nil {
		return
	}
	byID := p.NodeByID()
	nestable := func(n *model.Node) bool {
		return n.Kind == model.KindResource || n.Kind == model.KindData || n.Kind == model.KindModule
	}
	frame := func(n *model.Node) bool {
		return (n.Kind == model.KindResource || n.Kind == model.KindData) && isContainer(n.Type)
	}
	cands := map[string][]string{}
	for _, e := range p.Edges() {
		if e.Kind == "depends_on" || e.Source == e.Target {
			continue
		}
		src, dst := byID[e.Source], byID[e.Target]
		if src != nil && dst != nil && frame(src) && nestable(dst) {
			cands[dst.ID] = append(cands[dst.ID], src.ID)
		}
	}

	// Profondeur d'un cadre = nombre de cadres ancêtres ; calculée à la demande, cycles coupés.
	depth := map[string]int{}
	visiting := map[string]bool{}
	var parentOf func(id string) string
	var depthOf func(id string) int
	parentOf = func(id string) string {
		best, bestDepth := "", -1
		for _, c := range cands[id] {
			if visiting[c] {
				continue
			}
			if d := depthOf(c); d > bestDepth {
				best, bestDepth = c, d
			}
		}
		return best
	}
	depthOf = func(id string) int {
		if d, ok := depth[id]; ok {
			return d
		}
		visiting[id] = true
		d := 0
		if par := parentOf(id); par != "" {
			d = depthOf(par) + 1
		}
		visiting[id] = false
		depth[id] = d
		return d
	}
	for i := range p.Nodes {
		n := &p.Nodes[i]
		if nestable(n) {
			visiting[n.ID] = true
			n.Parent = parentOf(n.ID)
			visiting[n.ID] = false
		}
	}
}

// layoutPositions place les objets en colonnes selon leur profondeur de dépendance
// (colonne 0 = sans dépendance), récursivement dans chaque cadre : le contenu d'un cadre
// est disposé d'abord, puis le cadre est dimensionné pour l'englober.
func layoutPositions(p *model.Project, isContainer func(string) bool) {
	children := map[string][]*model.Node{}
	for i := range p.Nodes {
		n := &p.Nodes[i]
		children[n.Parent] = append(children[n.Parent], n)
	}
	preds := map[string][]string{}
	for _, e := range p.Edges() {
		if e.Source != e.Target {
			preds[e.Target] = append(preds[e.Target], e.Source)
		}
	}
	// Un cadre vide (VPC sans contenu) garde l'aspect d'un cadre, à sa taille minimale.
	isFrame := func(n *model.Node) bool {
		return len(children[n.ID]) > 0 || (isContainer != nil && (n.Kind == model.KindResource || n.Kind == model.KindData) && isContainer(n.Type))
	}

	var layoutGroup func(members []*model.Node) (w, h float64)
	sizeOf := func(n *model.Node) (float64, float64) {
		if n.Size != nil {
			return n.Size.W, n.Size.H
		}
		return cardW, cardH
	}
	layoutGroup = func(members []*model.Node) (float64, float64) {
		// 1. Dimensionner d'abord les cadres (contenu disposé relativement au cadre).
		for _, n := range members {
			if !isFrame(n) {
				continue
			}
			cw, ch := layoutGroup(children[n.ID])
			for _, c := range children[n.ID] {
				c.Position.X += framePad
				c.Position.Y += frameHeader
			}
			n.Size = &model.Size{W: max(cw+2*framePad, frameMinW), H: max(ch+frameHeader+framePad, frameMinH)}
		}
		// 2. Colonnes par profondeur de dépendance entre membres du groupe.
		in := map[string]bool{}
		for _, n := range members {
			in[n.ID] = true
		}
		depth := map[string]int{}
		visiting := map[string]bool{}
		var visit func(id string) int
		visit = func(id string) int {
			if d, ok := depth[id]; ok {
				return d
			}
			if visiting[id] {
				return 0
			}
			visiting[id] = true
			d := 0
			for _, src := range preds[id] {
				if in[src] {
					d = max(d, visit(src)+1)
				}
			}
			visiting[id] = false
			depth[id] = d
			return d
		}
		cols := map[int][]*model.Node{}
		maxCol := 0
		for _, n := range members {
			d := visit(n.ID)
			if n.Kind == model.KindOutput {
				d++
			}
			cols[d] = append(cols[d], n)
			maxCol = max(maxCol, d)
		}
		// 3. Placement : colonnes de largeur variable, lignes empilées.
		var x, totalH float64
		for c := 0; c <= maxCol; c++ {
			nodes := cols[c]
			if len(nodes) == 0 {
				continue
			}
			sort.SliceStable(nodes, func(i, j int) bool {
				if nodes[i].Kind != nodes[j].Kind {
					return nodes[i].Kind < nodes[j].Kind
				}
				return nodes[i].Address() < nodes[j].Address()
			})
			var y, colW float64
			for _, n := range nodes {
				w, h := sizeOf(n)
				n.Position = model.Position{X: x, Y: y}
				y += h + rowGap
				colW = max(colW, w)
			}
			x += colW + colGap
			totalH = max(totalH, y-rowGap)
		}
		return max(x-colGap, 0), totalH
	}
	layoutGroup(children[""])
}
