package modules

import (
	"strings"
	"testing"

	"github.com/AZIZI-Sajjad/hcldesigner/internal/hclgen"
	"github.com/AZIZI-Sajjad/hcldesigner/internal/model"
)

func ref(node, attr string) model.Value {
	return model.Value{Mode: model.ModeRef, Ref: &model.Ref{NodeID: node, Attr: attr}}
}

// Le scénario d'acceptation : VPC + subnets extraits en module "network", réutilisé via module.network.*
func TestExtractNetwork(t *testing.T) {
	p := model.New()
	p.Providers = []model.ProviderConfig{{LocalName: "aws", Source: "hashicorp/aws", Version: "~> 5.0"}}
	p.Nodes = []model.Node{
		{ID: "cidr", Kind: model.KindVariable, Label: "vpc_cidr", Attrs: map[string]model.Value{}},
		{ID: "vpc", Kind: model.KindResource, Type: "aws_vpc", Label: "main", Attrs: map[string]model.Value{"cidr_block": ref("cidr", "")}},
		{ID: "sub", Kind: model.KindResource, Type: "aws_subnet", Label: "public", Attrs: map[string]model.Value{"vpc_id": ref("vpc", "id")}},
		{ID: "ec2", Kind: model.KindResource, Type: "aws_instance", Label: "web", Attrs: map[string]model.Value{"subnet_id": ref("sub", "id")}, Meta: model.Meta{DependsOn: []string{"vpc"}}},
	}
	res, err := Extract(&p, []string{"vpc", "sub"}, "mod-1", "network", "network")
	if err != nil {
		t.Fatal(err)
	}
	if len(res.Project.Nodes) != 3 {
		t.Fatalf("le projet doit contenir variable, instance et module : %d nœuds", len(res.Project.Nodes))
	}
	var ec2, mod *model.Node
	for i := range res.Project.Nodes {
		switch res.Project.Nodes[i].ID {
		case "ec2":
			ec2 = &res.Project.Nodes[i]
		case res.ModuleNodeID:
			mod = &res.Project.Nodes[i]
		}
	}
	if r := ec2.Attrs["subnet_id"].Ref; r == nil || r.NodeID != res.ModuleNodeID || r.Attr != "public_id" {
		t.Errorf("subnet_id doit référencer module.network.public_id : %+v", r)
	}
	if len(ec2.Meta.DependsOn) != 1 || ec2.Meta.DependsOn[0] != res.ModuleNodeID {
		t.Errorf("depends_on doit pointer vers le module : %v", ec2.Meta.DependsOn)
	}
	if r := mod.Attrs["vpc_cidr"].Ref; r == nil || r.NodeID != "cidr" {
		t.Errorf("l'input vpc_cidr du module doit référencer var.vpc_cidr : %+v", mod.Attrs)
	}
	vars, outs := hclgen.ModuleInterface(&res.Module)
	if len(vars) != 1 || vars[0].Name != "vpc_cidr" || len(outs) != 1 || outs[0].Name != "public_id" {
		t.Errorf("interface du module inattendue : %+v %+v", vars, outs)
	}
	// Génération complète : le module et l'appel doivent produire du HCL cohérent.
	gen := hclgen.Generate(&res.Project, nil, hclgen.Options{Modules: map[string]*hclgen.ModuleDef{"mod-1": {ID: "mod-1", Name: "network", Version: "1.0.0", Model: &res.Module}}})
	if len(gen.Diags) > 0 {
		t.Fatalf("diagnostics : %+v", gen.Diags)
	}
	if !strings.Contains(gen.Files["main.tf"], "subnet_id = module.network.public_id") {
		t.Errorf("main.tf :\n%s", gen.Files["main.tf"])
	}
	if !strings.Contains(gen.Files["modules/network/main.tf"], "vpc_id = aws_vpc.main.id") {
		t.Errorf("module :\n%s", gen.Files["modules/network/main.tf"])
	}
}

// Cadres : extraire le VPC et son subnet libère l'instance (elle remonte à la racine, même place
// à l'écran) ; extraire seulement l'instance place le module dans le subnet.
func TestExtractFrames(t *testing.T) {
	build := func() model.Project {
		p := model.New()
		p.Providers = []model.ProviderConfig{{LocalName: "aws", Source: "hashicorp/aws"}}
		p.Nodes = []model.Node{
			{ID: "vpc", Kind: model.KindResource, Type: "aws_vpc", Label: "main", Attrs: map[string]model.Value{}, Position: model.Position{X: 100, Y: 100}},
			{ID: "sub", Kind: model.KindResource, Type: "aws_subnet", Label: "a", Parent: "vpc", Attrs: map[string]model.Value{"vpc_id": ref("vpc", "id")}, Position: model.Position{X: 24, Y: 48}},
			{ID: "ec2", Kind: model.KindResource, Type: "aws_instance", Label: "web", Parent: "sub", Attrs: map[string]model.Value{"subnet_id": ref("sub", "id")}, Position: model.Position{X: 24, Y: 48}},
		}
		return p
	}
	p := build()
	res, err := Extract(&p, []string{"vpc", "sub"}, "m1", "network", "network")
	if err != nil {
		t.Fatal(err)
	}
	for _, n := range res.Project.Nodes {
		if n.ID == "ec2" && (n.Parent != "" || n.Position != (model.Position{X: 148, Y: 196})) {
			t.Errorf("instance libérée : parent=%q position=%+v", n.Parent, n.Position)
		}
	}
	for _, n := range res.Module.Nodes {
		if n.ID == "vpc" && n.Parent != "" || n.ID == "sub" && n.Parent != "vpc" {
			t.Errorf("imbrication conservée dans le module : %s parent=%q", n.ID, n.Parent)
		}
	}

	p = build()
	res, err = Extract(&p, []string{"ec2"}, "m2", "compute", "compute")
	if err != nil {
		t.Fatal(err)
	}
	for _, n := range res.Project.Nodes {
		if n.ID == res.ModuleNodeID && (n.Parent != "sub" || n.Position != (model.Position{X: 24, Y: 48})) {
			t.Errorf("module placé dans le cadre de la sélection : parent=%q position=%+v", n.Parent, n.Position)
		}
	}
}
