-- v3 : workers distants (agents HTTP) et intégration Git.

-- Workers : chaque agent s'authentifie avec son propre jeton (révocable).
CREATE TABLE workers (
    id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    name          text NOT NULL UNIQUE,
    token_hash    bytea NOT NULL,
    state         text NOT NULL DEFAULT 'active' CHECK (state IN ('active','paused','revoked')),
    slots         int  NOT NULL DEFAULT 2 CHECK (slots BETWEEN 1 AND 64),
    labels        text[] NOT NULL DEFAULT '{}',
    is_default    boolean NOT NULL DEFAULT false,
    version       text NOT NULL DEFAULT '',
    hostname      text NOT NULL DEFAULT '',
    os_arch       text NOT NULL DEFAULT '',
    remote_addr   text NOT NULL DEFAULT '',
    running       int  NOT NULL DEFAULT 0,
    last_seen_at  timestamptz,
    created_by    uuid REFERENCES users(id) ON DELETE SET NULL,
    created_at    timestamptz NOT NULL DEFAULT now()
);

-- Jetons d'enrôlement : usage unique, durée limitée, échangés contre un jeton de worker.
CREATE TABLE worker_join_tokens (
    id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    token_hash  bytea NOT NULL UNIQUE,
    name        text NOT NULL,
    slots       int  NOT NULL DEFAULT 2,
    labels      text[] NOT NULL DEFAULT '{}',
    expires_at  timestamptz NOT NULL,
    used_at     timestamptz,
    worker_id   uuid REFERENCES workers(id) ON DELETE SET NULL,
    created_by  uuid REFERENCES users(id) ON DELETE SET NULL,
    created_at  timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE runs ADD COLUMN worker_id uuid REFERENCES workers(id) ON DELETE SET NULL;
ALTER TABLE runs ADD COLUMN last_seen_at timestamptz;
ALTER TABLE schema_jobs ADD COLUMN worker_id uuid REFERENCES workers(id) ON DELETE SET NULL;
ALTER TABLE schema_jobs ADD COLUMN started_at timestamptz;

-- Un environnement peut exiger des labels de worker (ex. "dc1" : réseau joignable depuis ce site).
ALTER TABLE environments ADD COLUMN worker_labels text[] NOT NULL DEFAULT '{}';

-- Connexions Git personnelles : chaque utilisateur a ses propres jetons et son identité de commit.
CREATE TABLE git_connections (
    id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id       uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    name          text NOT NULL,
    provider      text NOT NULL CHECK (provider IN ('github','gitlab','gitea')),
    base_url      text NOT NULL,
    username      text NOT NULL DEFAULT '',
    token_enc     bytea NOT NULL,
    author_name   text NOT NULL DEFAULT '',
    author_email  text NOT NULL DEFAULT '',
    ca_cert       text NOT NULL DEFAULT '',
    insecure_tls  boolean NOT NULL DEFAULT false,
    created_at    timestamptz NOT NULL DEFAULT now(),
    UNIQUE (user_id, name)
);

-- Dépôt lié à un projet (partagé) : chaque utilisateur pousse avec sa propre connexion vers cet hôte.
CREATE TABLE project_git (
    project_id      uuid PRIMARY KEY REFERENCES projects(id) ON DELETE CASCADE,
    provider        text NOT NULL CHECK (provider IN ('github','gitlab','gitea')),
    base_url        text NOT NULL,
    repo            text NOT NULL,          -- owner/name ou groupe/sous-groupe/nom
    branch          text NOT NULL,
    path            text NOT NULL DEFAULT '',
    last_commit     text NOT NULL DEFAULT '',
    last_sync_at    timestamptz,
    last_sync_by    uuid REFERENCES users(id) ON DELETE SET NULL,
    last_sync_kind  text NOT NULL DEFAULT ''  -- import | push | pr
);

CREATE INDEX runs_worker_running ON runs(worker_id) WHERE status='running';
