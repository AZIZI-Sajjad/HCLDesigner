package agent

import (
	"bytes"
	"compress/gzip"
	"context"
	"crypto/tls"
	"crypto/x509"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"os"
	"strings"
	"time"
)

// ErrUnauthorized : jeton refusé (worker révoqué, supprimé ou jeton renouvelé).
var ErrUnauthorized = errors.New("jeton de worker refusé")

// client parle à l'API HCLDesigner (préfixe /api/agent).
type client struct {
	base  string
	http  *http.Client
	token func() string
}

// newHTTPClient applique les options TLS (CA privée, vérification désactivée).
func newHTTPClient(caFile string, insecure bool) (*http.Client, error) {
	tr := http.DefaultTransport.(*http.Transport).Clone()
	tr.TLSClientConfig = &tls.Config{MinVersion: tls.VersionTLS12, InsecureSkipVerify: insecure} //nolint:gosec // choix explicite de l'administrateur
	if caFile != "" {
		pem, err := os.ReadFile(caFile)
		if err != nil {
			return nil, fmt.Errorf("CA %s : %w", caFile, err)
		}
		pool, _ := x509.SystemCertPool()
		if pool == nil {
			pool = x509.NewCertPool()
		}
		if !pool.AppendCertsFromPEM(pem) {
			return nil, fmt.Errorf("CA %s : aucun certificat PEM", caFile)
		}
		tr.TLSClientConfig.RootCAs = pool
	}
	return &http.Client{Transport: tr, Timeout: 5 * time.Minute}, nil
}

// do envoie une requête JSON (corps compressé en gzip au-delà de 64 Ko) et décode la réponse.
// Renvoie false si le serveur a répondu 204 (rien à faire).
func (c *client) do(ctx context.Context, method, path string, in, out any) (bool, error) {
	var body io.Reader
	gz := false
	if in != nil {
		raw, err := json.Marshal(in)
		if err != nil {
			return false, err
		}
		if len(raw) > 64<<10 {
			var buf bytes.Buffer
			w := gzip.NewWriter(&buf)
			_, _ = w.Write(raw)
			_ = w.Close()
			raw, gz = buf.Bytes(), true
		}
		body = bytes.NewReader(raw)
	}
	req, err := http.NewRequestWithContext(ctx, method, c.base+"/api/agent"+path, body)
	if err != nil {
		return false, err
	}
	req.Header.Set("Content-Type", "application/json")
	if gz {
		req.Header.Set("Content-Encoding", "gzip")
	}
	if t := c.token(); t != "" {
		req.Header.Set("Authorization", "Bearer "+t)
	}
	resp, err := c.http.Do(req)
	if err != nil {
		return false, err
	}
	defer resp.Body.Close()
	switch {
	case resp.StatusCode == http.StatusNoContent:
		return false, nil
	case resp.StatusCode == http.StatusUnauthorized:
		return false, ErrUnauthorized
	case resp.StatusCode >= 300:
		msg, _ := io.ReadAll(io.LimitReader(resp.Body, 4096))
		return false, fmt.Errorf("%s %s : HTTP %d %s", method, path, resp.StatusCode, strings.TrimSpace(string(msg)))
	}
	if out != nil {
		return true, json.NewDecoder(resp.Body).Decode(out)
	}
	return true, nil
}

// postLog envoie un morceau de log brut (déjà masqué).
func (c *client) postLog(ctx context.Context, runID string, chunk []byte) (bool, error) {
	req, err := http.NewRequestWithContext(ctx, http.MethodPost, c.base+"/api/agent/runs/"+runID+"/log", bytes.NewReader(chunk))
	if err != nil {
		return false, err
	}
	req.Header.Set("Content-Type", "application/octet-stream")
	req.Header.Set("Authorization", "Bearer "+c.token())
	resp, err := c.http.Do(req)
	if err != nil {
		return false, err
	}
	defer resp.Body.Close()
	if resp.StatusCode == http.StatusUnauthorized {
		return true, ErrUnauthorized
	}
	if resp.StatusCode >= 300 {
		return false, fmt.Errorf("log : HTTP %d", resp.StatusCode)
	}
	var lr LogResponse
	_ = json.NewDecoder(resp.Body).Decode(&lr)
	return lr.Cancel, nil
}
