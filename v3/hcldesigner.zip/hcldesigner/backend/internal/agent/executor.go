package agent

import (
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"strings"
	"time"

	"github.com/AZIZI-Sajjad/hcldesigner/internal/core"
	"github.com/AZIZI-Sajjad/hcldesigner/internal/schema"
	"github.com/AZIZI-Sajjad/hcldesigner/internal/tfbin"
)

// Executor exécute les jobs reçus du serveur dans des workspaces éphémères.
type Executor struct {
	DataDir string
	TF      *tfbin.Manager
}

// NewExecutor prépare les dossiers de travail du worker.
func NewExecutor(dataDir string) (*Executor, error) {
	for _, d := range []string{"work", "bin", "plugin-cache"} {
		if err := os.MkdirAll(filepath.Join(dataDir, d), 0o700); err != nil {
			return nil, err
		}
	}
	return &Executor{DataDir: dataDir, TF: tfbin.New(dataDir)}, nil
}

// Run exécute un run Terraform. log reçoit la sortie (secrets masqués) ; canceled est
// interrogé régulièrement pendant l'exécution des commandes.
func (e *Executor) Run(ctx context.Context, j *Job, log io.Writer, canceled func() bool) *Result {
	if j.TimeoutSec > 0 {
		var cancel context.CancelFunc
		ctx, cancel = context.WithTimeout(ctx, time.Duration(j.TimeoutSec)*time.Second)
		defer cancel()
	}
	mw := newMaskWriter(log, j.Secrets)
	defer mw.Flush()
	res, err := e.run(ctx, j, mw, canceled)
	switch {
	case errors.Is(err, ErrCanceled):
		return &Result{Canceled: true, ExitCode: -1, Error: "annulé"}
	case err != nil:
		fmt.Fprintf(mw, "\n\x1b[31m[hcldesigner] échec : %s\x1b[0m\n", err)
		mw.Flush()
		return &Result{Failed: true, ExitCode: -1, Error: err.Error()}
	}
	return res
}

func (e *Executor) run(ctx context.Context, spec *Job, log *maskWriter, canceled func() bool) (*Result, error) {
	dir, err := os.MkdirTemp(filepath.Join(e.DataDir, "work"), "run-*")
	if err != nil {
		return nil, err
	}
	defer os.RemoveAll(dir)

	bin, err := e.TF.Resolve(ctx, spec.Engine, spec.EngineVersion)
	if err != nil {
		return nil, err
	}
	cli, err := e.TF.CLIConfig(dir, spec.Mirror)
	if err != nil {
		return nil, err
	}
	env := tfbin.BaseEnv(cli)
	for _, v := range spec.Env {
		env = append(env, strings.ReplaceAll(v, core.WorkdirPlaceholder, dir))
	}
	if err := writeFiles(dir, spec.Files); err != nil {
		return nil, err
	}
	if err := writeFiles(dir, spec.CredFiles); err != nil {
		return nil, err
	}
	stateFile := filepath.Join(dir, "terraform.tfstate")
	if spec.Internal && len(spec.InternalState) > 0 {
		if err := os.WriteFile(stateFile, spec.InternalState, 0o600); err != nil {
			return nil, err
		}
	}

	j := &job{runID: spec.RunID, dir: dir, bin: bin, env: env, log: log, cancel: canceled}
	j.logf("%s (%s, worker %s)", spec.Title, filepath.Base(bin), hostname())

	res := &Result{}
	if code, err := j.run(ctx, nil, spec.InitArgs...); err != nil {
		return nil, err
	} else if code != 0 {
		return &Result{ExitCode: code, Error: "terraform init en échec", Step: "init"}, nil
	}
	if b, err := os.ReadFile(filepath.Join(dir, ".terraform.lock.hcl")); err == nil {
		res.LockFile = string(b)
	}

	switch spec.Operation {
	case "init":
	case "validate":
		err = e.validate(ctx, j, res)
	case "plan":
		err = e.plan(ctx, j, spec, res)
	case "apply":
		err = e.apply(ctx, j, spec, res)
	case "state":
		err = e.state(ctx, j, spec, res)
	default:
		err = fmt.Errorf("opération inconnue %q", spec.Operation)
	}
	if err != nil {
		return nil, err
	}
	if spec.ArchiveState && res.Error == "" && !res.StateChanged {
		if spec.Internal {
			res.FinalState, _ = os.ReadFile(stateFile)
		} else if raw, _, err := statePull(ctx, j); err == nil {
			res.FinalState = raw
		} else {
			j.logf("lecture du state final impossible : %v", err)
		}
	}
	return res, nil
}

func (e *Executor) validate(ctx context.Context, j *job, res *Result) error {
	var buf bytes.Buffer
	code, err := j.run(ctx, &buf, "validate", "-json", "-no-color")
	if err != nil {
		return err
	}
	res.ExitCode, res.ValidateJSON = code, buf.Bytes()
	return nil
}

func (e *Executor) plan(ctx context.Context, j *job, spec *Job, res *Result) error {
	_, meta, err := statePull(ctx, j)
	if err != nil {
		return err
	}
	res.StateSerial, res.StateLineage = &meta.Serial, meta.Lineage
	code, err := j.run(ctx, nil, spec.Plan.Args...)
	if err != nil {
		return err
	}
	res.ExitCode = code
	if code == 1 || code < 0 {
		res.Error, res.Step = "terraform plan en échec", "plan"
		return nil
	}
	var show bytes.Buffer
	if c, err := j.run(ctx, &show, "show", "-json", "plan.tfplan"); err != nil {
		return err
	} else if c != 0 {
		res.ExitCode, res.Error, res.Step = c, "terraform show -json en échec", "show"
		return nil
	}
	res.PlanJSON = show.Bytes()
	res.PlanFile, err = os.ReadFile(filepath.Join(j.dir, "plan.tfplan"))
	return err
}

func (e *Executor) apply(ctx context.Context, j *job, spec *Job, res *Result) error {
	a := spec.Apply
	if err := os.WriteFile(filepath.Join(j.dir, "plan.tfplan"), a.PlanFile, 0o600); err != nil {
		return err
	}
	// Le state ne doit pas avoir changé depuis le plan.
	_, meta, err := statePull(ctx, j)
	if err != nil {
		return err
	}
	if a.ExpectSerial != nil && (meta.Serial != *a.ExpectSerial || meta.Lineage != a.ExpectLineage) {
		res.StateChanged, res.ExitCode = true, -1
		res.Error = fmt.Sprintf("le state a changé depuis le plan (serial %d → %d) : relancez un plan", *a.ExpectSerial, meta.Serial)
		return nil
	}
	code, err := j.run(ctx, nil, a.Args...)
	if err != nil {
		return err
	}
	res.ExitCode = code
	if code != 0 {
		res.Error, res.Step = "terraform apply en échec", "apply"
	}
	return nil
}

func (e *Executor) state(ctx context.Context, j *job, spec *Job, res *Result) error {
	s := spec.State
	if s.Backup {
		if raw, _, err := statePull(ctx, j); err == nil && len(bytes.TrimSpace(raw)) > 0 {
			res.BackupState = raw
			j.logf("sauvegarde du state effectuée avant modification")
		}
	}
	switch s.Cmd {
	case "pull":
		raw, meta, err := statePull(ctx, j)
		if err != nil {
			return err
		}
		res.PulledState, res.StateSerial, res.StateLineage = raw, &meta.Serial, meta.Lineage
		return nil
	case "push":
		if err := os.WriteFile(filepath.Join(j.dir, "migrate.tfstate"), s.PushState, 0o600); err != nil {
			return err
		}
	}
	code, err := j.run(ctx, nil, s.Args...)
	if err != nil {
		return err
	}
	res.ExitCode = code
	if code != 0 {
		res.Error, res.Step = "terraform "+strings.Join(s.Args[:min(2, len(s.Args))], " ")+" en échec", "state"
	}
	return nil
}

// statePull lit le state courant (tout backend) avec son serial et son lineage.
func statePull(ctx context.Context, j *job) ([]byte, *core.StateMeta, error) {
	var buf bytes.Buffer
	code, err := j.run(ctx, &buf, "state", "pull")
	if err != nil {
		return nil, nil, err
	}
	if code != 0 {
		return nil, nil, fmt.Errorf("terraform state pull en échec (code %d)", code)
	}
	meta, err := core.ParseStateMeta(bytes.TrimSpace(buf.Bytes()))
	return buf.Bytes(), meta, err
}

// Schema résout un provider et renvoie son schéma.
func (e *Executor) Schema(ctx context.Context, s *SchemaJob) *SchemaResult {
	fail := func(err error) *SchemaResult { return &SchemaResult{Error: err.Error()} }
	bin, err := e.TF.Resolve(ctx, s.Engine, s.EngineVersion)
	if err != nil {
		return fail(err)
	}
	tmp, err := os.MkdirTemp(filepath.Join(e.DataDir, "work"), "schema-cli-*")
	if err != nil {
		return fail(err)
	}
	defer os.RemoveAll(tmp)
	cli, err := e.TF.CLIConfig(tmp, s.Mirror)
	if err != nil {
		return fail(err)
	}
	fctx, cancel := context.WithTimeout(ctx, 20*time.Minute)
	defer cancel()
	res, err := schema.Fetch(fctx, bin, tfbin.BaseEnv(cli), tmp, s.LocalName, s.Source, s.Constraint)
	if err != nil {
		return fail(err)
	}
	raw, err := json.Marshal(res.Schema)
	if err != nil {
		return fail(err)
	}
	return &SchemaResult{Source: res.Source, Address: res.Address, Version: res.Version, Schema: raw}
}

func hostname() string {
	h, _ := os.Hostname()
	return h
}
