package agent

import (
	"bytes"
	"context"
	"errors"
	"fmt"
	"io"
	"os"
	"os/exec"
	"path/filepath"
	"sort"
	"strings"
	"sync"
	"syscall"
	"time"
)

// maskWriter remplace les secrets connus avant d'écrire dans le fichier de log.
type maskWriter struct {
	mu      sync.Mutex
	out     io.Writer
	secrets []string
	pending []byte
}

func newMaskWriter(out io.Writer, secrets []string) *maskWriter {
	var s []string
	for _, x := range secrets {
		x = strings.TrimSpace(x)
		if len(x) >= 4 {
			s = append(s, x)
		}
		// Les secrets multilignes (clés JSON, kubeconfig) sont aussi masqués ligne par ligne.
		for _, line := range strings.Split(x, "\n") {
			if l := strings.TrimSpace(line); len(l) >= 12 {
				s = append(s, l)
			}
		}
	}
	sort.Slice(s, func(i, j int) bool { return len(s[i]) > len(s[j]) })
	return &maskWriter{out: out, secrets: s}
}

// Write ne libère que des lignes complètes, pour qu'un secret ne soit jamais coupé entre deux écritures.
func (m *maskWriter) Write(p []byte) (int, error) {
	m.mu.Lock()
	defer m.mu.Unlock()
	m.pending = append(m.pending, p...)
	idx := bytes.LastIndexByte(m.pending, '\n')
	if idx < 0 {
		if len(m.pending) > 64*1024 {
			idx = len(m.pending) - 1
		} else {
			return len(p), nil
		}
	}
	chunk := m.mask(string(m.pending[:idx+1]))
	m.pending = append([]byte{}, m.pending[idx+1:]...)
	_, err := io.WriteString(m.out, chunk)
	return len(p), err
}

func (m *maskWriter) Flush() {
	m.mu.Lock()
	defer m.mu.Unlock()
	if len(m.pending) > 0 {
		_, _ = io.WriteString(m.out, m.mask(string(m.pending)))
		m.pending = nil
	}
}

func (m *maskWriter) mask(s string) string {
	for _, sec := range m.secrets {
		s = strings.ReplaceAll(s, sec, "***")
	}
	return s
}

// job regroupe le contexte d'exécution d'un run sur le worker.
type job struct {
	runID  string
	dir    string
	bin    string
	env    []string
	log    *maskWriter
	cancel func() bool // renvoie true si l'annulation a été demandée
}

// ErrCanceled signale une exécution annulée par l'utilisateur.
var ErrCanceled = errors.New("exécution annulée")

// logf écrit une ligne d'information HCLDesigner dans le log du run.
func (j *job) logf(format string, a ...any) {
	fmt.Fprintf(j.log, "\n\x1b[36m[hcldesigner] "+format+"\x1b[0m\n", a...)
}

// run exécute le binaire terraform avec les arguments ; la sortie est journalisée (masquée).
// capture != nil reçoit stdout brut (non journalisé), pour les sorties JSON.
func (j *job) run(ctx context.Context, capture *bytes.Buffer, args ...string) (int, error) {
	j.logf("$ %s %s", filepath.Base(j.bin), strings.Join(args, " "))
	cmd := exec.Command(j.bin, args...)
	cmd.Dir = j.dir
	cmd.Env = j.env
	cmd.SysProcAttr = &syscall.SysProcAttr{Setpgid: true} // permet de signaler tout le groupe
	if capture != nil {
		cmd.Stdout = capture
	} else {
		cmd.Stdout = j.log
	}
	cmd.Stderr = j.log
	if err := cmd.Start(); err != nil {
		return -1, err
	}
	done := make(chan error, 1)
	go func() { done <- cmd.Wait() }()
	poll := time.NewTicker(2 * time.Second)
	defer poll.Stop()
	canceled := false
	var killAt <-chan time.Time
	for {
		select {
		case err := <-done:
			j.log.Flush()
			if canceled {
				return -1, ErrCanceled
			}
			if err != nil {
				var ee *exec.ExitError
				if errors.As(err, &ee) {
					return ee.ExitCode(), nil
				}
				return -1, err
			}
			return 0, nil
		case <-ctx.Done():
			if !canceled {
				canceled = true
				j.logf("délai dépassé ou arrêt du worker : interruption de terraform")
				_ = syscall.Kill(-cmd.Process.Pid, syscall.SIGINT)
				killAt = time.After(30 * time.Second)
			}
		case <-poll.C:
			if !canceled && j.cancel() {
				canceled = true
				j.logf("annulation demandée : envoi de SIGINT (terraform libère le verrou de state)")
				_ = syscall.Kill(-cmd.Process.Pid, syscall.SIGINT)
				killAt = time.After(30 * time.Second)
			}
		case <-killAt:
			j.logf("terraform ne s'arrête pas : SIGKILL")
			_ = syscall.Kill(-cmd.Process.Pid, syscall.SIGKILL)
		}
	}
}

// writeFiles écrit le snapshot dans le workspace en refusant toute sortie du dossier.
func writeFiles(dir string, files map[string]string) error {
	for name, content := range files {
		clean := filepath.Clean(name)
		if filepath.IsAbs(clean) || strings.HasPrefix(clean, "..") {
			return fmt.Errorf("chemin de fichier interdit : %s", name)
		}
		p := filepath.Join(dir, clean)
		if err := os.MkdirAll(filepath.Dir(p), 0o700); err != nil {
			return err
		}
		if err := os.WriteFile(p, []byte(content), 0o600); err != nil {
			return err
		}
	}
	return nil
}
