// Package agent contient le worker HCLDesigner : un processus autonome qui s'enrôle auprès de
// l'API, réclame des jobs (runs Terraform, résolutions de providers), les exécute dans un
// workspace éphémère et renvoie le résultat. Il n'a accès ni à la base ni à la clé maître :
// le serveur lui transmet tout ce qu'il faut (fichiers, credentials déchiffrés, state).
//
// Ce fichier définit le protocole partagé entre l'API (internal/api/agent.go) et l'agent.
package agent

import (
	"encoding/json"

	"github.com/AZIZI-Sajjad/hcldesigner/internal/tfbin"
)

// Version du protocole agent <-> serveur (refus d'enrôlement si incompatible).
const ProtocolVersion = 1

// Préfixes des jetons (lisibles dans les logs d'audit, jamais stockés en clair).
const (
	JoinTokenPrefix   = "hcldj_" // jeton d'enrôlement à usage unique
	WorkerTokenPrefix = "hcldw_" // jeton propre à un worker
)

// RegisterRequest : échange d'un jeton d'enrôlement contre une identité de worker.
type RegisterRequest struct {
	JoinToken string `json:"joinToken"`
	Hostname  string `json:"hostname"`
	OSArch    string `json:"osArch"`
	Version   string `json:"version"`
	Protocol  int    `json:"protocol"`
}

type RegisterResponse struct {
	WorkerID string `json:"workerId"`
	Name     string `json:"name"`
	Token    string `json:"token"`
}

// Heartbeat : signal de vie envoyé toutes les 15 s.
type Heartbeat struct {
	Hostname string   `json:"hostname"`
	OSArch   string   `json:"osArch"`
	Version  string   `json:"version"`
	Protocol int      `json:"protocol"`
	Running  []string `json:"running"` // runs en cours sur ce worker
}

// HeartbeatResponse transmet l'état voulu par l'administrateur.
type HeartbeatResponse struct {
	Name   string   `json:"name"`
	State  string   `json:"state"` // active | paused | revoked
	Slots  int      `json:"slots"`
	Cancel []string `json:"cancel"` // runs dont l'annulation a été demandée
}

// Claim : réponse à une demande de travail (204 si rien à faire).
type Claim struct {
	Kind   string     `json:"kind"` // run | schema
	Run    *Job       `json:"run,omitempty"`
	Schema *SchemaJob `json:"schema,omitempty"`
}

// Job décrit un run Terraform complet. Les chemins de credentials utilisent
// core.WorkdirPlaceholder, remplacé par le workspace du worker.
type Job struct {
	RunID         string             `json:"runId"`
	Title         string             `json:"title"` // en-tête du log
	Engine        string             `json:"engine"`
	EngineVersion string             `json:"engineVersion"`
	Mirror        tfbin.MirrorConfig `json:"mirror"`
	Files         map[string]string  `json:"files"`     // configuration, lock file, tfvars, backend.hcl
	CredFiles     map[string]string  `json:"credFiles"` // fichiers de credentials (kubeconfig…)
	Env           []string           `json:"env"`       // credentials, TF_WORKSPACE
	Secrets       []string           `json:"secrets"`   // valeurs masquées dans les logs
	InitArgs      []string           `json:"initArgs"`
	Internal      bool               `json:"internal"`      // backend interne : state fourni et rendu en fichier
	InternalState []byte             `json:"internalState"` // terraform.tfstate initial
	Operation     string             `json:"operation"`     // init | validate | plan | apply | state
	TimeoutSec    int                `json:"timeoutSec"`
	Plan          *PlanJob           `json:"plan,omitempty"`
	Apply         *ApplyJob          `json:"apply,omitempty"`
	State         *StateJob          `json:"state,omitempty"`
	ArchiveState  bool               `json:"archiveState"` // renvoyer le state final (apply, state mv/rm/import/push)
}

type PlanJob struct {
	Args []string `json:"args"` // arguments complets de terraform plan
}

type ApplyJob struct {
	PlanFile      []byte   `json:"planFile"`
	ExpectSerial  *int64   `json:"expectSerial"` // state au moment du plan
	ExpectLineage string   `json:"expectLineage"`
	Args          []string `json:"args"`
}

type StateJob struct {
	Cmd       string   `json:"cmd"`  // list | show | mv | rm | import | unlock | push | pull
	Args      []string `json:"args"` // arguments complets de la commande terraform
	PushState []byte   `json:"pushState"`
	Backup    bool     `json:"backup"` // renvoyer le state avant modification
}

// Result est renvoyé par le worker à la fin d'un run. Le serveur en déduit le statut
// (résumé du plan, conformité, archivage du state, notifications).
type Result struct {
	Failed   bool   `json:"failed"`   // erreur d'exécution (hors code retour terraform)
	Canceled bool   `json:"canceled"` // annulé (demande utilisateur ou délai)
	ExitCode int    `json:"exitCode"`
	Error    string `json:"error"`
	Step     string `json:"step"` // étape en échec : init | plan | show | apply | validate | state

	LockFile string `json:"lockFile"` // .terraform.lock.hcl après init

	PlanFile     []byte `json:"planFile,omitempty"`
	PlanJSON     []byte `json:"planJson,omitempty"`
	StateSerial  *int64 `json:"stateSerial,omitempty"`
	StateLineage string `json:"stateLineage,omitempty"`
	StateChanged bool   `json:"stateChanged"` // apply : le state a changé depuis le plan

	ValidateJSON []byte `json:"validateJson,omitempty"`
	BackupState  []byte `json:"backupState,omitempty"`
	FinalState   []byte `json:"finalState,omitempty"`
	PulledState  []byte `json:"pulledState,omitempty"`
}

// SchemaJob : résolution d'un provider et lecture de son schéma.
type SchemaJob struct {
	ID            string             `json:"id"`
	Engine        string             `json:"engine"`
	EngineVersion string             `json:"engineVersion"`
	LocalName     string             `json:"localName"`
	Source        string             `json:"source"`
	Constraint    string             `json:"constraint"`
	Mirror        tfbin.MirrorConfig `json:"mirror"`
}

type SchemaResult struct {
	Error   string          `json:"error,omitempty"`
	Source  string          `json:"source"`
	Address string          `json:"address"`
	Version string          `json:"version"`
	Schema  json.RawMessage `json:"schema"`
}

// LogResponse : réponse à l'envoi d'un morceau de log.
type LogResponse struct {
	Cancel bool `json:"cancel"`
}
