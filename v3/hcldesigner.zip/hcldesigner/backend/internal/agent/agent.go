package agent

import (
	"bytes"
	"context"
	"errors"
	"fmt"
	"log/slog"
	"os"
	"path/filepath"
	"runtime"
	"strings"
	"sync"
	"sync/atomic"
	"time"
)

// Version du binaire (renseignée à la compilation : -ldflags "-X .../agent.BuildVersion=3.0.0").
var BuildVersion = "3.0.0"

// Config de l'agent, lue depuis l'environnement (voir ConfigFromEnv).
type Config struct {
	ServerURL string // URL de l'API (ex. https://hcldesigner.example.com)
	DataDir   string // workspaces, binaires terraform, cache de plugins, jeton
	TokenFile string // jeton du worker (créé à l'enrôlement)
	JoinToken string // jeton d'enrôlement à usage unique (premier démarrage)
	CAFile    string
	Insecure  bool
}

// ConfigFromEnv lit HCLD_SERVER_URL, HCLD_DATA_DIR, HCLD_AGENT_TOKEN_FILE, HCLD_JOIN_TOKEN,
// HCLD_CA_FILE et HCLD_INSECURE_TLS.
func ConfigFromEnv() (Config, error) {
	c := Config{
		ServerURL: strings.TrimRight(os.Getenv("HCLD_SERVER_URL"), "/"),
		DataDir:   os.Getenv("HCLD_DATA_DIR"),
		TokenFile: os.Getenv("HCLD_AGENT_TOKEN_FILE"),
		JoinToken: os.Getenv("HCLD_JOIN_TOKEN"),
		CAFile:    os.Getenv("HCLD_CA_FILE"),
		Insecure:  os.Getenv("HCLD_INSECURE_TLS") == "true",
	}
	if c.ServerURL == "" {
		return c, errors.New("HCLD_SERVER_URL obligatoire (URL de l'API HCLDesigner)")
	}
	if c.DataDir == "" {
		c.DataDir = "/var/lib/hcldesigner-agent"
	}
	if c.TokenFile == "" {
		c.TokenFile = filepath.Join(c.DataDir, "agent.token")
	}
	return c, nil
}

// Agent : boucle d'enrôlement, signal de vie, réclamation et exécution des jobs.
type Agent struct {
	cfg  Config
	cli  *client
	exec *Executor

	mu      sync.Mutex
	token   string
	name    string
	state   string // active | paused | revoked
	slots   int
	running map[string]*runCtl
	busy    atomic.Int32
}

// runCtl permet d'annuler un run en cours (demande utilisateur ou révocation du worker).
type runCtl struct {
	canceled atomic.Bool
}

func New(cfg Config) (*Agent, error) {
	httpc, err := newHTTPClient(cfg.CAFile, cfg.Insecure)
	if err != nil {
		return nil, err
	}
	ex, err := NewExecutor(cfg.DataDir)
	if err != nil {
		return nil, err
	}
	a := &Agent{cfg: cfg, exec: ex, state: "active", slots: 1, running: map[string]*runCtl{}}
	a.cli = &client{base: cfg.ServerURL, http: httpc, token: a.currentToken}
	return a, nil
}

func (a *Agent) currentToken() string {
	a.mu.Lock()
	defer a.mu.Unlock()
	return a.token
}

// loadToken relit le fichier de jeton (le worker par défaut le reçoit de l'API via le volume partagé).
func (a *Agent) loadToken() bool {
	b, err := os.ReadFile(a.cfg.TokenFile)
	if err != nil {
		return false
	}
	t := strings.TrimSpace(string(b))
	a.mu.Lock()
	defer a.mu.Unlock()
	changed := t != a.token
	a.token = t
	return t != "" && changed
}

// enroll échange le jeton d'enrôlement contre un jeton de worker, enregistré dans TokenFile.
func (a *Agent) enroll(ctx context.Context) error {
	host, _ := os.Hostname()
	var resp RegisterResponse
	_, err := a.cli.do(ctx, "POST", "/register", RegisterRequest{JoinToken: a.cfg.JoinToken, Hostname: host,
		OSArch: runtime.GOOS + "/" + runtime.GOARCH, Version: BuildVersion, Protocol: ProtocolVersion}, &resp)
	if err != nil {
		return err
	}
	if err := os.MkdirAll(filepath.Dir(a.cfg.TokenFile), 0o700); err != nil {
		return err
	}
	if err := os.WriteFile(a.cfg.TokenFile, []byte(resp.Token+"\n"), 0o600); err != nil {
		return err
	}
	a.mu.Lock()
	a.token, a.name = resp.Token, resp.Name
	a.mu.Unlock()
	slog.Info("worker enrôlé", "name", resp.Name, "id", resp.WorkerID)
	return nil
}

// Run tourne jusqu'à l'annulation du contexte. Les erreurs réseau sont retentées indéfiniment :
// un worker survit aux redémarrages de l'API.
func (a *Agent) Run(ctx context.Context) error {
	slog.Info("agent démarré", "server", a.cfg.ServerURL, "version", BuildVersion, "data", a.cfg.DataDir)
	for ctx.Err() == nil {
		if a.loadToken() || a.currentToken() != "" {
			break
		}
		if a.cfg.JoinToken == "" {
			slog.Warn("aucun jeton de worker : attente du fichier", "file", a.cfg.TokenFile)
		} else if err := a.enroll(ctx); err != nil {
			slog.Error("enrôlement", "err", err)
		} else {
			break
		}
		sleep(ctx, 10*time.Second)
	}

	hb := time.NewTicker(15 * time.Second)
	poll := time.NewTicker(2 * time.Second)
	defer hb.Stop()
	defer poll.Stop()
	a.heartbeat(ctx)
	for {
		select {
		case <-ctx.Done():
			a.wait()
			return nil
		case <-hb.C:
			a.heartbeat(ctx)
		case <-poll.C:
			a.claimAll(ctx)
		}
	}
}

// heartbeat signale l'état du worker et récupère sa configuration (état, slots, annulations).
func (a *Agent) heartbeat(ctx context.Context) {
	host, _ := os.Hostname()
	var resp HeartbeatResponse
	_, err := a.cli.do(ctx, "POST", "/heartbeat", Heartbeat{Hostname: host, OSArch: runtime.GOOS + "/" + runtime.GOARCH,
		Version: BuildVersion, Protocol: ProtocolVersion, Running: a.runningIDs()}, &resp)
	if errors.Is(err, ErrUnauthorized) {
		a.setState("revoked")
		a.cancelAll("worker révoqué ou jeton renouvelé")
		if a.loadToken() { // le worker par défaut reçoit un nouveau jeton via le volume partagé
			slog.Info("nouveau jeton de worker chargé")
		}
		return
	}
	if err != nil {
		slog.Warn("signal de vie", "err", err)
		return
	}
	a.mu.Lock()
	if a.state != resp.State || a.slots != resp.Slots || a.name != resp.Name {
		slog.Info("configuration du worker", "name", resp.Name, "state", resp.State, "slots", resp.Slots)
	}
	a.name, a.state, a.slots = resp.Name, resp.State, max(resp.Slots, 1)
	for _, id := range resp.Cancel {
		if r := a.running[id]; r != nil {
			r.canceled.Store(true)
		}
	}
	a.mu.Unlock()
}

// claimAll réclame des jobs tant qu'il reste des slots libres.
func (a *Agent) claimAll(ctx context.Context) {
	for {
		a.mu.Lock()
		ok := a.state == "active" && int(a.busy.Load()) < a.slots
		a.mu.Unlock()
		if !ok {
			return
		}
		var c Claim
		got, err := a.cli.do(ctx, "POST", "/claim", nil, &c)
		if errors.Is(err, ErrUnauthorized) {
			a.setState("revoked")
			return
		}
		if err != nil {
			slog.Warn("réclamation de job", "err", err)
			return
		}
		if !got {
			return
		}
		a.busy.Add(1)
		switch c.Kind {
		case "run":
			go a.doRun(ctx, c.Run)
		case "schema":
			go a.doSchema(ctx, c.Schema)
		default:
			a.busy.Add(-1)
			slog.Error("job de type inconnu", "kind", c.Kind)
			return
		}
	}
}

func (a *Agent) doRun(ctx context.Context, j *Job) {
	defer a.busy.Add(-1)
	ctl := &runCtl{}
	a.mu.Lock()
	a.running[j.RunID] = ctl
	a.mu.Unlock()
	defer func() {
		a.mu.Lock()
		delete(a.running, j.RunID)
		a.mu.Unlock()
	}()
	slog.Info("run", "id", j.RunID, "op", j.Operation)

	logs := newLogShipper(ctx, a.cli, j.RunID, ctl)
	res := a.exec.Run(ctx, j, logs, ctl.canceled.Load)
	logs.Close()
	// Le résultat doit arriver même si l'API redémarre : nouvelles tentatives pendant 10 minutes.
	deadline := time.Now().Add(10 * time.Minute)
	for {
		_, err := a.cli.do(context.Background(), "POST", "/runs/"+j.RunID+"/complete", res, nil)
		if err == nil || errors.Is(err, ErrUnauthorized) || time.Now().After(deadline) {
			if err != nil {
				slog.Error("envoi du résultat abandonné", "run", j.RunID, "err", err)
			}
			return
		}
		slog.Warn("envoi du résultat", "run", j.RunID, "err", err)
		time.Sleep(10 * time.Second)
	}
}

func (a *Agent) doSchema(ctx context.Context, s *SchemaJob) {
	defer a.busy.Add(-1)
	slog.Info("résolution de provider", "source", s.Source)
	res := a.exec.Schema(ctx, s)
	if _, err := a.cli.do(context.Background(), "POST", "/schema/"+s.ID+"/complete", res, nil); err != nil {
		slog.Error("envoi du schéma", "source", s.Source, "err", err)
	}
}

func (a *Agent) runningIDs() []string {
	a.mu.Lock()
	defer a.mu.Unlock()
	ids := make([]string, 0, len(a.running))
	for id := range a.running {
		ids = append(ids, id)
	}
	return ids
}

func (a *Agent) setState(s string) {
	a.mu.Lock()
	defer a.mu.Unlock()
	if a.state != s {
		slog.Warn("état du worker", "state", s)
	}
	a.state = s
}

func (a *Agent) cancelAll(reason string) {
	a.mu.Lock()
	defer a.mu.Unlock()
	for id, r := range a.running {
		if !r.canceled.Load() {
			slog.Warn("annulation du run", "id", id, "reason", reason)
			r.canceled.Store(true)
		}
	}
}

// wait laisse les runs en cours se terminer à l'arrêt (terraform reçoit SIGINT via le contexte).
func (a *Agent) wait() {
	for i := 0; i < 60 && a.busy.Load() > 0; i++ {
		time.Sleep(time.Second)
	}
}

func sleep(ctx context.Context, d time.Duration) {
	select {
	case <-ctx.Done():
	case <-time.After(d):
	}
}

// logShipper regroupe la sortie et l'envoie à l'API toutes les secondes. La réponse indique
// si l'annulation du run a été demandée ; un jeton refusé annule aussi le run.
type logShipper struct {
	cli   *client
	runID string
	ctl   *runCtl
	mu    sync.Mutex
	buf   bytes.Buffer
	done  chan struct{}
	wg    sync.WaitGroup
}

func newLogShipper(ctx context.Context, cli *client, runID string, ctl *runCtl) *logShipper {
	s := &logShipper{cli: cli, runID: runID, ctl: ctl, done: make(chan struct{})}
	s.wg.Add(1)
	go func() {
		defer s.wg.Done()
		t := time.NewTicker(time.Second)
		defer t.Stop()
		for {
			select {
			case <-s.done:
				s.flush(context.Background())
				return
			case <-t.C:
				s.flush(ctx)
			}
		}
	}()
	return s
}

func (s *logShipper) Write(p []byte) (int, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	return s.buf.Write(p)
}

func (s *logShipper) flush(ctx context.Context) {
	s.mu.Lock()
	if s.buf.Len() == 0 {
		s.mu.Unlock()
		// Signal de vie du run même sans sortie (détection des workers perdus).
		if cancel, err := s.cli.postLog(ctx, s.runID, nil); cancel || errors.Is(err, ErrUnauthorized) {
			s.ctl.canceled.Store(true)
		}
		return
	}
	chunk := append([]byte(nil), s.buf.Bytes()...)
	s.buf.Reset()
	s.mu.Unlock()
	cancel, err := s.cli.postLog(ctx, s.runID, chunk)
	if cancel || errors.Is(err, ErrUnauthorized) {
		s.ctl.canceled.Store(true)
	}
	if err != nil && !errors.Is(err, ErrUnauthorized) {
		// Réseau indisponible : on remet le morceau en tête pour ne rien perdre.
		s.mu.Lock()
		rest := append([]byte(nil), s.buf.Bytes()...)
		s.buf.Reset()
		s.buf.Write(chunk)
		s.buf.Write(rest)
		s.mu.Unlock()
	}
}

func (s *logShipper) Close() {
	close(s.done)
	s.wg.Wait()
}

// Describe résume la configuration (affiché au démarrage et par `hcldesigner agent --check`).
func (c Config) Describe() string {
	return fmt.Sprintf("serveur=%s données=%s jeton=%s", c.ServerURL, c.DataDir, c.TokenFile)
}
