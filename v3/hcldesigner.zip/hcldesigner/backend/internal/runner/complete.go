package runner

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"os"
	"strings"
	"time"

	"github.com/AZIZI-Sajjad/hcldesigner/internal/agent"
	"github.com/AZIZI-Sajjad/hcldesigner/internal/core"
	"github.com/AZIZI-Sajjad/hcldesigner/internal/model"
	"github.com/AZIZI-Sajjad/hcldesigner/internal/schema"
)

// Complete traite le résultat d'un run renvoyé par son worker.
func (d *Dispatcher) Complete(ctx context.Context, w *core.Worker, runID string, res *agent.Result) error {
	c := d.core
	run, err := c.GetRun(ctx, runID)
	if err != nil {
		return err
	}
	var owner *string
	_ = c.DB.QueryRow(ctx, `SELECT worker_id FROM runs WHERE id=$1`, runID).Scan(&owner)
	if run.Status != core.StatusRunning || owner == nil || *owner != w.ID {
		return fmt.Errorf("run %s non attribué à ce worker ou déjà terminé", runID)
	}
	out, err := d.outcomeOf(ctx, run, res)
	if err != nil {
		d.logf(runID, "traitement du résultat impossible : %v", err)
		out = outcome{status: core.StatusFailed, exitCode: -1, errMsg: err.Error()}
	}
	d.finish(ctx, run, out)
	return nil
}

// outcomeOf transforme le résultat brut du worker en statut du run (même logique qu'en v2).
func (d *Dispatcher) outcomeOf(ctx context.Context, run *core.Run, res *agent.Result) (outcome, error) {
	c := d.core
	switch {
	case res.Canceled:
		return outcome{status: core.StatusCanceled, exitCode: -1, errMsg: "annulé"}, nil
	case res.Failed:
		return outcome{status: core.StatusFailed, exitCode: -1, errMsg: res.Error}, nil
	}
	proj, err := c.GetProject(ctx, run.ProjectID)
	if err != nil {
		return outcome{}, err
	}
	// Lock file produit par init : recopié dans le projet s'il a changé.
	if res.LockFile != "" && res.LockFile != proj.LockFile {
		_, _ = c.DB.Exec(ctx, `UPDATE projects SET lock_file=$2 WHERE id=$1`, proj.ID, res.LockFile)
	}
	if res.Step == "init" {
		return outcome{status: core.StatusFailed, exitCode: res.ExitCode, errMsg: res.Error}, nil
	}
	if res.BackupState != nil {
		if _, err := c.SaveStateVersion(ctx, run.EnvironmentID, run.ID, "sauvegarde avant state "+run.Options.StateCmd, res.BackupState); err != nil {
			return outcome{}, err
		}
	}
	var out outcome
	switch run.Operation {
	case core.OpInit:
		out = outcome{status: core.StatusSucceeded}
	case core.OpValidate:
		out = d.validateOutcome(ctx, run, res)
	case core.OpPlan:
		out, err = d.planOutcome(ctx, run, proj, res)
	case core.OpApply:
		out = d.applyOutcome(ctx, run, res)
	case core.OpState:
		out, err = d.stateOutcome(ctx, run, res)
	default:
		err = fmt.Errorf("opération inconnue %s", run.Operation)
	}
	if err != nil {
		return outcome{}, err
	}
	if len(bytes.TrimSpace(res.FinalState)) > 0 {
		if sv, err := c.SaveStateVersion(ctx, run.EnvironmentID, run.ID, opLabel(run), res.FinalState); err != nil {
			d.logf(run.ID, "archivage du state impossible : %v", err)
		} else {
			d.logf(run.ID, "state archivé (serial %d, %d ressources)", sv.Serial, sv.Resources)
		}
	}
	return out, nil
}

func (d *Dispatcher) planOutcome(ctx context.Context, run *core.Run, proj *core.Project, res *agent.Result) (outcome, error) {
	if res.Error != "" {
		return outcome{status: core.StatusFailed, exitCode: res.ExitCode, errMsg: res.Error}, nil
	}
	m := d.modelAtVersion(ctx, proj, run.ProjectVersion)
	sum, err := ParsePlanSummary(res.PlanJSON, nodeIndex(m))
	if err != nil {
		return outcome{}, err
	}
	rep, err := d.evaluatePolicies(ctx, proj.ID, res.PlanJSON, m)
	if err != nil {
		d.logf(run.ID, "évaluation de conformité impossible : %v", err)
	}
	// Artefacts chiffrés : le plan binaire (pour l'apply) et sa version JSON (pour l'affichage).
	adir := d.artifactDir(run.ID)
	if err := os.MkdirAll(adir, 0o700); err != nil {
		return outcome{}, err
	}
	if err := d.core.Vault.WriteFile(adir+"/plan.tfplan.enc", res.PlanFile); err != nil {
		return outcome{}, err
	}
	if err := d.core.Vault.WriteFile(adir+"/plan.json.enc", res.PlanJSON); err != nil {
		return outcome{}, err
	}
	d.logf(run.ID, "résumé : %s", summaryText(sum))
	if rep != nil && len(rep.Violations) > 0 {
		d.logf(run.ID, "conformité : %d violation(s)%s", len(rep.Violations), map[bool]string{true: " dont bloquante(s)", false: ""}[rep.Blocking])
	}
	out := outcome{exitCode: res.ExitCode, summary: sum, policy: rep, serial: res.StateSerial, lineage: res.StateLineage}
	switch {
	case run.Options.Drift:
		out.status = core.StatusChecked
	case res.ExitCode == 2:
		out.status = core.StatusPlanned
		ttl := time.Duration(d.core.Settings.Runs(ctx).PlanTTLMinutes) * time.Minute
		if ttl <= 0 {
			ttl = 24 * time.Hour
		}
		exp := time.Now().Add(ttl)
		out.planExpires = &exp
	default:
		out.status = core.StatusNoChanges
	}
	return out, nil
}

func (d *Dispatcher) applyOutcome(ctx context.Context, run *core.Run, res *agent.Result) outcome {
	var sum PlanSummary
	if run.PlanRunID != nil {
		if plan, err := d.core.GetRun(ctx, *run.PlanRunID); err == nil {
			_ = json.Unmarshal(plan.Summary, &sum)
		}
	}
	switch {
	case res.StateChanged:
		_, _ = d.core.DB.Exec(ctx, `UPDATE runs SET status='discarded' WHERE id=$1`, *run.PlanRunID)
		return outcome{status: core.StatusFailed, exitCode: -1, errMsg: res.Error}
	case res.ExitCode != 0:
		return outcome{status: core.StatusFailed, exitCode: res.ExitCode, errMsg: "terraform apply en échec", summary: &sum}
	}
	return outcome{status: core.StatusApplied, exitCode: 0, summary: &sum}
}

func (d *Dispatcher) stateOutcome(ctx context.Context, run *core.Run, res *agent.Result) (outcome, error) {
	if run.Options.StateCmd == "pull" {
		if _, err := d.core.SaveStateVersion(ctx, run.EnvironmentID, run.ID, "export (state pull)", res.PulledState); err != nil {
			return outcome{}, err
		}
		return outcome{status: core.StatusSucceeded, serial: res.StateSerial, lineage: res.StateLineage}, nil
	}
	if res.Error != "" {
		return outcome{status: core.StatusFailed, exitCode: res.ExitCode, errMsg: res.Error}, nil
	}
	return outcome{status: core.StatusSucceeded}, nil
}

func (d *Dispatcher) validateOutcome(ctx context.Context, run *core.Run, res *agent.Result) outcome {
	var v struct {
		Valid       bool `json:"valid"`
		Diagnostics []struct {
			Severity string `json:"severity"`
			Summary  string `json:"summary"`
			Detail   string `json:"detail"`
			Range    *struct {
				Filename string `json:"filename"`
				Start    struct {
					Line int `json:"line"`
				} `json:"start"`
			} `json:"range"`
		} `json:"diagnostics"`
	}
	if err := json.Unmarshal(res.ValidateJSON, &v); err != nil {
		return outcome{status: core.StatusFailed, exitCode: res.ExitCode, errMsg: "sortie de validate illisible"}
	}
	snap, _ := d.core.RunSnapshot(ctx, run.ID)
	diags := []model.Diagnostic{}
	var lines strings.Builder
	for _, x := range v.Diagnostics {
		md := model.Diagnostic{Severity: x.Severity, Summary: x.Summary, Detail: x.Detail}
		if x.Range != nil {
			md.File, md.Line = x.Range.Filename, x.Range.Start.Line
			if snap != nil {
				md.NodeID = nodeAt(snap, md.File, md.Line)
			}
		}
		diags = append(diags, md)
		fmt.Fprintf(&lines, "%s: %s %s:%d %s\n", strings.ToUpper(x.Severity), x.Summary, md.File, md.Line, x.Detail)
	}
	d.appendLog(run.ID, []byte(lines.String()))
	d.logf(run.ID, "validate : %s (%d diagnostic(s))", map[bool]string{true: "valide", false: "invalide"}[v.Valid], len(diags))
	if !v.Valid {
		return outcome{status: core.StatusFailed, exitCode: res.ExitCode, errMsg: "configuration invalide", diagnostics: diags}
	}
	return outcome{status: core.StatusSucceeded, exitCode: res.ExitCode, diagnostics: diags}
}

// logf ajoute une ligne d'information HCLDesigner au log du run (côté serveur).
func (d *Dispatcher) logf(runID, format string, a ...any) {
	d.appendLog(runID, []byte(fmt.Sprintf("\n\x1b[36m[hcldesigner] "+format+"\x1b[0m\n", a...)))
}

func decodeSchemaResult(res *agent.SchemaResult) (*schema.FetchResult, error) {
	var ps schema.ProviderSchema
	if err := json.Unmarshal(res.Schema, &ps); err != nil {
		return nil, fmt.Errorf("schéma illisible : %w", err)
	}
	return &schema.FetchResult{Source: res.Source, Address: res.Address, Version: res.Version, Schema: &ps}, nil
}
