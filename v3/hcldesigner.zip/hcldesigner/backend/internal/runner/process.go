package runner

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"log/slog"
	"strconv"
	"time"

	"github.com/AZIZI-Sajjad/hcldesigner/internal/core"
	"github.com/AZIZI-Sajjad/hcldesigner/internal/model"
	"github.com/AZIZI-Sajjad/hcldesigner/internal/notify"
)

// outcome est le résultat d'une exécution, écrit en base à la fin.
type outcome struct {
	status      string
	exitCode    int
	errMsg      string
	summary     any
	diagnostics any
	policy      any
	serial      *int64
	lineage     string
	planExpires *time.Time
}

func mutatingState(cmd string) bool {
	return cmd == "mv" || cmd == "rm" || cmd == "import" || cmd == "push"
}

func opLabel(r *core.Run) string {
	switch {
	case r.Operation == core.OpPlan && r.Destroy:
		return "plan -destroy"
	case r.Operation == core.OpApply && r.Destroy:
		return "destroy (apply du plan)"
	case r.Operation == core.OpState:
		return "state " + r.Options.StateCmd
	}
	return r.Operation
}

// finish enregistre le résultat, déclenche notifications et suites (apply automatique).
func (d *Dispatcher) finish(ctx context.Context, run *core.Run, out outcome) {
	c := d.core
	toJSON := func(v any, def string) []byte {
		if v == nil {
			return []byte(def)
		}
		b, err := json.Marshal(v)
		if err != nil {
			return []byte(def)
		}
		return b
	}
	_, err := c.DB.Exec(ctx, `UPDATE runs SET status=$2, exit_code=$3, error=$4, summary=$5, diagnostics=$6, policy_report=$7,
		state_serial=COALESCE($8, state_serial), state_lineage=CASE WHEN $9='' THEN state_lineage ELSE $9 END, plan_expires_at=$10, finished_at=now() WHERE id=$1`,
		run.ID, out.status, out.exitCode, out.errMsg, toJSON(out.summary, "{}"), toJSON(out.diagnostics, "[]"), toJSON(out.policy, "{}"),
		out.serial, out.lineage, out.planExpires)
	logErr(run.ID, err)
	if run.Operation == core.OpApply && run.PlanRunID != nil {
		st := core.StatusApplied
		if out.status != core.StatusApplied {
			st = core.StatusFailed
		}
		_, _ = c.DB.Exec(ctx, `UPDATE runs SET status=$2 WHERE id=$1`, *run.PlanRunID, st)
	}
	// Un nouveau plan rend obsolètes les plans précédents non appliqués du même environnement.
	if run.Operation == core.OpPlan && out.status == core.StatusPlanned {
		_, _ = c.DB.Exec(ctx, `UPDATE runs SET status='discarded' WHERE environment_id=$1 AND operation='plan' AND status='planned' AND id<>$2`, run.EnvironmentID, run.ID)
	}
	if run.TaskID != nil {
		d.finishTaskExecution(ctx, run, out)
	}
	d.notify(ctx, run, out)
	if run.Operation == core.OpPlan && out.status == core.StatusPlanned && run.Options.AutoApply && run.ApprovalsRequired == 0 {
		fresh, err := c.GetRun(ctx, run.ID)
		if err == nil {
			_, err = c.CreateRun(ctx, core.RunRequest{ProjectID: run.ProjectID, EnvironmentID: run.EnvironmentID, Operation: core.OpApply,
				PlanRunID: fresh.ID, TriggeredBy: fresh.TriggeredBy, TaskID: deref(fresh.TaskID)})
		}
		logErr(run.ID, err)
	}
}

func deref(s *string) string {
	if s == nil {
		return ""
	}
	return *s
}

func (d *Dispatcher) finishTaskExecution(ctx context.Context, run *core.Run, out outcome) {
	status := "succeeded"
	if out.status == core.StatusFailed || out.status == core.StatusCanceled {
		status = "failed"
	}
	msg := out.errMsg
	if msg == "" {
		msg = "run " + out.status
	}
	_, _ = d.core.DB.Exec(ctx, `UPDATE task_executions SET status=$2, message=$3, finished_at=now() WHERE run_id=$1 AND finished_at IS NULL`, run.ID, status, msg)
	_, _ = d.core.DB.Exec(ctx, `UPDATE scheduled_tasks SET last_status=$2 WHERE id=$1`, *run.TaskID, status)
	if status == "failed" {
		d.core.Notifier.Emit(ctx, notify.Event{Type: notify.EvTaskFailed, ProjectID: run.ProjectID, Project: run.ProjectName, Environment: run.EnvironmentName,
			Summary: "Tâche planifiée en échec : " + msg, Link: "/runs/" + run.ID})
	}
}

func (d *Dispatcher) notify(ctx context.Context, run *core.Run, out outcome) {
	ev := notify.Event{ProjectID: run.ProjectID, Project: run.ProjectName, Environment: run.EnvironmentName, Actor: run.CreatedByName, Link: "/runs/" + run.ID}
	summary := summaryText(out.summary)
	if rep, ok := out.policy.(interface{ HasViolations() bool }); ok && rep.HasViolations() {
		d.core.Notifier.Emit(ctx, notify.Event{Type: notify.EvCompliance, ProjectID: run.ProjectID, Project: run.ProjectName, Environment: run.EnvironmentName,
			Summary: "Le plan contient des non-conformités.", Link: ev.Link})
	}
	switch {
	case out.status == core.StatusFailed:
		ev.Type, ev.Summary = notify.EvRunFailed, opLabel(run)+" en échec : "+out.errMsg
		if run.Operation == core.OpApply {
			ev.Type = notify.EvApplyFailed
		}
	case run.Operation == core.OpApply && run.Destroy:
		ev.Type, ev.Summary = notify.EvDestroyFinished, "Destroy exécuté.\n"+summary
	case run.Operation == core.OpApply:
		ev.Type, ev.Summary = notify.EvApplySucceeded, "Apply réussi.\n"+summary
	case run.Operation == core.OpPlan && out.status == core.StatusChecked:
		if s, ok := out.summary.(*PlanSummary); ok && len(s.Drift) > 0 {
			ev.Type, ev.Summary = notify.EvDrift, fmt.Sprintf("%d ressource(s) modifiée(s) hors Terraform.\n%s", len(s.Drift), driftText(s))
		} else {
			return
		}
	case run.Operation == core.OpPlan && (out.status == core.StatusPlanned || out.status == core.StatusNoChanges):
		ev.Type, ev.Summary = notify.EvPlanFinished, summary
		d.core.Notifier.Emit(ctx, ev)
		if out.status == core.StatusPlanned && run.ApprovalsRequired > 0 {
			ev.Type = notify.EvApprovalRequest
			ev.Summary = fmt.Sprintf("%d approbation(s) requise(s).\n%s", run.ApprovalsRequired, summary)
		} else {
			return
		}
	default:
		return
	}
	d.core.Notifier.Emit(ctx, ev)
}

func summaryText(v any) string {
	s, ok := v.(*PlanSummary)
	if !ok || s == nil {
		return ""
	}
	return "à créer : " + strconv.Itoa(s.Add) + ", à modifier : " + strconv.Itoa(s.Change) + ", à remplacer : " + strconv.Itoa(s.Replace) + ", à détruire : " + strconv.Itoa(s.Destroy)
}

func driftText(s *PlanSummary) string {
	var b bytes.Buffer
	for _, d := range s.Drift {
		b.WriteString("- " + d.Address + "\n")
	}
	return b.String()
}

// nodeIndex associe une adresse Terraform (sans index) à un id de nœud.
func nodeIndex(m *model.Project) map[string]string {
	idx := map[string]string{}
	for _, n := range m.Nodes {
		switch n.Kind {
		case model.KindResource, model.KindData, model.KindModule:
			idx[n.Address()] = n.ID
		}
	}
	return idx
}

func logErr(runID string, err error) {
	if err != nil {
		slog.Error("run", "id", runID, "err", err)
	}
}
