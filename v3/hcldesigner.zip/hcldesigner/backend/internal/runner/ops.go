package runner

import (
	"context"
	"encoding/json"
	"path/filepath"
	"regexp"
	"strconv"
	"strings"

	"github.com/AZIZI-Sajjad/hcldesigner/internal/core"
	"github.com/AZIZI-Sajjad/hcldesigner/internal/model"
	"github.com/AZIZI-Sajjad/hcldesigner/internal/policy"
	"github.com/AZIZI-Sajjad/hcldesigner/internal/settings"
)

// PlanSummary est le résumé stocké dans runs.summary et affiché sur le canvas.
type PlanSummary struct {
	Add     int               `json:"add"`
	Change  int               `json:"change"`
	Destroy int               `json:"destroy"`
	Replace int               `json:"replace"`
	Import  int               `json:"import"`
	Changes []ChangeItem      `json:"changes"`
	Drift   []ChangeItem      `json:"drift"`
	Outputs []string          `json:"outputs"`
	ByNode  map[string]string `json:"byNode"` // nodeId -> action dominante (create|update|replace|delete)
}

type ChangeItem struct {
	Address string   `json:"address"`
	Type    string   `json:"type"`
	Actions []string `json:"actions"`
	NodeID  string   `json:"nodeId,omitempty"`
}

type planShow struct {
	ResourceChanges []struct {
		Address string `json:"address"`
		Mode    string `json:"mode"`
		Type    string `json:"type"`
		Change  struct {
			Actions   []string        `json:"actions"`
			Importing json.RawMessage `json:"importing"`
		} `json:"change"`
	} `json:"resource_changes"`
	ResourceDrift []struct {
		Address string `json:"address"`
		Type    string `json:"type"`
		Change  struct {
			Actions []string `json:"actions"`
		} `json:"change"`
	} `json:"resource_drift"`
	OutputChanges map[string]struct {
		Actions []string `json:"actions"`
	} `json:"output_changes"`
}

var indexRe = regexp.MustCompile(`\[[^\]]*\]`)

// baseAddress retire les index : aws_subnet.public[0] -> aws_subnet.public ; module.x.aws_y.z -> module.x
func baseAddress(addr string) string {
	a := indexRe.ReplaceAllString(addr, "")
	if strings.HasPrefix(a, "module.") {
		parts := strings.SplitN(a, ".", 3)
		return parts[0] + "." + parts[1]
	}
	return a
}

// ParsePlanSummary construit le résumé depuis `terraform show -json`.
func ParsePlanSummary(raw []byte, idx map[string]string) (*PlanSummary, error) {
	var ps planShow
	if err := json.Unmarshal(raw, &ps); err != nil {
		return nil, err
	}
	s := &PlanSummary{Changes: []ChangeItem{}, Drift: []ChangeItem{}, Outputs: []string{}, ByNode: map[string]string{}}
	rank := map[string]int{"read": 0, "update": 1, "create": 2, "replace": 3, "delete": 4}
	for _, rc := range ps.ResourceChanges {
		if rc.Mode == "data" {
			continue
		}
		acts := rc.Change.Actions
		action := ""
		switch {
		case len(acts) == 2:
			s.Replace++
			action = "replace"
		case len(acts) == 1 && acts[0] == "create":
			s.Add++
			action = "create"
		case len(acts) == 1 && acts[0] == "update":
			s.Change++
			action = "update"
		case len(acts) == 1 && acts[0] == "delete":
			s.Destroy++
			action = "delete"
		}
		if len(rc.Change.Importing) > 0 && string(rc.Change.Importing) != "null" {
			s.Import++
		}
		if action == "" {
			continue
		}
		item := ChangeItem{Address: rc.Address, Type: rc.Type, Actions: acts, NodeID: idx[baseAddress(rc.Address)]}
		s.Changes = append(s.Changes, item)
		if item.NodeID != "" && rank[action] >= rank[s.ByNode[item.NodeID]] {
			s.ByNode[item.NodeID] = action
		}
	}
	for _, d := range ps.ResourceDrift {
		s.Drift = append(s.Drift, ChangeItem{Address: d.Address, Type: d.Type, Actions: d.Change.Actions, NodeID: idx[baseAddress(d.Address)]})
	}
	for name, oc := range ps.OutputChanges {
		if len(oc.Actions) > 0 && oc.Actions[0] != "no-op" {
			s.Outputs = append(s.Outputs, name)
		}
	}
	return s, nil
}

func (d *Dispatcher) artifactDir(runID string) string {
	return filepath.Join(d.core.Cfg.DataDir, "artifacts", runID)
}

// modelAtVersion renvoie le modèle tel qu'il était lors de la création du run.
func (d *Dispatcher) modelAtVersion(ctx context.Context, proj *core.Project, version int) *model.Project {
	var raw []byte
	if err := d.core.DB.QueryRow(ctx, `SELECT model FROM project_versions WHERE project_id=$1 AND version=$2`, proj.ID, version).Scan(&raw); err == nil {
		var m model.Project
		if json.Unmarshal(raw, &m) == nil {
			return &m
		}
	}
	return &proj.Model
}

// LoadPolicies renvoie les règles actives applicables à un projet.
func LoadPolicies(ctx context.Context, c *core.Core, projectID string) ([]policy.Policy, error) {
	rows, err := c.DB.Query(ctx, `SELECT id, name, kind, severity, enabled, params FROM policies WHERE enabled AND (project_id IS NULL OR project_id=$1)`, projectID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var out []policy.Policy
	for rows.Next() {
		var p policy.Policy
		if err := rows.Scan(&p.ID, &p.Name, &p.Kind, &p.Severity, &p.Enabled, &p.Params); err != nil {
			return nil, err
		}
		out = append(out, p)
	}
	return out, rows.Err()
}

func (d *Dispatcher) evaluatePolicies(ctx context.Context, projectID string, planJSON []byte, m *model.Project) (*policy.Report, error) {
	pols, err := LoadPolicies(ctx, d.core, projectID)
	if err != nil || len(pols) == 0 {
		return nil, err
	}
	inst, err := policy.FromPlan(planJSON, m)
	if err != nil {
		return nil, err
	}
	rep := policy.Evaluate(pols, inst, m.Providers)
	return &rep, nil
}

// nodeAt retrouve le nœud qui couvre une ligne d'un fichier généré.
func nodeAt(snap *core.Snapshot, file string, line int) string {
	for _, r := range snap.Ranges {
		if r.File == file && line >= r.Start && line <= r.End {
			return r.NodeID
		}
	}
	return ""
}

func parallelism(n int, rs settings.Runs) string {
	if n <= 0 {
		n = rs.Parallelism
	}
	if n <= 0 {
		n = 10
	}
	return "-parallelism=" + strconv.Itoa(n)
}
