// Package runner répartit le travail entre les workers (agents) : réservation des runs,
// préparation de tout ce qu'il faut pour les exécuter, puis traitement du résultat
// (résumé, conformité, artefacts chiffrés, state, notifications, suites).
// L'exécution elle-même (terraform) a lieu sur le worker : voir internal/agent.
package runner

import (
	"context"
	"encoding/json"
	"fmt"
	"log/slog"
	"os"
	"path/filepath"
	"time"

	"github.com/AZIZI-Sajjad/hcldesigner/internal/agent"
	"github.com/AZIZI-Sajjad/hcldesigner/internal/core"
	"github.com/AZIZI-Sajjad/hcldesigner/internal/hclgen"
	"github.com/AZIZI-Sajjad/hcldesigner/internal/settings"
)

type Dispatcher struct {
	core *core.Core
}

func New(c *core.Core) *Dispatcher {
	for _, d := range []string{"logs", "artifacts"} {
		_ = os.MkdirAll(filepath.Join(c.Cfg.DataDir, d), 0o700)
	}
	return &Dispatcher{core: c}
}

// Claim attribue au worker un job compatible : d'abord les résolutions de providers (rapides,
// elles débloquent l'éditeur), puis le plus ancien run en file dont l'environnement est libre
// et dont les labels exigés sont portés par le worker.
func (d *Dispatcher) Claim(ctx context.Context, w *core.Worker) (*agent.Claim, error) {
	if w.State != "active" {
		return nil, nil
	}
	var running int
	_ = d.core.DB.QueryRow(ctx, `SELECT count(*) FROM runs WHERE worker_id=$1 AND status='running'`, w.ID).Scan(&running)
	if running >= w.Slots {
		return nil, nil
	}
	if sj, err := d.claimSchema(ctx, w); err != nil || sj != nil {
		return sj, err
	}
	for attempt := 0; attempt < 5; attempt++ {
		runID, err := d.reserveRun(ctx, w)
		if err != nil || runID == "" {
			return nil, err
		}
		job, err := d.buildJob(ctx, runID)
		if err == nil {
			return &agent.Claim{Kind: "run", Run: job}, nil
		}
		// Préparation impossible (credential supprimé, state illisible…) : échec explicite, run suivant.
		slog.Error("préparation du run", "id", runID, "err", err)
		d.appendLog(runID, []byte(fmt.Sprintf("\n\x1b[31m[hcldesigner] préparation impossible : %s\x1b[0m\n", err)))
		if run, gerr := d.core.GetRun(ctx, runID); gerr == nil {
			d.finish(ctx, run, outcome{status: core.StatusFailed, exitCode: -1, errMsg: err.Error()})
		}
	}
	return nil, nil
}

// reserveRun passe un run de "queued" à "running" pour ce worker. Le verrou consultatif de
// transaction sérialise les réservations sur un même environnement : jamais deux runs à la fois.
func (d *Dispatcher) reserveRun(ctx context.Context, w *core.Worker) (string, error) {
	rows, err := d.core.DB.Query(ctx, `SELECT r.id, r.environment_id FROM runs r JOIN environments e ON e.id=r.environment_id
		WHERE r.status='queued' AND e.worker_labels <@ $1::text[]
		AND NOT EXISTS (SELECT 1 FROM runs x WHERE x.environment_id=r.environment_id AND x.status='running')
		ORDER BY r.created_at LIMIT 10`, w.Labels)
	if err != nil {
		return "", err
	}
	type cand struct{ id, env string }
	var cands []cand
	for rows.Next() {
		var c cand
		if rows.Scan(&c.id, &c.env) == nil {
			cands = append(cands, c)
		}
	}
	rows.Close()
	for _, c := range cands {
		ok, err := d.tryReserve(ctx, w, c.id, c.env)
		if err != nil {
			return "", err
		}
		if ok {
			return c.id, nil
		}
	}
	return "", nil
}

func (d *Dispatcher) tryReserve(ctx context.Context, w *core.Worker, runID, envID string) (bool, error) {
	tx, err := d.core.DB.Begin(ctx)
	if err != nil {
		return false, err
	}
	defer tx.Rollback(ctx)
	if _, err := tx.Exec(ctx, `SELECT pg_advisory_xact_lock(hashtext($1))`, envID); err != nil {
		return false, err
	}
	var busy bool
	if err := tx.QueryRow(ctx, `SELECT EXISTS(SELECT 1 FROM runs WHERE environment_id=$1 AND status='running')`, envID).Scan(&busy); err != nil || busy {
		return false, err
	}
	tag, err := tx.Exec(ctx, `UPDATE runs SET status='running', started_at=now(), last_seen_at=now(), worker=$2, worker_id=$3
		WHERE id=$1 AND status='queued'`, runID, w.Name, w.ID)
	if err != nil || tag.RowsAffected() != 1 {
		return false, err
	}
	return true, tx.Commit(ctx)
}

func (d *Dispatcher) claimSchema(ctx context.Context, w *core.Worker) (*agent.Claim, error) {
	var sj agent.SchemaJob
	err := d.core.DB.QueryRow(ctx, `UPDATE schema_jobs SET status='running', worker_id=$1, started_at=now() WHERE id = (
		SELECT id FROM schema_jobs WHERE status='queued' ORDER BY created_at FOR UPDATE SKIP LOCKED LIMIT 1)
		RETURNING id, engine, engine_version, local_name, source, constraint_`, w.ID).
		Scan(&sj.ID, &sj.Engine, &sj.EngineVersion, &sj.LocalName, &sj.Source, &sj.Constraint)
	if err != nil {
		return nil, nil // aucun job en attente
	}
	_ = d.core.Settings.Get(ctx, settings.KeyMirror, &sj.Mirror)
	return &agent.Claim{Kind: "schema", Schema: &sj}, nil
}

// buildJob rassemble tout ce dont le worker a besoin : fichiers figés à la création du run,
// credentials déchiffrés, configuration du backend, state interne, plan à appliquer.
func (d *Dispatcher) buildJob(ctx context.Context, runID string) (*agent.Job, error) {
	c := d.core
	run, err := c.GetRun(ctx, runID)
	if err != nil {
		return nil, err
	}
	proj, err := c.GetProject(ctx, run.ProjectID)
	if err != nil {
		return nil, err
	}
	env, err := c.GetEnvironment(ctx, run.EnvironmentID)
	if err != nil {
		return nil, err
	}
	env = run.Options.Backend.ApplyTo(env) // backend tel qu'il était à la création du run
	snap, err := c.RunSnapshot(ctx, run.ID)
	if err != nil {
		return nil, err
	}
	rs := c.Settings.Runs(ctx)
	timeout := time.Duration(rs.TimeoutMinutes) * time.Minute
	if timeout <= 0 {
		timeout = c.Cfg.RunTimeout
	}
	j := &agent.Job{
		RunID: run.ID, Title: fmt.Sprintf("run %s — %s sur %s/%s", run.ID, opLabel(run), run.ProjectName, run.EnvironmentName),
		Engine: proj.Model.Engine, EngineVersion: proj.Model.EngineVersion, Files: map[string]string{},
		Operation: run.Operation, TimeoutSec: int(timeout.Seconds()),
	}
	_ = c.Settings.Get(ctx, settings.KeyMirror, &j.Mirror)
	for name, content := range snap.Files {
		j.Files[name] = content
	}
	if proj.LockFile != "" {
		j.Files[".terraform.lock.hcl"] = proj.LockFile
	}
	if env.TFVars != "" {
		j.Files["terraform.tfvars"] = env.TFVars
	}
	if j.Env, j.CredFiles, j.Secrets, err = c.CredentialMaterial(ctx, env.CredentialIDs); err != nil {
		return nil, err
	}
	if env.Workspace != "" {
		j.Env = append(j.Env, "TF_WORKSPACE="+env.Workspace)
	}

	j.InitArgs = []string{"init", "-input=false", "-no-color"}
	be, err := c.BackendFor(ctx, env, true)
	if err != nil {
		return nil, err
	}
	j.Internal = be == nil
	if !j.Internal {
		content, err := hclgen.BackendConfigFile(be)
		if err != nil {
			return nil, err
		}
		j.Files["backend.hcl"] = content
		j.InitArgs = append(j.InitArgs, "-backend-config=backend.hcl")
		for _, v := range be.Config {
			var s string
			if json.Unmarshal(v, &s) == nil {
				j.Secrets = append(j.Secrets, s)
			}
		}
	} else if j.InternalState, err = c.LatestState(ctx, env.ID); err != nil {
		return nil, err
	}
	if run.Options.Upgrade {
		j.InitArgs = append(j.InitArgs, "-upgrade")
	}
	if run.Options.Reconfigure {
		j.InitArgs = append(j.InitArgs, "-reconfigure")
	}
	if run.Options.MigrateState {
		j.InitArgs = append(j.InitArgs, "-migrate-state", "-force-copy")
	}
	if run.Operation == core.OpValidate {
		j.InitArgs = []string{"init", "-input=false", "-no-color", "-backend=false"}
	}

	switch run.Operation {
	case core.OpPlan:
		args := []string{"plan", "-input=false", "-no-color", "-out=plan.tfplan", "-detailed-exitcode", "-lock-timeout=120s"}
		if run.Destroy {
			args = append(args, "-destroy")
		}
		if run.Options.RefreshOnly {
			args = append(args, "-refresh-only")
		}
		for _, t := range run.Options.Targets {
			args = append(args, "-target="+t)
		}
		for _, r := range run.Options.Replace {
			args = append(args, "-replace="+r)
		}
		j.Plan = &agent.PlanJob{Args: append(args, parallelism(run.Options.Parallelism, rs))}
	case core.OpApply:
		if run.PlanRunID == nil {
			return nil, fmt.Errorf("apply sans plan")
		}
		plan, err := c.GetRun(ctx, *run.PlanRunID)
		if err != nil {
			return nil, err
		}
		bin, err := c.Vault.ReadFile(filepath.Join(d.artifactDir(plan.ID), "plan.tfplan.enc"))
		if err != nil {
			return nil, fmt.Errorf("fichier de plan introuvable : %w", err)
		}
		j.Apply = &agent.ApplyJob{PlanFile: bin, ExpectSerial: plan.StateSerial, ExpectLineage: plan.StateLineage,
			Args: []string{"apply", "-input=false", "-no-color", "-lock-timeout=120s", parallelism(run.Options.Parallelism, rs), "plan.tfplan"}}
		j.ArchiveState = true
	case core.OpState:
		sj, err := d.stateJob(ctx, run)
		if err != nil {
			return nil, err
		}
		j.State = sj
		j.ArchiveState = mutatingState(run.Options.StateCmd)
	}
	return j, nil
}

// stateJob traduit une opération de state en commande terraform.
func (d *Dispatcher) stateJob(ctx context.Context, run *core.Run) (*agent.StateJob, error) {
	o := run.Options
	sj := &agent.StateJob{Cmd: o.StateCmd, Backup: mutatingState(o.StateCmd) && o.StateCmd != "push"}
	switch o.StateCmd {
	case "list":
		sj.Args = append([]string{"state", "list"}, o.StateArgs...)
	case "show":
		sj.Args = []string{"state", "show", "-no-color", o.StateArgs[0]}
	case "mv":
		sj.Args = []string{"state", "mv", "-lock-timeout=120s", o.StateArgs[0], o.StateArgs[1]}
	case "rm":
		sj.Args = append([]string{"state", "rm", "-lock-timeout=120s"}, o.StateArgs...)
	case "import":
		sj.Args = []string{"import", "-input=false", "-no-color", "-lock-timeout=120s", o.StateArgs[0], o.StateArgs[1]}
	case "unlock":
		sj.Args = []string{"force-unlock", "-force", o.StateArgs[0]}
	case "pull":
	case "push":
		// Migration de backend : on pousse la sauvegarde faite par le run "pull" qui précède immédiatement.
		var prevOK bool
		_ = d.core.DB.QueryRow(ctx, `SELECT operation='state' AND options->>'stateCmd'='pull' AND status='succeeded' FROM runs
			WHERE environment_id=$1 AND created_at < $2 ORDER BY created_at DESC LIMIT 1`, run.EnvironmentID, run.CreatedAt).Scan(&prevOK)
		if !prevOK {
			return nil, fmt.Errorf("la sauvegarde (state pull) préalable à la migration n'a pas réussi : push annulé")
		}
		raw, err := d.core.LatestState(ctx, run.EnvironmentID)
		if err != nil || raw == nil {
			return nil, fmt.Errorf("aucune version de state archivée à pousser")
		}
		sj.PushState = raw
		sj.Args = []string{"state", "push", "-lock-timeout=120s", "migrate.tfstate"}
	default:
		return nil, fmt.Errorf("commande de state inconnue %q", o.StateCmd)
	}
	return sj, nil
}

// AppendLog ajoute un morceau de log et indique si l'annulation du run est demandée.
// Un worker ne peut écrire que dans les runs qui lui sont attribués.
func (d *Dispatcher) AppendLog(ctx context.Context, w *core.Worker, runID string, chunk []byte) (bool, error) {
	var cancel bool
	err := d.core.DB.QueryRow(ctx, `UPDATE runs SET last_seen_at=now() WHERE id=$1 AND worker_id=$2 AND status='running'
		RETURNING cancel_requested`, runID, w.ID).Scan(&cancel)
	if err != nil {
		return true, fmt.Errorf("run %s non attribué à ce worker", runID)
	}
	if len(chunk) > 0 {
		d.appendLog(runID, chunk)
	}
	return cancel, nil
}

func (d *Dispatcher) appendLog(runID string, chunk []byte) {
	f, err := os.OpenFile(filepath.Join(d.core.Cfg.DataDir, "logs", runID+".log"), os.O_CREATE|os.O_WRONLY|os.O_APPEND, 0o600)
	if err != nil {
		slog.Error("log du run", "id", runID, "err", err)
		return
	}
	defer f.Close()
	_, _ = f.Write(chunk)
}

// CancelRequested renvoie les runs du worker dont l'annulation a été demandée.
func (d *Dispatcher) CancelRequested(ctx context.Context, w *core.Worker) []string {
	rows, err := d.core.DB.Query(ctx, `SELECT id FROM runs WHERE worker_id=$1 AND status='running' AND cancel_requested`, w.ID)
	if err != nil {
		return []string{}
	}
	defer rows.Close()
	ids := []string{}
	for rows.Next() {
		var id string
		if rows.Scan(&id) == nil {
			ids = append(ids, id)
		}
	}
	return ids
}

// CompleteSchema enregistre le schéma résolu par un worker.
func (d *Dispatcher) CompleteSchema(ctx context.Context, w *core.Worker, id string, res *agent.SchemaResult) error {
	var owner *string
	if err := d.core.DB.QueryRow(ctx, `SELECT worker_id FROM schema_jobs WHERE id=$1 AND status='running'`, id).Scan(&owner); err != nil || owner == nil || *owner != w.ID {
		return fmt.Errorf("résolution %s non attribuée à ce worker", id)
	}
	fail := func(msg string) error {
		_, err := d.core.DB.Exec(ctx, `UPDATE schema_jobs SET status='failed', error=$2, finished_at=now() WHERE id=$1`, id, msg)
		return err
	}
	if res.Error != "" {
		slog.Error("résolution de provider", "id", id, "err", res.Error)
		return fail(res.Error)
	}
	fr, err := decodeSchemaResult(res)
	if err != nil {
		return fail(err.Error())
	}
	if err := d.core.StoreSchema(ctx, fr); err != nil {
		return fail(err.Error())
	}
	_, err = d.core.DB.Exec(ctx, `UPDATE schema_jobs SET status='succeeded', version=$2, finished_at=now() WHERE id=$1`, id, fr.Version)
	slog.Info("provider résolu", "source", fr.Source, "version", fr.Version, "worker", w.Name)
	return err
}
