# HCLDesigner

Application web de conception Terraform / OpenTofu sur un canvas. On place des ressources, on les relie, on génère le code HCL (un seul fichier ou plusieurs), et on exécute init, plan, apply et destroy avec approbations, gestion du state, planification, notifications et contrôle d'accès par rôles.

## Fonctionnalités

| Domaine | Contenu |
|---|---|
| Cadres | VPC, subnet, resource group, VNet, namespace, zone, cluster vSphere… affichés comme des cadres qui contiennent d'autres objets ; glisser un objet dans un cadre l'y range et crée la référence (`subnet_id`, `vpc_id`, `resource_group_name`…) ; redimensionnement, repli, rangement automatique à l'import |
| Canvas | Catalogue de tous les providers résolus (schéma lu depuis `terraform providers schema -json`), glisser-déposer, liaisons guidées par règles YAML et inférence, arguments obligatoires et valeurs par défaut affichés à la liaison, contrôle de cycles, annuler/rétablir, mise en page automatique (ELK), groupes, recherche |
| Code | Génération déterministe ; découpages `single`, `standard`, `category`, `service` (ec2.tf, s3.tf…) ou `custom` (fichier par nœud + règles glob) ; aperçu Monaco en direct, synchronisé avec le canvas ; blocs `import` et `moved` ; export zip |
| Import | Code Terraform existant (fichiers `.tf` ou archive `.zip` du dépôt) converti en objets et liens sur le canvas, fichiers d'origine conservés, rapport des éléments non repris ; modèle HCLDesigner exporté (JSON) |
| Modules | Modules internes (versions semver, interface variables/outputs, diff d'interface), extraction d'une sélection en module, modules du registry, Git et locaux |
| Exécution | init, validate, plan, apply du plan sauvegardé, destroy ; logs en direct (WebSocket), secrets masqués, annulation ; plans chiffrés avec date d'expiration |
| Workers | Agents d'exécution sans accès à la base ; worker par défaut inclus ; ajout sur toute machine Linux par une commande générée ; pause, reprise, révocation, suppression, slots, labels (un environnement peut exiger un label : réseau d'un site, vSphere joignable…) |
| Git | Connexions personnelles GitHub / GitLab / Gitea (SaaS ou auto-hébergé, CA interne) ; import d'un projet depuis un dépôt (sous-dossier compris) ; push du code généré en commit direct ou nouvelle branche + pull/merge request ; mise à jour depuis Git |
| Environnements | Variables, credentials, backend, fenêtres de modification, protection (approbations obligatoires, destroy interdit), auto-apply |
| State | Backends `internal` (chiffré, versionné), s3, azurerm, gcs, http, gitlab, pg, consul, kubernetes, oss, cos, remote ; explorateur (list/show/mv/rm/import/unlock), versions, migration entre backends. `.terraform.lock.hcl` reste avec le code (export, Git) et n'est pas envoyé dans le backend. |
| Conformité | Tags obligatoires, valeurs autorisées, nommage, ingress ouvert interdit, régions autorisées, version minimale de provider ; évaluée sur le modèle et sur le plan ; mode bloquant |
| Planification | Drift, plan (+ auto-apply), apply d'un plan, destroy d'environnement éphémère, montée de versions, sauvegarde du state, scan de conformité, rapport ; cron, fuseau horaire, reprises, historique |
| Notifications | Mail SMTP (starttls/tls), webhooks génériques / Teams / Slack, modèles éditables, règles par événement et périmètre, digests |
| Administration | Utilisateurs, équipes, MFA TOTP, jetons d'API, rôles prédéfinis et personnalisés (matrice de permissions, portée globale/projet/environnement), credentials, catalogue des providers, paramètres, audit immuable |
| Tableaux | Colonnes déplaçables par glisser-déposer, redimensionnement manuel, épinglage, masquage, filtres multichoix, recherche globale, vues enregistrées, préférences persistées par utilisateur, export CSV/HTML |
| Tableau de bord | Runs par statut et par jour, drift, conformité, projets les plus modifiés |

## Démarrage rapide (Docker)

Procédure courte (installation, mise à jour, ajout de workers, désinstallation) : voir [INSTALL.md](INSTALL.md). Nouveautés : [RELEASE_NOTES.md](RELEASE_NOTES.md).

Prérequis : Debian/Ubuntu en root. Le script installe Docker si besoin, crée le `.env`, construit et démarre :

```bash
unzip hcldesigner.zip && cd hcldesigner
sudo ./install.sh            # installation, ou mise à jour (le .env est conservé)
sudo ./install.sh --reset    # repartir de zéro (supprime les données)
```

Installation manuelle (Docker 24+ et Compose v2) :

```bash
cp .env.example .env
# Clé maître (32 octets en base64). À sauvegarder hors du serveur :
# sans elle, credentials, states internes et plans sont illisibles.
sed -i "s|^HCLD_MASTER_KEY=.*|HCLD_MASTER_KEY=$(openssl rand -base64 32)|" .env
# Mot de passe du compte admin initial et mot de passe PostgreSQL
vi .env

docker compose up -d --build
docker compose logs -f api
```

Interface : `http://<hôte>:8080`, compte `admin` avec le mot de passe `HCLD_ADMIN_PASSWORD`. Le compte n'est créé qu'au premier démarrage.

Services lancés :

| Service | Commande | Rôle |
|---|---|---|
| `postgres` | — | Données, file des runs, verrous |
| `api` | `hcldesigner api` | REST + WebSocket ; applique les migrations au démarrage |
| `worker` | `hcldesigner agent` | Worker par défaut : exécute Terraform/OpenTofu, sans accès à la base (limites CPU/mémoire dans le compose) |
| `scheduler` | `hcldesigner scheduler` | Tâches planifiées, envoi des notifications, rétention |
| `frontend` | nginx | Fichiers statiques + proxy `/api` |

Plus de runs en parallèle : augmenter les slots du worker (Administration → Workers) ou ajouter des workers (voir « Workers »). Deux runs sur un même environnement ne tournent jamais en même temps (verrou PostgreSQL par environnement).

### Variables principales

| Variable | Défaut | Rôle |
|---|---|---|
| `HCLD_DATABASE_URL` | défini par le compose | DSN PostgreSQL |
| `HCLD_MASTER_KEY` | — | Clé AES-256 en base64 (obligatoire) |
| `HCLD_ADMIN_USER` / `HCLD_ADMIN_PASSWORD` / `HCLD_ADMIN_EMAIL` | `admin` / — / — | Compte super admin créé au premier démarrage |
| `HCLD_DATA_DIR` | `/data` | Logs, plans, states internes, cache des providers |
| `HCLD_LISTEN` | `:8000` | Adresse d'écoute de l'API |
| `HCLD_BASE_URL` | — | URL publique utilisée dans les liens des mails |
| `HCLD_SECURE_COOKIES` | `false` | Passer à `true` derrière HTTPS |
| `HCLD_TRUST_PROXY` | `true` | Lire l'IP client dans `X-Forwarded-For` (limitation de débit, audit) |
| `HCLD_SESSION_TTL` | `12h` | Durée de vie des sessions |
| `HCLD_WORKER_CONCURRENCY` | `2` | Slots du worker par défaut à sa création (modifiables ensuite dans Workers) |
| `HCLD_RUN_TIMEOUT` | `2h` | Durée maximale d'un run |
| `TERRAFORM_BIN` / `TOFU_BIN` | préinstallés dans l'image | Binaires utilisés pour leur version ; les autres versions sont téléchargées et vérifiées (SHA256SUMS) |
| `HCLD_TERRAFORM_URL` / `HCLD_TOFU_URL` | dépôts officiels | Dépôt interne des binaires (`{v}`, `{os}`, `{arch}` remplacés) |
| `HCLD_REGISTRY_URL` | `https://registry.terraform.io` | Registry consulté pour les providers et les modules |
| `HCLD_STATIC_DIR` | — | Sert le frontend compilé depuis l'API (sans nginx) |
| `HTTPS_PROXY` / `NO_PROXY` | — | Proxy sortant, transmis aux exécutions |

Le SMTP, le miroir de providers (filesystem ou réseau), la politique de mots de passe, la MFA obligatoire, la rétention, le blocage de `local-exec` et la durée de validité des plans se règlent dans **Administration → Paramètres**.

Variables du worker (`hcldesigner agent`) : `HCLD_SERVER_URL` (URL de l'API), `HCLD_DATA_DIR`, `HCLD_AGENT_TOKEN_FILE` (défaut `$HCLD_DATA_DIR/agent.token`), `HCLD_JOIN_TOKEN` (premier démarrage), `HCLD_CA_FILE`, `HCLD_INSECURE_TLS`. Le script d'installation les renseigne.

### Mise en production

- Placer un reverse proxy TLS devant le port 8080, puis définir `HCLD_SECURE_COOKIES=true` et `HCLD_BASE_URL=https://…`.
- Sauvegarder PostgreSQL (`pg_dump`), le volume `tcdata` et `HCLD_MASTER_KEY`, séparément.
- Environnement isolé : renseigner `HCLD_REGISTRY_URL`, `HCLD_TERRAFORM_URL`/`HCLD_TOFU_URL` et le miroir de providers (Paramètres) vers vos dépôts internes.

## Utilisation

1. **Administration → Credentials** : créer les accès cloud (AWS, Azure, GCP, vSphere, VCD, Proxmox, Kubernetes, Cloudflare, OVH, variables libres ou accès backend).
2. **Projets → Nouveau** : choisir Terraform ou OpenTofu et sa version.
3. **Paramètres du projet → Providers** : ajouter les providers (`hashicorp/aws ~> 5.0`…) puis **Résoudre**. Le worker télécharge le provider et importe son schéma, et le catalogue se remplit.
4. **Éditeur** : glisser les ressources depuis le catalogue, relier les poignées. Le panneau de liaison propose l'argument cible, montre les obligatoires et les défauts. Le formulaire de droite liste tous les arguments du schéma (obligatoires en premier, valeurs par défaut affichées).
5. **Code** : choisir le découpage des fichiers dans les paramètres ; cliquer sur un nœud surligne son bloc dans le code.
6. **Environnements** : créer `dev`, `prod`… avec backend, variables, credentials et protection.
7. **Run** depuis l'éditeur : plan, puis approbation si l'environnement l'exige, puis apply.
8. **Planifications** : drift quotidien, destroy des environnements éphémères le soir, etc.
9. **Git** (facultatif) : **Mon compte → Connexions Git**, puis **Paramètres du projet → Dépôt Git** ou **Projets → Importer (Git)**.

### Workers

Un worker exécute les runs et les résolutions de providers. Il réclame ses jobs à l'API avec son propre jeton : aucun accès à PostgreSQL ni à la clé maître. Il reçoit pour chaque run les fichiers, les credentials déchiffrés et le state, et renvoie logs et résultat.

- **Worker par défaut** : conteneur `worker` du compose, enrôlé automatiquement (jeton déposé par l'API dans le volume). Il se gère comme les autres : pause, révocation, suppression, slots, labels. Supprimé, il n'est pas recréé au redémarrage (bouton « Recréer le worker par défaut »).
- **Ajouter un worker** : **Administration → Workers → Ajouter un worker** génère une commande à usage unique (valable 1 h à 7 jours) :

  ```bash
  curl -fsSL https://hcldesigner.example.com/api/agent/install.sh | sudo bash -s -- --url https://hcldesigner.example.com --token hcldj_…
  ```

  Sur la machine (Debian, Ubuntu, RHEL, Rocky… avec systemd), le script installe curl et git si besoin, télécharge le binaire depuis HCLDesigner et vérifie son SHA-256, crée l'utilisateur système `hcld-agent` et le service durci `hcldesigner-agent`, puis enrôle le worker. Variante Docker proposée pour l'hôte HCLDesigner. Options : `--ca-file` (CA interne), `--insecure`, `--uninstall`.
- **Cycle de vie** :

  | Action | Effet |
  |---|---|
  | Pause | Plus de nouveaux jobs ; les runs en cours se terminent |
  | Reprise | Le worker reprend des jobs |
  | Révocation | Jeton refusé immédiatement, runs en cours marqués en échec ; réactivation par réenrôlement (nouvelle commande) |
  | Réenrôler | Nouvelle commande pour la même identité (machine réinstallée, jeton compromis) |
  | Renouveler le jeton | Worker par défaut : nouveau jeton relu automatiquement |
  | Slots / labels | Appliqués au signal de vie suivant (15 s) |
  | Suppression | Possible sans run en cours ; désinstaller ensuite l'agent sur la machine |

- **Labels** : un environnement qui exige `dc1` n'est exécuté que par un worker portant ce label. Utile quand un vCenter, un VCD ou un Proxmox n'est joignable que depuis un site.
- **Pannes** : un run dont le worker ne donne plus de nouvelles depuis 5 minutes passe en échec. Le worker survit aux redémarrages de l'API et renvoie son résultat dès qu'elle revient.

Logs d'un worker installé : `journalctl -u hcldesigner-agent -f`.

### Git

1. **Mon compte → Connexions Git → Ajouter** : fournisseur (GitHub, GitLab, Gitea / Forgejo), URL pour un serveur auto-hébergé, jeton d'accès personnel, auteur des commits, CA interne au besoin. La connexion est testée à l'enregistrement. Chaque utilisateur a ses propres connexions et pousse sous sa propre identité.
2. **Importer un projet** : **Projets → Importer (Git)** → connexion, dépôt, branche, dossier du code Terraform (les dossiers contenant des `.tf` sont proposés). Le projet créé reste lié au dépôt.
3. **Lier un projet existant** : **Paramètres du projet → Dépôt Git → Lier à un dépôt** (dossier existant ou nouveau).
4. **Pousser le code** : nouvelle branche + pull/merge request (recommandé) ou commit direct. Seuls les `.tf` du dossier lié sont remplacés (un `.tf` absent du modèle est supprimé) ; le reste du dépôt n'est pas touché. Le `.terraform.lock.hcl` du projet est poussé avec le code.
5. **Mettre à jour depuis Git** : le code du dépôt remplace le modèle dans une nouvelle version (versions précédentes restaurables).

Permissions : `git.link` (lier, mettre à jour), `git.push` (pousser), `admin.workers` (workers).

### Cadres (imbrication)

Certains types s'affichent comme des cadres : `aws_vpc`, `aws_subnet`, `azurerm_resource_group`, `azurerm_virtual_network`, `azurerm_subnet`, `google_compute_network`, `google_compute_subnetwork`, `kubernetes_namespace`, `cloudflare_zone`, réseaux et cluster OVH, pool Proxmox, edge gateway / réseau / vApp VCD, datacenter / cluster / resource pool / dossier vSphere.

- Glisser un objet dans un cadre (depuis le catalogue ou le canvas) l'y range. Si une règle de connexion existe, la référence est créée (instance dans un subnet : `subnet_id = aws_subnet.x.id`) ; un argument déjà renseigné n'est jamais écrasé.
- Le cadre le plus profond l'emporte : une instance lâchée dans un subnet lui-même dans un VPC va dans le subnet.
- Sortir un objet d'un cadre le remonte à la racine ; la référence reste (à supprimer si besoin dans le panneau de droite).
- Déplacer un cadre déplace son contenu ; poignées de redimensionnement quand le cadre est sélectionné ; chevron pour replier.
- Supprimer un cadre remonte son contenu d'un niveau, à la même place.
- Les liens de contenance (`vpc_id` d'un subnet rangé dans son VPC) ne sont pas dessinés : l'imbrication les montre déjà.
- À l'import de code `.tf`, chaque objet est rangé dans le cadre qu'il référence.
- L'imbrication est purement visuelle : elle ne change pas le code généré.

### Importer un projet Terraform existant

**Projets → Importer (Terraform)** : choisir les fichiers `.tf` du dossier, ou une archive `.zip` du dépôt. Un rapport s'affiche avant la création du projet.

| Repris | Comportement |
|---|---|
| `resource`, `data`, `module`, `variable`, `locals`, `output` | Un objet par bloc, placé en colonnes selon les dépendances |
| Références simples (`aws_vpc.main.id`, `aws_subnet.a[0].id`, `aws_subnet.a[*].id`, `var.x`, `module.m.out`) | Liens éditables sur le canvas |
| Expressions (`"${…}"`, fonctions, conditions) | Conservées telles quelles ; les objets cités sont reliés en pointillés |
| `provider` (alias compris), `required_providers`, `required_version` | Paramètres du projet ; version résolue reprise si le provider est déjà en cache sur l'instance |
| `count`, `for_each`, `provider`, `depends_on`, `lifecycle`, `import`, `moved` | Méta-arguments du nœud |
| Fichiers d'origine | Découpage « fichier par nœud » : chaque ressource reste dans son fichier |

Non repris, et signalé dans le rapport : blocs `dynamic`, provisioners, `check`, `removed`, `backend` / `cloud` (à configurer dans l'environnement), modules à source locale, sous-dossiers d'une archive. Dans une archive, seul le dossier le moins profond contenant des `.tf` est importé. Les fichiers `.tfvars` et `.tf.json` sont ignorés.

Pour reprendre l'infrastructure existante sans la recréer : importer le code, configurer le backend de l'environnement sur le state existant (ou migrer le state), puis lancer un plan, qui doit annoncer « No changes ».

## Développement

Prérequis : Go 1.24, Node 20+, PostgreSQL 16, et Terraform ou OpenTofu dans le `PATH` (ou `TERRAFORM_BIN` / `TOFU_BIN`).

```bash
# Base locale
createdb hcldesigner
export HCLD_DATABASE_URL=postgres://localhost/hcldesigner?sslmode=disable
export HCLD_MASTER_KEY=$(openssl rand -base64 32) HCLD_ADMIN_PASSWORD='Admin-Terra-2026!'
export HCLD_DATA_DIR=/tmp/tcdata

make dev-api     # API + scheduler + worker intégré dans un seul processus (rôle "all"), port 8000
make dev-front   # Vite sur :5173, proxy /api vers :8000
```

Le `go.mod` remplace `golang.org/x/*` et `gopkg.in/yaml.v3` par leurs miroirs GitHub (le réseau de développement bloquait les domaines vanity). Si votre réseau y accède, ces `replace` peuvent être supprimés. Sinon, compiler avec :

```bash
GOPROXY=direct GOSUMDB=off go build ./...
```

### Tests

```bash
make test                      # go vet + go test, tsc + vitest
cd backend && go test ./...    # golden files hclgen, moteur de liaison, conformité, extraction de modules, RBAC
cd frontend && npm test        # vitest
CHROME_PATH=/usr/bin/chromium npm run e2e   # Playwright : liaison sur le canvas, génération, formulaire
./scripts/smoke.sh             # E2E API : providers → génération → validate → plan → apply → state → destroy → export
```

`smoke.sh` attend une instance lancée sur `:8000` (rôle `all` : API, scheduler et worker intégré). `MIRROR_PATH=/chemin/miroir` permet de résoudre les providers hors ligne. Les tests Playwright Git utilisent `FORGE_URL` (forge Gitea de test) et sont ignorés sans cette variable.

Pour régénérer les golden files après une évolution voulue du générateur : `cd backend && go test ./internal/hclgen -update`.

## Arborescence

```
backend/
  cmd/hcldesigner/        point d'entrée : api | agent | scheduler | all | migrate | healthcheck
  internal/
    api/                  routes HTTP par domaine (auth, projets, runs, state, admin…)
    core/                 services partagés : projets, backends, credentials, runs, state
    model/                modèle de projet (nœuds, valeurs, références, cycles)
    schema/               schémas providers, catalogue, lock file
    connection/           moteur de liaison (règles + inférence)
    hclgen/               génération HCL, découpage, backend, modules internes
    modules/              extraction d'une sélection en module
    policy/               règles de conformité (modèle et plan)
    runner/               répartition des jobs aux workers, préparation, traitement des résultats
    agent/                worker : enrôlement, signal de vie, exécution terraform, envoi des logs
    gitprov/              GitHub / GitLab / Gitea : API (dépôts, branches, PR/MR) et opérations git
    scheduler/            cron, notifications, rétention
    notify/ rbac/ auth/ vault/ audit/ settings/ config/ db/ tfbin/
  rules/                  règles de connexion et défauts par provider (YAML embarqués)
frontend/src/
  api/ types/ store/ lib/            client HTTP, types, store de l'éditeur (zustand + immer)
  components/ui, components/table    composants de base, DataTable générique
  pages/editor/                      canvas, catalogue, propriétés, liaison, code, runs
  pages/project/ runs/ modules/ admin/
docs/
  architecture.md         composants, modèle de données, séquences, sécurité, écarts
  regles-connexion.md     ajouter des règles de liaison et des défauts
  openapi.yaml            166 routes
scripts/smoke.sh
docker-compose.yml  .env.example  install.sh  INSTALL.md  RELEASE_NOTES.md  Makefile  .gitlab-ci.yml
```

Détails dans [docs/architecture.md](docs/architecture.md).

## Rôles prédéfinis

| Rôle | Droits |
|---|---|
| Super admin | Tout (`*`) |
| Admin | Tout sauf la gestion des super admins |
| Concepteur | Projets et modules en écriture, plan, lecture des runs |
| Opérateur | Plan, apply, opérations de state, lecture des projets |
| Approbateur | Lecture, approbation des plans (ne peut pas approuver ses propres runs) |
| Lecteur | Lecture seule |

Les rôles personnalisés se créent dans **Administration → Rôles** (matrice domaine × action) et s'attribuent à un utilisateur ou une équipe, globalement ou sur un projet ou un environnement.

## Limites et écarts

Écarts d'architecture au cahier des charges (justifiés dans `docs/architecture.md` §5) :

- File de jobs PostgreSQL au lieu de Redis, volume partagé au lieu de MinIO.
- Runs exécutés en sous-processus isolé sur le worker (agent sans accès à la base), et non dans un conteneur par run (cela évite d'exposer le socket Docker).
- Providers et alias configurés dans les paramètres du projet, et non comme nœuds du canvas.
- Formulaires générés depuis les schémas, sans react-hook-form/zod ; composants UI maison au lieu de shadcn/ui.

Non implémenté (phase 2) :

- Import d'un `.tfstate` vers le canvas (l'import de code `.tf` est fait, voir ci-dessous)
- Intégration OPA, checkov, tfsec, Infracost
- LDAP / OIDC / SAML (comptes locaux + MFA uniquement)
- Édition collaborative temps réel (un verrou optimiste protège des écrasements)
- Assistant IA, bibliothèque de modèles de projets, chart Helm

Non vérifié dans l'environnement de développement : `docker compose up` et le script d'installation d'un worker sur une machine systemd (aucun démon Docker ni systemd disponible). Testés : binaire, migrations, enrôlement et cycle de vie des workers (worker intégré et worker distant lancé depuis le binaire téléchargé), smoke E2E avec OpenTofu, parcours Git contre une forge Gitea de test, tests Go, vitest, Playwright.

## Marques

Terraform est une marque déposée de HashiCorp, Inc. OpenTofu est une marque de la Linux Foundation. HCLDesigner est un projet indépendant, sans lien avec HashiCorp ni la Linux Foundation, et n'est ni approuvé ni soutenu par eux.
